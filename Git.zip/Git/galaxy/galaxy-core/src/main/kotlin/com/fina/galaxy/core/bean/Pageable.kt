package com.fina.galaxy.core.bean

open class Pageable(
    var size: Int? = 15,
    var skip: Int? = 0
)