package com.fina.galaxy.core.utils

/**
 * 分割驼峰字段
 * @param name
 * @param separator
 * @return
 */
private fun separateCamelCase(name: String, separator: String): String {
    val translation = StringBuilder()
    for (i in 0 until name.length) {
        val character = name[i]
        if (Character.isUpperCase(character) && translation.isNotEmpty()) {
            translation.append(separator)
        }
        translation.append(character)
    }
    return translation.toString()
}

/**
 * 下划线转换为驼峰
 */
fun underscore2CamelCase(name: String): String {
    val translation = StringBuilder()
    for (i in 0 until name.length) {
        val character = name[i]
        if (character == '_')
            continue
        if (translation.isNotEmpty() && name[i - 1] == '_') {
            translation.append(Character.toUpperCase(character))
        } else {
            translation.append(character)
        }
    }
    return translation.toString()
}

/**
 * 驼峰转换为下划线
 * @param name
 * @return
 */
fun camelCase2Underscore(name: String): String {
    return separateCamelCase(name, "_").toLowerCase()
}

/**
 * 首字母大写
 * @param name
 * @return
 */
fun upperCaseFirstLetter(name: String): String {
    val fieldNameBuilder = StringBuilder()
    var index = 0
    var firstCharacter = name[index]
    while (index < name.length - 1) {
        if (Character.isLetter(firstCharacter)) {
            break
        }

        fieldNameBuilder.append(firstCharacter)
        firstCharacter = name[++index]
    }

    if (index == name.length) {
        return fieldNameBuilder.toString()
    }

    if (!Character.isUpperCase(firstCharacter)) {
        val modifiedTarget = modifyString(Character.toUpperCase(firstCharacter), name, ++index)
        return fieldNameBuilder.append(modifiedTarget).toString()
    } else {
        return name
    }
}

/**
 * 首字母小写
 * @param name
 * @return
 */
fun lowerCaseFirstLetter(name: String): String {
    val fieldNameBuilder = StringBuilder()
    var index = 0
    var firstCharacter = name[index]
    while (index < name.length - 1) {
        if (Character.isLetter(firstCharacter)) {
            break
        }

        fieldNameBuilder.append(firstCharacter)
        firstCharacter = name[++index]
    }

    if (index == name.length) {
        return fieldNameBuilder.toString()
    }

    return if (!Character.isLowerCase(firstCharacter)) {
        val modifiedTarget = modifyString(Character.toLowerCase(firstCharacter), name, ++index)
        fieldNameBuilder.append(modifiedTarget).toString()
    } else {
        name
    }
}

/**
 * 修改字符串
 * @param firstCharacter
 * @param srcString
 * @param indexOfSubstring
 * @return
 */
private fun modifyString(firstCharacter: Char, srcString: String, indexOfSubstring: Int): String {
    return if (indexOfSubstring < srcString.length)
        firstCharacter + srcString.substring(indexOfSubstring)
    else
        firstCharacter.toString()
}
