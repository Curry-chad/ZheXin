package com.fina.galaxy.core.utils

import org.springframework.beans.BeanUtils
import org.springframework.beans.BeanWrapperImpl

import java.util.HashSet

object BeanCopyUtil {
    //source中的非空属性复制到target中
    fun <T> beanCopy(source: T, target: T) {
        BeanUtils.copyProperties(source!!, target!!, *getNullPropertyNames(source))
    }

    //source中的非空属性复制到target中，但是忽略指定的属性，也就是说有些属性是不可修改的（个人业务需要）
    fun <T> beanCopyWithIngore(source: T, target: T, vararg ignoreProperties: String) {
        val pns = getNullAndIgnorePropertyNames(source!!, *ignoreProperties)
        BeanUtils.copyProperties(source, target!!, *pns)
    }

    fun getNullAndIgnorePropertyNames(source: Any, vararg ignoreProperties: String): Array<String> {
        val emptyNames = getNullPropertyNameSet(source)
        for (s in ignoreProperties) {
            emptyNames.add(s)
        }
        val result = arrayOfNulls<String>(emptyNames.size)
        return emptyNames.toTypedArray()
    }

    fun getNullPropertyNames(source: Any): Array<String> {
        val emptyNames = getNullPropertyNameSet(source)
        val result = arrayOfNulls<String>(emptyNames.size)
        return emptyNames.toTypedArray()
    }

    fun getNullPropertyNameSet(source: Any): MutableSet<String> {
        val src = BeanWrapperImpl(source)
        val pds = src.propertyDescriptors
        val emptyNames = HashSet<String>()
        for (pd in pds) {
            val srcValue = src.getPropertyValue(pd.name)
            if (srcValue == null) emptyNames.add(pd.name)
        }
        return emptyNames
    }
}