package com.fina.galaxy.core.serialize

import org.slf4j.LoggerFactory

import java.io.*

object SerializeUtils {

    private val logger = LoggerFactory.getLogger(SerializeUtils::class.java)

    private fun close(closeable: Closeable?) {
        if (closeable != null) {
            try {
                closeable.close()
            } catch (e: Exception) {
                logger.info("Unable to close $closeable", e)
            }

        }
    }


    fun serialize(value: Any?): ByteArray? {
        if (value == null) {
            throw NullPointerException("Can't serialize null")
        }
        var result: ByteArray? = null
        var bos: ByteArrayOutputStream? = null
        var os: ObjectOutputStream? = null
        try {
            bos = ByteArrayOutputStream()
            os = ObjectOutputStream(bos)
            os.writeObject(value)
            os.close()
            bos.close()
            result = bos.toByteArray()
        } catch (e: IOException) {
            throw IllegalArgumentException("Non-serializable object", e)
        } finally {
            close(os)
            close(bos)
        }
        return result
    }

    fun <M> deserialize(`in`: ByteArray?): M? {
        var result: M? = null
        var bis: ByteArrayInputStream? = null
        var `is`: ObjectInputStream? = null
        try {
            if (`in` != null) {
                bis = ByteArrayInputStream(`in`)
                `is` = ObjectInputStream(bis)
                result = `is`.readObject() as M
                `is`.close()
                bis.close()
            }
        } catch (e: IOException) {
            logger.error("Caught IOException decoding {} bytes of data", `in`!!.size, e)
        } catch (e: ClassNotFoundException) {
            logger.error("Caught CNFE decoding {} bytes of data", `in`!!.size, e)
        } finally {
            close(`is`)
            close(bis)
        }
        return result
    }
}
