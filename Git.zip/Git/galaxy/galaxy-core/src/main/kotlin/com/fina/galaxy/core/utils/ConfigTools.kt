/*
 * Copyright 1999-2017 Alibaba Group Holding Ltd.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.fina.galaxy.core.utils

import com.alipay.api.internal.util.codec.Base64
import java.security.*
import java.security.interfaces.RSAPrivateKey
import java.security.interfaces.RSAPublicKey
import java.security.spec.PKCS8EncodedKeySpec
import java.security.spec.RSAPrivateKeySpec
import java.security.spec.RSAPublicKeySpec
import java.security.spec.X509EncodedKeySpec
import java.util.*
import javax.crypto.Cipher


object ConfigTools {

    val DEFAULT_PUBLIC_KEY_STRING =
        "MFwwDQYJKoZIhvcNAQEBBQADSwAwSAJBAKHGwq7q2RmwuRgKxBypQHw0mYu4BQZ3eMsTrdK8E6igRcxsobUC7uT0SoxIjl1WveWniCASejoQtn/BY6hVKWsCAwEAAQ=="
    private val DEFAULT_PRIVATE_KEY_STRING =
        "MIIBVAIBADANBgkqhkiG9w0BAQEFAASCAT4wggE6AgEAAkEAocbCrurZGbC5GArEHKlAfDSZi7gFBnd4yxOt0rwTqKBFzGyhtQLu5PRKjEiOXVa95aeIIBJ6OhC2f8FjqFUpawIDAQABAkAPejKaBYHrwUqUEEOe8lpnB6lBAsQIUFnQI/vXU4MV+MhIzW0BLVZCiarIQqUXeOhThVWXKFt8GxCykrrUsQ6BAiEA4vMVxEHBovz1di3aozzFvSMdsjTcYRRo82hS5Ru2/OECIQC2fAPoXixVTVY7bNMeuxCP4954ZkXp7fEPDINCjcQDywIgcc8XLkkPcs3Jxk7uYofaXaPbg39wuJpEmzPIxi3k0OECIGubmdpOnin3HuCP/bbjbJLNNoUdGiEmFL5hDI4UdwAdAiEAtcAwbm08bKN7pwwvyqaCBC//VnEWaq39DCzxr+Z2EIk="

//    @Throws(Exception::class)
//    @JvmStatic
//    fun main(args: Array<String>) {
//        val password = args[0]
//        val arr = genKeyPair(512)
//        println("privateKey:" + arr[0])
//        println("publicKey:" + arr[1])
//        println("password:" + encrypt(arr[0], password))
//    }

    @Throws(Exception::class)
    fun decrypt(cipherText: String): String? {
        return decrypt(null, cipherText)
    }

    @Throws(Exception::class)
    fun decrypt(publicKeyText: String?, cipherText: String): String? {
        val publicKey = getPublicKey(publicKeyText)

        return decrypt(publicKey, cipherText)
    }

    fun getPublicKey(publicKeyText: String?): PublicKey {
        var publicKeyText = publicKeyText
        if (publicKeyText == null || publicKeyText.isEmpty()) {
            publicKeyText = DEFAULT_PUBLIC_KEY_STRING
        }

        try {
            val publicKeyBytes = Base64.decodeBase64(publicKeyText.toByteArray())
            val x509KeySpec = X509EncodedKeySpec(
                publicKeyBytes
            )

            val keyFactory = KeyFactory.getInstance("RSA", "SunRsaSign")
            return keyFactory.generatePublic(x509KeySpec)
        } catch (e: Exception) {
            throw IllegalArgumentException("Failed to get public key", e)
        }

    }


    @Throws(Exception::class)
    fun decrypt(publicKey: PublicKey, cipherText: String?): String? {
        var cipher = Cipher.getInstance("RSA/ECB/PKCS1Padding")
        try {
            cipher.init(Cipher.DECRYPT_MODE, publicKey)
        } catch (e: InvalidKeyException) {
            // 因为 IBM JDK 不支持私钥加密, 公钥解密, 所以要反转公私钥
            // 也就是说对于解密, 可以通过公钥的参数伪造一个私钥对象欺骗 IBM JDK
            val rsaPublicKey = publicKey as RSAPublicKey
            val spec = RSAPrivateKeySpec(rsaPublicKey.modulus, rsaPublicKey.publicExponent)
            val fakePrivateKey = KeyFactory.getInstance("RSA").generatePrivate(spec)
            cipher = Cipher.getInstance("RSA") //It is a stateful object. so we need to get new one.
            cipher.init(Cipher.DECRYPT_MODE, fakePrivateKey)
        }

        if (cipherText == null || cipherText.length == 0) {
            return cipherText
        }

        val cipherBytes = Base64.decodeBase64(cipherText.toByteArray())
        val plainBytes = cipher.doFinal(cipherBytes)

        return String(plainBytes)
    }

    @Throws(Exception::class)
    fun encrypt(plainText: String): String {
        return encrypt(null as String?, plainText)
    }

    @Throws(Exception::class)
    fun encrypt(key: String?, plainText: String): String {
        var key = key
        if (key == null) {
            key = DEFAULT_PRIVATE_KEY_STRING
        }

        val keyBytes = Base64.decodeBase64(key.toByteArray())
        return encrypt(keyBytes, plainText)
    }

    @Throws(Exception::class)
    fun encrypt(keyBytes: ByteArray, plainText: String): String {
        val spec = PKCS8EncodedKeySpec(keyBytes)
        val factory = KeyFactory.getInstance("RSA", "SunRsaSign")
        val privateKey = factory.generatePrivate(spec)
        var cipher = Cipher.getInstance("RSA/ECB/PKCS1Padding")
        try {
            cipher.init(Cipher.ENCRYPT_MODE, privateKey)
        } catch (e: InvalidKeyException) {
            //For IBM JDK, 原因请看解密方法中的说明
            val rsaPrivateKey = privateKey as RSAPrivateKey
            val publicKeySpec = RSAPublicKeySpec(
                rsaPrivateKey.modulus, rsaPrivateKey
                    .privateExponent
            )
            val fakePublicKey = KeyFactory.getInstance("RSA").generatePublic(publicKeySpec)
            cipher = Cipher.getInstance("RSA")
            cipher.init(Cipher.ENCRYPT_MODE, fakePublicKey)
        }

        val encryptedBytes = cipher.doFinal(plainText.toByteArray(charset("UTF-8")))

        return Arrays.toString(Base64.encodeBase64(encryptedBytes))
    }

    @Throws(NoSuchAlgorithmException::class, NoSuchProviderException::class)
    fun genKeyPairBytes(keySize: Int): Array<ByteArray?> {
        val keyPairBytes = arrayOfNulls<ByteArray>(2)

        val gen = KeyPairGenerator.getInstance("RSA", "SunRsaSign")
        gen.initialize(keySize, SecureRandom())
        val pair = gen.generateKeyPair()

        keyPairBytes[0] = pair.private.encoded
        keyPairBytes[1] = pair.public.encoded

        return keyPairBytes
    }

    @Throws(NoSuchAlgorithmException::class, NoSuchProviderException::class)
    fun genKeyPair(keySize: Int): Array<String?> {
        val keyPairBytes = genKeyPairBytes(keySize)
        val keyPairs = arrayOfNulls<String>(2)

        keyPairs[0] = Arrays.toString(Base64.encodeBase64(keyPairBytes[0]))
        keyPairs[1] = Arrays.toString(Base64.encodeBase64(keyPairBytes[1]))

        return keyPairs
    }

}
