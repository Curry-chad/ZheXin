package com.fina.galaxy.core.handler

import java.lang.Exception

open class SimpleException(message: String) : Exception(message) {

    private var code: String? = "0"

    fun getCode(): String? {
        return code
    }

    fun getMsg(): String? {
        return message
    }

    constructor(code: String, message: String) : this(message) {
        this.code = code
    }
}