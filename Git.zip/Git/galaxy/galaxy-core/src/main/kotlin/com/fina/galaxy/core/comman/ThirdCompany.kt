package com.fina.galaxy.core.comman

enum class ThirdCompany {
    YP,//云瀑
    FY,//蜂云
    YIBAO,
    JK //金科
}