package com.fina.summer.app.manager.config


import com.fina.metis.auth.client.LogoutFilter
import com.fina.metis.auth.client.PermissionFilter
import com.fina.metis.auth.client.SmartContainer
import com.fina.metis.auth.client.SsoFilter
import com.smart.sso.rpc.AuthenticationRpcService
import org.springframework.beans.factory.annotation.Value
import org.springframework.context.annotation.Bean
import org.springframework.context.annotation.Configuration

@Configuration
class SmartConfig {

    @Value("\${sso.server.url}")
    private val serverUrl: String? = null

//    @Value("\${sso.back.url}")
//    private val backUrl: String? = null

    @Value("\${sso.app.code}")
    private val appCode: String? = null

    @org.apache.dubbo.config.annotation.Reference
    private lateinit var authenticationRpcService: AuthenticationRpcService

    @Bean("smartFilter")
    fun smartFilter(): SmartContainer {
        val smartContainer = SmartContainer()
        smartContainer.ssoServerUrl = serverUrl
        smartContainer.authenticationRpcService = authenticationRpcService


        val ssoFilter = SsoFilter()
//        ssoFilter.ssO_BACK_URL = backUrl
        ssoFilter.authenticationRpcService = authenticationRpcService

        val logoutFilter = LogoutFilter()
        logoutFilter.pattern = "/logout"
        logoutFilter.setSsoBackUrl("/index")
        logoutFilter.authenticationRpcService = authenticationRpcService

        val permissionFilter = PermissionFilter()
        permissionFilter.setSsoAppCode(appCode!!)
        permissionFilter.authenticationRpcService = authenticationRpcService

        val list = arrayOf(ssoFilter, logoutFilter, permissionFilter)

        smartContainer.setFilters(list)
        return smartContainer
    }



}