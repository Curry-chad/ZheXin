//package com.fina.summer.app.manager.controller.order;
//
//
//import com.fina.summer.core.bean.PageResult
//import com.fina.summer.core.respone.ResEnum
//import com.fina.summer.core.respone.WebResult
//import com.fina.summer.manager.impl.order.InnerOrderService
//import com.fina.summer.manager.impl.order.MovedOrderService
//import com.fina.summer.persistent.bean.Area
//import com.fina.summer.persistent.bean.loan.LoanOrder
//import com.fina.summer.persistent.ceres.entity.domain.BillInFlowsPO
//import com.fina.summer.persistent.summer.entity.OrderReceivableParam
//import com.fina.summer.persistent.summer.entity.domain.OrderInfoPO
//import io.swagger.annotations.Api;
//import io.swagger.annotations.ApiOperation;
//import org.apache.shiro.authz.annotation.RequiresPermissions;
//import org.springframework.web.bind.annotation.*
//import javax.transaction.Transactional
//
//
//@Api(tags = ["订单管理"])
//@RestController
//@RequestMapping("/order")
//@RequiresPermissions("/order")
//
//class OrderManageController(
//        private val movedOrderService: MovedOrderService,
//        private val innerOrderService: InnerOrderService
//) {
//    /**
//     * 移动版订单查询·
//     */
//    @ApiOperation("移动版订单查询")
//
//    @PostMapping("/moved")
//    fun movedOrders(@RequestBody orderReceivableParam: OrderReceivableParam): WebResult<PageResult<OrderInfoPO>> {
//        val result = movedOrderService.getOrder(orderReceivableParam)
//        return ResEnum.success(result)
//    }
//    /**
//     * 地区回显·
//     */
//    @ApiOperation("地区回显")
//
//    @PostMapping("/areaDisplay")
//    fun areaDisplay(@RequestBody orderReceivableParam: OrderReceivableParam): WebResult<List<Area>> {
//        val result = innerOrderService.areaDisplay(orderReceivableParam)
//        return ResEnum.success(result)
//    }
//
//    /**
//     * 内部订单查询·
//     */
//    @ApiOperation("内部版订单查询")
//
//    @PostMapping("/inner")
//    fun innerOrders(@RequestBody orderReceivableParam: OrderReceivableParam): WebResult<PageResult<LoanOrder>> {
//        val result = innerOrderService.findInnerOrder(orderReceivableParam)
//        return ResEnum.success(result)
//    }
//    /**
//     * 订单详情查询·
//     */
//    @ApiOperation("订单详情查询")
//
//    @PostMapping("/detail")
//    fun detail(@RequestBody orderReceivableParam: OrderReceivableParam): WebResult<List<LoanOrder>> {
//        val result = innerOrderService.detail(orderReceivableParam)
//        return ResEnum.success(result)
//    }
//
//    /**
//     * 内部订单下载·
//     */
//    @ApiOperation("内部订单下载")
//
//    @PostMapping("/down")
//    fun down(@RequestBody orderReceivableParam: OrderReceivableParam): WebResult<PageResult<LoanOrder>> {
//        val result = innerOrderService.down(orderReceivableParam)
//        return ResEnum.success(result)
//    }
//
//    /**
//     * 合约补录·
//     */
//    @ApiOperation("合约补录")
//
//    @PostMapping("/contractSupplement")
//    @Transactional
//    fun contractSupplement(@RequestParam(value = "orderId",required = false) orderId: String, @RequestParam(value = "telecomAgreementNo",required = false) telecomAgreementNo: String, @RequestParam(value = "telecomAgreementPic",required = false) telecomAgreementPic: String): WebResult<Void> {
//        return innerOrderService.contractSupplement(orderId,telecomAgreementNo,telecomAgreementPic)
//    }
//
//    /**
//     * 订单状态修改·
//     */
//    @ApiOperation("订单状态修改")
//
//    @PostMapping("/statusChange")
//    @Transactional
//    fun statusChange(@RequestParam(value = "orderId",required = false) orderId: String): WebResult<Void> {
//        return innerOrderService.statusChange(orderId)
//    }
//
//
//
//    // * 退款审核·
//
// /*   @ApiOperation("退款审核回显")
//
//    @PostMapping("/refundReviewSearch")
//    fun refundReviewSearch(@RequestParam(value = "orderId",required = false) orderId: String,@RequestParam(value = "type",required = false) type: String): Any? {
//        return innerOrderService.refundReviewSearch(orderId,type)
//    }*/
//
//}
