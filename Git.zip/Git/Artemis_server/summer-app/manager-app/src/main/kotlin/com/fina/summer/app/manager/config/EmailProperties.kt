package com.fina.summer.app.manager.config

import org.springframework.beans.factory.annotation.Value
import org.springframework.stereotype.Component

@Component
class EmailProperties {

    @Value("\${email.to}")
    var to: String? = null

    @Value("\${email.host}")
    var host: String? = null

    @Value("\${email.port}")
    var port: String? = null

    @Value("\${email.account}")
    var account: String? = null

    @Value("\${email.password}")
    var password: String? = null

}
