package com.fina.summer.app.manager.kafka

import com.alibaba.fastjson.JSONObject
import com.alibaba.fastjson.TypeReference
import com.fina.summer.core.handler.SimpleException
import com.fina.summer.manager.impl.operate.RefundService
import com.fina.summer.manager.impl.operate.TradeTaskNotifyService
import com.fina.summer.persistent.ceres.entity.constant.BisTaskType
import com.fina.summer.persistent.ceres.entity.domain.FailCreateTasksPO
import com.fina.summer.persistent.ceres.repo.FailCreateTasksRepo
import org.apache.kafka.clients.consumer.ConsumerRecord
import org.slf4j.Logger
import org.slf4j.LoggerFactory
import org.springframework.kafka.annotation.KafkaListener
import org.springframework.stereotype.Component
import java.util.*

@Component
class TradeTaskNotifyListener(
        private val failCreateTasksRepo: FailCreateTasksRepo,
        private val tradeTaskNotifyService: TradeTaskNotifyService,
        private val refundService: RefundService
) {

    private val logger: Logger = LoggerFactory.getLogger(TradeTaskNotifyListener::class.java)
    /**
     * 生成用户还款/商户打款task数据
     */
    @KafkaListener(topics = ["trade_task_notify"])
    fun saveBisTask(record: ConsumerRecord<Any, Any>) {
        var id: String? = null
        var type: String? = null
        val monitorData: KafkaTO<RepayCreateIdTO>
        val now = Date()

        var failCreateTasksPO: FailCreateTasksPO? = null

        try {
            val value = record.value() as String
            logger.info("kafka topic:trade_task_notify, value:$value")
            val clazz = object : TypeReference<KafkaTO<RepayCreateIdTO>>() {}.type!!
            monitorData = JSONObject.parseObject<KafkaTO<RepayCreateIdTO>>(value, clazz)!!
            id = monitorData.data!!.id!!
            type = monitorData.type!!
            logger.info("id:$value,type = $type ")
            when (type) {
                BisTaskType.RepayPlan.type -> tradeTaskNotifyService.saveRepayPlanAndTasks(id)
                BisTaskType.MerRemit.type -> tradeTaskNotifyService.saveMerRemitAndTasks(id)

                BisTaskType.RepayPlanCancel.type -> refundService.refund(id)
                BisTaskType.MerRemitCancel.type -> refundService.refund(id)

                BisTaskType.RepayInvalid.type -> tradeTaskNotifyService.createInvalidRepayPlan(id)
                BisTaskType.RemitInvalid.type -> tradeTaskNotifyService.createInvalidMerRemit(id)

                else -> failCreateTasksPO = FailCreateTasksPO(
                        bisTaskId = id,
                        bisTaskType = type,
                        createdTime = now,
                        updatedTime = now
                )
            }
        } catch (e: Exception) {

            if (e is SimpleException) {
                logger.warn("kafka[ trade_task_notify ] error...", e)
            } else {
                logger.error("kafka[ trade_task_notify ] error...", e)
            }
            if (id != null && type != null) {
                failCreateTasksPO = FailCreateTasksPO(
                        bisTaskId = id,
                        bisTaskType = type,
                        createdTime = now,
                        updatedTime = now
                )
            }
        } finally {
            if (failCreateTasksPO != null) {
                failCreateTasksRepo.save(failCreateTasksPO)
            }
        }
    }

}
