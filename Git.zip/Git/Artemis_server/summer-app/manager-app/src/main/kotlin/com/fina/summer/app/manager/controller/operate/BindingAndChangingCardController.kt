package com.fina.summer.app.manager.controller.operate

import com.fina.summer.core.respone.WebResult
import com.fina.summer.manager.impl.operate.BindingAndChangingService
import com.fina.summer.persistent.ceres.entity.vo.BingdingAndChangingCardVO
import io.swagger.annotations.Api
import io.swagger.annotations.ApiImplicitParam
import io.swagger.annotations.ApiOperation
import org.springframework.web.bind.annotation.PostMapping
import org.springframework.web.bind.annotation.RequestBody
import org.springframework.web.bind.annotation.RequestMapping
import org.springframework.web.bind.annotation.RestController
import javax.transaction.Transactional

@Api(tags = ["[运营后台]绑定与换卡"])
@RestController
@RequestMapping("/operate")
class BindingAndChangingCardController(
        private val bindingAndChangingService: BindingAndChangingService
) {
    /**
     * 储蓄卡绑定与更换接口
     */
    @Transactional
    @ApiOperation("储蓄卡绑定与更换接口")
    @ApiImplicitParam(name = "orderId", value = "订单表id", required = true, dataType = "String")
    @PostMapping("/bindingAndChanginggCard")
    fun bindingAndChangingCard(@RequestBody bingdingAndChangingCardVO: BingdingAndChangingCardVO): WebResult<Void> {
        return  bindingAndChangingService.bindingAndChangingCard(bingdingAndChangingCardVO)
    }

}