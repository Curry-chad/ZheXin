package com.fina.summer.app.manager.kafka

import java.io.Serializable
import java.util.*

data class RepayCreateIdTO(
        var id: String? = null,

        var timestamp: Date?  =null
): Serializable