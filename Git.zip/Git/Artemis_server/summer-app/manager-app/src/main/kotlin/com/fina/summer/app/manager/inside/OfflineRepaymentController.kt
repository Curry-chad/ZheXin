package com.fina.summer.app.manager.inside

import com.fina.summer.core.respone.ResEnum
import com.fina.summer.core.respone.WebResult
import com.fina.summer.manager.client.util.TimeCalculationUtils
import com.fina.summer.manager.entity.bo.FileImportBO
import com.fina.summer.manager.inside.OfflineRepaymentService
import com.fina.summer.persistent.ceres.entity.vo.OfflineRepaymentStatusVO
import io.swagger.annotations.Api
import io.swagger.annotations.ApiOperation
import org.slf4j.LoggerFactory
import org.springframework.web.bind.annotation.PostMapping
import org.springframework.web.bind.annotation.RequestBody
import org.springframework.web.bind.annotation.RequestMapping
import org.springframework.web.bind.annotation.RestController

@Api(tags = ["催收任务生成"])
@RestController
@RequestMapping("/inside/offlineRepayment")
class OfflineRepaymentController(
        private val offlineRepaymentService: OfflineRepaymentService
) {
    private val logger = LoggerFactory.getLogger(OfflineRepaymentController :: class.java)

    /**
     * 催收结果更新
     */
    @ApiOperation("催收结果更新")
    @PostMapping("/offlineRepaymentUpdate")
    fun offlineRepaymentUpdate(@RequestBody offlineRepaymentStatusVO: List<OfflineRepaymentStatusVO>): WebResult<FileImportBO>{
        val time = TimeCalculationUtils.startTime()
        logger.info("开始催收结果更新-请求参数:[$offlineRepaymentStatusVO],开始时间:【$time】")
        val msg = offlineRepaymentService.offlineRepaymentUpdate(offlineRepaymentStatusVO)
        val endTime = TimeCalculationUtils.endTime(time)
        logger.info("请求结束:耗时【$endTime-ms】,响应参数：【$msg】")
        return msg
    }

    /**
     *线下催收结果
     */
    @ApiOperation("线下催收结果")
    @PostMapping("/offlineRepaymentConfirm")
    fun offlineRepaymentConfirm(@RequestBody offlineRepaymentStatusVO: OfflineRepaymentStatusVO): WebResult<FileImportBO>{
        val time = TimeCalculationUtils.startTime()
        logger.info("开始线下催收结果确认-请求参数:[$offlineRepaymentStatusVO],开始时间:【$time】")
        val str = TimeCalculationUtils.isNotEmptyBatch(offlineRepaymentStatusVO,"orderId","id",
                "payer","transferMethod","collectionAccount","planExecuteTime","shouldAmountNum","totalAmount",
                "finishTime","overdueNum")
        if(str.isNotEmpty()){
            return ResEnum.fail("请求参数：【$str】为空")
        }
        val msg = offlineRepaymentService.offlineRepaymentConfirm(offlineRepaymentStatusVO)
        val endTime = TimeCalculationUtils.endTime(time)
        logger.info("请求结束:耗时【$endTime-ms】,响应参数：【$msg】")
        return msg
    }
}