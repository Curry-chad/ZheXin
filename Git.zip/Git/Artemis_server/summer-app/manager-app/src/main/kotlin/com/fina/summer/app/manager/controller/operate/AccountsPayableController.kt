package com.fina.summer.app.manager.controller.operate

import com.fina.summer.core.respone.WebResult
import com.fina.summer.manager.impl.operate.AccountsPayableService
import com.fina.summer.persistent.ceres.entity.vo.OutBackQueryParam
import io.swagger.annotations.Api
import io.swagger.annotations.ApiOperation
import org.springframework.web.bind.annotation.PostMapping
import org.springframework.web.bind.annotation.RequestBody
import org.springframework.web.bind.annotation.RequestMapping
import org.springframework.web.bind.annotation.RestController
import javax.transaction.Transactional

@Api(tags = ["[运营后台]应付账单模块Api"])
@RestController
@RequestMapping("/operate/receive")
class AccountsPayableController(
        private val AccountsPayableService: AccountsPayableService
) {

//    /**
//     * 收款接口
//     * param startTime String            该日应打款订单时间
//     */
//    @ApiOperation("收款")
//    @Transactional
//    @PostMapping("/change")
//    fun change(@RequestBody accountPayableVO: AccountPayableVO): WebResult<Void> {
//        return AccountsPayableService.change(accountPayableVO)
//    }

    /**
     * 回退接口
     */
    @ApiOperation("回退")
    @Transactional
    @PostMapping("/back")
    fun back(@RequestBody outBackQueryParam: OutBackQueryParam): WebResult<Void> {
        return AccountsPayableService.back(outBackQueryParam)
    }
}