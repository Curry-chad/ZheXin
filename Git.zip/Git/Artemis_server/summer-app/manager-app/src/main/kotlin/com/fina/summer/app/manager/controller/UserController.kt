package com.fina.summer.app.manager.controller

import com.fina.summer.core.respone.ResEnum
import com.fina.summer.core.respone.WebResult
import com.fina.summer.manager.auth.app.ManagerShiroRealm
import com.fina.summer.manager.entity.bo.ManagerUserInfoBO
import com.fina.summer.manager.impl.user.UserService
import com.fina.summer.persistent.artemis.entity.vo.ManagerMenuVO
import io.swagger.annotations.Api
import io.swagger.annotations.ApiImplicitParam
import io.swagger.annotations.ApiImplicitParams
import io.swagger.annotations.ApiOperation
import org.springframework.web.bind.annotation.*

@Api(tags = ["用户模块Api"])
@CrossOrigin
@RestController
@RequestMapping("/user")
class UserController(
        private val userService: UserService,
        private val managerShiroRealm: ManagerShiroRealm
) {

    @ApiOperation("获取当前用户信息")
    @GetMapping("/info")
    fun currentUserInfo(): WebResult<ManagerUserInfoBO> {
        managerShiroRealm.clearCachedAuthorizationInfo()
        val userInfoBO = userService.currentUserInfo()
        return ResEnum.success(userInfoBO)
    }

    @ApiOperation("获取当前用户于当前平台下的权限信息")
    @ApiImplicitParams(ApiImplicitParam(name = "firstLvUrl", value = "一级权限url", required = true, dataType = "String"))
    @PostMapping("/permissions")
    fun currentPermissions(@RequestParam firstLvUrl: String): WebResult<List<ManagerMenuVO>> {
        val permissions = userService.currentPermissions(firstLvUrl)
        return ResEnum.success(permissions)
    }

}