package com.fina.summer.app.manager.controller.operate

import com.fina.summer.core.respone.ResEnum
import com.fina.summer.core.respone.WebResult
import com.fina.summer.manager.entity.bo.RefundCheckListBO
import com.fina.summer.manager.impl.operate.RefundService
import com.fina.summer.manager.impl.operate.TradeTaskNotifyService
import com.fina.summer.persistent.ceres.entity.constant.BillType
import com.fina.summer.persistent.ceres.entity.constant.Progress
import com.fina.summer.persistent.ceres.entity.domain.BillRepayPlanPO
import com.fina.summer.persistent.ceres.repo.BillOutPlanRepo
import com.fina.summer.persistent.ceres.repo.BillOutTasksRepo
import com.fina.summer.persistent.ceres.repo.BillRepayPlanRepo
import io.swagger.annotations.Api
import io.swagger.annotations.ApiOperation
import org.slf4j.LoggerFactory
import org.springframework.transaction.annotation.Transactional
import org.springframework.web.bind.annotation.GetMapping
import org.springframework.web.bind.annotation.RequestMapping
import org.springframework.web.bind.annotation.RequestParam
import org.springframework.web.bind.annotation.RestController
import java.util.*

@Api(tags = ["[运营后台]无权限退款Api"])
@RestController
@RequestMapping("/operate/refund/notPower")
class OperateRefundNotPowerController (
        private val refundService: RefundService,
        private val tradeTaskNotifyService: TradeTaskNotifyService,
        private val billRepayPlanRepo: BillRepayPlanRepo,
        private val billOutPlanRepo: BillOutPlanRepo,
        private val billOutTasksRepo: BillOutTasksRepo
) {

    private val logger = LoggerFactory.getLogger(OperateRefundNotPowerController :: class.java)

    /**
     * 回款任务生成接口（退款审核）
     */
    @ApiOperation("回款任务生成")
    @GetMapping("/moneyBack")
    fun moneyBack(@RequestParam orderId: String): WebResult<RefundCheckListBO<BillRepayPlanPO>> {
        var msg = refundService.moneyBack(orderId)
        refundModification(orderId)
        return ResEnum.success(msg)
    }

    /**
     * 打款任务收款任务状态修改(变为审核中)
     */
    @ApiOperation("打款任务收款任务状态修改")
    @GetMapping("/refundModification")
    @Transactional
    fun refundModification(@RequestParam orderId: String): WebResult<Void> {
        val now = Date()
        val inPlan = billRepayPlanRepo.findByOrderIdAndType(orderId, BillType.User)
        val outPlan = billOutPlanRepo.findByOrderIdAndType(orderId, BillType.Merchant)
        val outTasks = billOutTasksRepo.findByOrderIdAndType(orderId, BillType.Merchant)
        val rewardPlan = billOutPlanRepo.findByOrderIdAndType(orderId, BillType.Reward)
        val rewardTasks = billOutTasksRepo.findByOrderIdAndType(orderId, BillType.Reward)
        val phoneBillInPlan = billRepayPlanRepo.findByOrderIdAndType(orderId, BillType.PhoneBill)
        val phoneBillOutPlan = billOutPlanRepo.findByOrderIdAndType(orderId, BillType.PhoneBill)
        val phoneBillNoAmountInPlan = billRepayPlanRepo.findByOrderIdAndType(orderId, BillType.PhoneBillNoAmount)
        val phoneBillNoAmountOutPlan = billOutPlanRepo.findByOrderIdAndType(orderId, BillType.PhoneBillNoAmount)
        if (inPlan != null) {
            val inId = inPlan.id!!
            //用户收款任务取消
            tradeTaskNotifyService.cancelRepayPlan(inId)
        }
        if (outPlan != null) {
            if (outTasks != null) {
                if(outTasks.status != Progress.Cancel) {
                    val outId = outPlan.id!!
                    //商户打款任务取消
                    tradeTaskNotifyService.cancelMerRemit(outId)
                }
            }
        }
        if (rewardPlan != null) {
            if (rewardTasks != null) {
                if(rewardTasks.status != Progress.Success) {
                    //红包打款任务取消
                    refundService.cancelRewardOutPlan(rewardPlan, rewardTasks, now)
                }
            }
        }
        if (phoneBillInPlan != null) {
            val inId = phoneBillInPlan.id!!
            //用户代扣任务取消
            tradeTaskNotifyService.cancelRepayPlan(inId)
        }
        if (phoneBillOutPlan != null) {
            val inId = phoneBillOutPlan.id!!
            //用户代充任务取消
            tradeTaskNotifyService.cancelMerRemit(inId)
        }
        if (phoneBillNoAmountInPlan != null) {
            val inId = phoneBillNoAmountInPlan.id!!
            //用户代扣任务取消
            tradeTaskNotifyService.cancelRepayPlan(inId)
        }
        if (phoneBillNoAmountOutPlan != null) {
            val inId = phoneBillNoAmountOutPlan.id!!
            //用户代充任务取消
            tradeTaskNotifyService.cancelMerRemit(inId)
        }
        return ResEnum.success()
    }

    /**
     * 线下退款状态修改
     */
    @ApiOperation("线下退款状态修改")
    @GetMapping("/reimburse")
    fun reimburse(@RequestParam("orderId") orderId: String, @RequestParam("type") type: BillType,
                  @RequestParam("moneyBack") moneyBack: String ): WebResult<Void> {
        refundService.refundModification(orderId, type, moneyBack)
        return ResEnum.success()
    }

    /**
     * 拒绝退单
     */
    @ApiOperation("拒绝退单")
    @GetMapping("/refusalWithdrawal")
    fun refusalWithdrawal(@RequestParam orderId: String): WebResult<Void> {
        refundService.refusalWithdrawal(orderId)
        return ResEnum.success()
    }

    /**
     * 退款(后台调用)
     */
    @ApiOperation("退款(后台调用)")
    @GetMapping("/refunds")
    fun refunds(@RequestParam orderId: String): WebResult<Void> {
        val inPlan = billRepayPlanRepo.findByOrderIdAndType(orderId, BillType.User)
        refundService.cancelPhoneBill(orderId)
        if (inPlan != null) {
            refundService.refund(inPlan.id!!)
        }else{
            logger.info("orderId = $orderId ,用户扣款计划不存在")
        }
        return ResEnum.success()
    }

    /**
     * 回款数据提供
     */
    @ApiOperation("退款(后台调用)")
    @GetMapping("/receivedPayments")
    fun receivedPayments(@RequestParam orderId: String) : WebResult<RefundCheckListBO<BillRepayPlanPO>>{
        val data = refundService.receivedPayments(orderId)
        return ResEnum.success(data)
    }
}