package com.fina.summer.app.manager.controller.operate

import com.fina.summer.core.bean.PageResult
import com.fina.summer.core.respone.ResEnum
import com.fina.summer.core.respone.WebResult
import com.fina.summer.manager.batch.BatchRecharge
import com.fina.summer.manager.entity.bo.*
import com.fina.summer.manager.entity.bo.BatchDeductBO
import com.fina.summer.manager.impl.operate.OperateReceivableService
import com.fina.summer.manager.impl.operate.OperateTopupService
import com.fina.summer.persistent.ceres.entity.vo.TopupAreaVO
import com.fina.summer.persistent.ceres.entity.vo.TopupParamVO
import com.fina.summer.persistent.ceres.entity.vo.TopupPlanVO
import io.swagger.annotations.Api
import io.swagger.annotations.ApiOperation
import org.slf4j.Logger
import org.slf4j.LoggerFactory
import org.springframework.util.CollectionUtils
import org.springframework.web.bind.annotation.PostMapping
import org.springframework.web.bind.annotation.RequestBody
import org.springframework.web.bind.annotation.RequestMapping
import org.springframework.web.bind.annotation.RestController

@Api(tags = ["[运营后台]河南充值Api"])
@RestController
@RequestMapping("/operate/topup")
class OperateTopupController (
        private val operateTopupService : OperateTopupService,
        private val operateReceivableService: OperateReceivableService,
        private val batchRecharge: BatchRecharge
        ) {

    private val logger: Logger = LoggerFactory.getLogger(OperateTopupController::class.java)

    /**
     * 河南充值列表
     */
    @ApiOperation("获取河南充值列表")
    @PostMapping("/list")
    fun topupList(@RequestBody topUpParamVO : TopupParamVO) : WebResult<PageResult<TopupPlanVO>> {
        val list=  operateTopupService.list(topUpParamVO)
        return ResEnum.success(list)
    }

    /**
     * 地区列表查询
     */
    @ApiOperation("获取地区列表")
    @PostMapping("/topupAreas")
    fun findAreas(@RequestBody topUpParamVO : TopupParamVO): WebResult<List<TopupAreaVO>> {
        val toList = operateTopupService.findTopUpAreasBy(topUpParamVO)
        return ResEnum.success(toList)
    }

    /**
     * 充值
     */
    @ApiOperation("充值")
    @PostMapping("/moreCredit")
    fun recharge(@RequestBody ids : List<String>) : WebResult<BatchDeductBO>{
        if(CollectionUtils.isEmpty(ids)) {
            return ResEnum.fail("请求参数为空")
        }
        val bo = operateTopupService.recharge(ids)
        return ResEnum.success(bo)
    }

    /**
     * 批量代缴任务
     */
    @ApiOperation("批量代缴任务")
    @PostMapping("/rechargeBatch")
    fun rechargeBatch() : WebResult<Void>{
        logger.info("-----开始批量代缴任务---------------")
        batchRecharge.batchRechargeTiming()
        logger.info("-----结束批量代缴任务---------------")
        return ResEnum.success()
    }

}