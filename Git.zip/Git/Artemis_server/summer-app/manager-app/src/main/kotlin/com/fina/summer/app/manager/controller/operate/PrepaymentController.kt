package com.fina.summer.app.manager.controller.operate

import com.fina.summer.core.respone.WebResult
import com.fina.summer.manager.impl.operate.PrepaymentService
import com.fina.summer.persistent.ceres.entity.vo.PrepaymentVO
import io.swagger.annotations.Api
import io.swagger.annotations.ApiOperation
import org.slf4j.LoggerFactory
import org.springframework.web.bind.annotation.PostMapping
import org.springframework.web.bind.annotation.RequestBody
import org.springframework.web.bind.annotation.RequestMapping
import org.springframework.web.bind.annotation.RestController
import javax.transaction.Transactional

@Api(tags = ["[运营后台]提前还款"])
@RestController
@RequestMapping("/operate")
class PrepaymentController(
        private val PrepaymentService: PrepaymentService
) {

    private val logger = LoggerFactory.getLogger(PrepaymentController :: class.java)

    /**
     * 还款查询接口
     * param name 还款姓名 String
     * param Acccount 还款卡号 String
     */
    @ApiOperation("还款接口")
    @PostMapping("/getPrepaymentList")
    fun getPrepaymentList(@RequestBody prepayment : PrepaymentVO): WebResult<PrepaymentVO> {
        logger.info("开始还款查询接口：请求参数【$prepayment】")
       return PrepaymentService.getPrepaymentList(prepayment)
    }
    /**
     * 还款修改接口
     * param name 还款姓名 String
     * param Acccount 还款卡号 String
     */
    @Transactional
    @ApiOperation("还款修改接口")
    @PostMapping("/prepayment")
    fun prepayment(@RequestBody prepayment : PrepaymentVO): WebResult<Void> {
        logger.info("开始还款修改接口：请求参数【$prepayment】")
        return  PrepaymentService.prepayment(prepayment)
    }

}