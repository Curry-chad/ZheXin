package com.fina.summer.app.manager.controller.finance

import com.fina.summer.core.respone.ResEnum
import com.fina.summer.core.respone.WebResult
import com.fina.summer.manager.entity.dto.PayableDTO
import com.fina.summer.manager.impl.finance.PayableService
import com.fina.summer.manager.impl.operate.TradeTaskNotifyService
import io.swagger.annotations.Api
import io.swagger.annotations.ApiOperation
import org.slf4j.LoggerFactory
import org.springframework.util.CollectionUtils
import org.springframework.web.bind.annotation.PostMapping
import org.springframework.web.bind.annotation.RequestBody
import org.springframework.web.bind.annotation.RequestMapping
import org.springframework.web.bind.annotation.RestController

@Api(tags = ["应付账款Api"])
@RestController
@RequestMapping("/finance/payable")
class PayableController(
        private val payableService: PayableService,
        private val tradeTaskNotifyService: TradeTaskNotifyService
) {
    private val logger = LoggerFactory.getLogger(PayableController::class.java)


    @ApiOperation("提交")
    @PostMapping("/submit")
    fun submit(@RequestBody list: List<PayableDTO>): WebResult<Void> {
        payableService.submit(list)
        return ResEnum.success()
    }

    /**
     * 打款/收款数据缺失补录
     */
    @ApiOperation("打款数据缺失补录")
    @PostMapping("/dataSupplement")
    fun dataSupplement(@RequestBody planIds: List<String>): WebResult<Void>{
        if (CollectionUtils.isEmpty(planIds)) {
            val msg = "请求参数为空"
            return ResEnum.fail(msg)
        }
        planIds.forEach {
            tradeTaskNotifyService.saveDataSupplementMerRemitAnd(it)
        }
        return ResEnum.success()
    }
}