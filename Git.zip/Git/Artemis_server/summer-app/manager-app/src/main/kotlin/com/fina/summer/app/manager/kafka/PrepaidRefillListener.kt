package com.fina.summer.app.manager.kafka

import com.alibaba.fastjson.JSONObject
import com.alibaba.fastjson.TypeReference
import com.fina.summer.manager.entity.dto.OfPayNoticeResp
import com.fina.summer.manager.impl.operate.OperateTopupService
import com.fina.summer.persistent.ceres.entity.domain.FailHandleFromKafkaPO
import com.fina.summer.persistent.ceres.repo.FailHandleFromKafkaRepo
import org.slf4j.LoggerFactory
import org.springframework.kafka.annotation.KafkaListener
import org.springframework.stereotype.Component
import java.util.*

@Component
class PrepaidRefillListener(

        private val failHandleFromKafkaRepo: FailHandleFromKafkaRepo,
        private val operateTopupService : OperateTopupService

) {
    private val logger = LoggerFactory.getLogger(PrepaidRefillListener::class.java)

    @KafkaListener(topics = ["hestia-phonerecharge-notice"])
    fun prepaidRefill(record: String) {
        val clazz = object : TypeReference<OfPayNoticeResp>() {}.type!!
        logger.debug("kafka topic:ceres-deduct-notice, value:$record")
        logger.info("接口返回参数：[$record]")
        val prepaidRefillData = JSONObject.parseObject<OfPayNoticeResp>(record, clazz)!!
        try {
            operateTopupService.prepaidRefill(prepaidRefillData)
        } catch (e: Exception) {
            logger.error("kafka[ hestia-phonerecharge-notice ] error...", e)
            val now = Date()
            failHandleFromKafkaRepo.save(FailHandleFromKafkaPO(
                    topic = "hestia-phonerecharge-notice",
                    kafkaKey = null,
                    kafkaValue = record,
                    createdTime = now,
                    updatedTime = now
            ))
        }
    }
}