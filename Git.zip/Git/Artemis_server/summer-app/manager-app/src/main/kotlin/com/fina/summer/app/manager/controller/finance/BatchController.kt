package com.fina.summer.app.manager.controller.finance

import com.fina.summer.core.respone.ResEnum
import com.fina.summer.core.respone.WebResult
import com.fina.summer.manager.batch.OverdueAmountService
import io.swagger.annotations.Api
import io.swagger.annotations.ApiOperation
import org.slf4j.LoggerFactory
import org.springframework.web.bind.annotation.PostMapping
import org.springframework.web.bind.annotation.RequestMapping
import org.springframework.web.bind.annotation.RestController

/**
 * @author zhengqiyang@zhexinit.com
 * @version V1.0
 * @since 1.0 2019/5/15 21:22
 * @description 批量任务手动执行
 */
@Api(tags = ["批量任务Api"])
@RestController
@RequestMapping("/finance/batch")
class BatchController(
        private val overdueAmountService: OverdueAmountService
) {
    private val logger = LoggerFactory.getLogger(BatchController::class.java)

    /**
     *
     * @author zhengqiyang@zhexinit.com
     * @date 2019/5/15 21:26
     * @param []
     * @return Any
     * @description 中原违约金计算---手工
     */

    @ApiOperation("中原违约金计算")
    @PostMapping("/overdueAmountBatch")
    fun overdueAmountBatch(): WebResult<Void> {
        logger.info("----------------开始批量计算中原违约金任务-----------------")
        overdueAmountService.overdueAmountBatch()
        logger.info("----------------结束批量计算中原违约金任务-----------------")
        return ResEnum.success()
    }
}