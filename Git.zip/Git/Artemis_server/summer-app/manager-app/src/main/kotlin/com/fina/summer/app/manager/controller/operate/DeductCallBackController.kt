package com.fina.summer.app.manager.controller.operate

import com.fina.ceres.open.api.BankCardPayService
import com.fina.ceres.open.api.bean.bankcard.BankCardRet
import com.fina.ceres.open.api.bean.bankcard.PayNotifyReq
import com.fina.ceres.open.api.bean.bankcard.PayQueryReq
import com.fina.ceres.open.api.bean.bankcard.TradeStatus
import com.fina.summer.manager.impl.operate.OperateReceivableService
import com.fina.zeus.core.CloudResp
import io.swagger.annotations.Api
import io.swagger.annotations.ApiOperation
import org.slf4j.LoggerFactory
import org.springframework.beans.BeanUtils
import org.springframework.web.bind.annotation.*

@Api(tags = ["扣款回调接口"])
@RestController
@RequestMapping("/operate/deduct")
class DeductCallBackController(

        private val operateReceivableService: OperateReceivableService,
        private val bankCardPayService: BankCardPayService

) {

    private val logger = LoggerFactory.getLogger(DeductCallBackController::class.java)

    /**
     * 扣款回调
     */
    @ApiOperation("获取应收列表")
    @PostMapping("/deductCallBack")
    fun deductCallBack(@RequestBody payNotifyReq: PayNotifyReq): String {
        logger.info("扣款回调接口请求开始--请求参数【$payNotifyReq】")
        val msg = operateReceivableService.deductCallBack(payNotifyReq)
        logger.info("扣款回调接口请求结束-响应参数订单号【${payNotifyReq.tradeId}】-msg = 【$msg】")
        return msg
    }

    @ApiOperation("扣款状态查询")
    @GetMapping("/queryStatus")
    fun queryStatus(thirdOrderId: String): CloudResp<PayNotifyReq> {
        logger.debug("扣款状态查询单号：{}", thirdOrderId)
        val resp = bankCardPayService.payQuery(PayQueryReq(thirdOrderId))
        logger.debug("扣款状态查询结果：{}", resp)
        val payNotifyReq = PayNotifyReq(tradeId = "", orderTradeId = "")
        if (resp.isSuccess) {
            val tres = resp.data!!
            BeanUtils.copyProperties(tres, payNotifyReq)
            payNotifyReq.retMsg = tres.msg
            payNotifyReq.amount = ((tres.amount ?: "0").toDouble() * 100).toInt().toString()

            payNotifyReq.retStatus =
                    when (tres.status) {
                        TradeStatus.PAYED -> BankCardRet.SUCCESS
                        TradeStatus.PAYING, TradeStatus.NEW -> BankCardRet.ING
                        TradeStatus.FAIL -> BankCardRet.FAIL
                        else -> BankCardRet.FAIL
                    }
            val msg = operateReceivableService.deductCallBack(payNotifyReq)
            return if (msg == "success") {
                CloudResp.success(payNotifyReq)
            } else {
                CloudResp.fail(msg)
            }
        } else {
            return CloudResp.fail(resp.code, resp.msg!!)
        }


    }

}