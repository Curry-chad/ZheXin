package com.fina.summer.app.manager.controller.operate

import com.fina.summer.core.respone.ResEnum
import com.fina.summer.core.respone.WebResult
import com.fina.summer.manager.impl.operate.RefundService
import io.swagger.annotations.Api
import io.swagger.annotations.ApiOperation
import org.springframework.web.bind.annotation.PostMapping
import org.springframework.web.bind.annotation.RequestMapping
import org.springframework.web.bind.annotation.RequestParam
import org.springframework.web.bind.annotation.RestController

@Api(tags = ["[运营后台]退款Api"])
@RestController
@RequestMapping("/operate/refund")
class OperateRefundController(
        private val refundService: RefundService
) {

    /**
     * 退款校验
     */
    @ApiOperation("退款校验")
    @PostMapping("/check")
    fun check(@RequestParam repayPlanId: String): WebResult<Void> {
        refundService.check(repayPlanId)
        return ResEnum.success()
    }

    /**
     * 退款
     */
    @ApiOperation("退款")
    @PostMapping("/refund")
    fun refund(@RequestParam repayPlanId: String): WebResult<Void> {
        refundService.refund(repayPlanId)
        return ResEnum.success()
    }

    /**
     * 收款（from 商户）结果成功通知
     */
    @ApiOperation("收款（from 商户）结果成功通知")
    @PostMapping("/successReceivableFromMer")
    fun successReceivableFromMer(@RequestParam repayPlanId: String): WebResult<Void> {
        refundService.successReceivableFromMer(repayPlanId)
        return ResEnum.success()
    }

    /**
     * 收款（from 商户）结果失败通知
     */
    /*@ApiOperation("收款（from 商户）结果失败通知")
    @PostMapping("/failReceivableFromMer")
    fun failReceivableFromMer(@RequestParam repayPlanId: String): WebResult<Void> {
        refundService.failReceivableFromMer(repayPlanId)
        return ResEnum.success()
    }*/
}