package com.fina.summer.app.manager.kafka

import com.alibaba.fastjson.JSONObject
import com.alibaba.fastjson.TypeReference
import com.fina.summer.manager.entity.dto.DeductNotice
import com.fina.summer.manager.impl.operate.OperateReceivableService
import com.fina.summer.persistent.ceres.entity.domain.FailHandleFromKafkaPO
import com.fina.summer.persistent.ceres.repo.FailHandleFromKafkaRepo
import org.apache.kafka.clients.consumer.ConsumerRecord
import org.slf4j.LoggerFactory
import org.springframework.kafka.annotation.KafkaListener
import org.springframework.stereotype.Component
import java.util.*

@Component
class CeresDeductNoticeListener(
        private val operateReceivableService: OperateReceivableService,
        private val failHandleFromKafkaRepo: FailHandleFromKafkaRepo
) {
    private val logger = LoggerFactory.getLogger(CeresDeductNoticeListener::class.java)

    @KafkaListener(topics = ["ceres-deduct-notice"])
    fun deductNotify(record: ConsumerRecord<Any, Any>) {
        val value = record.value() as String
        val clazz = object : TypeReference<DeductNotice>() {}.type!!
        logger.debug("kafka topic:ceres-deduct-notice, value:$value")
        val monitorData = JSONObject.parseObject<DeductNotice>(value, clazz)!!
        try {
            operateReceivableService.deductNotice(monitorData)
        } catch (e: Exception) {
            logger.error("kafka[ ceres-deduct-notice ] error...", e)
            val now = Date()
            failHandleFromKafkaRepo.save(FailHandleFromKafkaPO(
                    topic = "ceres-deduct-notice",
                    kafkaKey = null,
                    kafkaValue = value,
                    createdTime = now,
                    updatedTime = now
            ))
        }
    }
}