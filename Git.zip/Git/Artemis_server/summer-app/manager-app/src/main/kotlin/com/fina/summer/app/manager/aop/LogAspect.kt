package com.fina.summer.app.manager.aop

import com.alibaba.fastjson.JSONObject
import com.fina.summer.auth.core.shiro.SessionUtils
import com.fina.summer.core.utils.GetIpAddress
import com.fina.summer.manager.impl.user.UserService
import com.fina.summer.persistent.artemis.repo.user.ManagerUserRepo
import org.aspectj.lang.ProceedingJoinPoint
import org.aspectj.lang.annotation.Around
import org.aspectj.lang.annotation.Aspect
import org.aspectj.lang.annotation.Pointcut
import org.slf4j.Logger
import org.slf4j.LoggerFactory
import org.springframework.stereotype.Component
import org.springframework.util.StringUtils
import org.springframework.web.context.request.RequestContextHolder
import org.springframework.web.context.request.ServletRequestAttributes


@Aspect
@Component
class LogAspect(
        private val userService: UserService,
        private val managerUserRepo: ManagerUserRepo
) {

    private val logger: Logger = LoggerFactory.getLogger(LogAspect::class.java)

    @Pointcut("execution(public * com.fina.summer.app.manager.controller..*.*(..))")
    private fun controllerAspect() {}

    @Around(value = "controllerAspect()")
    @Throws(Throwable::class)
    fun methodAround(joinPoint: ProceedingJoinPoint): Any {
        val requestAttributes = RequestContextHolder
                .getRequestAttributes() as ServletRequestAttributes?
        val request = requestAttributes!!.request

        val beginTime = System.currentTimeMillis()

        val requestIp = GetIpAddress.getClientIp(request)
        val requestAddress = request.requestURI.toString()
        val requestWay = request.method
        val requestMethod = joinPoint.signature.toString()
        val requestParam = JSONObject.toJSONString(joinPoint.args)

        val result = joinPoint.proceed()

        val endTime = System.currentTimeMillis()
        val requestTime = endTime - beginTime
        val resultJson = JSONObject.toJSONString(result)

        var loginName = ""
        val userId = SessionUtils.currentUserId()
        if (!StringUtils.isEmpty(userId)) {
            val optional = managerUserRepo.findById(userId!!)
            if (optional.isPresent) {
                loginName = optional.get().loginName!!
            }
        }


        logger.debug("request log - {" +
                "login_name:$loginName," +
                "request_ip:$requestIp, " +
                "request_address:$requestAddress, " +
                "request_way:$requestWay, " +
                "request_method:$requestMethod, " +
                "request_params:$requestParam, " +
                "consuming_time:$requestTime, " +
                "result:$resultJson}")

        return result
    }

}