package com.fina.summer.app.manager.controller.operate


import com.fina.cmcc.entity.CloudResp
import com.fina.summer.core.bean.PageResult
import com.fina.summer.core.respone.ResEnum
import com.fina.summer.manager.batch.SmsNotificationService
import com.fina.summer.persistent.ceres.entity.vo.SmsResult
import io.swagger.annotations.ApiOperation
import org.slf4j.Logger
import org.slf4j.LoggerFactory
import org.springframework.web.bind.annotation.*
import javax.jws.WebResult


@RestController
@RequestMapping("/operate/sendSms")
class SmsNotificationController (
        private val smsNotificationService: SmsNotificationService
){
    private val logger: Logger = LoggerFactory.getLogger(SmsNotificationController::class.java)


    @ApiOperation("正常提醒")
    @GetMapping("/sendFirst")
    fun sendSmsFirst(): CloudResp<String> {
        return smsNotificationService.getInfoAboutSendSms()
    }

    @ApiOperation("逾期提醒")
    @GetMapping("/sendMultiphase")
    fun sendSmsMultiphase():CloudResp<String>{
        return smsNotificationService.getInfoAboutMultiphase()
    }

    @ApiOperation("接收短信结果")
    @PostMapping("/sendResults")
    fun sendSmsMore(@RequestBody smsResult:SmsResult):String{
        return smsNotificationService.getResults(smsResult)
    }

    @ApiOperation("代扣代缴")
    @GetMapping("/sendSmsWithholding")
    fun sendSmsWithholding():CloudResp<String>{
        return smsNotificationService.getInfoAboutWithholding()
    }

}