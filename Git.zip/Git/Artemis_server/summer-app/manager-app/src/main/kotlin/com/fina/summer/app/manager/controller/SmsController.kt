package com.fina.summer.app.manager.controller

import com.fina.summer.common.sms.SmsService
import com.fina.summer.core.enum.SmsType
import com.fina.summer.core.handler.SimpleException
import com.fina.summer.core.respone.ResEnum
import com.fina.summer.core.respone.WebResult
import com.fina.summer.manager.client.entity.Returnsms
import com.fina.summer.manager.entity.bo.ReceivableSmsResult
import com.fina.summer.manager.entity.dto.SmsReceivableTO
import com.fina.summer.manager.impl.SmsRService
import com.fina.summer.persistent.ceres.entity.domain.ShortMessagePO
import com.fina.summer.persistent.ceres.repo.ShortMessageRepo
import io.swagger.annotations.Api
import io.swagger.annotations.ApiImplicitParam
import io.swagger.annotations.ApiImplicitParams
import io.swagger.annotations.ApiOperation
import org.springframework.util.CollectionUtils
import org.springframework.web.bind.annotation.*

@Api(tags = ["短信Api"])
@CrossOrigin
@RestController
@RequestMapping("/sms")
class SmsController(
        private val smsService: SmsService,
        private val smsRService: SmsRService,
        private val shortMessageRepo: ShortMessageRepo
) {
    @ApiOperation("登录短信验证码接口")
    @ApiImplicitParams(ApiImplicitParam(name = "mobile", value = "手机号", required = true, dataType = "String"))
    @PostMapping("/loginCode")
    fun sendLoginCode(@RequestParam mobile: String): WebResult<Void> {
        smsService.send(SmsType.Login, mobile)
        return ResEnum.success()
    }

    /**
     * 扣款短信接口
     */
    @ApiOperation("扣款短信")
    @PostMapping("/batchSendReceivable")
    fun sendReceivable(@RequestBody smsReceivableTO: SmsReceivableTO): WebResult<ReceivableSmsResult> {
        if (smsReceivableTO.id == null || CollectionUtils.isEmpty(smsReceivableTO.taskIds)) {
            throw SimpleException(ResEnum.ParamErr.getCode(), "未选择模板或发送对象")
        }
        return ResEnum.success(smsRService.batchSendReceivable(smsReceivableTO.id!!, smsReceivableTO.taskIds!!))
    }

    /**
     * 扣款短信接口(提前3天提醒：数仓调用)
     */
    @ApiOperation("扣款短信接口(提前3天提醒：数仓调用)")
    @ApiImplicitParams(ApiImplicitParam(name = "shortMessageId", value = "短信模板id", required = true, dataType = "Int"),
                       ApiImplicitParam(name = "taskId", value = "还款任务id", required = true, dataType = "String"))
    @PostMapping("/sendRemind")
    fun sendRemind(@RequestParam shortMessageId: Long, @RequestParam taskId: String): WebResult<Void> {
        return if (smsRService.sendRemindAndFail(shortMessageId, taskId)) ResEnum.success() else ResEnum.fail("短信发送失败")
    }

    /**
     * 扣款短信
     */
    @PostMapping("/sendByContent")
    fun sendByContent(@RequestParam mobile: String, @RequestParam content: String): WebResult<Returnsms> {
        return ResEnum.success(smsRService.send(mobile, content))
    }

    /**
     * 扣款短信模板列表查询
     */
    @ApiOperation("扣款短信模板列表查询")
    @PostMapping("/receivableTemplates")
    fun receivableTemplates(): WebResult<List<ShortMessagePO>> {
        return ResEnum.success(shortMessageRepo.findAll())
    }



}