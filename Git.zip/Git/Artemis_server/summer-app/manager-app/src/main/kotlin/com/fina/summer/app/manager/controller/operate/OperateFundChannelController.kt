package com.fina.summer.app.manager.controller.operate

import com.fina.summer.core.respone.WebResult
import com.fina.summer.manager.impl.operate.OperateFundChannelService
import com.fina.summer.persistent.ceres.entity.vo.FundChannelVO
import io.swagger.annotations.Api
import io.swagger.annotations.ApiOperation
import org.springframework.web.bind.annotation.PostMapping
import org.springframework.web.bind.annotation.RequestBody
import org.springframework.web.bind.annotation.RequestMapping
import org.springframework.web.bind.annotation.RestController
import javax.transaction.Transactional

@Api(tags = ["[运营后台]资金方修改"])
@RestController
@RequestMapping("/operate")
class OperateFundChannelController(
        private val operateFundChannelService: OperateFundChannelService
) {
    /**
     * 资金方修改接口
     * param tradeId String
     */
    @ApiOperation("还款接口")
    @Transactional
    @PostMapping("/operateFundChannel")
    fun operateFundChannel(@RequestBody fundChannelVOList : List<FundChannelVO>): WebResult<Void> {
       return operateFundChannelService.operateFundChannel(fundChannelVOList)
    }


}