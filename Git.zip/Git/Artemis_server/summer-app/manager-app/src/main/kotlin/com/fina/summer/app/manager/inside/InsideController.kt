package com.fina.summer.app.manager.inside

import com.fina.summer.app.manager.controller.SmsController
import com.fina.summer.app.manager.controller.finance.PayableController
import com.fina.summer.app.manager.controller.operate.*
import com.fina.summer.core.respone.ResEnum
import com.fina.summer.core.respone.WebResult
import com.fina.summer.manager.entity.bo.BatchDeductBO
import com.fina.summer.manager.impl.operate.AccountsPayableService
import com.fina.summer.persistent.ceres.entity.vo.*
import io.swagger.annotations.Api
import io.swagger.annotations.ApiOperation
import org.slf4j.LoggerFactory
import org.springframework.web.bind.annotation.*
import javax.transaction.Transactional

@Api(tags = ["内部调用接口"])
@RestController
@RequestMapping("/inside")
class InsideController(
        private val smsController: SmsController,
        private val payableController: PayableController,
        private val operateReceivableController: OperateReceivableController,
        private val redEnvelopesController: RedEnvelopesController,
        private val operateTopUpController: OperateTopupController,
        private val operateFundChannelController: OperateFundChannelController,
        private val bindingAndChangingCardController: BindingAndChangingCardController,
        private val AccountsPayableService: AccountsPayableService
) {

    private val logger = LoggerFactory.getLogger(InsideController::class.java)

    /**
     * 扣款短信接口(提前3天提醒：数仓调用)
     */
    @ApiOperation("扣款短信接口(提前3天提醒：数仓调用)")
    @PostMapping("/sendRemind")
    fun sendRemind(@RequestParam shortMessageId: Long, @RequestParam taskId: String): WebResult<Void> {
        logger.info("内部接口调用开始请求：扣款短信【请求参数：$shortMessageId,$taskId】")
        return smsController.sendRemind(shortMessageId, taskId)
    }

    /**
     * 打款/收款数据缺失补录
     */
    @ApiOperation("打款数据缺失补录")
    @PostMapping("/dataSupplement")
    fun dataSupplement(@RequestBody planIds: List<String>): WebResult<Void>{
        logger.info("内部接口调用开始请求：打款数据缺失补录【请求参数：$planIds】")
        return payableController.dataSupplement(planIds)
    }

    /**
     * 扣款
     */
    @ApiOperation("扣款")
    @PostMapping("/batchDeduct")
    fun batchDeduct(@RequestBody deductVO: DeductVO): WebResult<BatchDeductBO> {
        logger.info("内部接口调用开始请求：扣款【请求参数：$deductVO】")
        return operateReceivableController.batchDeduct(deductVO)
    }

    /**
     * 红包发放
     */
    @ApiOperation("红包发放")
    @PostMapping("/outRedEnvelopes")
    fun outRedEnvelopes(@RequestBody list: List<String>): WebResult<BatchDeductBO>{
        logger.info("内部接口调用开始请求：红包发放【请求参数：$list】")
        return redEnvelopesController.outRedEnvelopes(list)
    }

    /**
     * 充值
     */
    @ApiOperation("充值")
    @PostMapping("/moreCredit")
    fun recharge(@RequestBody ids : List<String>) : WebResult<BatchDeductBO>{
        logger.info("内部接口调用开始请求：充值【请求参数：$ids】")
        return operateTopUpController.recharge(ids)
    }

    /**
     * 储蓄卡绑定与更换接口
     */
    @ApiOperation("储蓄卡绑定与更换接口")
    @PostMapping("/bindingAndChanginggCard")
    fun bindingAndChangingCard(@RequestBody bingdingAndChangingCardVO: BingdingAndChangingCardVO): WebResult<Void> {
        return  bindingAndChangingCardController.bindingAndChangingCard(bingdingAndChangingCardVO)
    }

    /**
     * 资金方修改接口
     * param tradeId String
     */
    @ApiOperation("还款接口")
    @PostMapping("/operateFundChannel")
    fun operateFundChannel(@RequestBody fundChannelVOList : List<FundChannelVO>): WebResult<Void> {
        return operateFundChannelController.operateFundChannel(fundChannelVOList)
    }


    @ApiOperation("批量审核确认")
    @Transactional
    @PostMapping("/batchAuditConfirm")
    fun batchAuditConfirm(@RequestBody batchAuditVO: BatchAuditVO): WebResult<List<String>> {
        logger.info("开始批量审核确认修改数据；请求参数-【$batchAuditVO】")
        val list =  AccountsPayableService.batchAuditConfirm(batchAuditVO)
        logger.info("批量审核确认修改数据接口请求结束；修改订单-【${batchAuditVO.success}】")
        return ResEnum.success(list)
    }

    /**
     * 收款接口
     * param startTime String            该日应打款订单时间
     */
    @ApiOperation("收款")
    @Transactional
    @PostMapping("/change")
    fun change(@RequestBody accountPayableVO: AccountPayableVO): WebResult<Void> {
        logger.info("开始线下审核确认修改数据；请求参数-【$accountPayableVO】")
        val msg = AccountsPayableService.change(accountPayableVO)
        logger.info("线下审核确认修改数据接口请求结束；修改订单编号-【${accountPayableVO.outTaskId}】")
        return msg
    }

//    /**
//     * 接受催收通知接口
//     * param startTime String            该日应打款订单时间
//     */
//    @ApiOperation("接受催收通知接口")
//    @PostMapping("/collection")
//    fun collection(@RequestBody ids: List<String>): WebResult<Void> {
//        logger.info("开始线下审核确认修改数据；请求参数-【$ids】")
//        val msg = collectionTaskJobService.collection(ids)
//        logger.info("线下审核确认修改数据接口请求结束；修改订单编号-【$ids】")
//        return msg
//    }
}