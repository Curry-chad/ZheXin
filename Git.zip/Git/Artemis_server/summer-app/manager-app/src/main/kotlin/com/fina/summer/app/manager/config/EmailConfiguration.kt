package com.fina.summer.app.manager.config

import com.fina.summer.core.utils.EmailUtil
import org.springframework.context.annotation.Bean
import org.springframework.context.annotation.Configuration
import java.util.*

@Configuration
class EmailConfiguration(
        private val eep: EmailProperties
) {

    @Bean
    fun emailUtil(): EmailUtil {
        val emailUtil = EmailUtil()
        emailUtil.from = eep!!.account
        emailUtil.host = eep.host
        emailUtil.password = eep.password
        emailUtil.port = eep.port
        val toStr = eep.to
        val toArray = toStr!!.split(",".toRegex()).dropLastWhile { it.isEmpty() }.toTypedArray()
        val toList = Arrays.asList(*toArray)
        emailUtil.to = toList
        return emailUtil
    }
}
