package com.fina.summer.app.manager.controller

import com.fina.summer.core.respone.ResEnum
import com.fina.summer.core.respone.WebResult
import com.fina.summer.manager.impl.LituoService
import com.fina.summer.persistent.entity.summer.OrderVO
import com.fina.summer.persistent.entity.summer.SellerVO
import com.fina.summer.persistent.entity.summer.StoreVO
import io.swagger.annotations.Api
import io.swagger.annotations.ApiOperation
import org.apache.shiro.authz.annotation.RequiresUser
import org.springframework.web.bind.annotation.CrossOrigin
import org.springframework.web.bind.annotation.PostMapping
import org.springframework.web.bind.annotation.RequestMapping
import org.springframework.web.bind.annotation.RestController

@Api(tags = ["李拓后台Api"])
@CrossOrigin
@RestController
@RequestMapping("/lituo")
class LituoController(
        private val lituoService: LituoService
) {

    @ApiOperation("交易检索")
    @PostMapping("/order")
    @RequiresUser
    fun orderList(): WebResult<List<OrderVO>> {
        val list = lituoService.orderList()
        return ResEnum.success(list)
    }

    @ApiOperation("店员检索")
    @PostMapping("/seller")
    @RequiresUser
    fun sellerList(): WebResult<List<SellerVO>> {
        val list = lituoService.sellerList()
        return ResEnum.success(list)
    }

    @ApiOperation("门店检索")
    @PostMapping("/store")
    @RequiresUser
    fun storeList(): WebResult<List<StoreVO>> {
        val list = lituoService.storeList()
        return ResEnum.success(list)
    }

}