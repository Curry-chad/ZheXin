package com.fina.summer.app.manager.controller

import com.fina.summer.core.respone.ResEnum
import com.fina.summer.core.respone.WebResult
import io.swagger.annotations.Api
import org.springframework.web.bind.annotation.CrossOrigin
import org.springframework.web.bind.annotation.RequestMapping
import org.springframework.web.bind.annotation.RestController

@Api(tags = ["邮件发送Api"])
@CrossOrigin
@RestController
@RequestMapping("/email")
class EmailController {

    /**
     * 邮件发送
     */
    fun sendEmail(): WebResult<Void> {
        return ResEnum.success()
    }

}