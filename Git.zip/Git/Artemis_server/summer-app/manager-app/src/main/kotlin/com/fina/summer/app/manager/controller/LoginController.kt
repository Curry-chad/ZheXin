package com.fina.summer.app.manager.controller

import com.fina.summer.core.respone.ResEnum
import com.fina.summer.core.respone.WebResult
import com.fina.summer.manager.entity.bo.ManagerUserInfoBO
import com.fina.summer.manager.impl.user.LoginService
import io.swagger.annotations.Api
import io.swagger.annotations.ApiImplicitParam
import io.swagger.annotations.ApiImplicitParams
import io.swagger.annotations.ApiOperation
import org.springframework.web.bind.annotation.*

@Api(tags = ["登录Api"])
@CrossOrigin
@RestController
@RequestMapping
class LoginController(
        private val loginService: LoginService
) {

    @ApiOperation("登录")
    @ApiImplicitParams(ApiImplicitParam(name = "loginName", value = "登录用户名（限制手机号）", required = true, dataType = "String"),
            ApiImplicitParam(name = "password", value = "密码", required = true, dataType = "String"))
    @PostMapping("/login")
    fun login(@RequestParam loginName: String, @RequestParam password: String): WebResult<ManagerUserInfoBO> {
        val userInfo = loginService.login(loginName, password)
        return ResEnum.success(userInfo)
    }

    @ApiOperation("短信登录")
    @ApiImplicitParams(ApiImplicitParam(name = "mobile", value = "登录手机号", required = true, dataType = "String"),
            ApiImplicitParam(name = "verifyCode", value = "验证码", required = true, dataType = "String"))
    @PostMapping("/loginBySms")
    fun loginBySms(@RequestParam mobile: String, @RequestParam verifyCode: String): WebResult<ManagerUserInfoBO> {
        val userInfo = loginService.loginBySms(mobile, verifyCode)
        return ResEnum.success(userInfo)
    }

    @ApiOperation("注销")
    @PostMapping("/logout")
    fun logout(): WebResult<Void> {
        loginService.logout()
        return ResEnum.success()
    }

}