package com.fina.summer.app.manager.controller.operate

import com.fina.summer.core.bean.PageResult
import com.fina.summer.core.respone.ResEnum
import com.fina.summer.core.respone.WebResult
import com.fina.summer.manager.entity.bo.BatchDeductBO
import com.fina.summer.manager.impl.operate.RedEnvelopesService
import com.fina.summer.persistent.ceres.entity.vo.RedEnvelopesNumVo
import com.fina.summer.persistent.ceres.entity.vo.RedEnvelopesPlanVO
import com.fina.summer.persistent.ceres.entity.vo.RedEnvelopesVO
import io.swagger.annotations.Api
import io.swagger.annotations.ApiOperation
import org.slf4j.Logger
import org.slf4j.LoggerFactory
import org.springframework.web.bind.annotation.*

@Api(tags = ["[运营后台]微信红包Api"])
@RestController
@RequestMapping("/operate/redEnvelopes")
class RedEnvelopesController(
        private val redEnvelopesService: RedEnvelopesService
) {

    private val logger: Logger = LoggerFactory.getLogger(OperateTopupController::class.java)

    /**
     * 红包列表展示
     */
    @ApiOperation("红包列表")
    @PostMapping("/list")
    fun list(@RequestBody redEnvelopesVO: RedEnvelopesVO) : WebResult<PageResult<RedEnvelopesPlanVO>> {
        var list = redEnvelopesService.list(redEnvelopesVO)
        return ResEnum.success(list)
    }

    /**
     * 红包数量/金额
     */
    @ApiOperation("红包数量/金额")
    @PostMapping("/num")
    fun redEnvelopesNum(@RequestBody redEnvelopesVO: RedEnvelopesVO): WebResult<List<RedEnvelopesNumVo>>{
        var list = redEnvelopesService.redEnvelopesNum(redEnvelopesVO)
        return ResEnum.success(list)
    }

    /**
     * 红包发放
     */
    @ApiOperation("红包发放")
    @PostMapping("/outRedEnvelopes")
    fun outRedEnvelopes(@RequestBody list: List<String>): WebResult<BatchDeductBO>{
        val bo = redEnvelopesService.outRedEnvelopes(list)
        return ResEnum.success(bo)
    }

    /**
     *手动红包发放，数据状态变更
     */
    @ApiOperation("红包发放")
    @PostMapping("/artificialRedEnvelope")
    fun artificialRedEnvelope(@RequestParam id: String): WebResult<Void> {
        var web = redEnvelopesService.artificialRedEnvelope(id)
        if(web.code == "99"){
            return ResEnum.fail("数据更新失败，数据不存在")
        }
        return ResEnum.success()
    }
}