package com.fina.summer.app.manager.kafka

import java.io.Serializable

data class KafkaTO<T>(

        var data: T? = null,

        var type: String? = null

): Serializable