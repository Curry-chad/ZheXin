package com.fina.summer.app.manager.controller.operate

import com.fina.summer.core.respone.ResEnum
import com.fina.summer.core.respone.WebResult
import com.fina.summer.core.utils.ConcurrentTask
import com.fina.summer.core.utils.DataUtil
import com.fina.summer.manager.batch.BatchDeductService
import com.fina.summer.manager.batch.BatchRepairOutTasks
import com.fina.summer.manager.client.SummerClient
import com.fina.summer.manager.entity.bo.BatchDeductBO
import com.fina.summer.manager.entity.bo.DeductBO
import com.fina.summer.manager.impl.operate.OperateReceivableService
import com.fina.summer.persistent.ceres.entity.domain.FailDeductPO
import com.fina.summer.persistent.ceres.entity.vo.DeductVO
import com.fina.summer.persistent.ceres.repo.BillInTasksRepo
import com.fina.summer.persistent.ceres.repo.FailDeductRepo
import io.swagger.annotations.Api
import io.swagger.annotations.ApiOperation
import org.slf4j.Logger
import org.slf4j.LoggerFactory
import org.springframework.web.bind.annotation.*
import java.util.*
import java.util.concurrent.Callable
import java.util.concurrent.ThreadPoolExecutor

@Api(tags = ["[运营后台]应收账款Api"])
@RestController
@RequestMapping("/operate/receivable")
class OperateReceivableController(
        private val operateReceivableService: OperateReceivableService,
        private val summerClient: SummerClient,
        private val billInTasksRepo: BillInTasksRepo,
        private val failDeductRepo: FailDeductRepo,
        private val batchDeductService: BatchDeductService,
        private val asyncTaskPool: ThreadPoolExecutor,
        private val batchRepairOutTasks: BatchRepairOutTasks
) {

    private val logger:Logger = LoggerFactory.getLogger(OperateReceivableController::class.java)

    /**
     * 测试
     */
    @ApiOperation("测试")
    @PostMapping("/test")
    fun test(): WebResult<Void> {
        return ResEnum.success()
    }


    /**
     * 测试修复数据
     */
    @ApiOperation("测试修复数据")
    @PostMapping("/testRepair")
    fun testRepair(): WebResult<Void> {
        batchRepairOutTasks.repairOutTasks()
        return ResEnum.success()
    }
    /**
     *
     * @author zhengqiyang@zhexinit.com
     * @date 2019/5/16 11:50
     * @param []
     * @return Any
     * @description 批量扣款，适用于代扣代缴不兜底
     */
    @ApiOperation("批量扣款，适用于代扣代缴不兜底")
    @PostMapping("/batchDeductRevealBottom")
    fun batchDeductRevealBottom(): WebResult<Void>{
        logger.info("开始代扣代缴不兜底业务中的代扣任务---------")
        batchDeductService.batchDeduct()
        logger.info("开始代扣代缴不兜底业务中的代扣任务---------")
        return ResEnum.success()
    }

    /**
     * 扣款
     */
    @ApiOperation("扣款")
    @PostMapping("/batchDeduct")
    fun batchDeduct(@RequestBody deductVO: DeductVO): WebResult<BatchDeductBO> {
        logger.info("扣款请求参数：【$deductVO】")
        var successCount = 0
        var failCount = 0    //失败总条数
        var successAmount = 0
        var failAmount = 0  //
        val ids = deductVO.ids!!  //扣款订单ids（集合）

        val c = ConcurrentTask<DeductBO>(asyncTaskPool)
        ids.forEach {

            c.submit(Callable {
                return@Callable deduct(it, deductVO)
            })
        }
        val resultList = c.getAll()  //获取结果集
        resultList.forEach { bo ->

            if (bo.success!!) { //成功次数+1 总金额+=本次金额
                successCount++
                successAmount += bo.amount!!
            } else {
                failCount++
                val taskAmount = bo.amount
                if (taskAmount != null) {
                    failAmount += taskAmount
                }
            }
        }
        return ResEnum.success(BatchDeductBO(
                successCount = successCount,
                failCount = failCount,
                successAmount = DataUtil.convertDecimal(successAmount.toString()),
                failAmount = DataUtil.convertDecimal(failAmount.toString())
        ))
    }

    fun deduct(taskId: String, deductVO: DeductVO): DeductBO {
        val now = Date()
        try {
            val bo = operateReceivableService.deduct(taskId, deductVO)
            if (!bo.success!!) {  //失败
                // TODO 扣款失败记录入库
                failDeductRepo.save(FailDeductPO(
                        bisTaskId = null,
                        taskId = taskId,
                        message = bo.msg,
                        amount = bo.amount,
                        createdTime = now,
                        updatedTime = now
                ))
                logger.debug("deduct fail: [task id: $taskId, fail amount: ${bo.amount}, fail msg: ${bo.msg}]")
            }
            return bo
        } catch (e: Exception) {
            val bo = DeductBO(success = false)
            val option = billInTasksRepo.findById(taskId)
            var taskAmount: Int? = 0
            if (option.isPresent) {
                val task = option.get()
                taskAmount = task.totalAmount
                if (taskAmount != null) {
                    bo.amount = taskAmount
                }
            }
            // TODO 扣款失败记录入库
            failDeductRepo.save(FailDeductPO(
                    bisTaskId = null,
                    taskId = taskId,
                    message = e.message,
                    amount = taskAmount,
                    createdTime = now,
                    updatedTime = now
            ))
            logger.error("错误task编号[$taskId]: failAmount:[$taskAmount], deduct error...", e)
            return bo
        }
    }

    /**
     * 申请核查
     */
    @ApiOperation("申请核查")
    @PostMapping("/applyCheck")
    fun applyCheck(@RequestParam id: String):WebResult<Void> {
        operateReceivableService.applyCheck(id)
        return ResEnum.success()
    }


}