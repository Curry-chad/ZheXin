package com.fina.summer.app.manager.controller

import com.fina.metis.auth.client.SsoFilter
import com.fina.summer.core.respone.ResEnum
import com.fina.summer.core.respone.WebResult
import com.fina.summer.manager.impl.operate.TradeTaskNotifyService
import io.swagger.annotations.Api
import io.swagger.annotations.ApiOperation
import org.apache.dubbo.common.logger.LoggerFactory
import org.springframework.web.bind.annotation.PostMapping
import org.springframework.web.bind.annotation.RequestMapping
import org.springframework.web.bind.annotation.RestController


@Api(tags = ["测试代扣代缴Api"])
@RestController
@RequestMapping("/finance/testnotify")
class BaseNotifyController(
        private val tradeTaskNotifyService: TradeTaskNotifyService
){
    private val logger = LoggerFactory.getLogger(BaseNotifyController::class.java)



    @ApiOperation("生成代扣任务")
    @PostMapping("/createreduct")
    fun createReduct(repayPlanId: String): WebResult<Void> {
        logger.info("----------------开始生成任务--B2428036265760890885---------------")
        tradeTaskNotifyService.saveRepayPlanAndTasks(repayPlanId)
        logger.info("----------------结束生成任务-----------------")
        return ResEnum.success()
    }

    @ApiOperation("生成代缴任务")
    @PostMapping("/createRe")
    fun createRe(repayPlanId: String): WebResult<Void> {
        logger.info("----------------开始生成任务-----------------")
        tradeTaskNotifyService.saveMerRemitAndTasks(repayPlanId)
        logger.info("----------------结束生成任务-----------------")
        return ResEnum.success()
    }
}

