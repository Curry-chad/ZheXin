package com.fina.summer.app.manager.controller.data.business

import com.fina.summer.core.respone.ResEnum
import com.fina.summer.core.respone.WebResult
import com.fina.summer.manager.IStatisticsService
import com.fina.summer.persistent.summer.entity.vo.SumAllVo
import io.swagger.annotations.Api
import io.swagger.annotations.ApiOperation
import org.springframework.web.bind.annotation.PostMapping
import org.springframework.web.bind.annotation.RequestMapping
import org.springframework.web.bind.annotation.RestController

@Api(tags = ["业务统计报表Api"])
@RestController
@RequestMapping("/data/business/statistics")
class StatisticsController(
        private val statisticsService: IStatisticsService
) {

    @ApiOperation("当前全部订单统计数据")
    @PostMapping("/sumAll")
    fun sumAll(): WebResult<SumAllVo> {
        return ResEnum.success(statisticsService.findByAll())
    }




}