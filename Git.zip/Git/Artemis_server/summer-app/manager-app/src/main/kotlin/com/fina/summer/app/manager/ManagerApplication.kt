package com.fina.summer.app.manager

import com.fasterxml.jackson.databind.module.SimpleModule
import com.fina.summer.core.utils.IdGenerator
import com.fina.summer.core.utils.TrimStringDeserializer
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.boot.CommandLineRunner
import org.springframework.boot.autoconfigure.SpringBootApplication
import org.springframework.boot.runApplication
import org.springframework.cloud.client.discovery.EnableDiscoveryClient
import org.springframework.cloud.netflix.eureka.EurekaClientConfigBean
import org.springframework.cloud.openfeign.EnableFeignClients
import org.springframework.context.annotation.Bean
import org.springframework.context.annotation.Primary
import org.springframework.core.env.ConfigurableEnvironment
import org.springframework.core.env.Environment
import org.springframework.core.env.PropertyResolver
import org.springframework.data.jpa.repository.config.EnableJpaAuditing
import org.springframework.http.converter.HttpMessageConverter
import org.springframework.http.converter.json.MappingJackson2HttpMessageConverter
import org.springframework.scheduling.annotation.EnableScheduling
import org.springframework.transaction.annotation.EnableTransactionManagement
import org.springframework.web.client.RestTemplate
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer
import springfox.documentation.swagger2.annotations.EnableSwagger2
import java.util.concurrent.LinkedBlockingQueue
import java.util.concurrent.ThreadPoolExecutor
import java.util.concurrent.TimeUnit


@EnableSwagger2
@SpringBootApplication(scanBasePackages = ["com.fina.summer", "com.smart.sso","com.fina.cmcc"])
@EnableDiscoveryClient
@EnableJpaAuditing
@EnableScheduling
@EnableTransactionManagement
@EnableFeignClients(basePackages = ["com.fina","com.fina.cmcc"])
class ManagerApplication : WebMvcConfigurer, CommandLineRunner {


    @Autowired
    lateinit var eurekaClientConfigBean: EurekaClientConfigBean
    @Autowired
    lateinit var  environment: Environment
    override fun run(vararg args: String?) {
        eurekaClientConfigBean.propertyResolver = environment
    }

    override fun extendMessageConverters(converters: MutableList<HttpMessageConverter<*>>) {
        //对String类型的数据自动trim处理
        converters.forEach { t: HttpMessageConverter<*>? ->
            if (t is MappingJackson2HttpMessageConverter) {
                val module = SimpleModule()
                module.addDeserializer(String::class.java, TrimStringDeserializer())
                t.objectMapper.registerModule(module)
                return super.extendMessageConverters(converters)
            }
        }
    }

    @Bean(name = ["redPackThreadPool"])
    fun asyncTaskPool(): ThreadPoolExecutor {
        return ThreadPoolExecutor(2, 64, 60L, TimeUnit.SECONDS,
                LinkedBlockingQueue())
    }

    @Bean
    fun idGenerator(): IdGenerator {
        return IdGenerator
    }


//    @Bean
//    fun filterRegistrationBean(): FilterRegistrationBean<*> {
//        val filterRegistration = FilterRegistrationBean<Filter>()
//        filterRegistration.filter = DelegatingFilterProxy("shiroFilter")
//        filterRegistration.isEnabled = true
//        filterRegistration.addUrlPatterns("/*")
//        filterRegistration.setDispatcherTypes(DispatcherType.REQUEST)
//        return filterRegistration
//    }

    @Bean
    fun restTemplate(): RestTemplate {
        return RestTemplate()
    }

    @Primary
    @Bean
    fun primaryPropertyResolver(environment: ConfigurableEnvironment): PropertyResolver {
        return environment
    }

}

fun main(args: Array<String>) {
    runApplication<ManagerApplication>(*args/*, "--debug"*/)
}
