package com.fina.summer.app.manager.controller.operate

import com.fina.summer.core.respone.ResEnum
import com.fina.summer.core.respone.WebResult
import com.fina.summer.manager.entity.bo.BillInInfoBO
import com.fina.summer.manager.impl.operate.NotifyService
import io.swagger.annotations.Api
import io.swagger.annotations.ApiImplicitParam
import io.swagger.annotations.ApiOperation
import org.springframework.web.bind.annotation.PostMapping
import org.springframework.web.bind.annotation.RequestMapping
import org.springframework.web.bind.annotation.RequestParam
import org.springframework.web.bind.annotation.RestController

@Api(tags = ["[运营后台]回调Api"])
@RestController
@RequestMapping("/operate/notify")
class OperateNotifyController(
        private val notifyService: NotifyService
) {
    /**
     * 获取用户还款计划
     */
    @ApiOperation("获取用户还款计划")
    @ApiImplicitParam(name = "bisTaskId", value = "收款计划总表id", required = true, dataType = "String")
    @PostMapping("/getBillTaskInfo")
    fun getBillTaskInfo(@RequestParam bisTaskId: String): WebResult<BillInInfoBO> {
        val list = notifyService.getBillTaskInfo(bisTaskId)
        return ResEnum.success(list)
    }

}