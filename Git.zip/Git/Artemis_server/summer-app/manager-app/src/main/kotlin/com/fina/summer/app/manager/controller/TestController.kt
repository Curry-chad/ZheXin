package com.fina.summer.app.manager.controller

import com.fina.summer.core.respone.ResEnum
import com.fina.summer.core.respone.WebResult
import org.springframework.kafka.core.KafkaTemplate
import org.springframework.web.bind.annotation.PostMapping
import org.springframework.web.bind.annotation.RequestMapping
import org.springframework.web.bind.annotation.RestController

@RestController
@RequestMapping("test")
class TestController(
        private val kafkaTemplate: KafkaTemplate<String, String>
) {

    @PostMapping("test")
    fun test(): WebResult<Void> {
       /* kafkaTemplate.send("trade_task_notify", JSONObject.toJSONString(KafkaTO(type = "repay_create", data = RepayCreateIdTO(id = "TRP262999129787895808"))))
        kafkaTemplate.send("trade_task_notify", JSONObject.toJSONString(KafkaTO(type = "remit_create", data = RepayCreateIdTO(id = "TMR262999129569792000"))))
        kafkaTemplate.send("trade_task_notify", JSONObject.toJSONString(KafkaTO(type = "repay_create", data = RepayCreateIdTO(id = "TRP262999130496733184"))))
*/
        /*kafkaTemplate.send("trade_task_notify", JSONObject.toJSONString(KafkaTO(type = "repay_invalid", data = RepayCreateIdTO(id = "TRP263031424401973248"))))
        kafkaTemplate.send("trade_task_notify", JSONObject.toJSONString(KafkaTO(type = "remit_invalid", data = RepayCreateIdTO(id = "TMR263031422451621888"))))
*/
        return ResEnum.success()
    }

}