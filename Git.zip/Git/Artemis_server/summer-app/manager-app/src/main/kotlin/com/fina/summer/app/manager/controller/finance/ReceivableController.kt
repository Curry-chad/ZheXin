package com.fina.summer.app.manager.controller.finance

import com.fina.summer.core.respone.ResEnum
import com.fina.summer.core.respone.WebResult
import com.fina.summer.manager.entity.bo.RepayInfoBO
import com.fina.summer.manager.entity.dto.ReceivableDTO
import com.fina.summer.manager.impl.finance.ReceivableService
import io.swagger.annotations.Api
import io.swagger.annotations.ApiOperation
import org.springframework.web.bind.annotation.PostMapping
import org.springframework.web.bind.annotation.RequestBody
import org.springframework.web.bind.annotation.RequestMapping
import org.springframework.web.bind.annotation.RestController

@Api(tags = ["应收账款Api"])
@RestController
@RequestMapping("/finance/receivable")
class ReceivableController(
        private val receivableService: ReceivableService
) {

    @ApiOperation("获取应收账单列表")
    @PostMapping("/list")
    fun list(@RequestBody receivableDTO: ReceivableDTO): WebResult<List<RepayInfoBO>> {
        val dtoList = receivableService.list(receivableDTO)
        return ResEnum.success(dtoList)
    }

    /*fun list(@RequestBody receivableTO: ReceivableParam): WebResult<List<RepayPlanBO>> {
        val toList = receivableService.list(receivableTO)
        return ResEnum.success(toList)
    }*/

}