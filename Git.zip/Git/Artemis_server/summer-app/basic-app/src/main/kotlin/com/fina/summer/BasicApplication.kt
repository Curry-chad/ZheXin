package com.fina.summer

import com.fasterxml.jackson.databind.module.SimpleModule
import com.fina.summer.core.utils.IdGenerator
import com.fina.summer.core.utils.TrimStringDeserializer
import org.springframework.boot.autoconfigure.SpringBootApplication
import org.springframework.boot.runApplication
import org.springframework.cloud.client.discovery.EnableDiscoveryClient
import org.springframework.context.annotation.Bean
import org.springframework.data.jpa.repository.config.EnableJpaAuditing
import org.springframework.http.converter.HttpMessageConverter
import org.springframework.http.converter.json.MappingJackson2HttpMessageConverter
import org.springframework.scheduling.annotation.EnableScheduling
import org.springframework.transaction.annotation.EnableTransactionManagement
import org.springframework.web.client.RestTemplate
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer
import springfox.documentation.swagger2.annotations.EnableSwagger2


@EnableSwagger2
@SpringBootApplication(scanBasePackages = ["com.fina.summer"])
@EnableJpaAuditing
@EnableScheduling
@EnableTransactionManagement
@EnableDiscoveryClient
open class BasicApplication : WebMvcConfigurer {

    override fun extendMessageConverters(converters: MutableList<HttpMessageConverter<*>>) {
        //对String类型的数据自动trim处理
        converters.forEach { t: HttpMessageConverter<*>? ->
            if (t is MappingJackson2HttpMessageConverter) {
                val module = SimpleModule()
                module.addDeserializer(String::class.java, TrimStringDeserializer())
                t.objectMapper.registerModule(module)
                return super.extendMessageConverters(converters)
            }
        }
    }


    @Bean
    open fun idGenerator(): IdGenerator {
        return IdGenerator
    }

    @Bean
    open fun restTemplate(): RestTemplate {
        return RestTemplate()
    }

}

fun main(args: Array<String>) {
    runApplication<BasicApplication>(*args/*, "--debug"*/)
}
