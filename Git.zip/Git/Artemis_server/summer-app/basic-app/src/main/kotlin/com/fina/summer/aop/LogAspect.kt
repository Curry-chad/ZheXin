package com.fina.summer.aop

import com.alibaba.fastjson.JSONObject
import com.fina.summer.core.utils.GetIpAddress
import org.aspectj.lang.ProceedingJoinPoint
import org.aspectj.lang.annotation.Around
import org.aspectj.lang.annotation.Aspect
import org.aspectj.lang.annotation.Pointcut
import org.slf4j.Logger
import org.slf4j.LoggerFactory
import org.springframework.stereotype.Component
import org.springframework.web.context.request.RequestContextHolder
import org.springframework.web.context.request.ServletRequestAttributes
import java.util.*


@Aspect
@Component
class LogAspect {

    private val logger: Logger = LoggerFactory.getLogger(LogAspect::class.java)

    @Pointcut("execution(public * com.fina.summer.controller..*.*(..))")
    private fun controllerAspect() {}

    @Around(value = "controllerAspect()")
    @Throws(Throwable::class)
    fun methodAround(joinPoint: ProceedingJoinPoint): Any {
        val requestAttributes = RequestContextHolder
                .getRequestAttributes() as ServletRequestAttributes?
        val request = requestAttributes!!.request

        val beginTime = System.currentTimeMillis()

        val requestIp = GetIpAddress.getClientIp(request)
        val requestAddress = request.requestURI.toString()
        val requestWay = request.method
        val requestMethod = joinPoint.signature.toString()
        val requestParam = JSONObject.toJSONString(joinPoint.args)

        val requestId = UUID.randomUUID().toString().substring(0, 16)
        logger.debug("request log before - {" +
                "request_id:$requestId" +
                "request_ip:$requestIp, " +
                "request_address:$requestAddress, " +
                "request_way:$requestWay, " +
                "request_method:$requestMethod, " +
                "request_params:$requestParam}")

        val result = joinPoint.proceed()

        val endTime = System.currentTimeMillis()
        val requestTime = endTime - beginTime
        val resultJson = JSONObject.toJSONString(result)

        logger.debug("request log after - {" +
                "request_id:$requestId" +
                "consuming_time:$requestTime, " +
                "result:$resultJson}")

        return result
    }

}