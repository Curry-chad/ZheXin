package com.fina.summer.controller

import com.fina.summer.basic.client.constant.OrderType
import com.fina.summer.basic.client.entity.*
import com.fina.summer.basic.impl.HenanCMService
import org.springframework.web.bind.annotation.PostMapping
import org.springframework.web.bind.annotation.RequestBody
import org.springframework.web.bind.annotation.RequestMapping
import org.springframework.web.bind.annotation.RestController

@RestController
@RequestMapping("/henanCM")
class HenanCMController(
        private val henanCMService: HenanCMService
) {

    /**
     * 预校验接口
     */
    @PostMapping("/prodAccept")
    fun prodAccept(@RequestBody prodAcceptReq: ProdAcceptReq): CloudResp<ProdAcceptResp> {
        return henanCMService.prodAccept(prodAcceptReq)
    }

    /**
     * 购机消费分期记录接口
     */
    @PostMapping("/credit")
    fun credit(@RequestBody creditReq: CreditReq): CloudResp<CreditResp> {
        return henanCMService.credit(creditReq)
    }

    /**
     * 订单查询接口
     */
    @PostMapping("/crepchaseOrder")
    fun crepchaseOrder(@RequestBody crepchaseOrderReq: CrepchaseOrderReq): CloudResp<CrepchaseBusiResp> {
        //return henanCMService.crepchaseOrder(crepchaseOrderReq)
        return henanCMService.crepchase(CrepchaseReq(
                mobile = crepchaseOrderReq.mobile,
                prodPrcId = crepchaseOrderReq.prodPrcId,
                orderType = OrderType.ORDER
        ))
    }

    /**
     * 返销查询接口
     */
    @PostMapping("/crepchaseRollBack")
    fun crepchaseRollBack(@RequestBody crepchaseRollBackReq: CrepchaseRollBackReq): CloudResp<CrepchaseBusiResp> {
        //return henanCMService.crepchaseRollBack(crepchaseRollBackReq)
        return henanCMService.crepchase(CrepchaseReq(
                mobile = crepchaseRollBackReq.mobile,
                prodPrcId = crepchaseRollBackReq.prodPrcId,
                orderType = OrderType.ORDER
        ))
    }

}