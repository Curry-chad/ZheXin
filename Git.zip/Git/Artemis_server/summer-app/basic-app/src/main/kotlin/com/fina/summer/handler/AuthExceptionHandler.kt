package com.fina.summer.handler

import com.alibaba.fastjson.JSONObject
import com.fina.summer.basic.client.entity.CloudResp
import com.fina.summer.core.handler.SimpleException
import com.fina.summer.core.respone.ResEnum
import com.fina.summer.core.respone.WebResult
import com.fina.summer.core.utils.Id
import com.fina.summer.core.utils.IdGenerator
import org.slf4j.LoggerFactory
import org.springframework.http.HttpStatus
import org.springframework.validation.BindException
import org.springframework.web.bind.annotation.ControllerAdvice
import org.springframework.web.bind.annotation.ExceptionHandler
import org.springframework.web.bind.annotation.ResponseBody
import org.springframework.web.bind.annotation.ResponseStatus
import org.springframework.web.method.annotation.MethodArgumentTypeMismatchException
import java.lang.reflect.UndeclaredThrowableException
import javax.servlet.http.HttpServletRequest
import javax.servlet.http.HttpServletResponse

@ControllerAdvice
class AuthExceptionHandler {

    private val logger = LoggerFactory.getLogger(AuthExceptionHandler::class.java)

    //普通业务的异常会被这个方法捕获
    @ExceptionHandler(SimpleException::class)
    @ResponseStatus(HttpStatus.OK)
    @ResponseBody
    fun handleSimpleError(req: HttpServletRequest, rsp: HttpServletResponse, e: SimpleException): CloudResp<Void> {
        logger.warn("请求出现异常！---${e.getCode()}, ${e.getMsg()}" )
        return CloudResp.fail(e.getCode()!!, e.getMsg()!!)
    }

    @ExceptionHandler(UndeclaredThrowableException::class)
    @ResponseStatus(HttpStatus.OK)
    @ResponseBody
    fun handlerUndeclared(req: HttpServletRequest, rsp: HttpServletResponse, e: UndeclaredThrowableException): CloudResp<Void> {
        if (e.cause is SimpleException) {
            val ee = e.cause as SimpleException
            logger.warn("系统异常", e.cause!!.cause)
            return CloudResp.fail(ee.getCode()!!, ee.getMsg()!!)
        } else {
            val errNo = IdGenerator.nextId(Id.Error)
            logger.error("系统错误[{}]:", errNo, e)
            return CloudResp.fail("系统错误[$errNo]")
        }

    }

    //500的异常会被这个方法捕获
    @ExceptionHandler(Throwable::class)
    @ResponseStatus(HttpStatus.INTERNAL_SERVER_ERROR)
    @ResponseBody
    fun handleError(req: HttpServletRequest, rsp: HttpServletResponse, e: Exception): CloudResp<Void> {
        val errNo = IdGenerator.nextId(Id.Error)
        logger.error("系统错误[{}]:", errNo, e)
        return CloudResp.fail("系统错误[$errNo]")
    }


    @ExceptionHandler(BindException::class)
    @ResponseStatus(HttpStatus.OK)
    @ResponseBody
    fun handleValidError(req: HttpServletRequest, rsp: HttpServletResponse, e: BindException): CloudResp<Void> {
        var message = ""
        e.bindingResult.allErrors.forEach { message += it.defaultMessage + ";" }
        logger.warn("参数校验不通过！url:{},详情：{}", req.requestURL, message)
        return CloudResp.fail(message)
    }
}