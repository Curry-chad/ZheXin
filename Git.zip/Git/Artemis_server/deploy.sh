#!/bin/bash

ROOT_PATH=/opt/lee/summer
MODULE=summer-app/seller-app


#SRC_NAME=xingbook_mobile_point
#SVN_URL=svn://121.40.42.190/xinbao/server/xingbook/branches/${SRC_NAME}

git pull


mvn -Dmaven.test.skip=true clean install

${ROOT_PATH}/restart.sh
#${ROOT_PATH}/mgr_restart.sh
#${ROOT_PATH}/task_restart.sh
tail -f ${ROOT_PATH}/summer-app/seller-app/nohup.out