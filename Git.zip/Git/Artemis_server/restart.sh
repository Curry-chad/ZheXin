ROOT_PATH=/opt/lee/summer

echo "Stopping  zxapp"
 PROID=`ps -ef|grep Dserver.no=1001|grep -v grep|awk '{print $2}'`
    if [ -n "$PROID" ]; then
      echo "Kill process id - ${PROID}"
      kill -9 ${PROID}
      echo STOPPED
    else
      echo "No process running."
    fi

DEBUG='-agentlib:jdwp=transport=dt_socket,server=y,suspend=n,address=8765'

cd ${ROOT_PATH}/summer-app/seller-app
nohup java -Xmx512m -Xms512m  -jar -Dspring.profiles.active=dev -Dserver.no=1001 `ls ./target/*.jar` &
sleep 1
#tail -f ./nohup.out