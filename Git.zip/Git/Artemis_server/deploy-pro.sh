#!/bin/bash

ROOT_PATH=/opt/summer
MODULE=summer-app/seller-app

git pull


mvn -Dmaven.test.skip=true clean install

${ROOT_PATH}/restart-pro.sh
#${ROOT_PATH}/mgr_restart.sh
#${ROOT_PATH}/task_restart.sh
tail -f ${ROOT_PATH}/summer-app/seller-app/nohup.out