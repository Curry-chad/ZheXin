package com.fina.summer.manager.entity.bo

import io.swagger.annotations.ApiModelProperty
import java.io.Serializable

data class RefundCheckListBO<T>(

        @ApiModelProperty("应向商户收款金额")
        var amount: Int? = null,

        @ApiModelProperty("手续费金额")
        var serviceChargeAmount: Int? = null,

        @ApiModelProperty("红包金额")
        var rewardAmount: Int? = null,

        @ApiModelProperty("红包状态")
        var rewardStatus: String? = null,

        @ApiModelProperty("回款任务")
        var data: List<T>? = null
): Serializable