package com.fina.summer.manager.entity.bo

import java.io.Serializable

data class ReceivableTemplate(
        var title: String? = null,

        var content: String? = null
): Serializable