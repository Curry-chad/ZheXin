package com.fina.summer.manager.entity.bo

import com.fina.summer.core.utils.DataUtil
import io.swagger.annotations.ApiModelProperty
import java.io.Serializable
import java.util.*

data class RepayInfoBO(

        @ApiModelProperty("还款计划编号")
        var repayId: String? = null,

        @ApiModelProperty("还款日期")
        var repayDate: Date? = null,

        @ApiModelProperty("还款人姓名")
        var payerName: String? = null,

        @ApiModelProperty("还款期数（分期数）")
        var seqNo: Int? = 0,

        @ApiModelProperty("是否逾期")
        var overdue: String? = null,

        @ApiModelProperty("逾期天数")
        var overdueDays: Int? = 0,

        @ApiModelProperty("来源商户")
        var merName: String? = null,

        @ApiModelProperty("来源类型")
        var lendType: String? = null,

        @ApiModelProperty("订单编号")
        var orderId: String? = null,

        @ApiModelProperty("还款状态")
        var status: String? = null,

        // 计划详情

        @ApiModelProperty("详情：已还款期数")
        var alreadyPeriod: Int? = 0,

        @ApiModelProperty("详情：最近一次应还款时间")
        var latelyShouldPayTime: Date? = null,

        @ApiModelProperty("详情：最近一次实际还款时间")
        var latelyActualPayTime: Date? = null,

        @ApiModelProperty("详情：最近一次应还款期数")
        var latelyShouldRepayablePeriod: Int? = null,

        @ApiModelProperty("详情：最近一次实际还款期数")
        var latelyActualRepayablePeriod: Int? = null

) : Serializable {

    @ApiModelProperty("还款金额")
    var repayAmount: String? = null
        get() = DataUtil.convertDecimalReturnA(field)

    @ApiModelProperty("逾期金额")
    var overdueAmount: String? = null
        get() = DataUtil.convertDecimalReturnA(field)

    @ApiModelProperty("详情：每期应还款金额")
    var periodAmount: String? = null
        get() = DataUtil.convertDecimalReturnA(field)

    @ApiModelProperty("详情：已还款金额")
    var alreadyAmount: String? = null
        get() = DataUtil.convertDecimalReturnA(field)

    @ApiModelProperty("详情：最近一次应还款金额")
    var latelyShouldRepayableAmount: String? = null
        get() = DataUtil.convertDecimalReturnA(field)

    @ApiModelProperty("详情：最近一次实际还款金额")
    var latelyActualRepayableAmount: String? = null
        get() = DataUtil.convertDecimalReturnA(field)

}