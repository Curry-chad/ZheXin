package com.fina.summer.manager.entity.bo

import io.swagger.annotations.ApiModelProperty
import java.io.Serializable

data class RefundCheckBO(

        @ApiModelProperty("应向商户收款金额")
        var amount: Int? = null,

        @ApiModelProperty("信息")
        var msg: String? = null
): Serializable