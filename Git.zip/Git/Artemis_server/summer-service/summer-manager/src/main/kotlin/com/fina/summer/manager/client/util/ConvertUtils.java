package com.fina.summer.manager.client.util;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.beans.IntrospectionException;
import java.lang.reflect.InvocationTargetException;
import java.util.Map;

public class ConvertUtils {

	private static final Logger LOGGER = LoggerFactory.getLogger(ConvertUtils.class);

	public static Object convertOperate(ConvertType type, String str, Class<?> clazz) {
		switch(type) {
		case XML:
			return convertByXml(str, clazz);
		case JSON:
			return convertByJson(str, clazz);
		}
		return null;
	}

	public static Object convertByXml(String xml, Class<?> clazz) {
		Map<String, Object> map = XmlUtil.readResponse(xml);
		return convert(map, clazz);
	}
	
	@SuppressWarnings("unchecked")
	public static Object convertByJson(String json, Class<?> clazz) {
		Object map = TypeConvertUtil.jsonToMap(json);
		if (map instanceof Map) {
			return convert((Map<String, Object>)map, clazz);
		}
		return null;
	}
	
	public static Object convert(Map<String, Object> map, Class<?> clazz) {
		Object result = null;
		try {
			result = TypeConvertUtil.convertMapWithLowerKey(clazz, map);
		} catch (IllegalAccessException | InstantiationException | InvocationTargetException
				| IntrospectionException e) {
			LOGGER.error("convert happened error ... {}", e);
		}
		return result;
	}
}
