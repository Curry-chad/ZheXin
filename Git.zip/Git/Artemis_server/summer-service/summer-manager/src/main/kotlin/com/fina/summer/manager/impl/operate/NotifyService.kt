package com.fina.summer.manager.impl.operate

import com.fina.summer.manager.entity.bo.BillInInfoBO
import com.fina.summer.persistent.ceres.repo.BillInTasksRepo
import com.fina.summer.persistent.ceres.repo.BillRepayPlanRepo
import org.springframework.stereotype.Service

@Service
class NotifyService(
        private val billInTasksRepo: BillInTasksRepo,
        private val billRepayPlanRepo: BillRepayPlanRepo
) {

    private val operator = "商户申请"

    /**
     * 获取用户还款计划
     */
    fun getBillTaskInfo(bisTaskId: String): BillInInfoBO {
        // TODO 根据总表id获取bill_in_tasks表对应所有期数信息
        val tasks = billInTasksRepo.findByBisTaskId(bisTaskId) ?: listOf()
        val bisTaskO = billRepayPlanRepo.findById(bisTaskId)
        if (bisTaskO.isPresent) {
            val bisTask = bisTaskO.get()
            return BillInInfoBO(status = bisTask.status!!, audit = bisTask.audit, tasks = tasks)
        }
        return BillInInfoBO()
    }

    /**
     * 获取计划还款时间为明天的信息
     */
    fun getBillTaskMsessage(){

    }
    /**
     * 申请退款
     */
   /* @Transactional
    fun applyRefund(bisTaskId: String) {
        val now = Date()

        val tasks = billInTasksRepo.findByBisTaskId(bisTaskId) ?: listOf()
        val bisTask = billRepayPlanRepo.findById(bisTaskId).get()

        tasks.forEach {
            it.status = Progress.RefundAuditPending
            it.modifyBy = operator
            it.modifyTime = now
            it.updatedTime = now
            billInTasksRepo.save(it)
        }

        bisTask.status = Progress.RefundAuditPending
        bisTask.modifyBy = operator
        bisTask.modifyTime = now
        bisTask.updatedTime = now
        billRepayPlanRepo.save(bisTask)
    }*/
}