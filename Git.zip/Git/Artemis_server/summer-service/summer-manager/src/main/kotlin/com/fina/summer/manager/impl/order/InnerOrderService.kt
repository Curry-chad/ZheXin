//package com.fina.summer.manager.impl.order
//
//import com.fina.summer.core.bean.PageResult
//import com.fina.summer.core.respone.ResEnum
//import com.fina.summer.core.respone.WebResult
//import com.fina.summer.manager.client.HttpConfig
//import com.fina.summer.manager.client.SummerUrl
//import com.fina.summer.manager.client.util.HttpRequestVO
//import com.fina.summer.persistent.bean.Area
//import com.fina.summer.persistent.bean.loan.ChargeBack
//import com.fina.summer.persistent.bean.loan.LoanOrder
//import com.fina.summer.persistent.ceres.mapper.BillInTasksMapper
//import com.fina.summer.persistent.summer.entity.OrderReceivableParam
//import com.fina.summer.persistent.mapper.loan.LoanMapper
//import com.fina.summer.persistent.repo.business.LoanOrderRepo
//import com.fina.summer.persistent.repo.business.LoanTradeRepo
//import com.fina.zeus.log.getLogger
//import org.apache.commons.lang3.StringUtils
//import org.springframework.http.HttpEntity
//import org.springframework.http.HttpHeaders
//import org.springframework.http.HttpMethod
//import org.springframework.stereotype.Service
//import org.springframework.util.LinkedMultiValueMap
//import org.springframework.util.MultiValueMap
//import org.springframework.web.client.RestTemplate
//
//
//@Service
//class InnerOrderService (
//        private val httpConfig: HttpConfig,
//        private val loanMapper: LoanMapper,
//        private val billInTasksMapper: BillInTasksMapper,
//        private val loanOrderRepo: LoanOrderRepo,
//        private val restTemplate: RestTemplate
//
//){
//    private val logger = getLogger(InnerOrderService::class.java)
//
//    fun findInnerOrder(orderReceivableParam: OrderReceivableParam): PageResult<LoanOrder> {
//        var poList: List<LoanOrder>? = null
//        var num:List<Integer>? = null
//        if(orderReceivableParam.page!=null && orderReceivableParam.rows!=null){
//            orderReceivableParam.page=(orderReceivableParam.page!! - 1)*( orderReceivableParam.rows!!)
//        }
//        poList=this.loanMapper.findInnerOrder(orderReceivableParam)
//        num=this.loanMapper.getTotalNum(orderReceivableParam)
//       return PageResult(num.size,poList!!)
//    }
//
//    fun contractSupplement(orderId: String, telecomAgreementNo: String, telecomAgreementPic: String): WebResult<Void> {
//        try {
//            this.loanOrderRepo.findById(orderId).get()
//            this.loanMapper.contractSupplement(orderId,telecomAgreementNo,telecomAgreementPic)
//        } catch (e: Exception) {
//            logger.debug { "错误order编号[$orderId]:订单数据不存在" }
//            return WebResult(code=ResEnum.OrderNotExists.getCode(),msg = "错误order编号[$orderId]:订单数据不存在")
//        }
//        return ResEnum.success()
//    }
//
//    fun refundReviewSearch(orderId: String,type: String): Any? {
//        var polist: List<ChargeBack>? = null
//        var flag:Int
//        //判断是否为储蓄卡
//        //this.loanOrderRepo.findById(orderId).get()
//        //var flag=this.loanMapper.judgePaymentChannel(orderId)
//        try {
//            this.loanOrderRepo.findById(orderId).get()
//            flag=this.loanMapper.judgePaymentChannel(orderId)!!
//        } catch (e: Exception) {
//            logger.debug { "错误order编号[$orderId]:订单数据不存在" }
//            return WebResult(code=ResEnum.OrderNotExists.getCode(),msg = "错误order编号[$orderId]:订单数据不存在",data = "")
//        }
//        if(flag==0){
//            polist=this.billInTasksMapper.refundReviewSearch(orderId,type)
//            return ResEnum.success(polist)
//        }
//        return chargeBack(orderId)
//
//    }
//
//    fun chargeBack(orderId: String): Any? {
//        var url: String = httpConfig.summerMerchantOrders + orderId  + SummerUrl.ChargeBack.interfaceName
//        //调用接口
//        val headers = HttpHeaders()
//        val request = HttpRequestVO()
//        request.method = HttpMethod.POST
//        val bodyMap: MultiValueMap<String, String> = LinkedMultiValueMap()
//        bodyMap["pass"] = "true"
//        request.url = url
//        request.body = bodyMap
//        val body = request.body as MultiValueMap<String, String>
//        return restTemplate.postForEntity(request.url!!, HttpEntity(body, headers), WebResult::class.java)
//    }
//
//
//    fun areaDisplay(orderReceivableParam: OrderReceivableParam): List<Area> {
//        var list: List<Area>? = null
//        if(orderReceivableParam.province.isNullOrBlank()){
//            list= this.loanMapper.areaDisplayPro(orderReceivableParam)
//            return list
//        }else if(orderReceivableParam.city.isNullOrBlank()){
//            list= this.loanMapper.areaDisplayCity(orderReceivableParam)
//            return list
//        }else{
//            list= this.loanMapper.areaDisplayArea(orderReceivableParam)
//            return list
//        }
//    }
//
//    fun detail(orderReceivableParam: OrderReceivableParam): List<LoanOrder> {
//        var poList: List<LoanOrder>? = null
//        poList=this.loanMapper.detail(orderReceivableParam.orderId)
//        return poList!!
//    }
//
//    fun down(orderReceivableParam: OrderReceivableParam): PageResult<LoanOrder> {
//        val poList  = loanMapper.down(orderReceivableParam)
//        poList!!.forEach {
//            if (StringUtils.isNotEmpty(it.sellMobile)){
//                it.sellMobile=it.sellMobile!!.substring(0,3)+"****"+it.sellMobile!!.substring(7,11)
//            }
//            if (StringUtils.isNotEmpty(it.applicantMobile)){
//                it.applicantMobile=it.applicantMobile!!.substring(0,3)+"****"+it.applicantMobile!!.substring(7,11)
//            }
//            if (StringUtils.isNotEmpty(it.idNo)){
//                it.idNo=it.idNo!!.substring(0,6)+"********"+it.idNo!!.substring(14)
//            }
//        }
//        return PageResult(poList.size,poList)
//
//    }
//
//    fun statusChange(orderId: String): WebResult<Void> {
//        try {
//           this.loanOrderRepo.findById(orderId).get()
//            this.loanMapper.statusChange(orderId)
//        } catch (e: Exception) {
//            logger.debug { "错误order编号[$orderId]:数据不存在" }
//            return WebResult(code=ResEnum.OrderNotExists.getCode(),msg = "错误order编号[$orderId]:订单数据不存在")
//        }
//        return  ResEnum.success()
//    }
//}
//
