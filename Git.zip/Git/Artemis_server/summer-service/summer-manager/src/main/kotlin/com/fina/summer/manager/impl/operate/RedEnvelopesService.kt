package com.fina.summer.manager.impl.operate

import com.fina.ceres.open.api.WxPayService
import com.fina.ceres.open.api.bean.CloudResp
import com.fina.ceres.open.api.bean.WxEntPayReq
import com.fina.ceres.open.api.bean.WxEntPayResp
import com.fina.summer.core.bean.PageResult
import com.fina.summer.core.respone.ResEnum
import com.fina.summer.core.respone.WebResult
import com.fina.summer.core.utils.ConcurrentTask
import com.fina.summer.core.utils.DataUtil
import com.fina.summer.manager.entity.bo.BatchDeductBO
import com.fina.summer.manager.entity.bo.DeductBO
import com.fina.summer.persistent.ceres.entity.constant.AuditStatus
import com.fina.summer.persistent.ceres.entity.constant.BillType
import com.fina.summer.persistent.ceres.entity.constant.PayType
import com.fina.summer.persistent.ceres.entity.constant.Progress
import com.fina.summer.persistent.ceres.entity.domain.BillOutFlowsPO
import com.fina.summer.persistent.ceres.entity.domain.BillOutTasksPO
import com.fina.summer.persistent.ceres.entity.domain.FailOutTask
import com.fina.summer.persistent.ceres.entity.vo.RedEnvelopesNumVo
import com.fina.summer.persistent.ceres.entity.vo.RedEnvelopesPlanVO
import com.fina.summer.persistent.ceres.entity.vo.RedEnvelopesVO
import com.fina.summer.persistent.ceres.mapper.BillOutTasksMapper
import com.fina.summer.persistent.ceres.mapper.RedEnvelopesMapper
import com.fina.summer.persistent.ceres.repo.BillOutFlowsRepo
import com.fina.summer.persistent.ceres.repo.BillOutPlanRepo
import com.fina.summer.persistent.ceres.repo.BillOutTasksRepo
import com.fina.summer.persistent.ceres.repo.FailOutTaskRepo
import org.slf4j.LoggerFactory
import org.springframework.stereotype.Service
import org.springframework.transaction.annotation.Transactional
import java.text.SimpleDateFormat
import java.util.*
import java.util.concurrent.Callable
import java.util.concurrent.ThreadPoolExecutor

@Service
class RedEnvelopesService(
        private val billOutTasksMapper: BillOutTasksMapper,
        private val redEnvelopesMapper: RedEnvelopesMapper,
        private val wxPayService: WxPayService,
        private val billOutTasksRepo: BillOutTasksRepo,
        private val billOutPlanRepo: BillOutPlanRepo,
        private val billOutFlowsRepo: BillOutFlowsRepo,
        private val failOutTaskRepo: FailOutTaskRepo,
        private val asyncTaskPool: ThreadPoolExecutor
) {
    private val logger = LoggerFactory.getLogger(RedEnvelopesService::class.java)

    /**
     * 红包列表展示
     */
    fun list(redEnvelopesVO: RedEnvelopesVO): PageResult<RedEnvelopesPlanVO> {
        //分页查询
        if (redEnvelopesVO.pageNo != null && redEnvelopesVO.pageSize != null) {
            var pageNo: Int = (((redEnvelopesVO.pageNo!!) - 1) * redEnvelopesVO.pageSize!!)
            redEnvelopesVO.pageNo = pageNo
        }
        var req = redEnvelopesVO.toString()
        logger.info("请求参数：$req")
        var list: List<RedEnvelopesPlanVO>? = null
        list = billOutTasksMapper.findByRedEnvelopesAll(redEnvelopesVO)
        list.forEach {
            it.shouldAmount = if (it.shouldAmount == null) DataUtil.convertDecimal("0") else DataUtil.convertDecimal(it.shouldAmount.toString())
        }
        logger.info(list.toString())
        var total: Int = billOutTasksMapper.findByByRedEnvelopesCount(redEnvelopesVO)
        return PageResult(total, list)
    }

    /**
     *红包数量金额相关展示
     */
    fun redEnvelopesNum(redEnvelopesVO: RedEnvelopesVO): List<RedEnvelopesNumVo> {
        val list = mutableListOf<RedEnvelopesNumVo>()
        if (redEnvelopesVO.status != null) {
            var str: String? = null
            redEnvelopesVO.status = str
        }
        //全部红包
        var allRed: Int = redEnvelopesMapper.findByRed(redEnvelopesVO)
        //全部红包金额
        var amountMoney: Int? = redEnvelopesMapper.findByShouldAmount(redEnvelopesVO)

        //已发放红包
        var grantRed: Int = redEnvelopesMapper.findByRedNum(redEnvelopesVO, Progress.Success)
        //已发放红包金额
        var grantAmountMoney: Int? = redEnvelopesMapper.findByRedShouldAmount(redEnvelopesVO, Progress.Success)

        //待发放红包
        var unissuedRed: Int = redEnvelopesMapper.findByRedNum(redEnvelopesVO, Progress.Ready)
        //代发放红包金额
        var unissuedAmountMoney: Int? = redEnvelopesMapper.findByRedShouldAmount(redEnvelopesVO, Progress.Ready)

        //发送失败红包
        var failRed: Int = redEnvelopesMapper.findByRedNum(redEnvelopesVO, Progress.Fail)
        //发送失败红包金额
        var failAmountMoney: Int? = redEnvelopesMapper.findByRedShouldAmount(redEnvelopesVO, Progress.Fail)

        list.add(RedEnvelopesNumVo(
                allRed = allRed,
                amountMoney = if (amountMoney == null) DataUtil.convertDecimal("0") else DataUtil.convertDecimal(amountMoney.toString()),
                grantRed = grantRed,
                grantAmountMoney = if (grantAmountMoney == null) DataUtil.convertDecimal("0") else DataUtil.convertDecimal(grantAmountMoney.toString()),
                unissuedRed = unissuedRed,
                unissuedAmountMoney = if (unissuedAmountMoney == null) DataUtil.convertDecimal("0") else DataUtil.convertDecimal(unissuedAmountMoney.toString()),
                failRed = failRed,
                failAmountMoney = if (failAmountMoney == null) DataUtil.convertDecimal("0") else DataUtil.convertDecimal(failAmountMoney.toString())
        ))
        return list
    }

    /**
     * 红包发放
     */
    fun outRedEnvelopes(list: List<String>): BatchDeductBO {
        var successCount = 0
        var failCount = 0
        var successAmount = 0
        var failAmount = 0
//        val indexList = mutableListOf<Int>()

        val c = ConcurrentTask<DeductBO>(asyncTaskPool)
        list.forEach {
            c.submit(Callable {
                return@Callable redEnvelopes(it)
            })
        }

        val resultList = c.getAll()
        resultList.forEach { bo ->
            if (bo.success!!) {
                successCount++
                successAmount += bo.amount!!
            } else {
                failCount++
                val taskAmount = bo.amount
                if (taskAmount != null) {
                    failAmount += taskAmount
                }
            }
        }
        return BatchDeductBO(
                successCount = successCount,
                failCount = failCount,
                successAmount = DataUtil.convertDecimal(successAmount.toString()),
                failAmount = DataUtil.convertDecimal(failAmount.toString())
        )
    }

    fun redEnvelopes(taskId: String): DeductBO {
        val now = Date()
        val openId = billOutTasksMapper.findByOpenId(taskId)
        try {
            if (openId == null) {
                //红包发放失败记录入库
                val msg = "错误task编号[$taskId]:红包数据不存在"
                failOutTaskRepo.save(FailOutTask(
                        bisTaskId = null,
                        taskId = taskId,
                        message = msg,
                        amount = 0,
                        type = BillType.Reward.toString(),
                        createdTime = now,
                        updatedTime = now
                ))
                logger.debug("deduct fail: [task id: $taskId, fail msg: openId不存在]")
                return DeductBO(success = false, amount = 0, msg = msg)
            }
            val bo = redPacketInterface(openId)
            if (!bo.success!!) {
                failOutTaskRepo.save(FailOutTask(
                        bisTaskId = null,
                        taskId = taskId,
                        message = bo.msg,
                        createdTime = now,
                        type = openId.type.toString(),
                        amount = bo.amount,
                        updatedTime = now
                ))
                logger.debug("deduct fail: [task id: $taskId, fail amount: ${bo.amount}, fail msg: ${bo.msg}]")
            }
            return bo
        } catch (e: Exception) {
            val bo = DeductBO(success = false)
            // TODO 红包发放失败记录入库
            failOutTaskRepo.save(FailOutTask(
                    bisTaskId = null,
                    taskId = taskId,
                    message = e.message,
                    amount = 0,
                    type = BillType.Reward.toString(),
                    createdTime = now,
                    updatedTime = now
            ))
            logger.error("错误task编号[$taskId]:  deduct error...", e)
            return bo
        }
    }

    fun redPacketInterface(tasksPO: BillOutTasksPO): DeductBO {
        val now = Date()
        val status = tasksPO.status!!
        val amount = tasksPO.totalAmount
        val openId = tasksPO.payeeAccount
        val operator = "ceres"

        val failBO = DeductBO(success = false, amount = amount)
        val errorMsg = "错误任务编号[${tasksPO.orderId}]："

        // TODO 判断红包任务是否已执行过
        if (status == Progress.Success) {
            failBO.msg = errorMsg + "本期红包任务已成功执行"
            return failBO
        }

        if (tasksPO.audit == AuditStatus.InRefundAudit.status) {
            failBO.msg = errorMsg + "本期红包任务处于退款审核中"
            return failBO
        }

        val plan = billOutPlanRepo.findByIdAndOrderId(tasksPO.bisTaskId!!, tasksPO.orderId!!)
        if (plan == null) {
            failBO.msg = errorMsg + "红包对应任务不存在"
            return failBO
        }

        if (amount == null) {
            failBO.msg = errorMsg + "红包发放金额为空"
            return failBO
        }
        if (openId == null) {
            failBO.msg = errorMsg + "微信openId为空"
            return failBO
        }

        //红包发放成功之前修改任务状态
        tasksPO.status = Progress.Doing
        billOutTasksRepo.save(tasksPO)

        val resp: CloudResp<WxEntPayResp>?
        try {
            logger.info("接口请求参数：tasksPO[${tasksPO.payeeAccount}],amount[${tasksPO.totalAmount}],desc[${tasksPO.orderId}]")
            resp = wxPayService.entPay(WxEntPayReq(
                    openId = openId,
                    amount = amount,
                    desc = "${tasksPO.orderId}"
            ))
        } catch (e: Exception) {
            failBO.msg = "红包接口异常"
            logger.error("调用微信发红包接口异常:", e)
            return failBO
        }
        val res = resp.toString()
        logger.info("接口返回参数：[$res]")
        if (resp.code != ResEnum.Success.getCode()) {
            tasksPO.status = Progress.Fail
            billOutTasksRepo.save(tasksPO)
            failBO.msg = errorMsg + resp.msg
            return failBO
        }

        val dataResp = resp.data!!

        val partnerTradeNo = dataResp.partnerTradeNo!!
        val sdf = SimpleDateFormat("yyyy-MM-dd HH:mm:ss")
        val time = sdf.parse(dataResp.paymentTime!!)//微信支付时间
        val thirdOrderId = dataResp.paymentNo!!
        val payer = dataResp.mchId!!
        val payAccount = dataResp.appId!!

        //更新tasks表
        tasksPO.status = Progress.Success
        tasksPO.modifyBy = operator
        tasksPO.modifyTime = now
        tasksPO.updatedTime = now
        tasksPO.thirdOrderId = thirdOrderId
        tasksPO.finishTime = now
        tasksPO.requestNo = partnerTradeNo
        tasksPO.payer = payer
        tasksPO.payAccount = payAccount
        tasksPO.finishTime = time
        tasksPO.payBank = PayType.WeiXin.toString()
        tasksPO.payType = PayType.WeiXin

        billOutTasksRepo.save(tasksPO)

        //更新plan
        plan.status = Progress.Success
        plan.modifyBy = operator
        plan.modifyTime = now
        plan.updatedTime = now
        plan.actualAmount = tasksPO.totalAmount
        billOutPlanRepo.save(plan)

        //记录打款流水
        billOutFlowsRepo.save(BillOutFlowsPO(
                taskId = tasksPO.id,
                bisTaskId = tasksPO.bisTaskId,
                thirdOrderId = thirdOrderId,
                amount = tasksPO.totalAmount,
                payeeAccount = tasksPO.payeeAccount,
                payee = tasksPO.payee,
                payBank = tasksPO.payBank,
                requestNo = partnerTradeNo,
                tradeId = tasksPO.tradeId,
                createBy = operator,
                modifyTime = now,
                executeTime = time,
                payAccount = payAccount,
                payType = tasksPO.payType.toString(),
                payer = payer,
                status = tasksPO.status.toString(),
                message = resp.msg
        ))

        return DeductBO(success = true, amount = amount, msg = resp.msg)
    }

    @Transactional
    fun artificialRedEnvelope(id: String): WebResult<Void> {
        val now = Date()
        val operator = "ceres"
        var tasks = billOutTasksMapper.findByOpenId(id)
        if (tasks != null) {
            //更新tasks表
            tasks.status = Progress.Success
            tasks.modifyTime = now
            tasks.updatedTime = now
            tasks.finishTime = now
            tasks.lastExecuteTime = now
            tasks.payBank = PayType.WeiXin.toString()
            tasks.payType = PayType.WeiXin
            billOutTasksRepo.save(tasks)

            var plan = billOutPlanRepo.findByIdAndOrderId(tasks.bisTaskId!!, tasks.orderId!!)
            if (plan != null) {
                plan.status = Progress.Success
                plan.modifyTime = now
                plan.updatedTime = now
                plan.actualAmount = tasks.shouldAmount
                billOutPlanRepo.save(plan)

                var msg: String = "线下打款"

                //记录打款流水
                billOutFlowsRepo.save(BillOutFlowsPO(
                        taskId = tasks.id,
                        bisTaskId = tasks.bisTaskId,
                        amount = tasks.totalAmount,
                        payeeAccount = tasks.payeeAccount,
                        payee = tasks.payee,
                        payBank = tasks.payBank,
                        tradeId = tasks.tradeId,
                        createBy = operator,
                        modifyTime = now,
                        executeTime = now,
                        status = Progress.Success.toString(),
                        message = msg
                ))
                return WebResult()
            }
        }
        return WebResult(code = "99")
    }
}