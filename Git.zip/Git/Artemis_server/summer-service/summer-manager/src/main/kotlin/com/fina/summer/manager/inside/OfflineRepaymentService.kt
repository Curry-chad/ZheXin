package com.fina.summer.manager.inside

import com.fina.summer.core.respone.ResEnum
import com.fina.summer.core.respone.WebResult
import com.fina.summer.core.utils.DateUtils
import com.fina.summer.manager.entity.bo.FileImportBO
import com.fina.summer.persistent.ceres.entity.constant.Progress
import com.fina.summer.persistent.ceres.entity.domain.BillInTasksPO
import com.fina.summer.persistent.ceres.entity.domain.BillOfflineRepaymentPO
import com.fina.summer.persistent.ceres.entity.vo.OfflineRepaymentStatusVO
import com.fina.summer.persistent.ceres.repo.BillInTasksRepo
import com.fina.summer.persistent.ceres.repo.BillOfflineRepaymentRepo
import com.fina.summer.persistent.ceres.repo.BillRepayPlanRepo
import com.google.gson.Gson
import org.slf4j.LoggerFactory
import org.springframework.stereotype.Service
import org.springframework.transaction.annotation.Transactional
import java.util.*

@Service
class OfflineRepaymentService(
        private val billOfflineRepaymentRepo: BillOfflineRepaymentRepo,
        private val billInTasksRepo: BillInTasksRepo,
        private val billRepayPlanRepo: BillRepayPlanRepo
) {

    private val logger = LoggerFactory.getLogger(OfflineRepaymentService :: class.java)
    private val operator = "ceres"

    /**
     * 催收任务生成
     */
    fun createOfflineRepayment(offlineRepaymentStatusVO: OfflineRepaymentStatusVO, tasks: BillInTasksPO, msg: String, status: Progress){
        logger.info("开始生成催收任务数据")
        val now = Date()
        try{
            billOfflineRepaymentRepo.save(BillOfflineRepaymentPO(
                    id = offlineRepaymentStatusVO.id,
                    orderId = offlineRepaymentStatusVO.orderId,
                    shouldAmountNum = offlineRepaymentStatusVO.shouldAmountNum,
                    planExecuteTime = DateUtils.getStringToDate(offlineRepaymentStatusVO.planExecuteTime!!),
                    shouldAmount = tasks.shouldAmount,
                    payer = offlineRepaymentStatusVO.payer,
                    payBank = tasks.payBank,
                    message = msg,
                    overdueNum = offlineRepaymentStatusVO.overdueNum,
                    payerIdno = tasks.payerIdno,
                    totalAmount = offlineRepaymentStatusVO.totalAmount,
                    createBy = offlineRepaymentStatusVO.modifyBy,
                    modifyBy = offlineRepaymentStatusVO.modifyBy,
                    createdTime = now,
                    updatedTime = now,
                    status = status,
                    transferMethod = offlineRepaymentStatusVO.transferMethod,
                    collectionAccount = offlineRepaymentStatusVO.collectionAccount,
                    finishTime = DateUtils.getStringToDate(offlineRepaymentStatusVO.finishTime!!),
                    payAccount = tasks.payAccount
            ))
        }catch (e: Exception){
            logger.error("催收任务生成失败", e)
        }
    }

    /**
     * 催收结果更新
     */
    @Transactional
    fun offlineRepaymentUpdate(offlineRepaymentStatusVO: List<OfflineRepaymentStatusVO>): WebResult<FileImportBO>{
        val now = Date()
        var data = FileImportBO()
        val amountFail = mutableListOf<String>()//金额不相等
        val repaymentNumFail = mutableListOf<String>()//还款期数错误
        val orderNullFail = mutableListOf<String>()//还款订单不存在
        val orderIdFail = mutableListOf<String>()//数据为null
        val orderSuccess = mutableListOf<String>()//订单已还款成功
        val collectionExists = mutableListOf<String>()//催收任务已存在
        offlineRepaymentStatusVO.forEach {
            val str = isNotEmptyBatch(it,"orderId","id",
                    "payer","transferMethod","collectionAccount","planExecuteTime","shouldAmountNum","totalAmount",
                    "finishTime","overdueNum")
            val plan = billOfflineRepaymentRepo.findByTaskId(it.id!!)
            if(plan != null){
                failUpdate(collectionExists, it.orderId!!, data)
                logger.info("催收任务已存在，订单编号：【${it.orderId}】,还款任务编号【${it.id}】,应还款金额.【${plan.shouldAmountNum}】，" +
                        "实际还款金额【${plan.totalAmount}】")
            }else{
                val tasks = billInTasksRepo.findByOrderIdAndId(it.orderId!!,it.id!!)
                if(tasks != null){
                    if(tasks.status == Progress.Success) {
                        val msg = "还款任务已还款"
                        data.fileFailCount = data.fileFailCount + 1
                        orderSuccess.add(it.orderId!!)
                        logger.info("${msg}，订单编号：【${it.orderId}】,还款任务编号【${it.id}】,应还款金额.【${it.shouldAmountNum}】，" +
                                "实际还款金额【${it.totalAmount}】")
                    }else if(tasks.status == Progress.Cancel){
                        val msg = "还款任务已取消"
                        data.fileFailCount = data.fileFailCount + 1
                        orderSuccess.add(it.orderId!!)
                        logger.info("${msg}，订单编号：【${it.orderId}】,还款任务编号【${it.id}】,应还款金额.【${it.shouldAmountNum}】，" +
                                "实际还款金额【${it.totalAmount}】")
                    }else {
                        val amount = tasks.shouldAmount!!+tasks.penalty!!
                        when {
                            str.isNotEmpty() -> failUpdate(orderIdFail, it.orderId!!, data)//部分数据为空
                            amount > it.totalAmount!! -> failUpdate(amountFail, it, tasks, "实际还款金额小于应还款金额", data)
                            tasks.seqNo != it.overdueNum -> fail(repaymentNumFail, it, "还款期数不匹配", data)
                            else -> updateTask(tasks, now, it, "成功", Progress.Success, data)
                        }
                    }
                }else{
                    data.fileFailCount = data.fileFailCount + 1
                    val msg = "还款任务不存在"
                    orderNullFail.add(it.orderId!!)
                    logger.info("${msg}，订单编号：【${it.orderId}】,还款任务编号【${it.id}】,应还款金额.【${it.shouldAmountNum}】，" +
                            "实际还款金额【${it.totalAmount}】")
                }
            }
        }
        data.amountFail = amountFail
        data.repaymentNumFail = repaymentNumFail
        data.orderNullFail = orderNullFail
        data.orderIdFail = orderIdFail
        data.orderSuccess = orderSuccess
        data.collectionExists = collectionExists
        return ResEnum.success(data)
    }

    //计数并入库
    fun failUpdate(list: MutableList<String>, it: OfflineRepaymentStatusVO, tasks: BillInTasksPO, msg: String, data: FileImportBO){
        data.fileFailCount = data.fileFailCount + 1
        list.add(it.orderId!!)
        logger.info("${msg}，订单编号：【${it.orderId}】,还款任务编号【${it.id}】,应还款金额.【${it.shouldAmountNum}】，" +
                "实际还款金额【${it.totalAmount}】")
        createOfflineRepayment(it, tasks, msg, Progress.Fail)
    }

    //计数
    fun failUpdate(list: MutableList<String>, it: String,data: FileImportBO){
        list.add(it)
        data.fileFailCount = data.fileFailCount + 1
        logger.info("部分数据为null，订单编号：【${it}】")
    }

    //还款期数不正确计数
    fun fail(list: MutableList<String>, it: OfflineRepaymentStatusVO, msg: String, data: FileImportBO){
        data.fileFailCount = data.fileFailCount + 1
        list.add(it.orderId!!)
        logger.info("${msg}，订单编号：【${it.orderId}】,还款任务编号【${it.id}】,应还款金额.【${it.shouldAmountNum}】，" +
                "实际还款金额【${it.totalAmount}】")
    }

    //修改订单状态
    fun updateTask(tasks: BillInTasksPO, now: Date, it: OfflineRepaymentStatusVO, msg: String, status: Progress, data: FileImportBO){
        data.fileSuccessCount = data.fileSuccessCount + 1
        val date = DateUtils.getStringToDate(it.finishTime!!)
        createOfflineRepayment(it, tasks, msg, status)
        repaymentStatusUpdate(it.id!!, it.orderId!!, it.modifyBy!!, status, date)
    }

    /**
     *线下催收结果
     */
    @Transactional
    fun offlineRepaymentConfirm(offlineRepaymentStatusVO: OfflineRepaymentStatusVO): WebResult<FileImportBO>{
        val now = Date()
        var data = FileImportBO()
        val orderNullFail = mutableListOf<String>()//订单不存在
        val orderSuccess = mutableListOf<String>()//订单已还款成功
        val amountFail = mutableListOf<String>()//金额不相等
        val plan = billOfflineRepaymentRepo.findByTaskId(offlineRepaymentStatusVO.id!!)
        val status = offlineRepaymentStatusVO.status!!
        val tasks = billInTasksRepo.findByOrderIdAndId(offlineRepaymentStatusVO.orderId!!,offlineRepaymentStatusVO.id!!)
        if (plan != null) {
            val date = DateUtils.getStringToDate(offlineRepaymentStatusVO.finishTime!!)
            val amount = tasks!!.shouldAmount!! + tasks.penalty!!
            if(offlineRepaymentStatusVO.totalAmount!! < amount) {
                amountFail.add(offlineRepaymentStatusVO.orderId!!)
                data.fileFailCount = data.fileFailCount + 1
                logger.info("实际还款金额小于应还款金额，订单编号：【${offlineRepaymentStatusVO.orderId}】,还款任务编号【${offlineRepaymentStatusVO.id}】,应还款金额.【${offlineRepaymentStatusVO.shouldAmountNum}】，" +
                        "实际还款金额【${offlineRepaymentStatusVO.totalAmount}】")
            }else{
                plan.updatedTime = now
                plan.finishTime = date
                plan.totalAmount = offlineRepaymentStatusVO.totalAmount
                plan.collectionAccount = offlineRepaymentStatusVO.collectionAccount
                plan.transferMethod = offlineRepaymentStatusVO.transferMethod
                plan.status = status
                plan.modifyBy = offlineRepaymentStatusVO.modifyBy
                plan.message = "成功"
                billOfflineRepaymentRepo.save(plan)
                repaymentStatusUpdate(offlineRepaymentStatusVO.id!!,offlineRepaymentStatusVO.orderId!!,offlineRepaymentStatusVO.modifyBy!!, status, date)
                data.fileSuccessCount = data.fileSuccessCount + 1
                logger.info("成功，订单编号：【${offlineRepaymentStatusVO.orderId}】,还款任务编号【${offlineRepaymentStatusVO.id}】,应还款金额.【${offlineRepaymentStatusVO.shouldAmountNum}】，" +
                        "实际还款金额【${offlineRepaymentStatusVO.totalAmount}】")
            }
        }else {
            orderNullFail.add(offlineRepaymentStatusVO.orderId!!)
            data.fileFailCount = data.fileFailCount + 1
            logger.info("催收计划不存在，订单编号：【${offlineRepaymentStatusVO.orderId}】,还款任务编号【${offlineRepaymentStatusVO.id}】,应还款金额.【${offlineRepaymentStatusVO.shouldAmountNum}】，" +
                    "实际还款金额【${offlineRepaymentStatusVO.totalAmount}】")
        }

        data.orderNullFail = orderNullFail
        data.orderSuccess = orderSuccess
        data.amountFail = amountFail
        return ResEnum.success(data)
    }

    fun repaymentStatusUpdate(id: String, orderId: String, operator: String, status: Progress, date: Date){
        val now = Date()
        val tasks = billInTasksRepo.findByOrderIdAndId(orderId,id)
        if (tasks != null) {
            if(tasks.status == Progress.Success){
                return
            }
            //更新tasks表
            tasks.status = status
            tasks.modifyTime = now
            tasks.updatedTime = now
            tasks.finishTime = date
            tasks.lastExecuteTime = date
            tasks.modifyBy = operator
            tasks.message = "线下还款成功"
            billInTasksRepo.save(tasks)

            val plan = billRepayPlanRepo.findById(tasks.bisTaskId!!).get()
            plan.modifyTime = now
            plan.updatedTime = now
            billRepayPlanRepo.save(plan)
        }
    }

    /**
     * 参数校验
     */
    fun isNotEmptyBatch(obj: Any, vararg str: String): List<String>{
        val json = Gson()
        val string = json.toJson(obj)
        val map = HashMap<String, Any>()
        val strs = string.replace("[","").replace("]","")
        logger.info(strs)
        val maps = json.fromJson(strs,map.javaClass)
        val list = mutableListOf<String>()
        str.forEach {
            if(maps[it] == null){
                list.add(it)
            }
        }
        return list
    }
}