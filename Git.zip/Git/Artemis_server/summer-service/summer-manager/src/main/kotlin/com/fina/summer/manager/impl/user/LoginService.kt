package com.fina.summer.manager.impl.user

import com.fina.summer.auth.core.auth.BaseManagerAuth
import com.fina.summer.common.sms.SmsService
import com.fina.summer.core.enum.SmsType
import com.fina.summer.core.handler.ServiceException
import com.fina.summer.core.respone.ResEnum
import com.fina.summer.manager.entity.bo.ManagerUserInfoBO
import com.fina.summer.persistent.artemis.entity.domain.user.ManagerUserDO
import com.fina.summer.persistent.artemis.entity.domain.user.ManagerUserLoginLogDO
import com.fina.summer.persistent.artemis.repo.user.ManagerUserLoginLogRepo
import org.apache.shiro.authc.UnknownAccountException
import org.apache.shiro.authc.UsernamePasswordToken
import org.springframework.beans.BeanUtils
import org.springframework.stereotype.Service
import java.util.*

@Service
class LoginService(
        private val userService: UserService,
        private val baseManagerAuth: BaseManagerAuth,
        private val managerUserLoginLogRepo: ManagerUserLoginLogRepo,
        private val smsService: SmsService
) {

    private fun loginLog(userDO: ManagerUserDO) {
        val userId = userDO.id!!

        // 用户信息更新
        userDO.loginTime = Date()
        userService.saveUser(userDO)

        // 记录用户登录
        val userLoginLog = ManagerUserLoginLogDO(userId = userId, loginName = userDO.loginName)
        BeanUtils.copyProperties(userDO, userLoginLog, userId)
        managerUserLoginLogRepo.save(userLoginLog)
    }

    fun login(loginName: String, password: String): ManagerUserInfoBO {
        val userDO = userService.getUserByLoginName(loginName)?: throw UnknownAccountException(ResEnum.UserNotExist.getMsg())
        // 登录
        baseManagerAuth.loginWithPW {
            return@loginWithPW UsernamePasswordToken(userDO.id, password.toCharArray())
        }

        // 更新用户信息并记录登录日志
        loginLog(userDO)

        // 获取用户信息（角色与权限信息）
        return userService.currentUserInfo(userDO)
    }

    fun loginBySms(loginName: String, verifyCode: String): ManagerUserInfoBO {
        if (!smsService.checkCode(loginName, verifyCode, SmsType.Login)) {
            throw ServiceException(ResEnum.CodeWrong)
        }
        var userDO: ManagerUserDO? = userService.getUserByLoginName(loginName)
                ?: throw ServiceException(ResEnum.UserNotExist)
        userDO = userDO!!
        baseManagerAuth.login {
            return@login userDO
        }
        // 更新用户信息并记录登录日志
        loginLog(userDO)

        // 获取用户信息（角色与权限信息）
        return userService.currentUserInfo(userDO)
    }

    fun logout() {
        val user = userService.currentUser()
        user.logoutTime = Calendar.getInstance().time
        userService.saveUser(user)
        // 记录用户登出
        val userLoginLog = ManagerUserLoginLogDO(userId = user.id, logoutTime = user.logoutTime)
        BeanUtils.copyProperties(user, userLoginLog, user.id)
        managerUserLoginLogRepo.save(userLoginLog)

        baseManagerAuth.logout()
    }

}