package com.fina.summer.manager.impl.operate

import com.fina.summer.core.utils.DateUtils
import com.fina.summer.persistent.ceres.entity.constant.BillType
import com.fina.summer.persistent.ceres.entity.constant.Progress
import java.util.*

/**
 * @author zhengqiyang@zhexinit.com
 * @version V1.0
 * @since 1.0 2019/5/15 15:34
 * @description 请输入功能描述
 */
fun main(args: Array<String>) {
    println("mingc              " + Progress.Cancel.name)
    println("firstDay              " + DateUtils.getBeginDayOfMonth(Date()))
    println("endDay              " + DateUtils.getLastDayOfMonth(Date()))
}