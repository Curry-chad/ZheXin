package com.fina.summer.manager.impl.operate

import com.fina.summer.core.respone.ResEnum
import com.fina.summer.core.respone.WebResult
import com.fina.summer.persistent.ceres.entity.constant.BillType
import com.fina.summer.persistent.ceres.entity.constant.OperateType
import com.fina.summer.persistent.ceres.entity.constant.PayType
import com.fina.summer.persistent.ceres.entity.constant.Progress
import com.fina.summer.persistent.ceres.entity.domain.BillInFlowsPO
import com.fina.summer.persistent.ceres.entity.vo.FundChannelVO
import com.fina.summer.persistent.ceres.repo.BillInFlowsRepo
import com.fina.summer.persistent.ceres.repo.BillInTasksRepo
import com.fina.summer.persistent.ceres.repo.BillRepayPlanRepo
import org.slf4j.LoggerFactory
import org.springframework.stereotype.Service
import java.util.*

@Service
class OperateFundChannelService(
        private val billInTasksRepo: BillInTasksRepo,
        private val billRepayPlanRepo: BillRepayPlanRepo,
        private val billInFlowsRepo: BillInFlowsRepo

) {
    private val logger = LoggerFactory.getLogger(OperateFundChannelService::class.java)
    private var operator = "资金方修改"
    private var modify = "ceres"
    fun operateFundChannel(list: List<FundChannelVO>): WebResult<Void> {
        var now=Date()
        if (list!=null && !list.isEmpty()){
            list.forEach {
                val bisTask = this.billRepayPlanRepo.findByTradeIdAndType(it.tradeId!!,BillType.User)
                if (bisTask!=null) {
                    bisTask.fundChannel=it.fundChannel
                    bisTask.updatedTime = now
                    this.billRepayPlanRepo.save(bisTask)
                    val tasks = billInTasksRepo.findByBisTaskId(bisTask.id!!) ?: listOf()
                    if (tasks.isEmpty()){
                        logger.warn("deduct fail: [trade_id:${it.tradeId},bis_task_id: ${bisTask.id} , fail msg:bill_in_task不存在]")
                        return ResEnum.fail(code = "99",msg = "trade_id:${it.tradeId},bis_task_id: ${bisTask.id} , fail msg:bill_in_task不存在]")
                    }
                    for (billInTaskPo in tasks){
                            if (billInTaskPo.status!=Progress.Success){
                                billInTaskPo.fundChannel=it.fundChannel
                                billInTaskPo.updatedTime=now
                                this.billInTasksRepo.save(billInTaskPo)

                                this.billInFlowsRepo.save(BillInFlowsPO(
                                        taskId = billInTaskPo.id,
                                        requestNo = billInTaskPo.requestNo,
                                        thirdOrderId = billInTaskPo.thirdOrderId,
                                        tradeId = billInTaskPo.tradeId,
                                        bisTaskId = billInTaskPo.bisTaskId,
                                        payBank = billInTaskPo.payBank,
                                        payType = PayType.Debit,
                                        payer = billInTaskPo.payer,
                                        payerIdno = billInTaskPo.payerIdno,
                                        status = billInTaskPo.status,
                                        payAccount = billInTaskPo.payAccount,
                                        penalty = billInTaskPo.penalty,
                                        createdTime = now,
                                        updatedTime = now,
                                        orderId = billInTaskPo.orderId,
                                        debitChannel = billInTaskPo.debitChannel,
                                        finishTime = billInTaskPo.finishTime,
                                        fundChannel = billInTaskPo.fundChannel,
                                        planExecuteTime = billInTaskPo.planExecuteTime,
                                        nextExecuteTime = billInTaskPo.nextExecuteTime,
                                        lastExecuteTime = billInTaskPo.lastExecuteTime,
                                        overdueDays = billInTaskPo.overdueDays,
                                        seqNo = billInTaskPo.seqNo,
                                        shouldAmount = billInTaskPo.shouldAmount,
                                        checkStatus = billInTaskPo.checkStatus,
                                        amount = billInTaskPo.totalAmount,
                                        createBy = billInTaskPo.createBy,
                                        modifyBy =billInTaskPo.modifyBy,
                                        modifyTime = billInTaskPo.modifyTime,
                                        loanNo = billInTaskPo.loanNo,
                                        loanReqNo = billInTaskPo.loanReqNo,
                                        contNo = billInTaskPo.contNo,
                                        contReqNo = billInTaskPo.contReqNo,
                                        taskType = billInTaskPo.type,
                                        audit = billInTaskPo.audit,
                                        operateType = OperateType.FundChannel
                                ))
                            }


                    }

                }else{
                    logger.warn("deduct fail: [tradeId]: ${it.tradeId} 和[type]:User, fail msg:bill_repay_plan不存在]")
                    return ResEnum.fail(code ="99",msg = "deduct fail: [tradeId]: ${it.tradeId} 和[type]:User, fail msg:bill_repay_plan不存在]")
                }
            }
        }


        return ResEnum.success()
    }

}