package com.fina.summer.manager.batch


import com.fina.cmcc.MessageSendService
import com.fina.cmcc.entity.CloudResp
import com.fina.cmcc.entity.MessagePkgContent
import com.fina.cmcc.entity.MessagePkgReq
import com.fina.cmcc.entity.MessageReq
import com.fina.summer.core.handler.ServiceException
import com.fina.summer.core.respone.ResEnum
import com.fina.summer.core.utils.Id
import com.fina.summer.core.utils.IdGenerator
import com.fina.summer.persistent.ceres.entity.constant.ResultStatus
import com.fina.summer.persistent.ceres.entity.domain.ResultSendSms
import com.fina.summer.persistent.ceres.entity.vo.SmsResult
import com.fina.summer.persistent.ceres.mapper.SmsNotificationMapper
import org.joda.time.DateTime
import org.slf4j.LoggerFactory
import org.springframework.beans.factory.annotation.Value
import org.springframework.stereotype.Service
import java.util.*


@Service
class SmsNotificationService(
        private val smsNotificationMapper: SmsNotificationMapper,
        private val messageSendService: MessageSendService,
        @Value("\${sms.callback.url}")
        private val smsCallBackUrl: String
) {
    private val logger = LoggerFactory.getLogger(SmsNotificationService::class.java)

    //===============正常提醒用户-信息-短信================
    fun getInfoAboutSendSms(): CloudResp<String> {

        val list = smsNotificationMapper.findInfoAboutSendSms()  //获取list<Sms对象>
        if (list.isNotEmpty()) {
            //短信接口list
            val msgs = list/*.filter { it.mobile != null }*/.map {

                val amount = (it.shouldAmount ?: 0) / 100.0
                MessagePkgContent(
                        phone = "18270209531",
                        context = "【和分享】尊敬的客户，您于" + DateTime(it.createdTime).toString("yyyy-MM-dd") + "在"
                                + it.storeName + "办理的" + it.name + "，本期账单" + amount + "元。系统将于"
                                + DateTime(it.planExecuteTime).toString("yyyy-MM-dd") + ",10点从您尾号" + it.payAccount?.takeLast(4)
                                + "的储蓄卡扣款。若卡内余额不足，扣款失败将影响您的个人征信，请及时预存，如有疑问可拨打客服电话0571-87209074。感谢您的配合。退订回T。"
                )
            }
            //短信结果list
            val out_id = IdGenerator.nextId(Id.SMS) //批次号
            val listsms = msgs.map {
                ResultSendSms(
                        id = IdGenerator.nextId(Id.SMS),
                        //mobile = it.phone,
                        msg = it.context,
                        createdTime = Calendar.getInstance().time,
                        status = ResultStatus.Request,
                        outMsgId = out_id
                )
            }
            //infoSendSms批量入库
           /* if(listsms.size>0)
            {
                smsNotificationMapper.insertSendSms(listsms)
                logger.info("符合提前提醒的短信批号为"+out_id+"存入result_send_sms")
            }
*/

            return messageSendService.sendPkg(MessagePkgReq(msgs, method = MessagePkgReq.Method.DK, out_msgid = out_id, backUrl = smsCallBackUrl))
        } else {
            throw ServiceException(ResEnum.NoUsersToAlert)
        }

    }
    //===============提醒-短信发送-结果处理===============
    fun getResults(smsResult: SmsResult): String {
        val res = smsResult.result
        val mobile = smsResult.mobile
        val outMsgId = smsResult.outMsgId
        if (res == "fail") {  //根据mobile和批次号 修改status为失败，信息发送失败后会用其他方式提醒并修改 成 成功，
            val status:String = ResultStatus.Failure.name
            smsNotificationMapper.updateStatus(mobile!!, outMsgId!!,status)
        }else{
            val status:String = ResultStatus.Success.name
            smsNotificationMapper.updateStatus(mobile!!, outMsgId!!,status)
        }
        return "SuccessfulReceipt"
    }

    //==============还款当日-"扣款结果"-提醒=============
    //---成功---
    fun sendOkSms(id: String): CloudResp<String> {
        //根据mobile查询SmsVO对象
        val smsvo = smsNotificationMapper.findInfoSendSmsByTaskId(id)
        val listsms = mutableListOf<ResultSendSms>()

        if (smsvo != null) {
            val amount = (smsvo.shouldAmount ?: 0) / 100.0
            val out_id = IdGenerator.nextId(Id.SMS)
            val messageReq = MessageReq(mobile = "", msg = "", out_msgid = out_id, method = MessageReq.Method.DK, backUrl = smsCallBackUrl)

            messageReq.mobile = smsvo.mobile!!
            messageReq.msg = "【和分享】尊敬的客户，您于" + DateTime(smsvo.createdTime).toString("yyyy-MM-dd") + "在" + smsvo.storeName + "办理的" + smsvo.name + "," + "本期账单" + amount + "元已扣款成功。" + "如有疑问可拨打客服电话0571-87209074。感谢您的支持与配合。退订回T。"

            val resultSendSms = ResultSendSms(
                    id = IdGenerator.nextId(Id.SMS),
                    mobile = smsvo.mobile,
                    msg = messageReq.msg,
                    createdTime = Calendar.getInstance().time,
                    status = ResultStatus.Request,
                    outMsgId = out_id
            )
            listsms.add(resultSendSms)
            smsNotificationMapper.insertSendSms(listsms)

            return messageSendService.send(messageReq)

        } else {
            throw ServiceException(ResEnum.NoThisUser)
        }
    }
    //----失败----
    fun sendFailSms(id: String): CloudResp<String> {
        //根据mobile查询SmsVO对象
        val smsvo = smsNotificationMapper.findInfoSendSmsByTaskId(id)
        val listsms = mutableListOf<ResultSendSms>()
        val out_id = IdGenerator.nextId(Id.SMS)

        if (smsvo != null) {
            val messageReq = MessageReq(mobile = "", msg = "", out_msgid = out_id, method = MessageReq.Method.DK, backUrl = smsCallBackUrl)
            val currentHour = DateTime().hourOfDay().get()
            val amount = (smsvo.shouldAmount ?: 0) / 100.0

            if (currentHour == 10) {  //am
                messageReq.mobile = smsvo.mobile!!
                messageReq.msg = "【和分享】尊敬的客户，您于" + DateTime(smsvo.createdTime).toString("yyyy-MM-dd") + "在" + smsvo.storeName + "办理的" + smsvo.name + "，" + "本期账单" + amount + "元。您绑定的尾号" + smsvo.payAccount?.takeLast(4) + "储蓄卡余额不足导致扣款失败，请在今日20点前预存足额月供" + amount + "元，扣款失败将影响您的个人征信。如有疑问可拨打客服电话0571-87209074。退订回T。"

            } else if (currentHour == 21) {  //pm
                messageReq.mobile = smsvo.mobile!!
                messageReq.msg = "【和分享】尊敬的客户，您于" + DateTime(smsvo.createdTime).toString("yyyy-MM-dd") + "在" + smsvo.storeName + "办理的分期业务，本期账单" + amount + "元。您绑定的尾号" + smsvo.payAccount?.takeLast(4) + "储蓄卡余额不足扣款失败，请在明日8点前预存" + amount + "元，扣款失败将影响您的个人征信。如有疑问可拨打客服电话0571-87209074。退订回T。"
            }

            //符合发短信的条件--存入集合
            if (messageReq.mobile!=null && messageReq.mobile.length!=0) {
                //短信记录信息
                val resultSendSms = ResultSendSms(
                        id = IdGenerator.nextId(Id.SMS),
                        mobile = messageReq.mobile,
                        outMsgId = out_id,
                        msg = messageReq.msg,
                        createdTime = Calendar.getInstance().time,
                        status = ResultStatus.Request
                )
                listsms.add(resultSendSms)
                smsNotificationMapper.insertSendSms(listsms)
                return messageSendService.send(messageReq)
            }else{
                throw ServiceException(ResEnum.NoOverdueUsersEligible)
            }

        } else {
            throw ServiceException(ResEnum.NoThisUser)
        }

    }
    //============（单）多期逾期=================
    fun getInfoAboutMultiphase(): CloudResp<String> {

        val list = smsNotificationMapper.findInfoSendMultiphaseSms()

        //短信接口list
        val msgs = mutableListOf<MessagePkgContent>()
        //短信结果list
        val listsms = mutableListOf<ResultSendSms>()
        //批次号
        val outId = IdGenerator.nextId(Id.SMS)

        if (list.isNotEmpty()) {

            list.filter { it.mobile != null }.map {
                val messagePkgContent = MessagePkgContent(phone = "", context = "")

                if (it.overdueDays!! < 4) {
                    val totalAmount: Double = (it.shouldAmount ?: 0)/100.0
                    messagePkgContent.phone = it.mobile!!
                    messagePkgContent.context = "【和分享】尊敬的客户，您于" + DateTime(it.createdTime).toString("yyyy-MM-dd") + "在" + it.storeName + "办理的" + it.name + "，本期账单" + totalAmount + "元。系统将于今日10点从您尾号" + it.payAccount?.takeLast(4) + "的储蓄卡扣款。若卡内余额不足，扣款失败将影响您的个人征信，请及时预存，如有疑问可拨打客服电话0571-87209074。感谢您的配合。退订回T。"

                } else if (it.overdueDays!! in arrayOf(4, 10, 15)) {
                    val totalAmount: Double = ((it.penalty ?: 0) + (it.shouldAmount ?: 0))/100.0
                    messagePkgContent.phone = it.mobile!!
                    messagePkgContent.context = "【和分享】尊敬的客户，您于" + DateTime(it.createdTime).toString("yyyy-MM-dd") + "在" + it.storeName + "办理的" + it.name + "已逾期，逾期金额" + totalAmount + "元。系统将于今日10点从您尾号" + it.payAccount?.takeLast(4) + "的储蓄卡扣款。逾期3天后你的负面记录可能会上传人行征信，负面记录5年内无法消除。为避免您的生活受到影响，请务必于今日17点前还款，如有疑问可拨打客服电话0571-87209074。感谢您的配合。退订回T"

                } else if (it.overdueDays!! > 15 && (it.overdueDays!! - 16) % 7 == 0) {
                    val totalAmount: Double = ((it.penalty ?: 0) + (it.shouldAmount ?: 0)) / 100.0
                    messagePkgContent.phone = it.mobile!!
                    messagePkgContent.context = "【和分享】尊敬的客户，您于" + DateTime(it.createdTime).toString("yyyy-MM-dd") + "在" + it.storeName + "办理的" + it.name + "已逾期多日，且有意躲避我司催缴电话，已涉嫌恶意拖欠，逾期金额" + totalAmount + "元。请务必于今日17点前还款，否则我司可能会将您列入同业信贷风险客户名单，不良后果由你本人承担，如有疑问可拨打客服电话0571-87209074。退订回T。"

                }
                //符合发短信的条件--存入集合
                if (messagePkgContent.phone!=null && messagePkgContent.phone.length!=0) {
                    msgs.add(messagePkgContent)
                    //短信记录信息
                    val resultSendSms = ResultSendSms(
                            id = IdGenerator.nextId(Id.SMS),
                            mobile = messagePkgContent.phone,
                            outMsgId = outId,
                            msg = messagePkgContent.context,
                            createdTime = Calendar.getInstance().time,
                            status = ResultStatus.Request
                    )
                    listsms.add(resultSendSms)
                }
            }
            //当有符合的数据才发短信，短信记录才入库
            if (msgs.isNotEmpty()) {
                smsNotificationMapper.insertSendSms(listsms)
                logger.info("符合逾期提醒的短信批号为"+outId+"存入result_send_sms")
                return messageSendService.sendPkg(MessagePkgReq(msgs, method = MessagePkgReq.Method.CS, out_msgid = outId, backUrl = smsCallBackUrl))
            }else{
                throw ServiceException(ResEnum.NoOverdueUsersEligible)
            }

        } else {
            throw ServiceException(ResEnum.NoOverdueUsers)
      }
    }
   //===================代扣代缴（不兜底）提醒（月底+初）===================
   fun getInfoAboutWithholding():CloudResp<String> {
       val list = smsNotificationMapper.findInfoSendWithholding()
       val nowTime = Calendar.getInstance().time//当前系统时间
       val tim = Calendar.getInstance() //获取本月1号
       tim.add(Calendar.MONTH, 0)
       tim.set(Calendar.DAY_OF_MONTH, 1)
       
       if (list.isNotEmpty()) {
           //短信接口list
           val msgs = list.filter { it.mobile != null }.map {
               val amount = (it.shouldAmount ?: 0) / 100.0
               if(nowTime==tim.time){//当日提醒
                   MessagePkgContent(
                           phone = it.mobile!!,
                           context = "【和分享】尊敬的客户，您于" + DateTime(it.createdTime).toString("yyyy-MM-dd") + "在" + it.storeName + "办理的" + it.name +
                                   "，本期代扣话费" +amount+ "元。系统将于" + DateTime(nowTime).toString("yyyy-MM-dd") +
                                   ",10点从您尾号" + it.payAccount?.takeLast(4) + "的储蓄卡扣款。若卡内余额不足，请及时预存，如有疑问可拨打客服电话0571-87209074。感谢您的配合。退订回T。"
                   )
               }else{ //提前（月底）提醒
                   MessagePkgContent(
                           phone = it.mobile!!,
                           context = "【和分享】尊敬的客户，您于" + DateTime(it.createdTime).toString("yyyy-MM-dd") + "在" + it.storeName +
                                   "办理的" + it.name + "，下期代扣话费" +amount+ "元。系统将于" + DateTime(nowTime).toString("yyyy-MM-dd")+
                                   ",10点从您尾号" + it.payAccount?.takeLast(4) +
                                   "的储蓄卡扣款。若卡内余额不足，请及时预存，如有疑问可拨打客服电话0571-87209074。感谢您的配合。退订回T。"
                   )
               }
           }
           //短信结果list
           val out_id = IdGenerator.nextId(Id.SMS) //批次号
           val listsms = msgs.map {
               ResultSendSms(
                       id = IdGenerator.nextId(Id.SMS),
                       mobile = it.phone,
                       msg = it.context,
                       createdTime = Calendar.getInstance().time,
                       status = ResultStatus.Request,
                       outMsgId = out_id
               )
           }
           //infoSendSms批量入库
           smsNotificationMapper.insertSendSms(listsms)
           return messageSendService.sendPkg(MessagePkgReq(msgs, method = MessagePkgReq.Method.DK, out_msgid = out_id, backUrl = smsCallBackUrl))
       } else {
           throw ServiceException(ResEnum.NoUsersToRemind)
       }
   }
    //#------------代扣代缴（回扣）--------------
    fun sendSmsByPhoneBillNoAmount(id: String,flag:Boolean): CloudResp<String> {
        //根据mobile查询SmsVO对象
        val smsvo = smsNotificationMapper.findInfoSendSmsByTaskId(id)
        val listsms = mutableListOf<ResultSendSms>()

        if (smsvo != null) {
            val amount = (smsvo.shouldAmount ?: 0) / 100.0
            val out_id = IdGenerator.nextId(Id.SMS)
            val messageReq = MessageReq(mobile = "", msg = "", out_msgid = out_id, method = MessageReq.Method.DK, backUrl = smsCallBackUrl)

            messageReq.mobile = smsvo.mobile!!
            //话费扣款成功短信提醒
            if(flag)
            {
                messageReq.msg = "【和分享】尊敬的客户，您于" + DateTime(smsvo.createdTime).toString("yyyy-MM-dd") + "在" + smsvo.storeName + "办理的" + smsvo.name + "," + "本期代扣话费" + amount + "元已扣款成功，即将为您充值到手机账户，请关注话费余额变动。如有疑问可拨打客服电话0571-87209074。感谢您的支持与配合。退订回T。"
            }
            //话费扣款失败短信提醒
            else
            {
                messageReq.msg = "【和分享】尊敬的客户，您于" + DateTime(smsvo.createdTime).toString("yyyy-MM-dd") + "在" + smsvo.storeName + "办理的" + smsvo.name + "," + "本期代扣话费" + amount + "元。您绑定的尾号"+smsvo.payAccount?.takeLast(4)+"储蓄卡余额不足扣款失败。如有需要，请前往营业厅充值。如有疑问可拨打客服电话0571-87209074。感谢您的支持与配合。退订回T。"
            }
            val resultSendSms = ResultSendSms(
                    id = IdGenerator.nextId(Id.SMS),
                    mobile = smsvo.mobile,
                    msg = messageReq.msg,
                    createdTime = Calendar.getInstance().time,
                    status = ResultStatus.Request,
                    outMsgId = out_id
            )
            listsms.add(resultSendSms)
            smsNotificationMapper.insertSendSms(listsms)

            return messageSendService.send(messageReq)

        } else {
            throw ServiceException(ResEnum.NoThisUser)
        }
    }


}