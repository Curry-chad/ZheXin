package com.fina.summer.manager.client.util

import org.springframework.http.HttpMethod
import java.io.File
import java.io.Serializable
import java.util.*

class HttpRequestVO : Serializable {

    var url: String? = null

    private val header = HashMap<String, String>()

    var body: Any? = null

    private val files = ArrayList<File>()

    var timeout: Int? = null

    var method: HttpMethod? = null

    init {
        timeout = 6000 // ms
    }

    fun getHeader(): Map<String, String> {
        return header
    }

    fun setHeader(name: String, value: String) {
        this.header[name] = value
    }

    fun getFiles(): List<File> {
        return files
    }

    fun addFile(file: File) {
        this.files.add(file)
    }

    companion object {

        private const val serialVersionUID = 1L
    }

}
