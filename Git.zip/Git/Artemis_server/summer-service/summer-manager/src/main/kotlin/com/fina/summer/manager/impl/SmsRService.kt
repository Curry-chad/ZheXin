package com.fina.summer.manager.impl

import com.fina.cmcc.MessageSendService
import com.fina.cmcc.entity.MessageReq
import com.fina.summer.core.handler.SimpleException
import com.fina.summer.core.respone.ResEnum
import com.fina.summer.core.utils.DataUtil
import com.fina.summer.core.utils.EmailUtil
import com.fina.summer.manager.client.SmsClient
import com.fina.summer.manager.client.entity.Returnsms
import com.fina.summer.manager.entity.bo.ReceivableSmsResult
import com.fina.summer.persistent.ceres.entity.constant.ReturnStatus
import com.fina.summer.persistent.ceres.entity.domain.BillInTasksPO
import com.fina.summer.persistent.ceres.entity.domain.ShortMessageFlowPO
import com.fina.summer.persistent.ceres.repo.BillInTasksRepo
import com.fina.summer.persistent.ceres.repo.ShortMessageFlowRepo
import com.fina.summer.persistent.ceres.repo.ShortMessageRepo
import com.fina.summer.persistent.repo.summer.LoanOrderApplicantRepo
import org.slf4j.Logger
import org.slf4j.LoggerFactory
import org.springframework.stereotype.Service
import java.text.SimpleDateFormat
import java.util.*

@Service
class SmsRService(
        private val smsClient: SmsClient,
        private val billInTasksRepo: BillInTasksRepo,
        private val loanOrderApplicantRepo: LoanOrderApplicantRepo,
        private val shortMessageFlowRepo: ShortMessageFlowRepo,
        private val shortMessageRepo: ShortMessageRepo,
        private val messageSendService: MessageSendService,
        private val emailUtil: EmailUtil
) {

    private val logger: Logger = LoggerFactory.getLogger(SmsRService::class.java)

    private val lastIndex = 4

    private val sf = SimpleDateFormat("yyyy年MM月dd日")

    fun send(mobile: String, content: String): Returnsms {

        val res = messageSendService.send(MessageReq(
                mobile = mobile,
                msg = content
        ))

        return Returnsms(
                returnstatus=  if (res.code == "0") ReturnStatus.Success.name else ReturnStatus.Faild.name ,
                message= res.msg,
                payinfo= "",
                remainpoint= "",
                taskID= "",
                successCounts= ""
        )
        //return smsClient.send(mobile, content) as Returnsms
    }

    //批量发送
    fun batchSendReceivable(shortMessageId: Long, taskIds: List<String>): ReceivableSmsResult {
        var successCount = 0
        var failCount = 0
        val contentO = shortMessageRepo.findById(shortMessageId)
        if (!contentO.isPresent) {
            throw SimpleException(ResEnum.ParamErr.getCode(), "不存在该短信模板id")
        }
        val sms = contentO.get()
        val title = sms.title!!
        val content = sms.message!!
        taskIds.forEach {
            if (send(title, content, it, shortMessageId)) successCount++ else failCount++
        }
        return ReceivableSmsResult(successCount, failCount)
    }

    //发送 一条
    fun sendRemindAndFail(shortMessageId: Long, taskId: String): Boolean {
        val contentO = shortMessageRepo.findById(shortMessageId)
        if (!contentO.isPresent) {
            throw SimpleException(ResEnum.ParamErr.getCode(), "不存在该短信模板id")
        }
        val sms = contentO.get()
        val title = sms.title!!
        val content = sms.message!!
        return send(title, content, taskId, shortMessageId)
    }

    //common
    private fun send(title: String, content: String, taskId: String, shortMessageId: Long): Boolean {
        try {
            val task = billInTasksRepo.findById(taskId).get()
            val orderInfo = loanOrderApplicantRepo.findByOrderId(task.orderId!!)
            val mobile = orderInfo.mobile!!

            //获取发送模板内容
            val contentStr = getContent(title, content, task)

            /*  {
                  "code": "0",
                  "msg": "请求成功",
                  "data": "2019051619071257200"
              }
              {
                  "code": "3104",
                  "msg": "[102]参数不完整，所有参数都必须有数据",
                  "data": null,
                  "success": false
              }*/

            val res = messageSendService.send(MessageReq(
                    mobile = mobile,
                    msg = contentStr
            ))
            //val result = smsClient.send(mobile, contentStr) as Returnsms
            val status = if (res.code == "0") ReturnStatus.Success else ReturnStatus.Faild
            shortMessageFlowRepo.saveAndFlush(ShortMessageFlowPO(
                    taskId = taskId,
                    bisTaskId = task.bisTaskId,
                    smsId = res.data,
                    status = status,
                    message = contentStr,
                    resultMsg = "第三方接口返回信息：" + res.msg,
                    shortMessageId = shortMessageId
            ))
            return ReturnStatus.Success == status
        } catch (e: Exception) {
            shortMessageFlowRepo.saveAndFlush(ShortMessageFlowPO(
                    taskId = taskId,
                    status = ReturnStatus.Faild,
                    message = content,
                    resultMsg = "短信接口异常",
                    shortMessageId = shortMessageId
            ))
            logger.warn("receivable ssm happened error...", e)
            return false
        }
    }


    /**
     * 获取发送短信内容
     * 一丶 整理参数
     * 1.amount         task中获取金额
     * 2.account        task中获取银行卡
     * 3.deductTime     task中计划扣款时间
     *二丶 将参数替换掉模板中变量
     *
     * title 模板标题
     * content 模板内容
     *
     * smsClient.replaceContent(x,y)  //x 模板内容
     */
    private fun getContent(title: String, content: String, task: BillInTasksPO): String {
        val amount = DataUtil.convertDecimal(DataUtil.intToString(task.totalAmount))
        val account = task.payAccount!!.substring(task.payAccount!!.length - lastIndex)

        val planExecuteTime = task.planExecuteTime!!
        val deductTime = sf.format(planExecuteTime)

        return when (title) {
            "扣款前三天短信提示" -> smsClient.replaceContent(content, arrayOf(
                    amount,
                    deductTime,
                    account
            ))
            "扣款当天短信提示" -> smsClient.replaceContent(content, arrayOf(
                    amount,
                    account
            ))
            "10:00扣款失败短信提示" -> smsClient.replaceContent(content, arrayOf(
                    amount,
                    account,
                    "20:00"
            ))
            "22:00扣款失败短信提示" -> smsClient.replaceContent(content, arrayOf(
                    amount,
                    account,
                    "明日8:00"
            ))
            "扣款成功短信提示" -> smsClient.replaceContent(content, arrayOf(
                    amount
            ))
            else -> throw SimpleException(ResEnum.ParamErr.getCode(), "短信内容生成失败！")
        }
    }

}
