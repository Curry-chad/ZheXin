package com.fina.summer.manager.entity.bo

import java.io.Serializable

data class BatchDeductBO(
        var successCount: Int? = 0,

        var successAmount: String? = null,

        var failCount: Int? = 0,

        var failAmount: String? = null
): Serializable