package com.fina.summer.manager.client.util;

import com.alibaba.fastjson.JSONObject;
import org.dom4j.Document;
import org.dom4j.DocumentException;
import org.dom4j.DocumentHelper;
import org.dom4j.Element;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.Marshaller;
import java.io.StringWriter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class XmlUtil {
	
	private static final Logger LOGGER = LoggerFactory.getLogger(XmlUtil.class);
	
	public static <T> String beanToXml(T t) {
		try {
			JAXBContext context = JAXBContext.newInstance(t.getClass());
	        Marshaller m = context.createMarshaller();
	        
	        m.setProperty(Marshaller.JAXB_ENCODING, "UTF-8");
            m.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, true);
            m.setProperty(Marshaller.JAXB_FRAGMENT, true);
	        
	        StringWriter sw = new StringWriter();
	        m.marshal(t, sw);
	        return sw.toString();
		} catch (Exception e) {
			LOGGER.error("beanToXml error ... ", e);
		}
        return "";
	}

	public static String xmlStrToJson(String xmlStr) throws DocumentException {
		return JSONObject.toJSONString(readResponse(xmlStr));
	}

	public static Document getDoc(String xmlStr) throws DocumentException {
		return DocumentHelper.parseText(xmlStr);
	}

	@SuppressWarnings("unchecked")
	public static void getAllElements(List<Element> list, Map<String, Object> result) {
		for (Element tempEle : list) {
			List<Element> childEle = tempEle.elements();
			Map<String, Object> childResult = new HashMap<>();
			if (childEle.size() > 0) {
				getAllElements(childEle, childResult);
				result.put(tempEle.getName(), childResult);
			} else {
				result.put(tempEle.getName(), tempEle.getStringValue());
			}
		}
	}
	
	public static Map<String, Object> readResponse(String xmlStr) {
		Document doc = null;
		try {
			doc = getDoc(xmlStr);
		} catch (DocumentException e) {
			LOGGER.error("readResponse happended error {}", e);
		}
		Element responseElt = doc.getRootElement(); // 获取根节点

		Map<String, Object> result = new HashMap<>();
		getAllElementsByList(responseElt, result);
		return result;
	}

	@SuppressWarnings("unchecked")
	public static void getAllElementsByList(Element parentE, Map<String, Object> result) {
		Map<String, Object> EleList = getRepeatEle(parentE);
		List<List<Element>> repeatEleList = (List<List<Element>>) EleList.get("repeat");
		List<Element> otherEleList = (List<Element>) EleList.get("other");

		if (repeatEleList.size() > 0) {
			for (List<Element> temp : repeatEleList) {
				List<Object> resultList = new ArrayList<>();
				for (Element t : temp) {
					Map<String, Object> childResult = new HashMap<>();
					getAllElementsByList(t, childResult);
					resultList.add(childResult);
				}
				result.put(temp.get(0).getName(), resultList);
			}
			return;
		}

		for (Element tempO : otherEleList) {
			if (tempO.elements().size() > 0) {
				Map<String, Object> childResultO = new HashMap<>();
				getAllElementsByList(tempO, childResultO);
				result.put(tempO.getName(), childResultO);
			} else {
				result.put(tempO.getName(), tempO.getStringValue());
			}
		}
	}

	@SuppressWarnings("unchecked")
	public static Map<String, Object> getRepeatEle(Element parentE) {
		List<Element> childEleList = parentE.elements();
		List<String> eNameList = getRepeatNameList(childEleList);

		List<List<Element>> repeatEleList = new ArrayList<>();
		List<Element> otherEleList = new ArrayList<>();

		for (String eName : eNameList) {
			List<Element> repeatList = new ArrayList<>();
			for (Element e : childEleList) {
				if (eName.equals(e.getName())) {
					repeatList.add(e);
				}
			}
			repeatEleList.add(repeatList);
		}

		for (Element e : childEleList) {
			String eName = e.getName();
			if (!exist(eNameList, eName)) {
				otherEleList.add(e);
			}
		}

		Map<String, Object> map = new HashMap<>();
		map.put("repeat", repeatEleList);
		map.put("other", otherEleList);
		return map;
	}

	public static List<String> getRepeatNameList(List<Element> childEleList) {
		Map<String, Integer> eleNameMap = new HashMap<>();

		for (Element e : childEleList) {
			Integer count = 1;
			String eName = e.getName();
			if (eleNameMap.containsKey(eName)) {
				count = eleNameMap.get(eName) + 1;
			}
			eleNameMap.put(eName, count);
		}

		List<String> eNameList = new ArrayList<>();
		for (Map.Entry<String, Integer> temp : eleNameMap.entrySet()) {
			if (temp.getValue() != 1) {
				eNameList.add(temp.getKey());
			}
		}
		return eNameList;
	}

	public static boolean exist(List<String> list, String s) {
		for (String t : list) {
			if (t.equals(s)) {
				return true;
			}
		}
		return false;
	}
}
