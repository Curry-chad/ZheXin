package com.fina.summer.manager.client

enum class SummerUrl(var interfaceName: String) {

    ZxReceipt("/notify/zxReceipt"),

    BillRepay("/bill/repay"),

    BillRemit("/bill/remit"),

    Deduct("/deduct/do"),

    ChargeBack("/doChargeBack"),

    DeDuctCallBack("/operate/deduct/deductCallBack")
}