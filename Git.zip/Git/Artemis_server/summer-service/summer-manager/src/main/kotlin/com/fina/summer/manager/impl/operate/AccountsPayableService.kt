package com.fina.summer.manager.impl.operate

import com.alibaba.fastjson.JSON
import com.aliyun.oss.ServiceException
import com.fina.summer.core.respone.ResEnum
import com.fina.summer.core.respone.WebResult
import com.fina.summer.persistent.ceres.entity.constant.Progress
import com.fina.summer.persistent.ceres.entity.domain.BillOutFlowsPO
import com.fina.summer.persistent.ceres.entity.vo.AccountPayableVO
import com.fina.summer.persistent.ceres.entity.vo.BatchAuditVO
import com.fina.summer.persistent.ceres.entity.vo.OutBackQueryParam
import com.fina.summer.persistent.ceres.mapper.BillOutMapper
import com.fina.summer.persistent.ceres.mapper.BillOutTasksMapper
import com.fina.summer.persistent.ceres.repo.BillOutFlowsRepo
import com.fina.summer.persistent.ceres.repo.BillOutPlanRepo
import com.fina.summer.persistent.ceres.repo.BillOutTasksRepo
import org.apache.commons.lang3.StringUtils
import org.slf4j.LoggerFactory
import org.springframework.stereotype.Service
import org.springframework.web.bind.annotation.RequestBody
import java.math.BigDecimal
import java.text.ParseException
import java.text.SimpleDateFormat
import java.util.*


@Service
class AccountsPayableService(

        private val billOutTasksMapper: BillOutTasksMapper,
        private val billOutTasksRepo: BillOutTasksRepo,
        private val billOutFlowsRepo: BillOutFlowsRepo,
        private val billOutMapper: BillOutMapper,
        private val billOutPlanRepo: BillOutPlanRepo

) {
    private val logger = LoggerFactory.getLogger(AccountsPayableService::class.java)


    fun change(accountPayableVO: AccountPayableVO): WebResult<Void> {
        logger.info("应付账单传入参数:$accountPayableVO")
        val format = SimpleDateFormat("yyyy-MM-dd HH:mm:ss")
        var str: String? = accountPayableVO.finishTime + " 00:00:00"
        val date = format.parse(str)
        val now = Date()
        val operator = "operator"
        if(accountPayableVO.outTaskId == null || accountPayableVO.totalAmount == null){
            throw ServiceException("参数缺失")
        }
        var outTaskPO = this.billOutTasksRepo.findById(accountPayableVO.outTaskId!!)
        if(!outTaskPO.isPresent){
            throw ServiceException("${accountPayableVO.outTaskId} 查找不到应付记录")
        }
        val db = BigDecimal(accountPayableVO.totalAmount)
        val amount = db.multiply(BigDecimal(100)).toInt()
        var outTask = outTaskPO.get()
        outTask.totalAmount =  amount
        outTask.payAccount = accountPayableVO.payAccount
        outTask.payBank = accountPayableVO.payBank
        outTask.payer = accountPayableVO.payer
        outTask.message = accountPayableVO.message
        outTask.modifyBy = accountPayableVO.modifyBy
        outTask.lastExecuteTime = now
        outTask.modifyTime = now
        outTask.updatedTime = now
        outTask.status = Progress.Success
        outTask.finishTime = date
        outTask = this.billOutTasksRepo.save(outTask)

        val planTask = billOutPlanRepo.findById(outTask.bisTaskId!!).get()
        planTask.status = Progress.Success
        planTask.modifyBy = accountPayableVO.modifyBy
        planTask.updatedTime = now
        planTask.modifyTime = now
        planTask.actualAmount = amount
        planTask.modifyBy = accountPayableVO.modifyBy
        billOutPlanRepo.save(planTask)

        logger.info("${JSON.toJSONString(outTask)} 更新成功")
        //生成流水
        this.billOutFlowsRepo.save(BillOutFlowsPO(
                taskId = outTask.id,
                bisTaskId = outTask.bisTaskId,
                requestNo = outTask.requestNo,
                thirdOrderId = outTask.thirdOrderId,
                amount = outTask.totalAmount,
                executeTime = outTask.lastExecuteTime,
                message = outTask.message,
                payAccount = outTask.payAccount,
                payBank = outTask.payBank,
                payer = outTask.payer,
                payType = outTask.payType.toString(),
                payee = outTask.payee,
                payeeAccount = outTask.payeeAccount,
                payeeOpenInstitution = outTask.payeeOpenInstitution,
                penalty = outTask.penalty,
                status = outTask.status.toString(),
                tradeId = outTask.tradeId,
                createBy = operator,
                modifyBy = outTask.modifyBy,
                modifyTime = outTask.modifyTime,
                createdTime = now,
                updatedTime = now
        ))
        logger.info("${accountPayableVO.outTaskId} - ${outTask.tradeId}流水数据更新成功")
        return ResEnum.success()
    }

    fun back(@RequestBody outBackQueryParam: OutBackQueryParam): WebResult<Void> {
        val now = Date()
        val operator = "ceres"
        var billStatus: Progress = Progress.Doing
        //val outFlow = this.billOutFlowsRepo.findByTaskIdDesc(outBackQueryParam.outTaskId!!)
        val outFlow = this.billOutMapper.findByTaskIdDesc(outBackQueryParam.outTaskId!!)
        val outTask = this.billOutTasksRepo.findById(outBackQueryParam.outTaskId!!).get()
        if (outFlow == null) {
            logger.info("流水数据为空${outBackQueryParam.outTaskId!!}")
            outTask.status = Progress.Ready
            outTask.payBank = null
            outTask.payAccount = null
            outTask.payer = null
            outTask.totalAmount = null
            outTask.lastExecuteTime = null
            outTask.thirdOrderId = null
            outTask.requestNo = null
        } else {
            logger.info("流水数据不为空${outBackQueryParam.outTaskId!!}")
            outTask.payBank = outFlow.payBank
            outTask.payAccount = outFlow.payAccount
            outTask.payer = outFlow.payer
            outTask.totalAmount = outFlow.amount
            outTask.thirdOrderId = outFlow.thirdOrderId
            when {
                outFlow.status == "Ready" -> billStatus = Progress.Ready
                outFlow.status == "Cancel" -> billStatus = Progress.Cancel
                outFlow.status == "Doing" -> billStatus = Progress.Doing
                outFlow.status == "Interrupt" -> billStatus = Progress.Interrupt
                outFlow.status == "Success" -> billStatus = Progress.Success
                outFlow.status == "Fail" -> billStatus = Progress.Fail
            }
            outTask.status = billStatus
            outTask.lastExecuteTime = outFlow.executeTime
            outTask.modifyBy = outBackQueryParam.modifyBy
            outTask.modifyTime = now
        }
        outTask.modifyBy = outBackQueryParam.modifyBy
        outTask.modifyTime = now
        outTask.message = "回退:${outBackQueryParam.msg}"
        outTask.updatedTime = now
        outTask.finishTime = null
        this.billOutTasksRepo.save(outTask)
        logger.info("${JSON.toJSONString(outTask)} 回退更新成功")

        this.billOutFlowsRepo.save(BillOutFlowsPO(
                taskId = outTask.id,
                bisTaskId = outTask.bisTaskId,
                requestNo = outTask.requestNo,
                thirdOrderId = outTask.thirdOrderId,
                amount = outTask.totalAmount,
                executeTime = outTask.lastExecuteTime,
                message = outTask.message,
                payAccount = outTask.payAccount,
                payBank = outTask.payBank,
                payer = outTask.payer,
                payType = outTask.payType.toString(),
                payee = outTask.payee,
                payeeAccount = outTask.payeeAccount,
                payeeOpenInstitution = outTask.payeeOpenInstitution,
                penalty = outTask.penalty,
                status = outTask.status.toString(),
                tradeId = outTask.tradeId,
                createBy = operator,
                modifyBy = outTask.modifyBy,
                modifyTime = outTask.modifyTime,
                createdTime = now,
                updatedTime = now
        ))
        return ResEnum.success()
    }


    fun batchAuditConfirm(batchAuditVO: BatchAuditVO): List<String> {
        val now = Date()
        val format = SimpleDateFormat("yyyyMMdd HH:mm:ss")
        var date: Date? = null
        var str: String? = batchAuditVO.date + " 00:00:00"
        val list = mutableListOf<String>()
        try {
            date = format.parse(str)
        } catch (e: ParseException) {
            e.printStackTrace()
        }
        if (batchAuditVO.success != null) {
            batchAuditVO.success!!.forEach {
                val outTask = this.billOutTasksMapper.findByOrderIdAndType(it.orderId!!)
                val planTask = billOutPlanRepo.findById(outTask!!.bisTaskId!!).get()
                if (outTask != null) list.add(outTask.tradeId!!)
                outTask!!.updatedTime = now
                outTask.finishTime = date
                outTask.status = Progress.Success
                outTask.lastExecuteTime = now
                outTask.message = "成功录入"
                outTask.modifyBy = batchAuditVO.modifyBy
                if (StringUtils.isNoneBlank(batchAuditVO.payAccount)) {
                    outTask.payAccount = batchAuditVO.payAccount
                }
                if (StringUtils.isNoneBlank(batchAuditVO.payBank)) {
                    outTask.payBank = batchAuditVO.payBank
                }
                if (StringUtils.isNoneBlank(batchAuditVO.payer)) {
                    outTask.payer = batchAuditVO.payer
                }
                if (StringUtils.isNoneBlank(it.thirdOrderId)) {
                    outTask.thirdOrderId = it.thirdOrderId
                }
                if (StringUtils.isNoneBlank(it.totalAmount)) {
                    outTask.totalAmount = it.totalAmount!!.toInt()
                }
                outTask.modifyBy = batchAuditVO.modifyBy
                this.billOutTasksRepo.save(outTask!!)

                planTask.status = Progress.Success
                planTask.modifyBy = batchAuditVO.modifyBy
                planTask.updatedTime = now
                planTask.modifyTime = now
                planTask.modifyBy = batchAuditVO.modifyBy
                planTask.actualAmount = it.totalAmount!!.toInt()
                billOutPlanRepo.save(planTask)

                this.billOutFlowsRepo.save(BillOutFlowsPO(
                        taskId = outTask.id,
                        bisTaskId = outTask.bisTaskId,
                        requestNo = outTask.requestNo,
                        thirdOrderId = outTask.thirdOrderId,
                        amount = outTask.totalAmount,
                        executeTime = outTask.lastExecuteTime,
                        message = outTask.message,
                        payAccount = outTask.payAccount,
                        payBank = outTask.payBank,
                        payer = outTask.payer,
                        payType = outTask.payType.toString(),
                        payee = outTask.payee,
                        payeeAccount = outTask.payeeAccount,
                        payeeOpenInstitution = outTask.payeeOpenInstitution,
                        penalty = outTask.penalty,
                        status = outTask.status.toString(),
                        tradeId = outTask.tradeId,
                        createBy = "ceres",
                        modifyBy = outTask.modifyBy,
                        modifyTime = outTask.modifyTime,
                        createdTime = date,
                        updatedTime = date
                ))
            }
        }
        failMessage(batchAuditVO.repeate!!, date, "重复打款")
        failMessage(batchAuditVO.more!!, date, "超额打款")
        failMessage(batchAuditVO.withoutAccount!!, date, "账号不存在")
        failMessage(batchAuditVO.wrongAmount!!, date, "金额不匹配")
        failMessage(batchAuditVO.withoutOrder!!, date, "订单不存在")
        batchAuditVO.other?.forEach {
            val outTask = this.billOutTasksMapper.findByOrderIdAndType(it.orderId!!)
            if (outTask != null) {
                outTask.updatedTime = date
                if (outTask.status != Progress.Success) {
                    outTask!!.message = it.msg
                    this.billOutTasksRepo.save(outTask!!)
                }
            }
        }
        return list
    }

    private fun failMessage(list: List<String>, date: Date?, string: String) = list?.forEach {
        val outTask = this.billOutTasksMapper.findByOrderIdAndType(it)
        if (outTask != null) {
            outTask.updatedTime = date
            if (outTask.status != Progress.Success) {
                outTask!!.message = string
                this.billOutTasksRepo.save(outTask!!)
            }
        }
    }
}