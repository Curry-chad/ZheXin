package com.fina.summer.manager.entity.bo

import java.io.Serializable

data class DeductBO(
        var success: Boolean? = null,

        var amount: Int? = null,

        var msg: String? = null
): Serializable