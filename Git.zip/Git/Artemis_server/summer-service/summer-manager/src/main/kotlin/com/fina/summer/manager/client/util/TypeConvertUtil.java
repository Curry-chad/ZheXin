package com.fina.summer.manager.client.util;

import com.alibaba.fastjson.JSONException;
import com.alibaba.fastjson.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.beans.BeanInfo;
import java.beans.IntrospectionException;
import java.beans.Introspector;
import java.beans.PropertyDescriptor;
import java.lang.reflect.InvocationTargetException;
import java.util.*;

public class TypeConvertUtil {
	
	private static final Logger LOGGER = LoggerFactory.getLogger(TypeConvertUtil.class);
	
	private static Map<String, Object> toLowerKey(Map<String, Object> map) {
		Map<String, Object> result = new HashMap<>();
		for (Map.Entry<String, Object> t : map.entrySet()) {
			String key = t.getKey();
			if (Character.isUpperCase(key.charAt(0))) {
				key = (new StringBuilder()).append(Character.toLowerCase(key.charAt(0))).append(key.substring(1))
						.toString();
			}
			result.put(key, t.getValue());
		}
		return result;
	}

	@SuppressWarnings({ "rawtypes", "unchecked" })
	public static Object convertMapWithLowerKey(Class type, Map map)
			throws IntrospectionException, IllegalAccessException, InstantiationException, InvocationTargetException {
		BeanInfo beanInfo = Introspector.getBeanInfo(type); // 获取类属性
		Object obj = type.newInstance(); // 创建 JavaBean 对象

		Map<String, Object> propertyMap = map;
		propertyMap = toLowerKey(propertyMap);
		// 给 JavaBean 对象的属性赋值
		PropertyDescriptor[] propertyDescriptors = beanInfo.getPropertyDescriptors();
		for (int i = 0; i < propertyDescriptors.length; i++) {
			PropertyDescriptor descriptor = propertyDescriptors[i];
			String propertyName = descriptor.getName();

			if (propertyMap.containsKey(propertyName)) {
				// 下面一句可以 try 起来，这样当一个属性赋值失败的时候就不会影响其他属性赋值。
				try {
					Object value = propertyMap.get(propertyName);

					Object[] args = new Object[1];
					args[0] = value;

					descriptor.getWriteMethod().invoke(obj, args);
				} catch(Exception e) {
					LOGGER.error("convert to class happened error ... {}", e);
				}
				
			}
		}
		return obj;
	}

	/**
	 * 将一个 Map 对象转化为一个 JavaBean
	 * 
	 * @param type
	 *            要转化的类型
	 * @param map
	 *            包含属性值的 map
	 * @return 转化出来的 JavaBean 对象
	 * @throws IntrospectionException
	 *             如果分析类属性失败
	 * @throws IllegalAccessException
	 *             如果实例化 JavaBean 失败
	 * @throws InstantiationException
	 *             如果实例化 JavaBean 失败
	 * @throws InvocationTargetException
	 *             如果调用属性的 setter 方法失败
	 */
	@SuppressWarnings("rawtypes")
	public static Object convertMap(Class type, Map map)
			throws IntrospectionException, IllegalAccessException, InstantiationException, InvocationTargetException {
		BeanInfo beanInfo = Introspector.getBeanInfo(type); // 获取类属性
		Object obj = type.newInstance(); // 创建 JavaBean 对象

		// 给 JavaBean 对象的属性赋值
		PropertyDescriptor[] propertyDescriptors = beanInfo.getPropertyDescriptors();
		for (int i = 0; i < propertyDescriptors.length; i++) {
			PropertyDescriptor descriptor = propertyDescriptors[i];
			String propertyName = descriptor.getName();

			if (map.containsKey(propertyName)) {
				// 下面一句可以 try 起来，这样当一个属性赋值失败的时候就不会影响其他属性赋值。
				Object value = map.get(propertyName);
				if (value instanceof Map) {
					value = convertMap(descriptor.getPropertyType(), (Map) value);
				}

				Object[] args = new Object[1];
				args[0] = value;

				descriptor.getWriteMethod().invoke(obj, args);
			}
		}
		return obj;
	}

	@SuppressWarnings("unchecked")
	public static Object jsonToMap(String test) {
		Map<Object, Object> resultMap = new HashMap<>();
		try {
			resultMap = JSONObject.parseObject(test, Map.class);
		} catch (JSONException ex) {
			List<Object> resulArray = new ArrayList<>();
			try {
				resulArray = JSONObject.parseArray(test);
			} catch (JSONException ex1) {
				return test;
			}
			if (resulArray != null && resulArray.size() > 0) {
				for (Object arrayTemp : resulArray) {
					if (arrayTemp != null) {
						Collections.replaceAll(resulArray, arrayTemp, jsonToMap(arrayTemp.toString()));
					}
				}
			}
			return resulArray;
		}
		if (resultMap != null && resultMap.size() > 0) {
			for (Map.Entry<Object, Object> temp : resultMap.entrySet()) {
				Object value = temp.getValue();
				if (value != null) {
					resultMap.put(temp.getKey(), jsonToMap(value.toString()));
				}
			}
		}
		return resultMap;
	}

	/**判断一个对象是否是基本类型或基本类型的封装类型*/
	public static boolean isPrimitive(Object obj) {
		try {
			return ((Class<?>)obj.getClass().getField("TYPE").get(null)).isPrimitive();
		} catch (Exception e) {
			return false;
		}
	}

}
