package com.fina.summer.manager.client.entity

import java.io.Serializable

data class Returnsms(

        var returnstatus: String? = null,

        var message: String? = null,

        var payinfo: String? = null,

        var remainpoint: String? = null,

        var taskID: String? = null,

        var successCounts: String? = null
): Serializable
