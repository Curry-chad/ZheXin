package com.fina.summer.manager.impl.data.business

import com.fina.summer.manager.IStatisticsService
import com.fina.summer.persistent.summer.entity.vo.SumAllVo
import com.fina.summer.persistent.summer.mapper.BusinessStatisticsMapper
import org.springframework.stereotype.Service

@Service
class StatisticsService(
        private val businessStatisticsMapper: BusinessStatisticsMapper
) : IStatisticsService {

    override fun findByAll(): SumAllVo {
        var areasList = businessStatisticsMapper.findGroupByArea()
        var sumAllVo = businessStatisticsMapper.findByAll()
        sumAllVo.areaList = areasList
        return sumAllVo
    }


}