package com.fina.summer.manager.client

import com.fina.summer.core.respone.WebResult
import com.fina.summer.manager.client.util.HttpRequestVO
import com.fina.summer.manager.client.util.Log
import org.springframework.core.ParameterizedTypeReference
import org.springframework.http.HttpEntity
import org.springframework.http.HttpHeaders
import org.springframework.http.HttpMethod
import org.springframework.http.HttpStatus
import org.springframework.stereotype.Component
import org.springframework.util.MultiValueMap
import org.springframework.web.client.RestTemplate

@Component
class BaseHttpClient(
        private val restTemplate: RestTemplate
) {

    @Log
    fun <T> restGet(requestVO: HttpRequestVO): WebResult<T>? {
        val headers = HttpHeaders()
        requestVO.getHeader().forEach {
            headers[it.key] = it.value
        }
        requestVO.method = HttpMethod.GET
        val parameterizedTypeReference = object: ParameterizedTypeReference<WebResult<T>>() {}
        val responseEntity = restTemplate.exchange<WebResult<T>>(
                requestVO.url!!,
                HttpMethod.GET,
                null,
                parameterizedTypeReference)
        if (responseEntity.statusCode != HttpStatus.OK) {
            return null
        }
        return responseEntity.body
    }

    @Log
    fun restPostByForm(requestVO: HttpRequestVO): Any? {
        val headers = HttpHeaders()
        requestVO.getHeader().forEach {
            headers[it.key] = it.value
        }
        requestVO.method = HttpMethod.POST
        val body = requestVO.body as MultiValueMap<String, String>
        val responseEntity = restTemplate.postForEntity(requestVO.url!!, HttpEntity(body, headers), String::class.java)
        if (responseEntity.statusCode != HttpStatus.OK) {
            return null
        }
        return responseEntity.body
    }
}
