package com.fina.summer.manager.impl.operate

import com.fina.summer.core.handler.SimpleException
import com.fina.summer.core.respone.ResEnum
import com.fina.summer.core.utils.DataUtil
import com.fina.summer.core.utils.DateUtils
import com.fina.summer.core.utils.EmailUtil
import com.fina.summer.manager.client.SummerClient
import com.fina.summer.manager.entity.dto.TotalRemitData
import com.fina.summer.manager.entity.dto.TotalRepayData
import com.fina.summer.persistent.ceres.entity.constant.*
import com.fina.summer.persistent.ceres.entity.domain.BillInTasksPO
import com.fina.summer.persistent.ceres.entity.domain.BillOutPlanPO
import com.fina.summer.persistent.ceres.entity.domain.BillOutTasksPO
import com.fina.summer.persistent.ceres.entity.domain.BillRepayPlanPO
import com.fina.summer.persistent.ceres.repo.BillInTasksRepo
import com.fina.summer.persistent.ceres.repo.BillOutPlanRepo
import com.fina.summer.persistent.ceres.repo.BillOutTasksRepo
import com.fina.summer.persistent.ceres.repo.BillRepayPlanRepo
import org.slf4j.Logger
import org.slf4j.LoggerFactory
import org.springframework.stereotype.Service
import org.springframework.transaction.annotation.Transactional
import org.springframework.util.CollectionUtils
import java.text.SimpleDateFormat
import java.util.*

@Service
class TradeTaskNotifyService(
        private val billInTasksRepo: BillInTasksRepo,
        private val billRepayPlanRepo: BillRepayPlanRepo,
        private val billOutPlanRepo: BillOutPlanRepo,
        private val billOutTasksRepo: BillOutTasksRepo,
        private val summerClient: SummerClient,
        private val emailUtil: EmailUtil
) {

    private val operator = "ceres"
    private val logger: Logger = LoggerFactory.getLogger(TradeTaskNotifyService::class.java)

    fun createInvalidRepayPlan(repayPlanId: String) {
        // TODO 请求getRepayPlanInfo,获取具体数据信息
        val response = summerClient.billRepay(repayPlanId)!!
        if (response.code != ResEnum.Success.getCode()) {
            throw SimpleException(response.code, response.msg!!)
        }
        val repayData = response.data!!
        when (repayData.type) {
            BillType.User -> saveInvalidRepayPlanFromUser(repayData)
            BillType.Zyxf -> saveInvalidRepayPlanFromZy(repayData)
            else -> throw SimpleException(ResEnum.Fail.getCode(), "repayPlanId = $repayPlanId,type = $repayData.type 无法识别款单类型（用户 or 中原?）")
        }
    }

    fun createInvalidMerRemit(merRemitId: String) {
        val response = summerClient.billRemit(merRemitId)!!
        if (response.code != ResEnum.Success.getCode()) {
            throw SimpleException(response.code, response.msg!!)
        }
        val merRemitData = response.data!!
        saveInvalidOutPlanFromMer(merRemitData)
    }

    fun cancelRepayPlan(bisTaskId: String) {
        val now = Date()
        val operator = "ceres"

        val repayPlan = billRepayPlanRepo.findById(bisTaskId).get()
        val tasks = billInTasksRepo.findByBisTaskId(bisTaskId) ?: listOf()
        // TODO 若用户在 完全生成全部期数task数据前 就取消了订单, 需要的处理?
        // TODO 订单取消(未还款task audit状态修改为 1)
        tasks.forEach {
            it.audit = AuditStatus.InRefundAudit.status
            it.modifyBy = operator
            it.modifyTime = now
            it.updatedTime = now

            billInTasksRepo.save(it)
        }
        // TODO 总表状态设置为取消
        repayPlan.audit = AuditStatus.InRefundAudit.status
        repayPlan.modifyBy = operator
        repayPlan.modifyTime = now
        repayPlan.updatedTime = now
        billRepayPlanRepo.save(repayPlan)
    }

    fun cancelMerRemit(bisTaskId: String) {
        val now = Date()
        val operator = "ceres"

        val merRemit = billOutPlanRepo.findById(bisTaskId).get()
        val tasks = billOutTasksRepo.findByBisTaskId(bisTaskId) ?: listOf()
        // TODO 订单取消(未还款task audit状态修改为 1)
        tasks.forEach {
            it.audit = AuditStatus.InRefundAudit.status
            it.modifyBy = operator
            it.modifyTime = now
            it.updatedTime = now

            billOutTasksRepo.save(it)
        }
        // TODO 总表状态设置为取消
        merRemit.audit = AuditStatus.InRefundAudit.status
        merRemit.modifyBy = operator
        merRemit.modifyTime = now
        merRemit.updatedTime = now
        billOutPlanRepo.save(merRemit)
    }

    /**
     * 更新总表以及tasks表 from kafka
     */
    fun saveRepayPlanAndTasks(repayPlanId: String) {
        // TODO 请求getRepayPlanInfo,获取具体数据信息
        logger.info("saveRepayPlanAndTasks id:$repayPlanId ")
        val response = summerClient.billRepay(repayPlanId)!!
        if (response.code != ResEnum.Success.getCode()) {
            throw SimpleException(response.code, "summerClient billRepay error,id:$repayPlanId " + response.msg!!)
        }
        val repayData = response.data!!
        logger.info("summerClient billRepay success,id:$repayPlanId ,repayData =$repayData")
        when (repayData.type) {
            BillType.User -> saveRepayPlanFromUser(repayData)
            BillType.Zyxf -> saveRepayPlanFromZhongyuan(repayData)
            BillType.PhoneBill -> saveRepayPlanFromUser(repayData)
            BillType.PhoneBillNoAmount ->saveRepayPlanFromUser(repayData)
            else -> throw SimpleException(ResEnum.Fail.getCode(), "repayPlanId = $repayPlanId,repayData= $repayData 无法识别款单类型（用户 or 中原?）")
        }
    }

    fun saveMerRemitAndTasks(merRemitId: String) {
        val response = summerClient.billRemit(merRemitId)!!

        if (response.code != ResEnum.Success.getCode()) {
            throw SimpleException(response.code, response.msg!!)
        }
        val merRemitData = response.data!!
        logger.info("类型为:" +merRemitData.type)
        saveMerRemitFromUser(merRemitData)


    }

    private fun saveInvalidRepayPlanFromUser(repayData: TotalRepayData) {
        val bisTaskId = repayData.id!!
        val periodTimes = repayData.periodTimes!!
        val now = Date()
        val status = Progress.Ready
        val audit = AuditStatus.InRefundAudit.status

        // TODO 更新bill_repay_plan表(insert or update[订单取消])，同时判断是否更新bill_in_tasks表(insert or update[订单取消])
        billRepayPlanRepo.save(BillRepayPlanPO(
                id = repayData.id,
                tradeId = repayData.tradeId,
                orderId = repayData.orderId,
                debitChannel = repayData.debitChannel,
                fundChannel = repayData.fundChannel,
                periodTimes = repayData.periodTimes,
                orderTradeTime = DataUtil.longToDate(repayData.orderTradeTime),
                payAccount = repayData.payAccount,
                payBank = repayData.payBank,
                payer = repayData.payer,
                payerIdno = repayData.payerIdno,
                repayDate = DataUtil.longToDate(repayData.repayDate),
                shouldAmount = repayData.shouldAmount,
                merId = repayData.merId,
                status = status,
                createBy = repayData.createBy,
                modifyBy = repayData.modifyBy,
                modifyTime = DataUtil.longToDate(repayData.modifyTime),
                createdTime = DataUtil.longToDate(repayData.createTime),
                updatedTime = now,
                loanReqNo = repayData.loanReqNo,
                loanNo = repayData.loanNo,
                contReqNo = repayData.contReqNo,
                contNo = repayData.contNo,
                type = repayData.type,
                audit = audit
        ))
        val tasks = billInTasksRepo.findByBisTaskId(bisTaskId)

        if (CollectionUtils.isEmpty(tasks)) {
            // TODO 创建tasks数据
            val totalShouldAmount = repayData.shouldAmount!!
            val orderTradeTime = DataUtil.longToDate(repayData.orderTradeTime)!!
            val shouldAmount = getShouldAmountByPeriod(totalShouldAmount, periodTimes)

            for (i in 1..periodTimes) {
                val planExecuteTime = getPlanExecuteTime(orderTradeTime, i)
                billInTasksRepo.save(BillInTasksPO(
                        bisTaskId = bisTaskId,
                        orderId = repayData.orderId,
                        tradeId = repayData.tradeId,
                        debitChannel = repayData.debitChannel,
                        finishTime = null,
                        fundChannel = repayData.fundChannel,
                        payAccount = repayData.payAccount,
                        payBank = repayData.payBank,
                        payType = PayType.Debit,
                        payer = repayData.payer,
                        payerIdno = repayData.payerIdno,
                        penalty = 0,
                        planExecuteTime = planExecuteTime,
                        nextExecuteTime = planExecuteTime,
                        lastExecuteTime = null,
                        overdueDays = 0,
                        message = null,
                        requestNo = null,
                        seqNo = i,
                        shouldAmount = shouldAmount,
                        status = status,
                        checkStatus = CheckStatus.NoApplyCheck.status,
                        taskType = TaskType.Repay,
                        thirdOrderId = null,
                        totalAmount = shouldAmount,
                        createBy = operator,
                        modifyBy = null,
                        modifyTime = null,
                        createdTime = now,
                        updatedTime = now,
                        loanReqNo = repayData.loanReqNo,
                        loanNo = repayData.loanNo,
                        contReqNo = repayData.contReqNo,
                        contNo = repayData.contNo,
                        type = repayData.type,
                        audit = audit
                ))
            }
        }
    }

    private fun saveInvalidRepayPlanFromZy(repayData: TotalRepayData) {
        val bisTaskId = repayData.id!!
        val periodTimes = repayData.periodTimes!!
        val now = Date()
        val status = Progress.Ready
        val audit = AuditStatus.InRefundAudit.status

        // TODO 更新bill_repay_plan表(insert or update[订单取消])，同时判断是否更新bill_in_tasks表(insert or update[订单取消])
        billRepayPlanRepo.save(BillRepayPlanPO(
                id = repayData.id,
                tradeId = repayData.tradeId,
                orderId = repayData.orderId,
                debitChannel = repayData.debitChannel,
                fundChannel = repayData.fundChannel,
                periodTimes = repayData.periodTimes,
                orderTradeTime = DataUtil.longToDate(repayData.orderTradeTime),
                payAccount = repayData.payAccount,
                payBank = repayData.payBank,
                payer = repayData.payer,
                payerIdno = repayData.payerIdno,
                repayDate = DataUtil.longToDate(repayData.repayDate),
                shouldAmount = repayData.shouldAmount,
                merId = repayData.merId,
                status = status,
                createBy = repayData.createBy,
                modifyBy = repayData.modifyBy,
                modifyTime = DataUtil.longToDate(repayData.modifyTime),
                createdTime = DataUtil.longToDate(repayData.createTime),
                updatedTime = now,
                loanReqNo = repayData.loanReqNo,
                loanNo = repayData.loanNo,
                contReqNo = repayData.contReqNo,
                contNo = repayData.contNo,
                type = repayData.type,
                audit = audit
        ))
        val tasks = billInTasksRepo.findByBisTaskId(bisTaskId)

        if (CollectionUtils.isEmpty(tasks)) {
            // TODO 创建tasks数据
            val totalShouldAmount = repayData.shouldAmount!!
            val shouldAmount = getShouldAmountByPeriod(totalShouldAmount, periodTimes)
            val planExecuteTime = getPlanExecuteTime(now, 0)
            for (i in 1..periodTimes) {
                billInTasksRepo.save(BillInTasksPO(
                        bisTaskId = bisTaskId,
                        orderId = repayData.orderId,
                        tradeId = repayData.tradeId,
                        debitChannel = repayData.debitChannel,
                        finishTime = null,
                        fundChannel = repayData.fundChannel,
                        payAccount = repayData.payAccount,
                        payBank = repayData.payBank,
                        payType = PayType.Debit,
                        payer = repayData.payer,
                        payerIdno = repayData.payerIdno,
                        penalty = 0,
                        planExecuteTime = planExecuteTime, //
                        nextExecuteTime = null, //
                        lastExecuteTime = null,
                        overdueDays = 0,
                        message = null,
                        requestNo = null,
                        seqNo = i,
                        shouldAmount = shouldAmount,
                        status = status,
                        checkStatus = CheckStatus.NoApplyCheck.status,
                        taskType = TaskType.Repay,
                        thirdOrderId = null,
                        totalAmount = shouldAmount,
                        createBy = operator,
                        modifyBy = null,
                        modifyTime = null,
                        createdTime = now,
                        updatedTime = now,
                        loanReqNo = repayData.loanReqNo,
                        loanNo = repayData.loanNo,
                        contReqNo = repayData.contReqNo,
                        contNo = repayData.contNo,
                        type = repayData.type,
                        audit = audit //
                ))
            }
        }
    }

    private fun saveInvalidOutPlanFromMer(merRemitData: TotalRemitData) {
        val bisTaskId = merRemitData.id!!
        val periodTimes = merRemitData.periodTimes!!
        val now = Date()
        val billType: BillType? = if (merRemitData.type != null) merRemitData.type else BillType.Merchant
        val status = Progress.Ready
        val audit = AuditStatus.InRefundAudit.status

        billOutPlanRepo.save(BillOutPlanPO(
                id = merRemitData.id,
                orderId = merRemitData.orderId,
                tradeId = merRemitData.tradeId,
                accountOpenBank = merRemitData.accountOpenBank,
                debitChannel = merRemitData.debitChannel,
                fundChannel = merRemitData.fundChannel,
                shouldAmount = merRemitData.shouldAmount,
                actualAmount = merRemitData.actualAmount,
                periodTimes = merRemitData.periodTimes,
                merId = merRemitData.merId,
                orderTradeTime = DataUtil.longToDate(merRemitData.orderTradeTime),
                payDate = DataUtil.longToDate(merRemitData.payDate),
                payeeAccount = merRemitData.payeeAccount,
                payeeBank = merRemitData.payeeBank,
                payeeName = merRemitData.payeeName,
                status = status,
                createBy = operator,
                modifyBy = operator,
                modifyTime = now,
                createdTime = now,
                updatedTime = now,
                loanReqNo = merRemitData.loanReqNo,
                loanNo = merRemitData.loanNo,
                contReqNo = merRemitData.contReqNo,
                contNo = merRemitData.contNo,
                type = billType,
                audit = audit
        ))
        val tasks = billOutTasksRepo.findByBisTaskId(bisTaskId)
        if (CollectionUtils.isEmpty(tasks)) {
            val totalShouldAmount = merRemitData.shouldAmount!!
            val shouldAmount = getShouldAmountByPeriod(totalShouldAmount, periodTimes)
            val orderTradeTime = DataUtil.longToDate(merRemitData.orderTradeTime)!!
            val planExecuteTime = DateUtils.getDayByDays(orderTradeTime, 1)

            // TODO 创建tasks数据
            for (i in 1..periodTimes) {
                billOutTasksRepo.save(BillOutTasksPO(
                        bisTaskId = bisTaskId,
                        orderId = merRemitData.orderId,
                        tradeId = merRemitData.tradeId,
                        finishTime = null,
                        lastExecuteTime = null, //*
                        message = null,
                        nextExecuteTime = planExecuteTime, //*
                        overdueDays = 0,
                        payAccount = null,
                        payBank = null,
                        payType = PayType.Debit,
                        payee = merRemitData.payeeName,
                        payeeAccount = merRemitData.payeeAccount,
                        payeeOpenInstitution = merRemitData.accountOpenBank, //收款方开户行机构
                        payer = null,
                        penalty = 0,
                        planExecuteTime = planExecuteTime, //*
                        requestNo = null,
                        seqNo = i,
                        shouldAmount = shouldAmount,
                        status = status,
                        checkStatus = CheckStatus.NoApplyCheck.status,
                        taskType = TaskType.Advance, //*
                        thirdOrderId = null,
                        totalAmount = shouldAmount,
                        payeeBank = merRemitData.payeeBank,
                        debitChannel = merRemitData.debitChannel,
                        fundChannel = merRemitData.fundChannel,
                        createBy = operator,
                        modifyBy = operator,
                        modifyTime = now,
                        createdTime = now,
                        updatedTime = now,
                        loanReqNo = merRemitData.loanReqNo,
                        loanNo = merRemitData.loanNo,
                        contReqNo = merRemitData.contReqNo,
                        contNo = merRemitData.contNo,
                        type = billType,
                        audit = audit
                ))
            }
        }
    }

    private fun saveRepayPlanFromZhongyuan(repayData: TotalRepayData) {
        val bisTaskId = repayData.id!!
        val periodTimes = repayData.periodTimes!!
        val now = Date()
        // TODO 更新bill_repay_plan表(insert or update[订单取消])，同时判断是否更新bill_in_tasks表(insert or update[订单取消])
        val repayPlanO = billRepayPlanRepo.findById(bisTaskId)
        if (repayPlanO.isPresent) {
            return
        }

        billRepayPlanRepo.save(BillRepayPlanPO(
                id = repayData.id,
                tradeId = repayData.tradeId,
                orderId = repayData.orderId,
                debitChannel = repayData.debitChannel,
                fundChannel = repayData.fundChannel,
                periodTimes = repayData.periodTimes,
                orderTradeTime = DataUtil.longToDate(repayData.orderTradeTime),
                payAccount = repayData.payAccount,
                payBank = repayData.payBank,
                payer = repayData.payer,
                payerIdno = repayData.payerIdno,
                repayDate = DataUtil.longToDate(repayData.repayDate),
                shouldAmount = repayData.shouldAmount,
                merId = repayData.merId,
                status = repayData.status,
                createBy = repayData.createBy,
                modifyBy = repayData.modifyBy,
                modifyTime = DataUtil.longToDate(repayData.modifyTime),
                createdTime = DataUtil.longToDate(repayData.createTime),
                updatedTime = now,
                loanReqNo = repayData.loanReqNo,
                loanNo = repayData.loanNo,
                contReqNo = repayData.contReqNo,
                contNo = repayData.contNo,
                type = repayData.type,
                audit = AuditStatus.Normal.status
        ))
        val tasks = billInTasksRepo.findByBisTaskId(bisTaskId)

        if (CollectionUtils.isEmpty(tasks)) {
            // TODO 创建tasks数据
            val totalShouldAmount = repayData.shouldAmount!!
            val shouldAmount = getShouldAmountByPeriod(totalShouldAmount, periodTimes)
            val planExecuteTime = getPlanExecuteTime(now, 0)
            for (i in 1..periodTimes) {
                billInTasksRepo.save(BillInTasksPO(
                        bisTaskId = bisTaskId,
                        orderId = repayData.orderId,
                        tradeId = repayData.tradeId,
                        debitChannel = repayData.debitChannel,
                        finishTime = null,
                        fundChannel = repayData.fundChannel,
                        payAccount = repayData.payAccount,
                        payBank = repayData.payBank,
                        payType = PayType.Debit,
                        payer = repayData.payer,
                        payerIdno = repayData.payerIdno,
                        penalty = 0,
                        planExecuteTime = planExecuteTime, //
                        nextExecuteTime = null, //
                        lastExecuteTime = null,
                        overdueDays = 0,
                        message = null,
                        requestNo = null,
                        seqNo = i,
                        shouldAmount = shouldAmount,
                        status = repayData.status,
                        checkStatus = CheckStatus.NoApplyCheck.status,
                        taskType = TaskType.Repay,
                        thirdOrderId = null,
                        totalAmount = shouldAmount,
                        createBy = operator,
                        modifyBy = null,
                        modifyTime = null,
                        createdTime = now,
                        updatedTime = now,
                        loanReqNo = repayData.loanReqNo,
                        loanNo = repayData.loanNo,
                        contReqNo = repayData.contReqNo,
                        contNo = repayData.contNo,
                        type = repayData.type,
                        audit = AuditStatus.Normal.status,
                        accountId = repayData.signAccountId
                ))
            }
        }
    }

    private fun saveRepayPlanFromUser(repayData: TotalRepayData) {
        val bisTaskId = repayData.id!!
        val periodTimes = repayData.periodTimes!!
        val now = Date()
        // TODO 更新bill_repay_plan表(insert or update[订单取消])，同时判断是否更新bill_in_tasks表(insert or update[订单取消])
        val repayPlanO = billRepayPlanRepo.findById(bisTaskId)
        if (repayPlanO.isPresent) {
            return
        }

        billRepayPlanRepo.save(BillRepayPlanPO(
                id = repayData.id,
                tradeId = repayData.tradeId,
                orderId = repayData.orderId,
                debitChannel = repayData.debitChannel,
                fundChannel = repayData.fundChannel,
                periodTimes = repayData.periodTimes,
                orderTradeTime = DataUtil.longToDate(repayData.orderTradeTime),
                payAccount = repayData.payAccount,
                payBank = repayData.payBank,
                payer = repayData.payer,
                payerIdno = repayData.payerIdno,
                repayDate = DataUtil.longToDate(repayData.repayDate),
                shouldAmount = repayData.shouldAmount,
                merId = repayData.merId,
                status = repayData.status,
                createBy = repayData.createBy,
                modifyBy = repayData.modifyBy,
                modifyTime = DataUtil.longToDate(repayData.modifyTime),
                createdTime = DataUtil.longToDate(repayData.createTime),
                updatedTime = now,
                loanReqNo = repayData.loanReqNo,
                loanNo = repayData.loanNo,
                contReqNo = repayData.contReqNo,
                contNo = repayData.contNo,
                type = repayData.type,
                audit = AuditStatus.Normal.status
        ))
        val tasks = billInTasksRepo.findByBisTaskId(bisTaskId)

        if (CollectionUtils.isEmpty(tasks)) {
            // TODO 创建tasks数据
            val totalShouldAmount = repayData.shouldAmount!!
            val orderTradeTime:Date
            if(  BillType.User ==repayData.type){
                orderTradeTime = DataUtil.longToDate(repayData.orderTradeTime)!!
            }else{
                orderTradeTime =  DateUtils.getMonthByMonths(DataUtil.longToDate(repayData.repayDate)!!,-1)

            }
            //val orderTradeTime = DataUtil.longToDate(repayData.orderTradeTime)!!
            val shouldAmount = getShouldAmountByPeriod(totalShouldAmount, periodTimes)

            for (i in 1..periodTimes) {
                val planExecuteTime = getPlanExecuteTime(orderTradeTime, i)
                billInTasksRepo.save(BillInTasksPO(
                        bisTaskId = bisTaskId,
                        orderId = repayData.orderId,
                        tradeId = repayData.tradeId,
                        debitChannel = repayData.debitChannel,
                        finishTime = null,
                        fundChannel = repayData.fundChannel,
                        payAccount = repayData.payAccount,
                        payBank = repayData.payBank,
                        payType = PayType.Debit,
                        payer = repayData.payer,
                        payerIdno = repayData.payerIdno,
                        penalty = 0,
                        planExecuteTime = planExecuteTime,
                        nextExecuteTime = planExecuteTime,
                        lastExecuteTime = null,
                        overdueDays = 0,
                        message = null,
                        requestNo = null,
                        seqNo = i,
                        shouldAmount = shouldAmount,
                        status = Progress.Ready,
                        checkStatus = CheckStatus.NoApplyCheck.status,
                        taskType = TaskType.Repay,
                        thirdOrderId = null,
                        totalAmount = shouldAmount,
                        createBy = operator,
                        modifyBy = null,
                        modifyTime = null,
                        createdTime = now,
                        updatedTime = now,
                        loanReqNo = repayData.loanReqNo,
                        loanNo = repayData.loanNo,
                        contReqNo = repayData.contReqNo,
                        contNo = repayData.contNo,
                        type = repayData.type,
                        audit = AuditStatus.Normal.status,
                        accountId = repayData.signAccountId
                ))
            }
        }
    }

    private fun saveMerRemitFromUser(merRemitData: TotalRemitData) {
        val bisTaskId = merRemitData.id!!
        val periodTimes = merRemitData.periodTimes!!
        val billType: BillType? = if (merRemitData.type != null) merRemitData.type else BillType.Merchant
        val now = Date()
        val date = DataUtil.longToDate(merRemitData.payDate)

        val outPlanO = billOutPlanRepo.findById(bisTaskId)
        if (outPlanO.isPresent) {
            return
        }
        billOutPlanRepo.save(BillOutPlanPO(
                id = merRemitData.id,
                orderId = merRemitData.orderId,
                tradeId = merRemitData.tradeId,
                accountOpenBank = merRemitData.accountOpenBank,
                debitChannel = merRemitData.debitChannel,
                fundChannel = merRemitData.fundChannel,
                shouldAmount = merRemitData.shouldAmount,
                actualAmount = merRemitData.actualAmount,
                periodTimes = merRemitData.periodTimes,
                merId = merRemitData.merId,
                orderTradeTime = DataUtil.longToDate(merRemitData.orderTradeTime),
                payDate = date,
                payeeAccount = merRemitData.payeeAccount,
                payeeBank = merRemitData.payeeBank,
                payeeName = merRemitData.payeeName,
                status = merRemitData.status,
                createBy = operator,
                modifyBy = operator,
                modifyTime = now,
                createdTime = now,
                updatedTime = now,
                loanReqNo = merRemitData.loanReqNo,
                loanNo = merRemitData.loanNo,
                contReqNo = merRemitData.contReqNo,
                contNo = merRemitData.contNo,
                type = billType,
                audit = AuditStatus.Normal.status,
                provinceName = merRemitData.province,
                cityName = merRemitData.city
        ))
        val tasks = billOutTasksRepo.findByBisTaskId(bisTaskId)
        if (CollectionUtils.isEmpty(tasks)) {
            val totalShouldAmount = merRemitData.shouldAmount!!
            val shouldAmount = getShouldAmountByPeriod(totalShouldAmount, periodTimes)
            val orderTradeTime = DataUtil.longToDate(merRemitData.orderTradeTime)!!
            var planExecuteTime: Date = Date()
            // TODO 创建tasks数据
            for (i in 1..periodTimes) {
                if (billType == BillType.Merchant) {
                    planExecuteTime = getPlanExecuteTime(date!!)
                } else if (billType == BillType.PhoneBill || billType == BillType.PhoneBillNoAmount) {
                    planExecuteTime = getPlanExecuteTime(date!!, i - 1)
                } else if (billType == BillType.Zyxf) {
                    planExecuteTime = getPlanExecuteTime(orderTradeTime, i)
                }
                billOutTasksRepo.save(BillOutTasksPO(
                        bisTaskId = bisTaskId,
                        orderId = merRemitData.orderId,
                        tradeId = merRemitData.tradeId,
                        finishTime = null,
                        lastExecuteTime = null, //*
                        message = null,
                        nextExecuteTime = planExecuteTime, //*
                        overdueDays = 0,
                        payAccount = null,
                        payBank = null,
                        payType = PayType.Debit,
                        payee = merRemitData.payeeName,
                        payeeAccount = merRemitData.payeeAccount,
                        payeeOpenInstitution = merRemitData.accountOpenBank, //收款方开户行机构
                        payer = null,
                        penalty = 0,
                        planExecuteTime = planExecuteTime, //*
                        requestNo = null,
                        seqNo = i,
                        shouldAmount = shouldAmount,
                        status = merRemitData.status,
                        checkStatus = CheckStatus.NoApplyCheck.status,
                        taskType = TaskType.Advance, //*
                        thirdOrderId = null,
                        totalAmount = shouldAmount,
                        payeeBank = merRemitData.payeeBank,
                        debitChannel = merRemitData.debitChannel,
                        fundChannel = merRemitData.fundChannel,
                        createBy = operator,
                        modifyBy = operator,
                        modifyTime = now,
                        createdTime = now,
                        updatedTime = now,
                        loanReqNo = merRemitData.loanReqNo,
                        loanNo = merRemitData.loanNo,
                        contReqNo = merRemitData.contReqNo,
                        contNo = merRemitData.contNo,
                        type = billType,
                        audit = AuditStatus.Normal.status
                ))
            }
        }
    }

    private fun saveMerRemitFromZhongyuan(merRemitData: TotalRemitData) {
        val bisTaskId = merRemitData.id!!
        val periodTimes = merRemitData.periodTimes!!
        val now = Date()

        val outPlanO = billOutPlanRepo.findById(bisTaskId)
        if (outPlanO.isPresent) {
            return
        }
        billOutPlanRepo.save(BillOutPlanPO(
                id = merRemitData.id,
                orderId = merRemitData.orderId,
                tradeId = merRemitData.tradeId,
                accountOpenBank = merRemitData.accountOpenBank,
                debitChannel = merRemitData.debitChannel,
                fundChannel = merRemitData.fundChannel,
                shouldAmount = merRemitData.shouldAmount,
                actualAmount = merRemitData.actualAmount,
                periodTimes = merRemitData.periodTimes,
                merId = merRemitData.merId,
                orderTradeTime = DataUtil.longToDate(merRemitData.orderTradeTime),
                payDate = DataUtil.longToDate(merRemitData.payDate),
                payeeAccount = merRemitData.payeeAccount,
                payeeBank = merRemitData.payeeBank,
                payeeName = merRemitData.payeeName,
                status = merRemitData.status,
                createBy = operator,
                modifyBy = operator,
                modifyTime = now,
                createdTime = now,
                updatedTime = now,
                loanReqNo = merRemitData.loanReqNo,
                loanNo = merRemitData.loanNo,
                contReqNo = merRemitData.contReqNo,
                contNo = merRemitData.contNo,
                type = BillType.Zyxf,
                audit = AuditStatus.Normal.status
        ))
        val tasks = billOutTasksRepo.findByBisTaskId(bisTaskId)
        if (CollectionUtils.isEmpty(tasks)) {
            val totalShouldAmount = merRemitData.shouldAmount!!
            val shouldAmount = getShouldAmountByPeriod(totalShouldAmount, periodTimes)

            // TODO 创建tasks数据
            for (i in 1..periodTimes) {
                billOutTasksRepo.save(BillOutTasksPO(
                        bisTaskId = bisTaskId,
                        orderId = merRemitData.orderId,
                        tradeId = merRemitData.tradeId,
                        finishTime = null,
                        lastExecuteTime = null, //*
                        message = null,
                        nextExecuteTime = now, //*
                        overdueDays = 0,
                        payAccount = null,
                        payBank = null,
                        payType = PayType.Debit,
                        payee = merRemitData.payeeName,
                        payeeAccount = merRemitData.payeeAccount,
                        payeeOpenInstitution = merRemitData.accountOpenBank, //收款方开户行机构
                        payer = null,
                        penalty = 0,
                        planExecuteTime = now, //*
                        requestNo = null,
                        seqNo = i,
                        shouldAmount = shouldAmount,
                        status = merRemitData.status,
                        checkStatus = CheckStatus.NoApplyCheck.status,
                        taskType = TaskType.Advance, //*
                        thirdOrderId = null,
                        totalAmount = shouldAmount,
                        payeeBank = merRemitData.payeeBank,
                        debitChannel = merRemitData.debitChannel,
                        fundChannel = merRemitData.fundChannel,
                        createBy = operator,
                        modifyBy = operator,
                        modifyTime = now,
                        createdTime = now,
                        updatedTime = now,
                        loanReqNo = merRemitData.loanReqNo,
                        loanNo = merRemitData.loanNo,
                        contReqNo = merRemitData.contReqNo,
                        contNo = merRemitData.contNo,
                        type = BillType.Merchant,
                        audit = AuditStatus.Normal.status
                ))
            }
        }
    }

    //打款缺失任务补录接口
    @Transactional
    fun saveDataSupplementMerRemitAnd(merRemitId: String) {
        val response = summerClient.billRemit(merRemitId)!!
        logger.info("响应参数：【$response】")
        if (response.code != ResEnum.Success.getCode()) {
            throw SimpleException(response.code, response.msg!!)
        }
        val merRemitData = response.data!!
        dataSupplementPlan(merRemitData)
    }

    //plan任务补录
    private fun dataSupplementPlan(merRemitData: TotalRemitData) {
        logger.info("响应参数：【$merRemitData】")
        val bisTaskId = merRemitData.id!!
        val billType: BillType? = if (merRemitData.type != null) merRemitData.type else BillType.Merchant
        val now = Date()
        val date = DataUtil.longToDate(merRemitData.payDate)

        val outPlanO = billOutPlanRepo.findById(bisTaskId)
        val outTasks = billOutTasksRepo.findByBisTaskId(bisTaskId)
        if (outPlanO.isPresent) {
            if (!CollectionUtils.isEmpty(outTasks)) {
                return
            }
            dataSupplementTasks(merRemitData)
            return
        }
        billOutPlanRepo.save(BillOutPlanPO(
                id = merRemitData.id,
                orderId = merRemitData.orderId,
                tradeId = merRemitData.tradeId,
                accountOpenBank = merRemitData.accountOpenBank,
                debitChannel = merRemitData.debitChannel,
                fundChannel = merRemitData.fundChannel,
                shouldAmount = merRemitData.shouldAmount,
                actualAmount = merRemitData.actualAmount,
                periodTimes = merRemitData.periodTimes,
                merId = merRemitData.merId,
                orderTradeTime = DataUtil.longToDate(merRemitData.orderTradeTime),
                payDate = date,
                payeeAccount = merRemitData.payeeAccount,
                payeeBank = merRemitData.payeeBank,
                payeeName = merRemitData.payeeName,
                status = merRemitData.status,
                createBy = operator,
                modifyBy = operator,
                modifyTime = now,
                createdTime = now,
                updatedTime = now,
                loanReqNo = merRemitData.loanReqNo,
                loanNo = merRemitData.loanNo,
                contReqNo = merRemitData.contReqNo,
                contNo = merRemitData.contNo,
                type = billType,
                audit = AuditStatus.Normal.status,
                provinceName = merRemitData.province,
                cityName = merRemitData.city
        ))
        dataSupplementTasks(merRemitData)
    }

    //tasks任务补录接口
    private fun dataSupplementTasks(merRemitData: TotalRemitData) {
        val bisTaskId = merRemitData.id!!
        val periodTimes = merRemitData.periodTimes!!
        val billType: BillType? = if (merRemitData.type != null) merRemitData.type else BillType.Merchant
        val now = Date()
        val date = DataUtil.longToDate(merRemitData.payDate)
        val tasks = billOutTasksRepo.findByBisTaskId(bisTaskId)
        if (CollectionUtils.isEmpty(tasks)) {
            val totalShouldAmount = merRemitData.shouldAmount!!
            val shouldAmount = getShouldAmountByPeriod(totalShouldAmount, periodTimes)
            val orderTradeTime = DataUtil.longToDate(merRemitData.orderTradeTime)!!
            var planExecuteTime: Date = Date()
            // TODO 创建tasks数据
            for (i in 1..periodTimes) {
                if (billType == BillType.Merchant) {
                    planExecuteTime = getPlanExecuteTime(date!!)
                } else if (billType == BillType.PhoneBill) {
                    planExecuteTime = getPlanExecuteTime(date!!, i - 1)
                } else if (billType == BillType.Zyxf) {
                    planExecuteTime = getPlanExecuteTime(orderTradeTime, i)
                }
                billOutTasksRepo.save(BillOutTasksPO(
                        bisTaskId = bisTaskId,
                        orderId = merRemitData.orderId,
                        tradeId = merRemitData.tradeId,
                        finishTime = null,
                        lastExecuteTime = null, //*
                        message = null,
                        nextExecuteTime = planExecuteTime, //*
                        overdueDays = 0,
                        payAccount = null,
                        payBank = null,
                        payType = PayType.Debit,
                        payee = merRemitData.payeeName,
                        payeeAccount = merRemitData.payeeAccount,
                        payeeOpenInstitution = merRemitData.accountOpenBank, //收款方开户行机构
                        payer = null,
                        penalty = 0,
                        planExecuteTime = planExecuteTime, //*
                        requestNo = null,
                        seqNo = i,
                        shouldAmount = shouldAmount,
                        status = merRemitData.status,
                        checkStatus = CheckStatus.NoApplyCheck.status,
                        taskType = TaskType.Advance, //*
                        thirdOrderId = null,
                        totalAmount = shouldAmount,
                        payeeBank = merRemitData.payeeBank,
                        debitChannel = merRemitData.debitChannel,
                        fundChannel = merRemitData.fundChannel,
                        createBy = operator,
                        modifyBy = operator,
                        modifyTime = now,
                        createdTime = now,
                        updatedTime = now,
                        loanReqNo = merRemitData.loanReqNo,
                        loanNo = merRemitData.loanNo,
                        contReqNo = merRemitData.contReqNo,
                        contNo = merRemitData.contNo,
                        type = billType,
                        audit = AuditStatus.Normal.status
                ))
            }
        }
    }

    private fun getShouldAmountByPeriod(totalShouldAmount: Int, periodTimes: Int): Int {
        return totalShouldAmount / periodTimes + (if (totalShouldAmount % periodTimes > 0) 1 else 0)
    }

    private fun getPlanExecuteTime(d: Date, n: Int): Date {
        val planYMD = DateUtils.getMonthByMonths(d, n)
        val sf = SimpleDateFormat("yyyy-MM-dd 10:00:00")
        return sf.parse(sf.format(planYMD))
    }

    private fun getPlanExecuteTime(d: Date): Date {
        val sf = SimpleDateFormat("yyyy-MM-dd 10:00:00")
        return sf.parse(sf.format(d))
    }
}