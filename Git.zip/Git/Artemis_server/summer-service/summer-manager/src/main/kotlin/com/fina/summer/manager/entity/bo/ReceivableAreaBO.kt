package com.fina.summer.manager.entity.bo

import io.swagger.annotations.ApiModelProperty
import java.io.Serializable

data class ReceivableAreaBO(

        @ApiModelProperty("地区名称")
        var areaName: String? = null,

        @ApiModelProperty("符合条件的订单数")
        var count: Int? = null,

        @ApiModelProperty("下级地区集合")
        var subList: List<ReceivableAreaBO>? = null

): Serializable