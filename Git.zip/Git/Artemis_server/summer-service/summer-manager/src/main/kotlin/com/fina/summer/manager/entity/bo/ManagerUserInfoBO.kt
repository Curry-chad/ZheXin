package com.fina.summer.manager.entity.bo

import com.fina.summer.persistent.artemis.entity.domain.ManagerRoleDO
import com.fina.summer.persistent.artemis.entity.vo.ManagerMenuVO
import java.io.Serializable
import java.util.*

data class ManagerUserInfoBO (

        var id: Long? = null,

        var userId: String? = null,

        var loginName: String? = null,

        var realName: String? = null,

        var mobile: String? = null,

        var createdTime: Date? = null,

        var updatedTime: Date? = null,

        var roleDOList: List<ManagerRoleDO>? = null,

        var firstLvList: List<ManagerMenuVO>? = null

): Serializable