package com.fina.summer.manager.impl.user

import com.fina.summer.auth.core.auth.BaseManagerAuth
import com.fina.summer.auth.core.shiro.SessionUtils
import com.fina.summer.core.handler.ServiceException
import com.fina.summer.core.respone.ResEnum
import com.fina.summer.manager.entity.bo.ManagerUserInfoBO
import com.fina.summer.persistent.artemis.entity.domain.user.ManagerUserDO
import com.fina.summer.persistent.artemis.entity.domain.user.ManagerUserInfoDO
import com.fina.summer.persistent.artemis.entity.vo.ManagerMenuVO
import com.fina.summer.persistent.artemis.mapper.ManagerMenuMapper
import com.fina.summer.persistent.artemis.mapper.ManagerRoleMapper
import com.fina.summer.persistent.artemis.repo.user.ManagerUserInfoRepo
import com.fina.summer.persistent.artemis.repo.user.ManagerUserRepo
import org.apache.shiro.authc.UnknownAccountException
import org.springframework.beans.BeanUtils
import org.springframework.stereotype.Service


@Service
class UserService(
        private val baseManagerAuth: BaseManagerAuth,
        private val managerUserRepo: ManagerUserRepo,
        private val managerUserInfoRepo: ManagerUserInfoRepo,
        private val managerMenuMapper: ManagerMenuMapper,
        private val managerRoleMapper: ManagerRoleMapper
) {

    internal fun saveUser(managerUserDO: ManagerUserDO): ManagerUserDO {
        return managerUserRepo.save(managerUserDO)
    }

    internal fun saveUserInfo(managerUserInfoDO: ManagerUserInfoDO): ManagerUserInfoDO {
        return managerUserInfoRepo.save(managerUserInfoDO)
    }

    fun getUserByLoginName(loginName: String): ManagerUserDO? {
        return managerUserRepo.findByLoginName(loginName)
    }

    fun currentUser(): ManagerUserDO {
        val userId = SessionUtils.currentUserId()?: throw UnknownAccountException()
        val optional = managerUserRepo.findById(userId)
        return if (optional.isPresent) {
            optional.get()
        } else {
            baseManagerAuth.logout()
            throw ServiceException(ResEnum.UserLogout)
        }
    }

    fun currentUserInfo(userDO: ManagerUserDO): ManagerUserInfoBO {
        val userId = userDO.id!!
        val userInfoDO: ManagerUserInfoDO = managerUserInfoRepo.findByUserId(userId)

        // 获取用户角色与权限信息
        val roleList = managerRoleMapper.listByUserId(userId)
        val firstLvMenus = managerMenuMapper.getFirstLvMenusByUserId(userId)

        val userInfoBO = ManagerUserInfoBO()
        BeanUtils.copyProperties(userInfoDO, userInfoBO)
        userInfoBO.loginName = userDO.loginName
        userInfoBO.roleDOList = roleList
        userInfoBO.firstLvList = firstLvMenus
        return userInfoBO
    }

    fun currentUserInfo(): ManagerUserInfoBO {
        val user = currentUser()
        return currentUserInfo(user)
    }

    fun currentPermissions(firstLvUrl: String): List<ManagerMenuVO> {
        val user = currentUser()
        return managerMenuMapper.listByParentUrlAndUserId(user.id!!, firstLvUrl)
    }

}