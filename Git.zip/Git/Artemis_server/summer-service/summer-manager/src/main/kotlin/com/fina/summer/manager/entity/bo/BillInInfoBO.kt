package com.fina.summer.manager.entity.bo

import com.fina.summer.persistent.ceres.entity.constant.Progress
import com.fina.summer.persistent.ceres.entity.domain.BillInTasksPO
import java.io.Serializable

data class BillInInfoBO(

        var status: Progress? = null,

        /**
         * 0-无审核状态
         * 1-退款审核中
         * 2-退款审核成功
         */
        var audit: Int? = null,

        var tasks: List<BillInTasksPO>? = null

): Serializable