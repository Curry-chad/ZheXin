package com.fina.summer.manager.impl

import com.fina.summer.persistent.entity.summer.OrderVO
import com.fina.summer.persistent.entity.summer.SellerVO
import com.fina.summer.persistent.entity.summer.StoreVO
import com.fina.summer.persistent.mapper.business.OrderMapper
import com.fina.summer.persistent.mapper.business.SellerMapper
import com.fina.summer.persistent.mapper.business.StoreMapper
import org.springframework.stereotype.Service

@Service
class LituoService(
        private val orderMapper: OrderMapper,
        private val sellerMapper: SellerMapper,
        private val storeMapper: StoreMapper
) {

    fun orderList(): List<OrderVO> {
        return orderMapper.list()
    }

    fun sellerList(): List<SellerVO> {
        return sellerMapper.list()
    }

    fun storeList(): List<StoreVO> {
        return storeMapper.list()
    }

}