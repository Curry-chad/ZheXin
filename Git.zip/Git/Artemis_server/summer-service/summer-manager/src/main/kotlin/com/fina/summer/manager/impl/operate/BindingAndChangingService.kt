package com.fina.summer.manager.impl.operate

import com.fina.summer.core.respone.ResEnum
import com.fina.summer.core.respone.WebResult
import com.fina.summer.persistent.ceres.entity.constant.OperateType
import com.fina.summer.persistent.ceres.entity.constant.PayType
import com.fina.summer.persistent.ceres.entity.constant.Progress
import com.fina.summer.persistent.ceres.entity.domain.BillInFlowsPO
import com.fina.summer.persistent.ceres.entity.vo.BingdingAndChangingCardVO
import com.fina.summer.persistent.ceres.repo.BillInFlowsRepo
import com.fina.summer.persistent.ceres.repo.BillInTasksRepo
import com.fina.summer.persistent.ceres.repo.BillRepayPlanRepo
import org.slf4j.LoggerFactory
import org.springframework.stereotype.Service
import java.util.*

@Service
class BindingAndChangingService(
        private val billInTasksRepo: BillInTasksRepo,
        private val billRepayPlanRepo: BillRepayPlanRepo,
        private val billInFlowsRepo: BillInFlowsRepo
) {
    private val logger = LoggerFactory.getLogger(BindingAndChangingService::class.java)
    private var operator = "储蓄卡绑定与更换"
    private var modify = "ceres"

    fun bindingAndChangingCard(bingdingAndChangingCardVO: BingdingAndChangingCardVO): WebResult<Void> {
        val bisTask=this.billRepayPlanRepo.findByOrderIdAndType(bingdingAndChangingCardVO.orderId!!,bingdingAndChangingCardVO.billType!!)
        var now=Date()
        if (bisTask!=null) {
            bisTask.payAccount = bingdingAndChangingCardVO.payAccount
            bisTask.payBank=bingdingAndChangingCardVO.payBank
            bisTask.updatedTime = now
            this.billRepayPlanRepo.save(bisTask)
            val tasks = billInTasksRepo.findByBisTaskId(bisTask.id!!) ?: listOf()
            if (tasks.isEmpty()){
                logger.warn("deduct fail: [bis_task_id: ${bisTask.id} , fail msg:bill_in_task不存在]")
                return ResEnum.fail(code = "99",msg = "BillInTask不存在")
            }
            tasks.forEach {
                if (it.status!=Progress.Success){
                    it.payAccount = bingdingAndChangingCardVO.payAccount
                    it.payBank=bingdingAndChangingCardVO.payBank
                    it.updatedTime=now
                    it.accountId = bingdingAndChangingCardVO.accountId//账户ID变更
                    this.billInTasksRepo.save(it)
                    this.billInFlowsRepo.save(BillInFlowsPO(
                            taskId = it.id,
                            requestNo = it.requestNo,
                            thirdOrderId = it.thirdOrderId,
                            tradeId = it.tradeId,
                            bisTaskId = it.bisTaskId,
                            payBank = it.payBank,
                            payType = PayType.Debit,
                            payer = it.payer,
                            payerIdno = it.payerIdno,
                            status = it.status,
                            payAccount = it.payAccount,
                            penalty = it.penalty,
                            createdTime = now,
                            updatedTime = now,
                            orderId = it.orderId,
                            debitChannel = it.debitChannel,
                            finishTime = it.finishTime,
                            fundChannel = it.fundChannel,
                            planExecuteTime = it.planExecuteTime,
                            nextExecuteTime = it.nextExecuteTime,
                            lastExecuteTime = it.lastExecuteTime,
                            overdueDays = it.overdueDays,
                            seqNo = it.seqNo,
                            shouldAmount = it.shouldAmount,
                            checkStatus = it.checkStatus,
                            amount = it.totalAmount,
                            createBy = it.createBy,
                            modifyBy =it.modifyBy,
                            modifyTime = it.modifyTime,
                            loanNo = it.loanNo,
                            loanReqNo = it.loanReqNo,
                            contNo = it.contNo,
                            contReqNo = it.contReqNo,
                            taskType = it.type,
                            audit = it.audit,
                            operateType = OperateType.BindingAndChangingCard
                    ))
                }
            }
        }else{
            logger.warn("deduct fail: [order编号: ${bingdingAndChangingCardVO.orderId} 或type:${bingdingAndChangingCardVO.billType} , fail msg:bill_repay_plan不存在]")
            return ResEnum.fail(code ="99",msg = "BillRepayPlan不存在")
        }
        return ResEnum.success()
    }

}