package com.fina.summer.manager.entity.bo

import java.io.Serializable

data class ReceivableBO (

        var areas: List<ReceivableAreaBO>? = null,

        var list: List<RepayPlanBO>? = null

): Serializable