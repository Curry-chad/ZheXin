package com.fina.summer.manager.entity.dto

import com.fina.summer.persistent.ceres.entity.constant.BillType
import com.fina.summer.persistent.ceres.entity.constant.DeductChannel
import com.fina.summer.persistent.ceres.entity.constant.FundChannel
import com.fina.summer.persistent.ceres.entity.constant.Progress
import java.io.Serializable

data class TotalRemitData (

        var id: String? = null,

        var tradeId: String? = null,

        var orderId: String? = null,

        var merId: String? = null,

        var payDate: Long? = null,

        var periodTimes: Int? = null,

        var leftPeriodTimes: Int? = null,

        var fundChannel: FundChannel? = null,

        var debitChannel: DeductChannel? = null,

        var accountOpenBank: String? = null,

        var payeeName: String? = null,

        var payeeBank: String? = null,

        var payeeAccount: String? = null,

        var shouldAmount: Int? = null,

        var actualAmount: Int? = null,

        var orderTradeTime: Long? = null,

        var status: Progress? = null,

        var createBy: String? = null,

        var createTime: Long? = null,

        var modifyBy: String? = null,

        var modifyTime: Long? = null,

        var loanReqNo: String? = null,

        var loanNo: String? = null,

        var contReqNo: String? = null,

        var contNo: String? = null,

        var type: BillType? = null,

        var province: String? = null,//省

        var city: String? = null//市
): Serializable