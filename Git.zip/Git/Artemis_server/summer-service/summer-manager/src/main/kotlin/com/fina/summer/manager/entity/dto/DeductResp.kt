package com.fina.summer.manager.entity.dto

import com.fina.summer.persistent.ceres.entity.constant.Progress
import java.io.Serializable
import javax.persistence.EnumType
import javax.persistence.Enumerated

data class DeductResp(

        var message: String? = null,

        var requestNo: String? = null,

        @Enumerated(EnumType.STRING)
        var status: Progress? = null,

        var thirdOrderId: String? = null

): Serializable