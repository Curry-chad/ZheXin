package com.fina.summer.manager.impl.operate

import com.fina.ceres.open.api.BankCardPayService
import com.fina.ceres.open.api.bean.CloudResp
import com.fina.ceres.open.api.bean.bankcard.BankCardRet
import com.fina.ceres.open.api.bean.bankcard.PayNotifyReq
import com.fina.ceres.open.api.bean.bankcard.PayReq
import com.fina.ceres.open.api.bean.bankcard.PayResp
import com.fina.summer.core.respone.ResEnum
import com.fina.summer.core.utils.DateUtils
import com.fina.summer.manager.batch.SmsNotificationService
import com.fina.summer.manager.client.HttpConfig
import com.fina.summer.manager.client.SummerUrl
import com.fina.summer.manager.entity.bo.DeductBO
import com.fina.summer.manager.entity.dto.DeductNotice
import com.fina.summer.manager.entity.dto.DeductTO
import com.fina.summer.persistent.ceres.entity.constant.*
import com.fina.summer.persistent.ceres.entity.domain.BillInFlowsPO
import com.fina.summer.persistent.ceres.entity.domain.BillInTasksPO
import com.fina.summer.persistent.ceres.entity.vo.DeductVO
import com.fina.summer.persistent.ceres.mapper.BillInTasksMapper
import com.fina.summer.persistent.ceres.mapper.BillOutTasksMapper
import com.fina.summer.persistent.ceres.repo.BillInFlowsRepo
import com.fina.summer.persistent.ceres.repo.BillInTasksRepo
import com.fina.summer.persistent.ceres.repo.YeepayPayBillFlowsRepo
import org.joda.time.DateTime
import org.slf4j.Logger
import org.slf4j.LoggerFactory
import org.springframework.stereotype.Service
import org.springframework.transaction.annotation.Transactional
import org.springframework.util.CollectionUtils
import java.text.SimpleDateFormat
import java.util.*
import kotlin.streams.toList

@Service
class OperateReceivableService(
        private val billInTasksRepo: BillInTasksRepo,
        private val billInFlowsRepo: BillInFlowsRepo,
        private val billInTasksMapper: BillInTasksMapper,
        private val yeepayPayBillFlowsRepo: YeepayPayBillFlowsRepo,
        private val bankCardPayService: BankCardPayService,
        private val httpConfig: HttpConfig,
        private val billOutTasksMapper: BillOutTasksMapper,
        private val smsNotificationService: SmsNotificationService

) {
    private val logger: Logger = LoggerFactory.getLogger(OperateReceivableService::class.java)


    /**
     *
     * @author zhengqiyang@zhexinit.com
     * @date 2019/5/15 16:22
     * @param []
     * @return List<String> 当期需要进行扣款的任务主键id列表
     * @description 查询当期需要进行代扣的订单列表
     */

    fun findBatchDeductByItem():List<String>?{
        //获取当前时间的本月当天和最后一天
        val startDate = DateUtils.getBeginDayOfMonth(Date())
        val endDate = DateUtils.getLastDayOfMonth(Date())
        val type = BillType.PhoneBillNoAmount.name
        val findReductListByItem = billInTasksMapper.findReductListByItem(startDate, endDate, type)
        if(CollectionUtils.isEmpty(findReductListByItem)){
            return null
        }
        return  findReductListByItem!!.stream().map { it.id!! }.toList()
    }

    /**
     * 扣款（中原）
     */
    fun deductFromZhongyuan(id: String): DeductBO {
        val now = Date()
        val task = billInTasksRepo.findById(id).get()
        val status = task.status!!
        val amount = task.totalAmount!!
        val planExecuteTime = task.planExecuteTime!!
        val orderId = task.orderId!!
        val requestNo = task.requestNo
        val thirdOrderId = task.thirdOrderId
        var operator = "ceres"

        val failBO = DeductBO(success = false, amount = amount)
        val errorMsg = "错误任务编号[$id]："

        // TODO 判断:当前执行时间 < 当前task计划执行日期,则拦截
        if (now < planExecuteTime) {
            failBO.msg = errorMsg + "当前执行时间 < 本期扣款任务计划执行时间"
            return failBO
        }

        // TODO 判断本期收款是否已执行过
        if (status == Progress.Doing) {
            failBO.msg = errorMsg + "本期扣款正在扣款中"
            return failBO
        }
        if (status == Progress.Success) {
            failBO.msg = errorMsg + "本期扣款已成功执行"
            return failBO
        }
        if (status == Progress.Cancel) {
            failBO.msg = errorMsg + "本期扣款已取消"
            return failBO
        }
        // TODO 与易宝交易记录比较,是否收款
        if (requestNo != null && thirdOrderId != null) {
            val yeepayFlow = yeepayPayBillFlowsRepo.findByClientOrderNumAndYeepayFlowNum(requestNo, thirdOrderId)
            if (yeepayFlow != null && yeepayFlow.payStatus == YeePayStatus.PAY_SUCCESS.name) {
                failBO.msg = errorMsg + "本期扣款第三方交易状态=成功支付"
                return failBO
            }
        }

        return DeductBO(success = true, amount = amount, msg = "扣款（中原）确认成功")
    }

    /**
     * 扣款
     */
    @Transactional
    fun deduct(id: String, deductVO: DeductVO): DeductBO {
        val now = Date()
        val task = billInTasksRepo.findById(id).get()
        val status = task.status!!
        val audit = task.audit
        val amount = task.totalAmount!!
        val planExecuteTime = task.planExecuteTime!!
        val orderId = task.orderId!!
        var requestNo = task.requestNo
        var thirdOrderId = task.thirdOrderId
        val operator = "ceres"
        val type = task.type

        val failBO = DeductBO(success = false, amount = amount)
        val errorMsg = "错误任务编号[$id]："


        // 判断:当前执行时间 < 当前task计划执行日期,则拦截
        //代扣代缴不兜底时每月1号开始扣款，无此限制
        //if(type != BillType.PhoneBillNoAmount){
            if (now < planExecuteTime) {
                logger.info("当前执行时间 < 本期扣款任务计划执行时间,未进行扣款，编号为:$requestNo")
                failBO.msg = errorMsg + "当前执行时间 < 本期扣款任务计划执行时间"
                return failBO
            }
        //}


        // 判断是否处于退款流程
        if (AuditStatus.InRefundAudit.status == audit) {
            logger.info("本期扣款处于退款流程中,未进行扣款，编号为:$requestNo")
            failBO.msg = errorMsg + "本期扣款处于退款流程中"
            return failBO
        }

        // 判断本期收款是否已执行过
        if (status == Progress.Doing) {
            logger.info("本期扣款正在扣款中,此次属于重复发起，编号为:$requestNo")
            failBO.msg = errorMsg + "本期扣款正在扣款中"
            return failBO
        }
        if (status == Progress.Success) {
            logger.info("本期扣款已成功执行，无需进行扣款，编号为:$requestNo")
            failBO.msg = errorMsg + "本期扣款已成功执行"
            return failBO
        }
        if (status == Progress.Cancel) {
            logger.info("本期扣款已取消，无需进行扣款，编号为:$requestNo")
            failBO.msg = errorMsg + "本期扣款已取消"
            return failBO
        }



        // TODO 与易宝交易记录比较,是否收款
        if (requestNo != null && thirdOrderId != null) {
            val yeepayFlow = yeepayPayBillFlowsRepo.findByClientOrderNumAndYeepayFlowNum(requestNo, thirdOrderId)
            if (yeepayFlow != null && yeepayFlow.payStatus == YeePayStatus.PAY_SUCCESS.name) {
                logger.info("本期扣款第三方交易状态=成功支付，编号为:$requestNo")
                failBO.msg = errorMsg + "本期扣款第三方交易状态=成功支付"
                return failBO
            }
        }

        // TODO 更新bill_in_tasks(status=Doing, last_execute_time)
        deductDoing(task, now, deductVO, operator)

        // TODO 请求扣款接口
        val accountId = task.accountId!!
        val url = httpConfig.financeDeductCallBack + SummerUrl.DeDuctCallBack.interfaceName
        val orderTradeId = task.id!!
        val deductTO = DeductTO(amount = amount.toString(),
                orderTradeId = orderTradeId,
                accountId = accountId,
                appId = "artemis-server",
                notifyUrl = url)

        logger.debug("请求参数：task id: [$id], deduct info: [amount = $amount, accountId = $accountId, orderTradeId = $orderTradeId, notifyUrl = $url]，" +
                "thirdOrderId:  [$thirdOrderId]")

        return deductStatus(deductTO, failBO, errorMsg, task, operator, now, amount, deductVO)
    }

    //扣款之前修改订单状态为Doing
    //@Transactional
    fun deductDoing(task: BillInTasksPO, now: Date, deductVO: DeductVO, operator: String) {
        task.status = Progress.Doing
        task.requestNo = task.id
        task.lastExecuteTime = now
        task.modifyBy = if (deductVO.modifyBy == null) operator else deductVO.modifyBy
        billInTasksRepo.save(task)
    }

    //调用扣款接口
    //@Transactional
    fun deductStatus(deductTO: DeductTO, failBO: DeductBO, errorMsg: String, task: BillInTasksPO,
                     operator: String, now: Date, amount: Int, deductVO: DeductVO): DeductBO {
        var resp: CloudResp<PayResp>
        //不兜底场景逻辑
        if (task.type == BillType.PhoneBillNoAmount) {
            try {
                resp = bankCardPayService.pay(PayReq(
                        amount = deductTO.amount!!,
                        orderTradeId = deductTO.orderTradeId!!,
                        accountId = deductTO.accountId!!,
                        appId = deductTO.appId!!,
                        notifyUrl = deductTO.notifyUrl!!
                ))
            } catch (e: Exception) {
                failBO.msg = errorMsg + "扣款接口请求异常"
                logger.error("扣款接口调用异常，异常的订单信息为:$deductTO", e)
                task.message = "扣款接口请求异常"
                task.status = Progress.Error
                task.modifyBy = if (deductVO.modifyBy == null) operator else deductVO.modifyBy
                billInTasksRepo.save(task)
                return failBO
            }
            logger.info("响应参数:【$resp】")
            if (resp.code != ResEnum.Success.getCode()) {
                //code不为0证明是扣款失败
                task.status = Progress.Cancel
                task.message = resp.msg
                task.modifyBy = if (deductVO.modifyBy == null) operator else deductVO.modifyBy
                logger.info("调用扣款接口，扣款失败的订单信息为:$task")
                billInTasksRepo.save(task)
                //查询出对应的打款记录，将打款任务取消
                val findRecordByOrderIdAndSeqNoAndType = billOutTasksMapper.findRecordByOrderIdAndSeqNoAndType(task.orderId!!, task.seqNo!!, BillType.PhoneBillNoAmount.name)
                if (findRecordByOrderIdAndSeqNoAndType != null) {
                    logger.info("取消打款任务，需要取消的打款id为:$findRecordByOrderIdAndSeqNoAndType")
                    billOutTasksMapper.updateStatusById(findRecordByOrderIdAndSeqNoAndType.id!!, Progress.Cancel.name)
                }
                failBO.msg = errorMsg + resp.msg
                return failBO
            }
        } else {
            try {
                resp = bankCardPayService.pay(PayReq(
                        amount = deductTO.amount!!,
                        orderTradeId = deductTO.orderTradeId!!,
                        accountId = deductTO.accountId!!,
                        appId = deductTO.appId!!,
                        notifyUrl = deductTO.notifyUrl!!
                ))
            } catch (e: Exception) {
                failBO.msg = errorMsg + "扣款接口请求异常"
                logger.error("扣款接口调用异常", e)
                task.message = "扣款接口请求异常"
                logger.error("扣款接口调用异常，异常的订单信息为:$deductTO", e)
                task.status = Progress.Fail
                task.modifyBy = if (deductVO.modifyBy == null) operator else deductVO.modifyBy
                billInTasksRepo.save(task)
                return failBO
            }
            logger.info("响应参数:【$resp】")
            // TODO 判断 扣款接口 返回信息 status, 更新bill_in_tasks(request_no, third_order_id, error?status=Fail)
            if (resp.code != ResEnum.Success.getCode()) {
                task.status = Progress.Fail
                task.message = resp.msg
                task.modifyBy = if (deductVO.modifyBy == null) operator else deductVO.modifyBy
                billInTasksRepo.save(task)
                failBO.msg = errorMsg + resp.msg
                return failBO
            }
            val deductResp = resp.data!!
            val deductStatus = deductResp.status!!.toString()
            val deductMsg = deductResp.bankCardRet.toString()
            if (deductStatus == "FAIL") {
                task.status = Progress.Fail
                task.message = resp.msg
                task.modifyBy = if (deductVO.modifyBy == null) operator else deductVO.modifyBy
                billInTasksRepo.save(task)
                failBO.msg = errorMsg + deductMsg
                return failBO
            }
            val requestNo = deductResp.orderTradeId
            val thirdOrderId = deductResp.tradeId
            task.requestNo = requestNo
            task.thirdOrderId = thirdOrderId
            task.modifyBy = if (deductVO.modifyBy == null) operator else deductVO.modifyBy
            task.modifyTime = now
            task.updatedTime = now

            billInTasksRepo.saveDefine(task)
            return DeductBO(success = true, amount = amount, msg = deductMsg)
        }
        return DeductBO(success = true, amount = amount, msg = "")
    }

    /**
     * 扣款回调 from kafka
     */
    @Transactional
    fun deductNotice(deductNotice: DeductNotice) {
        val now = Date()

        val requestNo = deductNotice.requestNo!!
        val thirdOrderId = deductNotice.thirdOrderId!!
        val amount = deductNotice.amount
        val tradeTime = deductNotice.tradeTime
        val resultStatus = deductNotice.result
        val message = deductNotice.message

        // TODO 根据扣款接口返回信息，更新bill_in_tasks(status=Success/Fail, modify_by, modify_time, Success?finish_time, Fail?next_execute_time)
        // TODO 新增bill_in_flows(status=Success/Fail)
        val task = billInTasksRepo.findByRequestNo(requestNo)!!
        task.status = resultStatus
        task.finishTime = tradeTime
        task.message = message

        val flow = BillInFlowsPO(
                taskId = task.id,
                bisTaskId = task.bisTaskId,
                requestNo = requestNo,
                thirdOrderId = thirdOrderId,
                amount = amount,
                message = message,
                payAccount = task.payAccount,
                payType = task.payType,
                payer = task.payer,
                payerIdno = task.payerIdno,
                penalty = task.penalty,
                status = resultStatus,
                createdTime = now,
                updatedTime = now,
                tradeId = task.tradeId
        )

        billInTasksRepo.save(task)
        billInFlowsRepo.save(flow)
    }

    /**
     * 扣款回调
     */
    @Transactional
    fun deductCallBack(payNotifyReq: PayNotifyReq): String {
        val now = Date()

        if (payNotifyReq.retStatus == BankCardRet.ING) {
            return "success"
        }

        var status: Progress//支付状态通知
        var message = payNotifyReq.retMsg//通知描述
        val amount = payNotifyReq.amount!!//金额
        val thirdOrderId = payNotifyReq.tradeId!!//平台支付流水号
        val requestNo = payNotifyReq.orderTradeId!!//业务方流水号
        val poundage = if (payNotifyReq.poundage == null) null else payNotifyReq.poundage!!.toInt()//手续费
        val task = billInTasksRepo.findByRequestNo(requestNo)
        if (task == null) {
            logger.warn("还款任务不存在:thirdOrderId = 【$thirdOrderId】,requestNo = 【$requestNo】")
            return "还款任务不存在"
        }

        //确定扣款类型：自动（10-11am,21-22pm）/手动
        val currentHour = DateTime().hourOfDay().get()
        val tim: Boolean = (currentHour == 10 || currentHour == 21)

        try {
            logger.info("开始扣款回调，回调状态是" + payNotifyReq.retStatus.toString() + "业务方流水号是：" + requestNo)
            if (task.type == BillType.PhoneBillNoAmount) {
                //如果是不兜底订单，状态流转不同
                if (payNotifyReq.retStatus.toString() == "SUCCESS") {
                    logger.info("不兜底话费代扣成功，开始状态变更,业务方流水号是$requestNo")
                    //成功，in表状态变为Success，out表状态变为Ready
                    changeInStatus(task, thirdOrderId, now, payNotifyReq, poundage, requestNo, amount)
                    //查到对应的out表期次记录
                    var findRecordByOrderIdAndSeqNoAndType = billOutTasksMapper.findRecordByOrderIdAndSeqNoAndType(task.orderId!!, task.seqNo!!, BillType.PhoneBillNoAmount.name)
                    if (findRecordByOrderIdAndSeqNoAndType != null) {
                        logger.info("不兜底话费代扣成功，变更out表状态，id为" + findRecordByOrderIdAndSeqNoAndType.id!!)
                        billOutTasksMapper.updateStatusById(findRecordByOrderIdAndSeqNoAndType.id!!, Progress.Ready.name)
                    }
                    //代扣代缴(不兜底)话费扣款成功，短信提醒
                    smsNotificationService.sendSmsByPhoneBillNoAmount(task.id!!,true)
                } else {
                    //失败
                    logger.info("不兜底话费代扣失败，变更状态，id为" + task.id!! + "失败原因为" + message)
                    task.status = Progress.Cancel
                    task.message = message
                    billInTasksRepo.save(task)
                    //查询出对应的打款记录，将打款任务取消
                    val findRecordByOrderIdAndSeqNoAndType = billOutTasksMapper.findRecordByOrderIdAndSeqNoAndType(task.orderId!!, task.seqNo!!, BillType.PhoneBillNoAmount.name)
                    if (findRecordByOrderIdAndSeqNoAndType != null) {
                        logger.info("扣款回调返回失败，取消对应打款任务，取消的订单信息为:$findRecordByOrderIdAndSeqNoAndType")
                        billOutTasksMapper.updateStatusById(findRecordByOrderIdAndSeqNoAndType.id!!, Progress.Cancel.name)
                    }
                    //代扣代缴(不兜底)话费扣款失败，短信提醒
                    smsNotificationService.sendSmsByPhoneBillNoAmount(task.id!!,false)
                }
            } else {
                // TODO 根据扣款接口返回信息，更新bill_in_tasks(status=Success/Fail, modify_by, modify_time, Success?finish_time, Fail?next_execute_time)
                // TODO 新增bill_in_flows(status=Success/Fail)
                when {
                    payNotifyReq.retStatus.toString() == "SUCCESS" -> status = Progress.Success
                    else -> status = Progress.Fail
                }
                if(status == Progress.Success){
                    message = "支付成功" + if (payNotifyReq.retMsg == null || payNotifyReq.retMsg == "") "" else "|" + payNotifyReq.retMsg
                }
                task.status = status
                task.thirdOrderId = thirdOrderId
                task.finishTime = now
                task.message = message
                task.serviceCharge = poundage
                logger.info("扣款回调返回结果，返回结果的订单信息为:$task")
                val flow = BillInFlowsPO(
                        taskId = task.id,
                        bisTaskId = task.bisTaskId,
                        requestNo = requestNo,
                        thirdOrderId = thirdOrderId,
                        amount = amount.toInt(),
                        message = message,
                        payAccount = task.payAccount,
                        payType = task.payType,
                        payer = task.payer,
                        payerIdno = task.payerIdno,
                        penalty = task.penalty,
                        status = status,
                        createdTime = now,
                        updatedTime = now,
                        tradeId = task.tradeId
                )
                billInTasksRepo.save(task)
                billInFlowsRepo.save(flow)
                //发送短信
                if (status == Progress.Success) {
                    message = "支付成功" + if (payNotifyReq.retMsg == null || payNotifyReq.retMsg == "") "" else "|" + payNotifyReq.retMsg
                    //============+==========
                    if(tim){  //自动扣款-成功
                        smsNotificationService.sendOkSms(task.id!!)
                    }
                }else{ //===========
                    if(tim){   //自动扣款-失败
                        smsNotificationService.sendFailSms(task.id!!)
                    }
                }
            }
        } catch (e: Exception) {
            logger.warn("还款回调出现问题:thirdOrderId = 【$thirdOrderId】,requestNo = 【$requestNo】,error:", e)
            return "还款回调出现问题:$e"
        }
        return "success"
    }

    private fun changeInStatus(task: BillInTasksPO, thirdOrderId: String, now: Date, payNotifyReq: PayNotifyReq, poundage: Int?, requestNo: String, amount: String) {
        task.status = Progress.Success
        task.thirdOrderId = thirdOrderId
        task.finishTime = now
        task.message = "支付成功" + if (payNotifyReq.retMsg == null || payNotifyReq.retMsg == "") "" else "|" + payNotifyReq.retMsg
        task.serviceCharge = poundage
        val flow = BillInFlowsPO(
                taskId = task.id,
                bisTaskId = task.bisTaskId,
                requestNo = requestNo,
                thirdOrderId = thirdOrderId,
                amount = amount.toInt(),
                message = task.message,
                payAccount = task.payAccount,
                payType = task.payType,
                payer = task.payer,
                payerIdno = task.payerIdno,
                penalty = task.penalty,
                status = Progress.Success,
                createdTime = now,
                updatedTime = now,
                tradeId = task.tradeId
        )
        billInTasksRepo.save(task)
        billInFlowsRepo.save(flow)
    }

    /**
     * 申请核查
     */
    fun applyCheck(id: String) {
        val task = billInTasksRepo.findById(id).get()
        task.checkStatus = CheckStatus.ApplyCheck.status
        billInTasksRepo.save(task)
        // TODO 邮件通知
        // emailUtil.send("", "")
    }

    private fun getShouldAmountByPeriod(totalShouldAmount: Int, periodTimes: Int): Int {
        return totalShouldAmount / periodTimes + (if (totalShouldAmount % periodTimes > 0) 1 else 0)
    }

    private fun getPlanExecuteTime(d: Date, n: Int): Date {
        val planYMD = DateUtils.getMonthByMonths(d, n)
        val sf = SimpleDateFormat("yyyy-MM-dd 10:00:00")
        return sf.parse(sf.format(planYMD))
    }

    private fun uuId(): String {
        return "DCT${UUID.randomUUID().toString().substring(0, 21).replace("-", "")}"
    }
}