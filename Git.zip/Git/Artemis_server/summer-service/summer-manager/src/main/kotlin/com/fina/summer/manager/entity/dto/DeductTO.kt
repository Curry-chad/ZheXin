package com.fina.summer.manager.entity.dto

import java.io.Serializable

data class DeductTO(
        //代扣金额
        var amount: String? = null,

        //充值任务编号ID
        var orderTradeId: String? = null,

        //账户ID
        var accountId: String? = null,

        //应用ID
        var appId: String? = null,

        //回调地址
        var notifyUrl: String? = null
): Serializable