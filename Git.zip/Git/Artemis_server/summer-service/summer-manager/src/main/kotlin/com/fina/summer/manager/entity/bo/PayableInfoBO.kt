package com.fina.summer.manager.entity.bo

import com.fina.summer.core.utils.DataUtil
import io.swagger.annotations.ApiModelProperty
import java.io.Serializable
import java.util.*

data class PayableInfoBO(

        @ApiModelProperty("应付账单单号")
        var id: String? = null,

        @ApiModelProperty("交易时间")
        var tradeTime: Date? = null,

        @ApiModelProperty("收款人姓名")
        var payeeName: String? = null,

        @ApiModelProperty("收款账号")
        var payeeAccount: String? = null,

        @ApiModelProperty("收款银行")
        var payeeBank: String? = null,

        @ApiModelProperty("商户名称")
        var merchantName: String? = null,

        @ApiModelProperty("付款人姓名")
        var payerName: String? = null,

        @ApiModelProperty("付款账号")
        var payerAccount: String? = null,

        @ApiModelProperty("付款银行")
        var payerBank: String? = null,

        @ApiModelProperty("付款状态")
        var status: String? = null,

        @ApiModelProperty("付款凭证")
        var payVoucher: String? = null,

        @ApiModelProperty("订单编号")
        var orderId: String? = null,

        @ApiModelProperty("资金方")
        var fundChannel: String? = null,

        @ApiModelProperty("收款人开户行")
        var accountOpenBank: String? = null,

        @ApiModelProperty("分期数")
        var ordInstallmentNum: Int? = null,//分期数

        @ApiModelProperty("借款人姓名")
        var applicantName: String? = null,//借款人姓名

        @ApiModelProperty("交易流水号")
        var tradeId: String? = null,//交易流水号

        @ApiModelProperty("省")
        var stoProvinceName: String? = null,//省

        @ApiModelProperty("市")
        var stoCityName: String? = null//市

) : Serializable {

    @ApiModelProperty("应收款金额")
    var shouldAmount: String? = ""
        get() = DataUtil.convertDecimal(field)

    @ApiModelProperty("付款金额")
    var payAmount: String? = ""
        get() = DataUtil.convertDecimal(field)

    @ApiModelProperty("每月还款金额")
    var monthlyRepaymentAmount: String? = ""
        get() = DataUtil.convertDecimal(field)
}