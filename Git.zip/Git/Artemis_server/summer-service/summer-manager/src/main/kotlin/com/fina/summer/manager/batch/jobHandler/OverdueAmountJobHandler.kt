package com.fina.summer.manager.batch.jobHandler

import com.fina.summer.manager.batch.OverdueAmountService
import com.xxl.job.core.biz.model.ReturnT
import com.xxl.job.core.handler.IJobHandler
import com.xxl.job.core.handler.annotation.JobHandler
import com.xxl.job.core.log.XxlJobLogger
import org.springframework.stereotype.Component

/**
 * @author zhengqiyang@zhexinit.com
 * @version V1.0
 * @since 1.0 2019/5/15 17:51
 * @description 逾期违约金金额计算--xxl定时任务
 */
@JobHandler(value = "overdueAmountJobHandler")
@Component
class OverdueAmountJobHandler(
        private val overdueAmountService: OverdueAmountService
) : IJobHandler() {

   @Throws
    override fun execute(p0: String?): ReturnT<String> {
       XxlJobLogger.log("-------开始执行逾期金额计算定时任务：------------")
       //logger1.log("-------开始执行逾期金额计算定时任务：------------")
        overdueAmountService.overdueAmountBatch()
       //logger.info("----结束执行逾期金额计算定时任务--------")
       XxlJobLogger.log("-------结束执行逾期金额计算定时任务：------------")
       val result = ReturnT<String>()
       result.msg = "执行完成"
       return result
    }


}