package com.fina.summer.manager.batch

import com.fina.summer.core.handler.SimpleException
import com.fina.summer.core.respone.ResEnum
import com.fina.summer.core.utils.DataUtil
import com.fina.summer.core.utils.DateUtils
import com.fina.summer.manager.client.SummerClient
import com.fina.summer.manager.entity.dto.TotalRemitData
import com.fina.summer.persistent.ceres.entity.constant.*
import com.fina.summer.persistent.ceres.entity.domain.BillOutTasksPO
import com.fina.summer.persistent.ceres.repo.BillOutTasksRepo
import org.slf4j.Logger
import org.slf4j.LoggerFactory
import org.springframework.stereotype.Component
import org.springframework.util.CollectionUtils
import java.text.SimpleDateFormat
import java.util.*

/**
 * @author zhengqiyang@zhexinit.com
 * @version V1.0
 * @since 1.0 2019/5/20 16:11
 * @description 临时修复生产环境数据
 */
@Component
class BatchRepairOutTasks(
        private val billOutTasksRepo: BillOutTasksRepo,
        private val summerClient: SummerClient
) {
    private val operator = "ceres"
    private val logger: Logger = LoggerFactory.getLogger(BatchRepairOutTasks::class.java)

    //@Scheduled(cron = "0 00 20 20 5 ?")
    //@Scheduled(cron = "0 23 17 20 5 ?")
    fun repairOutTasks() {
        /* val repairIdList: MutableList<String> = mutableListOf()
         repairIdList.add("TMR314488714820706304")
         repairIdList.add("TMR314489239570079744")
         repairIdList.add("TMR314489338186559488")
         repairIdList.add("TMR314489613832019968")
         repairIdList.add("TMR314490714132176896")
         repairIdList.add("TMR314492160529522688")
         repairIdList.add("TMR314492265265487872")
         repairIdList.add("TMR314492281661022208")
         for (it in repairIdList) {
             saveMerRemitAndTasks(it)
         }*/
    }


    fun saveMerRemitAndTasks(merRemitId: String) {
        logger.info("开始查询业务库信息，查询id为：$merRemitId")
        val response = summerClient.billRemit(merRemitId)!!
        logger.info("id为:$merRemitId 查询出来的结果为:$response")
        if (response.code != ResEnum.Success.getCode()) {
            throw SimpleException(response.code, response.msg!!)
        }
        val merRemitData = response.data!!
        logger.info("类型为:" + merRemitData.type)
        saveMerRemitFromUser(merRemitData)


    }


    private fun saveMerRemitFromUser(merRemitData: TotalRemitData) {
        val bisTaskId = merRemitData.id!!
        val periodTimes = merRemitData.periodTimes!!
        val billType: BillType? = if (merRemitData.type != null) merRemitData.type else BillType.Merchant
        val now = Date()
        //val date = DataUtil.longToDate(merRemitData.payDate)
        var date = DateUtils.getStringToDateDay("2019-05-21")
        val tasks = billOutTasksRepo.findByBisTaskId(bisTaskId)
        if (!CollectionUtils.isEmpty(tasks)) {
            logger.info("数据库中已经存在，所以未新增数据，id为:$bisTaskId")
        }
        if (CollectionUtils.isEmpty(tasks)) {
            val totalShouldAmount = merRemitData.shouldAmount!!
            val shouldAmount = getShouldAmountByPeriod(totalShouldAmount, periodTimes)
            val orderTradeTime = DataUtil.longToDate(merRemitData.orderTradeTime)!!
            var planExecuteTime: Date = Date()
            // TODO 创建tasks数据
            for (i in 1..periodTimes) {
                if (billType == BillType.Merchant) {
                    planExecuteTime = getPlanExecuteTime(date!!)
                } else if (billType == BillType.PhoneBill || billType == BillType.PhoneBillNoAmount) {
                    planExecuteTime = getPlanExecuteTime(date!!, i - 1)
                } else if (billType == BillType.Zyxf) {
                    planExecuteTime = getPlanExecuteTime(orderTradeTime, i)
                }
                billOutTasksRepo.save(BillOutTasksPO(
                        bisTaskId = bisTaskId,
                        orderId = merRemitData.orderId,
                        tradeId = merRemitData.tradeId,
                        finishTime = null,
                        lastExecuteTime = null, //*
                        message = null,
                        nextExecuteTime = planExecuteTime, //*
                        overdueDays = 0,
                        payAccount = null,
                        payBank = null,
                        payType = PayType.Debit,
                        payee = merRemitData.payeeName,
                        payeeAccount = merRemitData.payeeAccount,
                        payeeOpenInstitution = merRemitData.accountOpenBank, //收款方开户行机构
                        payer = null,
                        penalty = 0,
                        planExecuteTime = planExecuteTime, //*
                        requestNo = null,
                        seqNo = i,
                        shouldAmount = shouldAmount,
                        status = merRemitData.status,
                        checkStatus = CheckStatus.NoApplyCheck.status,
                        taskType = TaskType.Advance, //*
                        thirdOrderId = null,
                        totalAmount = shouldAmount,
                        payeeBank = merRemitData.payeeBank,
                        debitChannel = merRemitData.debitChannel,
                        fundChannel = merRemitData.fundChannel,
                        createBy = operator,
                        modifyBy = operator,
                        modifyTime = now,
                        createdTime = now,
                        updatedTime = now,
                        loanReqNo = merRemitData.loanReqNo,
                        loanNo = merRemitData.loanNo,
                        contReqNo = merRemitData.contReqNo,
                        contNo = merRemitData.contNo,
                        type = billType,
                        audit = AuditStatus.Normal.status
                ))
            }
            logger.info("修复数据结束，修复的id号为：$bisTaskId")
        }
    }

    private fun getShouldAmountByPeriod(totalShouldAmount: Int, periodTimes: Int): Int {
        return totalShouldAmount / periodTimes + (if (totalShouldAmount % periodTimes > 0) 1 else 0)
    }

    private fun getPlanExecuteTime(d: Date, n: Int): Date {
        val planYMD = DateUtils.getMonthByMonths(d, n)
        val sf = SimpleDateFormat("yyyy-MM-dd 10:00:00")
        return sf.parse(sf.format(planYMD))
    }

    private fun getPlanExecuteTime(d: Date): Date {
        val sf = SimpleDateFormat("yyyy-MM-dd 10:00:00")
        return sf.parse(sf.format(d))
    }
}