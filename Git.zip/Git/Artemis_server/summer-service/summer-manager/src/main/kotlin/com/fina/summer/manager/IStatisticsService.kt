package com.fina.summer.manager

import com.fina.summer.persistent.summer.entity.vo.SumAllVo

interface IStatisticsService {


    fun findByAll(): SumAllVo


}