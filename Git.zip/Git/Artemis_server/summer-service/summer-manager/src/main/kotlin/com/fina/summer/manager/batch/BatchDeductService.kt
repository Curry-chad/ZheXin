package com.fina.summer.manager.batch

import com.alibaba.excel.util.CollectionUtils
import com.fina.summer.core.utils.ConcurrentTask
import com.fina.summer.manager.entity.bo.DeductBO
import com.fina.summer.manager.impl.operate.OperateReceivableService
import com.fina.summer.persistent.ceres.entity.domain.FailDeductPO
import com.fina.summer.persistent.ceres.entity.vo.DeductVO
import com.fina.summer.persistent.ceres.repo.BillInTasksRepo
import com.fina.summer.persistent.ceres.repo.FailDeductRepo
import org.slf4j.Logger
import org.slf4j.LoggerFactory
import org.springframework.stereotype.Component
import java.util.*
import java.util.concurrent.Callable
import java.util.concurrent.ThreadPoolExecutor

/**
 * @author zhengqiyang@zhexinit.com
 * @version V1.0
 * @since 1.0 2019/5/16 11:57
 * @description 批量代扣定时任务---代扣代缴不兜底业务
 */
@Component
class BatchDeductService(
        private val operateReceivableService: OperateReceivableService,
        private val asyncTaskPool: ThreadPoolExecutor,
        private val billInTasksRepo: BillInTasksRepo,
        private val failDeductRepo: FailDeductRepo
) {
    private val logger: Logger = LoggerFactory.getLogger(BatchDeductService::class.java)
    //每个月1号的10点，13点，16点，19点各执行一次
    //@Scheduled(cron = "0 0 10,13,16,19 1 1/1 ?")
    fun batchDeduct() {
        //查询当期需要扣款的数据列表
        val findBatchDeductByItem = operateReceivableService.findBatchDeductByItem()
        if (CollectionUtils.isEmpty(findBatchDeductByItem)) {
            logger.info("本期需要进行扣款的数据为空")
            return
        }
        logger.info("本期开始进行扣款的数据为:$findBatchDeductByItem")
        //进行批量扣款
        var deductVO = DeductVO(findBatchDeductByItem, null)
        logger.info("扣款请求参数：【$deductVO】")
        val ids = deductVO.ids!!

        val c = ConcurrentTask<DeductBO>(asyncTaskPool)
        ids.forEach {

            c.submit(Callable {
                return@Callable deduct(it, deductVO)
            })
        }
    }

    fun deduct(taskId: String, deductVO: DeductVO): DeductBO {
        val now = Date()
        try {
            val bo = operateReceivableService.deduct(taskId, deductVO)
            if (!bo.success!!) {
                // TODO 扣款失败记录入库
                failDeductRepo.save(FailDeductPO(
                        bisTaskId = null,
                        taskId = taskId,
                        message = bo.msg,
                        amount = bo.amount,
                        createdTime = now,
                        updatedTime = now
                ))
                logger.debug("deduct fail: [task id: $taskId, fail amount: ${bo.amount}, fail msg: ${bo.msg}]")
            }
            return bo
        } catch (e: Exception) {
            val bo = DeductBO(success = false)
            val option = billInTasksRepo.findById(taskId)
            var taskAmount: Int? = 0
            if (option.isPresent) {
                val task = option.get()
                taskAmount = task.totalAmount
                if (taskAmount != null) {
                    bo.amount = taskAmount
                }
            }
            // TODO 扣款失败记录入库
            failDeductRepo.save(FailDeductPO(
                    bisTaskId = null,
                    taskId = taskId,
                    message = e.message,
                    amount = taskAmount,
                    createdTime = now,
                    updatedTime = now
            ))
            logger.error("错误task编号[$taskId]: failAmount:[$taskAmount], deduct error...", e)
            return bo
        }
    }

}