package com.fina.summer.manager.entity.bo

import io.swagger.annotations.ApiModelProperty
import java.io.Serializable
import java.util.*

data class RepayPlanBO (

        @ApiModelProperty("还款计划编号")
        var id: String? = null,

        @ApiModelProperty("还款人")
        var payerName: String? = null,

        @ApiModelProperty("扣款期数")
        var deductPeriod: String? = null,

        @ApiModelProperty("扣款本金")
        var deductAmount: String? = null,

        @ApiModelProperty("逾期天数")
        var overdueDays: Int? = null,

        @ApiModelProperty("实际扣款金额")
        var actualDeductAmount: String? = null,

        @ApiModelProperty("扣款时间")
        var deductTime: Date? = null,

        @ApiModelProperty("实际扣款时间")
        var finishTime: Date? = null,

        @ApiModelProperty("扣款状态")
        var status: String? = null,

        @ApiModelProperty("订单编号")
        var orderId: String? = null,

        @ApiModelProperty("交易时间")
        var orderTradeTime: Date? = null,

        @ApiModelProperty("门店名称")
        var storeName: String? = null,

        @ApiModelProperty("店员名称")
        var sellerName: String? = null,

        @ApiModelProperty("申请核准状态")
        var checkStatus: Int? = null,

        @ApiModelProperty("详情：还款人电话")
        var payerMobile: String? = null,

        @ApiModelProperty("详情：还款人身份证号码")
        var payerIdNo: String? = null,

        @ApiModelProperty("详情：还款人储蓄卡卡号")
        var payerAccount: String? = null,

        @ApiModelProperty("详情：套餐名称")
        var chargePlanName: String? = null,

        @ApiModelProperty("详情：设备型号")
        var deviceModel: String? = null,

        @ApiModelProperty("详情：店员电话")
        var sellerMobile: String? = null,

        @ApiModelProperty("详情：商户电话")
        var merMobile: String? = null,

        @ApiModelProperty("详情：联系人1姓名")
        var linkmanOneName: String? = null,

        @ApiModelProperty("详情：联系人1电话")
        var linkmanOneMobile: String? = null,

        @ApiModelProperty("详情：联系人1与还款人关系")
        var linkmanOneRelation: String? = null,

        @ApiModelProperty("详情：联系人2姓名")
        var linkmanTwoName: String? = null,

        @ApiModelProperty("详情：联系人2手机号")
        var linkmanTwoMobile: String? = null,

        @ApiModelProperty("详情：联系人2余还款人关系")
        var linkmanTwoRelation: String? = null,

        @ApiModelProperty( "上一次扣款时间")
        var lastExecuteTime: Date? = null
): Serializable