package com.fina.summer.manager.impl.finance

import com.fina.summer.core.utils.DataUtil
import com.fina.summer.manager.entity.bo.RepayInfoBO
import com.fina.summer.manager.entity.dto.ReceivableDTO
import com.fina.summer.persistent.ceres.entity.BillInQueryParam
import com.fina.summer.persistent.ceres.mapper.BillInMapper
import com.fina.summer.persistent.ceres.repo.BillInTaskRepo
import org.springframework.stereotype.Service
import java.util.*

@Service
class ReceivableService(
        private val billInMapper: BillInMapper,
        private val billInTaskRepo: BillInTaskRepo
) {

    fun list(receivableDTO: ReceivableDTO): List<RepayInfoBO> {
        val voList = billInMapper.findAllBy(BillInQueryParam(
                planExecuteTime = receivableDTO.repayDate,
                seqNo = receivableDTO.repayPeriod,
                overdueDays = receivableDTO.overdueDays,
                payer = receivableDTO.payerName,
                merName = receivableDTO.merchantName
        ))
        val boList = mutableListOf<RepayInfoBO>()
        voList.forEach {
            val bisTaskId = it.bisTaskId!!
            val taskId = it.taskId!!
            val fundChannel = it.fundChannel!!
            val overdueDays = it.overdueDays!!
            val status = it.status!!
            val planTotalShouldAmount = it.planTotalShouldAmount!!
            val periodTimes = it.periodTimes!!
            val leftPeriod = it.leftPeriod!!
            val leftAmount = it.leftAmount!!
            val seqNo = it.seqNo!!

            var latelyShouldPayTime: Date? = null
            var latelyActualPayTime: Date? = null
            var latelyShouldRepayablePeriod: Int? = null
            var latelyActualRepayablePeriod: Int? = null
            var latelyShouldRepayableAmount: Int? = null
            var latelyActualRepayableAmount: Int? = null

            val latelyTask = billInTaskRepo.findByBisTaskIdAndSeqNo(bisTaskId, (seqNo + 1))
            if (latelyTask != null) {
                latelyShouldPayTime = latelyTask.planExecuteTime
                latelyShouldRepayablePeriod = latelyTask.seqNo
                latelyShouldRepayableAmount = latelyTask.totalAmount
            }

            if (seqNo > 0) {
                val latelyFlow = billInMapper.findLatelyFLow(bisTaskId)
                if (latelyFlow != null) {
                    val actualLatelyTask = billInTaskRepo.findById(latelyFlow.taskId!!).get()
                    latelyActualPayTime = latelyFlow.executeTime
                    latelyActualRepayablePeriod = actualLatelyTask.seqNo
                    latelyActualRepayableAmount = actualLatelyTask.totalAmount
                }
            }
            val bo = RepayInfoBO(
                    repayId = taskId,
                    repayDate = it.planExecuteTime,
                    payerName = it.payer,
                    seqNo = seqNo,
                    overdue = if (overdueDays > 0) "已逾期" else "未逾期",
                    overdueDays = overdueDays,
                    merName = it.merName,
                    lendType = fundChannel.fundChannelName,
                    orderId = it.orderId,
                    status = status.msg,
                    alreadyPeriod = periodTimes - leftPeriod,
                    latelyShouldPayTime = latelyShouldPayTime,
                    latelyActualPayTime = latelyActualPayTime,
                    latelyShouldRepayablePeriod= latelyShouldRepayablePeriod,
                    latelyActualRepayablePeriod= latelyActualRepayablePeriod
            )
            bo.repayAmount = DataUtil.intToString(it.totalAmount)
            bo.overdueAmount = DataUtil.intToString(it.penalty)
            bo.periodAmount = DataUtil.intToString(planTotalShouldAmount / periodTimes)
            bo.alreadyAmount = DataUtil.intToString(planTotalShouldAmount - leftAmount)
            bo.latelyShouldRepayableAmount = DataUtil.intToString(latelyShouldRepayableAmount)
            bo.latelyActualRepayableAmount = DataUtil.intToString(latelyActualRepayableAmount)

            boList.add(bo)
        }
        return boList
    }

}