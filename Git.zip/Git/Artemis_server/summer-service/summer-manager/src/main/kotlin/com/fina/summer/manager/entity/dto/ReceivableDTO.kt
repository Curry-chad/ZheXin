package com.fina.summer.manager.entity.dto

import io.swagger.annotations.ApiModelProperty
import java.io.Serializable

data class ReceivableDTO(

        @ApiModelProperty("还款日期")
        var repayDate: String? = null,

        @ApiModelProperty("还款期数")
        var repayPeriod: Int? = null,

        @ApiModelProperty("逾期天数")
        var overdueDays: Int? = null,

        @ApiModelProperty("还款人姓名")
        var payerName: String? = null,

        @ApiModelProperty("来源商户")
        var merchantName: String? = null

) : Serializable