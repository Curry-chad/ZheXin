package com.fina.summer.manager.impl.operate

import com.fina.cmcc.HenanCMController
import com.fina.cmcc.entity.CloudResp
import com.fina.cmcc.entity.TelephoneRechargeReq
import com.fina.cmcc.entity.TelephoneRechargeResp
import com.fina.summer.core.bean.PageResult
import com.fina.summer.core.respone.ResEnum
import com.fina.summer.core.utils.AreaUtils
import com.fina.summer.core.utils.ConcurrentTask
import com.fina.summer.core.utils.DataUtil
import com.fina.summer.core.utils.DateUtils
import com.fina.summer.manager.entity.bo.BatchDeductBO
import com.fina.summer.manager.entity.bo.DeductBO
import com.fina.summer.manager.entity.dto.OfPayNoticeResp
import com.fina.summer.persistent.ceres.entity.constant.AuditStatus
import com.fina.summer.persistent.ceres.entity.constant.BillType
import com.fina.summer.persistent.ceres.entity.constant.PayType
import com.fina.summer.persistent.ceres.entity.constant.Progress
import com.fina.summer.persistent.ceres.entity.domain.BillOutFlowsPO
import com.fina.summer.persistent.ceres.entity.domain.BillOutPlanPO
import com.fina.summer.persistent.ceres.entity.domain.BillOutTasksPO
import com.fina.summer.persistent.ceres.entity.domain.FailOutTask
import com.fina.summer.persistent.ceres.entity.vo.TopupAreaVO
import com.fina.summer.persistent.ceres.entity.vo.TopupParamVO
import com.fina.summer.persistent.ceres.entity.vo.TopupPlanVO
import com.fina.summer.persistent.ceres.mapper.BillOutTasksMapper
import com.fina.summer.persistent.ceres.repo.BillOutFlowsRepo
import com.fina.summer.persistent.ceres.repo.BillOutPlanRepo
import com.fina.summer.persistent.ceres.repo.BillOutTasksRepo
import com.fina.summer.persistent.ceres.repo.FailOutTaskRepo
import org.slf4j.LoggerFactory
import org.springframework.stereotype.Service
import org.springframework.transaction.annotation.Transactional
import org.springframework.util.CollectionUtils
import java.text.SimpleDateFormat
import java.util.*
import java.util.concurrent.Callable
import java.util.concurrent.ThreadPoolExecutor
import kotlin.streams.toList

@Service
class OperateTopupService(
        private val billOutTasksMapper : BillOutTasksMapper,
        private val asyncTaskPool: ThreadPoolExecutor,
        private val billOutTasksRepo: BillOutTasksRepo,
        private val billOutPlanRepo: BillOutPlanRepo,
        private val billOutFlowsRepo: BillOutFlowsRepo,
        private val failOutTaskRepo: FailOutTaskRepo,
        private val henanCMController: HenanCMController
) {
    private val logger = LoggerFactory.getLogger(OperateTopupService::class.java)

    fun list(topUpParamVO: TopupParamVO): PageResult<TopupPlanVO> {
        //分页查询
        if (topUpParamVO.pageNo != null || topUpParamVO.pageSize != null) {
            var pageNo: Int = (((topUpParamVO.pageNo!!) - 1) * topUpParamVO.pageSize!!)
            topUpParamVO.pageNo = pageNo
        }
        topUpParamVO.areaCode = AreaUtils.getAreaPrefix(topUpParamVO.areaCode)
        logger.debug("topUpParamVO = $topUpParamVO")

        var list = billOutTasksMapper.findByTopUpAll(topUpParamVO)
        if (!CollectionUtils.isEmpty(list)) {
            list.forEach {
                it.num = "${it.seqNo}/${it.periodTimes}"
                it.amount = "${DataUtil.convertDecimal(it.shouldAmount.toString())}/${DataUtil.convertDecimal(it.shouldAmountAll.toString())}"
            }
        }
        var total: Int = billOutTasksMapper.findByCount(topUpParamVO)
        return PageResult(total, list)
    }

    fun findTopUpAreasBy(topUpParamVO: TopupParamVO): List<TopupAreaVO> {
        topUpParamVO.areaCode = AreaUtils.getAreaPrefix(topUpParamVO.areaCode)
        logger.debug("topUpParamVO = $topUpParamVO")
        return billOutTasksMapper.findTopUpAreasBy(topUpParamVO)
    }

    //话费充值
    fun recharge(mobile: List<String>): BatchDeductBO {
        var successCount = 0
        var failCount = 0
        var successAmount = 0
        var failAmount = 0

        val c = ConcurrentTask<DeductBO>(asyncTaskPool)
        mobile.forEach {
            c.submit(Callable {
                return@Callable redEnvelopes(it)
            })
        }

        val resultList = c.getAll()
        resultList.forEach { bo ->
            if (bo.success!!) {
                successCount++
                successAmount += bo.amount!!
            } else {
                failCount++
                val taskAmount = bo.amount
                if (taskAmount != null) {
                    failAmount += taskAmount
                }
            }
        }
        return BatchDeductBO(
                successCount = successCount,
                failCount = failCount,
                successAmount = DataUtil.convertDecimal(successAmount.toString()),
                failAmount = DataUtil.convertDecimal(failAmount.toString())
        )
    }

    fun redEnvelopes(taskId: String): DeductBO {
        val now = Date()
        val openId = billOutTasksMapper.findByMobile(taskId)
        try {
            if (openId == null) {
                //充值发放失败记录入库
                val msg = "错误task编号[$taskId]:充值数据不存在"
                failOutTaskRepo.save(FailOutTask(
                        bisTaskId = null,
                        taskId = taskId,
                        message = msg,
                        amount = 0,
                        type = BillType.PhoneBill.toString(),
                        createdTime = now,
                        updatedTime = now
                ))
                logger.debug("deduct fail: [task id: $taskId, fail msg: 充值数据不存在]")
                return DeductBO(success = false, amount = 0, msg = msg)
            }
            val bo = redPacketInterface(openId)
            if (!bo.success!!) {
                failOutTaskRepo.save(FailOutTask(
                        bisTaskId = null,
                        taskId = taskId,
                        message = bo.msg,
                        createdTime = now,
                        type = openId.type.toString(),
                        amount = bo.amount,
                        updatedTime = now
                ))
                logger.debug("deduct fail: [task id: $taskId, fail amount: ${bo.amount}, fail msg: ${bo.msg}]")
            }
            return bo
        } catch (e: Exception) {
            val bo = DeductBO(success = false)
            // TODO 充值发放失败记录入库
            failOutTaskRepo.save(FailOutTask(
                    bisTaskId = null,
                    taskId = taskId,
                    message = e.message,
                    amount = 0,
                    type = BillType.PhoneBill.toString(),
                    createdTime = now,
                    updatedTime = now
            ))
            logger.error("错误task编号[$taskId]:  deduct error...", e)
            return bo
        }
    }

    fun redPacketInterface(tasksPO: BillOutTasksPO): DeductBO {
        val now = Date()
        val status = tasksPO.status!!
        val amount = tasksPO.shouldAmount
        val mobileAmount = tasksPO.shouldAmount!!.toLong()
        val mobile = tasksPO.payeeAccount//手机号
        val operator = "ceres"

        val failBO = DeductBO(success = false, amount = amount)
        val errorMsg = "错误任务编号[${tasksPO.orderId}]："

        // TODO 判断充值任务是否已执行过
        if (status == Progress.Success) {
            logger.info("本期充值任务已成功执行,无需进行充值，任务编号为[${tasksPO.orderId}]")
            failBO.msg = errorMsg + "本期充值任务已成功执行"
            return failBO
        }

        val plan = billOutPlanRepo.findByIdAndOrderId(tasksPO.bisTaskId!!, tasksPO.orderId!!)
        if (plan == null) {
            logger.info("充值对应任务不存在，任务编号为[${tasksPO.orderId}]")
            failBO.msg = errorMsg + "充值对应任务不存在"
            return failBO
        }
        if (tasksPO.audit == AuditStatus.InRefundAudit.status) {
            logger.info("本期话费充值任务处于退款审核中，任务编号为[${tasksPO.orderId}]")
            failBO.msg = errorMsg + "本期话费充值任务处于退款审核中"
            return failBO
        }

        if (mobileAmount < 100) {
            logger.info("话费充值最低不能小于1元，任务编号为[${tasksPO.orderId}]")
            failBO.msg = errorMsg + "话费充值最低不能小于1元"
            return failBO
        }
        if (mobile == null) {
            logger.info("本期话费充值手机号为空，任务编号为[${tasksPO.orderId}]")
            failBO.msg = errorMsg + "手机号为空"
            return failBO
        }

        //充值成功之前修改任务状态
        topUpUpdateType(tasksPO)

        return topUpType(tasksPO, now, operator, mobile, mobileAmount, failBO, errorMsg, plan)
    }

    //充值前状态变更
    @Transactional
    fun topUpUpdateType(tasksPO: BillOutTasksPO) {
        tasksPO.status = Progress.Doing
        billOutTasksRepo.save(tasksPO)
    }

    //充值成功或失败状态变更
    @Transactional
    fun topUpType(tasksPO: BillOutTasksPO, now: Date, operator: String, mobile: String, mobileAmount: Long,
                  failBO: DeductBO, errorMsg: String, plan: BillOutPlanPO): DeductBO {
        var msg = ""
        val resp: CloudResp<TelephoneRechargeResp>
        try {
            logger.info("接口请求参数：tasksPO[${tasksPO.payeeAccount}],amount[${tasksPO.totalAmount}],desc[${tasksPO.orderId}]")
            resp = henanCMController.telephoneRecharge(TelephoneRechargeReq(
                    phoneNo = mobile,//手机号
                    money = mobileAmount//手机号
            ))
        } catch (e: Exception) {
            failBO.msg = "充值接口异常"
            logger.error("异常订单为$tasksPO,调用充值接口异常:", e)
            return failBO
        }
        val res = resp.toString()
        logger.info("接口返回参数：[$res]")
        if (resp.code != ResEnum.Success.getCode()) {
            tasksPO.status = Progress.Fail
            billOutTasksRepo.save(tasksPO)
            failBO.msg = errorMsg + resp.msg
            logger.error("用充值接口返回失败，失败订单为$tasksPO")
            return failBO
        }

        val dataResp = resp.data!!
        logger.error("打印充值接口返回结果信息为$dataResp")
        val tradeId = dataResp.tradeId!!
        val productId = dataResp.productId!!
        val phoneNumber = dataResp.phoneNumber!!
        val money = dataResp.money!!
        val paymentStatus = dataResp.status!!

        if (paymentStatus == "Failed") {
            tasksPO.status = Progress.Fail
            tasksPO.message = dataResp.msg
            billOutTasksRepo.save(tasksPO)
            failBO.msg = errorMsg + dataResp.msg
            return failBO
        }
        val data = SimpleDateFormat("yyyyMMddhhmmss").parse(dataResp.tradeTime!!)//话费充值支付时间

        //更新tasks表
        tasksPO.modifyBy = operator
        tasksPO.modifyTime = now
        tasksPO.updatedTime = now
        tasksPO.thirdOrderId = productId
        //tasksPO.finishTime = now
        tasksPO.requestNo = tradeId
        //tasksPO.finishTime = data
        tasksPO.lastExecuteTime = data
        tasksPO.payType = PayType.PhoneBill

        billOutTasksRepo.save(tasksPO)

        //更新plan
        plan.modifyBy = operator
        plan.modifyTime = data
        plan.updatedTime = now
        plan.actualAmount = money
        billOutPlanRepo.save(plan)

        //记录打款流水
        billOutFlowsRepo.save(BillOutFlowsPO(
                taskId = tasksPO.id,
                bisTaskId = tasksPO.bisTaskId,
                thirdOrderId = tradeId,
                amount = tasksPO.totalAmount,
                payeeAccount = tasksPO.payeeAccount,
                payee = tasksPO.payee,
                payBank = tasksPO.payBank,
                requestNo = productId,
                tradeId = tasksPO.tradeId,
                createBy = operator,
                modifyTime = data,
                executeTime = now,
                payAccount = phoneNumber,
                payType = tasksPO.payType.toString(),
                payer = productId,
                status = tasksPO.status.toString(),
                message = dataResp.msg
        ))
        return DeductBO(success = true, amount = mobileAmount.toInt(), msg = msg)
    }

    //话费充值回调
    fun prepaidRefill(prepaidRefillData: OfPayNoticeResp) {
        logger.info("开始话费充值回调，回调信息是：$prepaidRefillData")
        val now = Date()
        val operator = "ceres"
        val thirdOrderId = prepaidRefillData.productId!!
        val requestNo = prepaidRefillData.tradeId!!
        val money = prepaidRefillData.money
        val phoneNumber = prepaidRefillData.phoneNumber
        val status = if (prepaidRefillData.status == "Failed") Progress.Fail else Progress.Success
        val msg = prepaidRefillData.msg
        val data = SimpleDateFormat("yyyyMMddhhmmss").parse(prepaidRefillData.tradeTime!!)//话费充值支付时间

        // TODO 根据扣款接口返回信息，更新bill_in_tasks(status=Success/Fail, modify_by, modify_time, Success?finish_time, Fail?next_execute_time)
        // TODO 新增bill_in_flows(status=Success/Fail)
        val task = billOutTasksRepo.findByRequestNoAndThirdOrderId(requestNo, thirdOrderId)!!
        task.status = status
        task.finishTime = data
        task.message = msg

        val flow = BillOutFlowsPO(
                taskId = task.id,
                bisTaskId = task.bisTaskId,
                requestNo = requestNo,
                thirdOrderId = thirdOrderId,
                amount = money,
                message = msg,
                payAccount = phoneNumber,
                payeeAccount = phoneNumber,
                payType = task.payType.toString(),
                payer = task.payer,
                penalty = task.penalty,
                status = status.toString(),
                createdTime = now,
                updatedTime = now,
                tradeId = task.tradeId,
                payee = task.payee,
                payBank = task.payBank,
                createBy = operator,
                modifyTime = data,
                executeTime = now
        )

        billOutTasksRepo.save(task)
        billOutFlowsRepo.save(flow)
    }
/**
 *
 * @author zhengqiyang@zhexinit.com
 * @date 2019/5/16 11:44
 * @param []
 * @return List 当期需要进行充值的订单列表
 * @description 查询当期需要进行充值的订单列表
 */

    fun findRechargeListByItem():List<String>?{
        val startDate = DateUtils.getBeginDayOfMonth(Date())
        val endDate = DateUtils.getLastDayOfMonth(Date())
        val type = BillType.PhoneBillNoAmount.name
        val findRechargeListByItem = billOutTasksMapper.findRechargeListByItem(startDate, endDate, type)
        if(CollectionUtils.isEmpty(findRechargeListByItem)){
            return null
        }
    return findRechargeListByItem!!.stream().map { it.id!! }.toList()
    }
}