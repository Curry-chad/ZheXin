package com.fina.summer.manager.client

import com.alibaba.fastjson.JSONObject
import com.fina.summer.common.http.JsonRequest
import com.fina.summer.core.respone.WebResult
import com.fina.summer.manager.entity.dto.TotalRemitData
import com.fina.summer.manager.entity.dto.TotalRepayData
import com.google.gson.reflect.TypeToken
import org.slf4j.Logger
import org.slf4j.LoggerFactory
import org.springframework.http.HttpEntity
import org.springframework.http.HttpHeaders
import org.springframework.http.HttpStatus
import org.springframework.http.MediaType
import org.springframework.stereotype.Component
import org.springframework.web.client.RestTemplate

@Component
class SummerClient(
        private val httpConfig: HttpConfig,
        private val restTemplate: RestTemplate
) {
    private val logger: Logger = LoggerFactory.getLogger(SummerClient::class.java)

    fun zxReceipt(requestMap: Map<String, Any>): WebResult<*>? {
        val url = httpConfig.summerBase + SummerUrl.ZxReceipt.interfaceName
        val headers = HttpHeaders()
        headers.contentType = MediaType.APPLICATION_JSON

        val responseEntity = restTemplate.postForEntity(url,
                HttpEntity(JSONObject.toJSONString(requestMap), headers),
                WebResult::class.java)
        logger.debug("http response is [${JSONObject.toJSONString(responseEntity)}]")
        if (responseEntity.statusCode != HttpStatus.OK) {
            return null
        }
        return responseEntity.body
    }

    fun billRepay(bisTaskId: String): WebResult<TotalRepayData>? {
        val type = object: TypeToken<WebResult<TotalRepayData>>(){}.type
        return JsonRequest.formGet<WebResult<TotalRepayData>>(httpConfig.summerBase + SummerUrl.BillRepay.interfaceName + "?id=$bisTaskId", type)
    }

    fun billRemit(bisTaskId: String): WebResult<TotalRemitData>? {
        val type = object: TypeToken<WebResult<TotalRemitData>>(){}.type
        return JsonRequest.formGet<WebResult<TotalRemitData>>(httpConfig.summerBase + SummerUrl.BillRemit.interfaceName + "?id=$bisTaskId", type)
    }

//    fun deduct(deductTO: DeductTO): WebResult<DeductResp>? {
//        val type = object: TypeToken<WebResult<DeductResp>>(){}.type
//        val amount = deductTO.amount!!
//        val deductChannel = deductTO.deductChannel!!.name
//        val idno = deductTO.idno!!
//        val bankCardNo = deductTO.bankCardNo!!
//        return JsonRequest.jsonPost(httpConfig.summerCeresBase + SummerUrl.Deduct.interfaceName, mapOf(
//                "amount" to amount,
//                "deductChannel" to deductChannel,
//                "idno" to idno,
//                "bankCardNo" to bankCardNo
//        ), type)
//    }

}