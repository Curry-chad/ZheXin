package com.fina.summer.manager.entity.bo

import java.io.Serializable

data class ReceivableSmsResult(

        var successCount: Int? = 0,

        var failCount: Int? = 0

): Serializable