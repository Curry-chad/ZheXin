package com.fina.summer.manager.impl.operate

import com.fina.summer.core.handler.SimpleException
import com.fina.summer.core.respone.ResEnum
import com.fina.summer.manager.entity.bo.RefundCheckBO
import com.fina.summer.manager.entity.bo.RefundCheckListBO
import com.fina.summer.persistent.ceres.entity.constant.*
import com.fina.summer.persistent.ceres.entity.domain.*
import com.fina.summer.persistent.ceres.mapper.BillOutPlanMapper
import com.fina.summer.persistent.ceres.mapper.BillRepayPlanMapper
import com.fina.summer.persistent.ceres.repo.*
import org.slf4j.LoggerFactory
import org.springframework.stereotype.Service
import org.springframework.transaction.annotation.Transactional
import org.springframework.util.CollectionUtils
import java.util.*

@Service
class RefundService(
        private val billRepayPlanRepo: BillRepayPlanRepo,
        private val billInTasksRepo: BillInTasksRepo,
        private val billOutPlanRepo: BillOutPlanRepo,
        private val billOutTasksRepo: BillOutTasksRepo,
        private val billInFlowsRepo: BillInFlowsRepo,
        private val billOutPlanMapper: BillOutPlanMapper,
        private val billRepayPlanMapper: BillRepayPlanMapper
) {

    private val effectiveTime = 15 // 天
    private val exemptionTime = 7 //免手续费期限（天）
    private val rate : Double = 0.01 //手续费率(数据库金额存放精度为分例：10元=1000分)
    private val logger = LoggerFactory.getLogger(RefundService :: class.java)

    /**
     * 退款审核
     * @param repayPlanId: 用户还款计划总表id
     */
    @Transactional
    fun check(repayPlanId: String): RefundCheckBO {
        val operator = "退款校验"
        val now = Date()
        val repayPlanO = billRepayPlanRepo.findById(repayPlanId)
        if (!repayPlanO.isPresent) {
            throw SimpleException(ResEnum.ParamErr.getCode(), "repayPlanId = $repayPlanId 该笔 [用户扣款计划] 不存在")
        }

        val repayPlan = repayPlanO.get()
        val orderTradeTime = repayPlan.orderTradeTime!!
        val time = diffDays(orderTradeTime, now)
        val type = repayPlan.type
        val tradeId = repayPlan.tradeId!!

        val merRemitPlan = billOutPlanRepo.findByTradeIdAndType(tradeId, BillType.Merchant)
                ?: throw SimpleException(ResEnum.ParamErr.getCode(), "repayPlanId = $repayPlanId,tradeId = $tradeId 该笔 [用户扣款计划] 对应的 [商户打款计划] 不存在")
        val merRepayPlan = billRepayPlanRepo.findByTradeIdAndType(tradeId, BillType.Merchant)
        if (merRepayPlan != null) {
            throw SimpleException(ResEnum.ParamErr.getCode(), "repayPlanId = $repayPlanId,tradeId = $tradeId 已生成商户收款计划，请尽快收回商户打款后，再退款")
        }

        // TODO 判断对象是否为用户
        if (type != BillType.User) {
            throw SimpleException(ResEnum.ParamErr.getCode(), "repayPlanId = $repayPlanId,tradeId = $tradeId,BillType= $type 该笔退款对象不为用户")
        }

        // TODO 判断 订单交易时间距今 >= 15天
        if (time > effectiveTime) {
            throw SimpleException(ResEnum.ParamErr.getCode(), "repayPlanId = $repayPlanId,tradeId = $tradeId 该笔 [用户扣款计划] 订单交易时间距今已超过15天")
        }

        // TODO 判断是否已经向商户打款, 若没打款，则取消；若有打款通知人工追回钱款
        val outTasks = billOutTasksRepo.findByBisTaskId(merRemitPlan.id!!)

        var amount = 0
        if (!CollectionUtils.isEmpty(outTasks)) {
            outTasks!!.forEach {
                if (it.status == Progress.Success) {
                    amount += it.totalAmount!!
                }
            }
        }

        if (amount > 0) {
            createMerRepayPlan(merRemitPlan, amount, now, operator)
        }
        return RefundCheckBO(amount)
    }

    /**
     * 收款（from 商户）结果成功通知
     * @param repayPlanId: 用户还款计划总表id
     */
    @Transactional
    fun successReceivableFromMer(repayPlanId: String) {
        val now = Date()
        val operator = "收款from商户结果成功通知"
        val repayPlan = billRepayPlanRepo.findById(repayPlanId).get()
        val merRepayPlan = billRepayPlanRepo.findByTradeIdAndType(repayPlan.tradeId!!, BillType.Merchant)
                ?: throw SimpleException(ResEnum.ParamErr.getCode(), "repayPlanId = $repayPlanId 不存在相关商户收款计划")
        val merInTasks = billInTasksRepo.findByBisTaskId(merRepayPlan.id!!)
        successRepayPlan(merRepayPlan, merInTasks!!, now, operator)
    }

    /**
     * 收款（from 商户）结果失败通知
     * @param repayPlanId: 用户还款计划总表id
     */
    @Transactional
    fun failReceivableFromMer(repayPlanId: String) {
        val now = Date()
        val operator = "收款from商户结果失败通知"
        val repayPlan = billRepayPlanRepo.findById(repayPlanId).get()
        val inTasks = billInTasksRepo.findByBisTaskId(repayPlanId)

        val tradeId = repayPlan.tradeId!!
        val merRepayPlan = billRepayPlanRepo.findByTradeIdAndType(tradeId, BillType.Merchant)
                ?: throw SimpleException(ResEnum.ParamErr.getCode(), "repayPlanId = $repayPlanId,tradeId= $tradeId 不存在相关商户收款计划")
        val merInTasks = billInTasksRepo.findByBisTaskId(merRepayPlan.id!!)

        val merOutPlan = billOutPlanRepo.findByTradeIdAndType(tradeId, BillType.Merchant)
                ?: throw SimpleException(ResEnum.ParamErr.getCode(), "repayPlanId = $repayPlanId,tradeId= $tradeId 不存在相关商户打款计划")
        val merOutTasks = billOutTasksRepo.findByBisTaskId(merOutPlan.id!!)

        // TODO 恢复待审核的用户扣款计划
        restartRepayPlan(repayPlan, inTasks!!, now, operator)
        // TODO 取消相关商户收款计划
        cancelRepayPlan(merRepayPlan, merInTasks!!, now, operator)
        // TODO 人工回款给商户 【人工操作】
        // TODO 恢复待审核的商户打款计划
        restartOutPlan(merOutPlan, merOutTasks!!, now, operator)
    }

    /**
     * 退款
     * @param repayPlanId: 用户还款计划总表id
     */
    @Transactional
    fun refund(repayPlanId: String) {
        val operator = "退款"
        val now = Date()
        val repayPlan = billRepayPlanRepo.findById(repayPlanId).orElseThrow { SimpleException("该笔退款还款计划表不存在记录：repayPlanId--$repayPlanId") }
        val tradeId = repayPlan.tradeId!!

        val inTasks = billInTasksRepo.findByBisTaskId(repayPlanId)

        val rewardOutPlan = billOutPlanRepo.findByTradeIdAndType(tradeId, BillType.Reward)

        if (CollectionUtils.isEmpty(inTasks)) {
            throw SimpleException(ResEnum.Fail.getCode(), "repayPlanId = $repayPlanId,tradeId = $tradeId 该笔 [用户扣款计划] 下不存在相关扣款任务")
        }
        if (repayPlan.audit != AuditStatus.InRefundAudit.status) {
            throw SimpleException(ResEnum.Fail.getCode(), "repayPlanId = $repayPlanId,tradeId = $tradeId 该笔 [用户扣款计划]不在退款流程中")
        }

        //如果存在商户打款任务并且处于退款审核中，修改状态为审核通过
        cancelMerOutTask(repayPlanId, tradeId, now, operator)

        // TODO 判断in表中是否已经向中原发起请款申请
        val zyRepayPlan = billRepayPlanRepo.findByTradeIdAndType(tradeId, BillType.Zyxf)
        if (zyRepayPlan == null) {
            // TODO 在in表中，把用户的收款计划取消, 把没成功的商户收款计划取消
            cancelRepayPlanForSuccess(repayPlan, inTasks!!, now, operator)
            if(rewardOutPlan != null) {
                val rewardOutTasks = billOutTasksRepo.findByBisTaskId(rewardOutPlan.id!!)
                if(!CollectionUtils.isEmpty(rewardOutTasks)) {
                    cancelOutPlanForSuccess(rewardOutPlan, rewardOutTasks!!, now, operator)
                }
            }
            return
        }
        // TODO 在in表中，把用户的收款计划变为取消, 把没成功的商户收款计划取消
        val zyOutPlan = billOutPlanRepo.findByTradeIdAndType(tradeId, BillType.Zyxf)
                ?: throw SimpleException(ResEnum.ParamErr.getCode(), "repayPlanId = $repayPlanId,tradeId = $tradeId 不存在中原打款计划")
        val zyOutTasks=billOutTasksRepo.findByBisTaskId(zyOutPlan.id!!)

        val zyInTasks=billInTasksRepo.findByTradeIdAndType(tradeId, BillType.Zyxf)
                ?: throw SimpleException(ResEnum.ParamErr.getCode(), "repayPlanId = $repayPlanId,tradeId = $tradeId 不存在中原收款计划")
        val zyInPlan = billRepayPlanRepo.findByTradeIdAndType(tradeId, BillType.Zyxf)
                ?: throw SimpleException(ResEnum.ParamErr.getCode(), "repayPlanId = $repayPlanId,tradeId = $tradeId 不存在中原收款计划")

        if (CollectionUtils.isEmpty(zyOutTasks)) {
            throw SimpleException(ResEnum.Fail.getCode(), "repayPlanId = $repayPlanId,tradeId = $tradeId 该笔 [中原打款计划] 下不存在相关打款任务")
        }
        successRepayPlanForSuccess(repayPlan, inTasks!!, now, operator)
        successZyInPlanForSuccess(zyInPlan!!, zyInTasks!!, now, operator)
        cancelZyOutPlanForSuccess(zyOutPlan, zyOutTasks!!, now, operator)
        if(rewardOutPlan != null) {
            val rewardOutTasks = billOutTasksRepo.findByBisTaskId(rewardOutPlan.id!!)
            if(!CollectionUtils.isEmpty(rewardOutTasks)) {
                cancelOutPlanForSuccess(rewardOutPlan, rewardOutTasks!!, now, operator)
            }
        }
    }

    //商户打款任务相关处理
    fun cancelMerOutTask(repayPlanId: String, tradeId: String, now: Date, operator: String){
        val merOutPlan = billOutPlanRepo.findByTradeIdAndType(tradeId, BillType.Merchant)
        if(merOutPlan != null){
            logger.info("存在商户打款任务，开始商户退款流程" )
            val merOutTasks = billOutTasksRepo.findByBisTaskId(merOutPlan.id!!)
            if (merOutPlan.audit != AuditStatus.InRefundAudit.status) {
                throw SimpleException(ResEnum.Fail.getCode(), "repayPlanId = $repayPlanId,tradeId = $tradeId 该笔[商户打款计划] 不在退款流程中")
            }
            cancelOutPlanForSuccess(merOutPlan, merOutTasks!!, now, operator)
            logger.info("商户退款流程结束" )
            return
        }

    }

    //取消话费充值任务
    @Transactional
    fun cancelPhoneBill(orderId: String){
        val operator = "退款"
        val now = Date()
        val phoneBillOutPlan =  billOutPlanMapper.findByOrderIdAndTypeList(orderId, listOf(BillType.PhoneBill,BillType.PhoneBillNoAmount))
        val phoneBillInPlan = billRepayPlanMapper.findByOrderIdAndTypeList(orderId,listOf(BillType.PhoneBill,BillType.PhoneBillNoAmount))
       /* val phoneBillOutPlan = billOutPlanRepo.findByOrderIdAndType(orderId, BillType.PhoneBill)
        val phoneBillInPlan = billRepayPlanRepo.findByOrderIdAndType(orderId, BillType.PhoneBill)*/
        //关闭话费代扣任务
        if(phoneBillInPlan != null){
            val phoneBillInTasks = billInTasksRepo.findByBisTaskId(phoneBillInPlan.id!!)
            if(!CollectionUtils.isEmpty(phoneBillInTasks)) {
                cancelRepayPlanForSuccess(phoneBillInPlan, phoneBillInTasks!!, now, operator)
            }
        }
        //关闭话费代充任务
        if(phoneBillOutPlan != null){
            val phoneBillOutTasks = billOutTasksRepo.findByBisTaskId(phoneBillOutPlan.id!!)
            if(!CollectionUtils.isEmpty(phoneBillOutTasks)) {
                cancelOutPlanForSuccess(phoneBillOutPlan, phoneBillOutTasks!!, now, operator)
            }
        }
    }

    private fun createMerRepayPlan(merRemitPlan: BillOutPlanPO, amount: Int, now: Date, operator: String) : BillRepayPlanPO{
        val repayPlanId = uuId()
        val r = billRepayPlanRepo.save(BillRepayPlanPO(
                id = repayPlanId,
                orderId = merRemitPlan.orderId,
                tradeId = merRemitPlan.tradeId,
                debitChannel = merRemitPlan.debitChannel,
                fundChannel = merRemitPlan.fundChannel,
                periodTimes = 1,
                orderTradeTime = merRemitPlan.orderTradeTime,
                payAccount = merRemitPlan.payeeAccount,
                payBank = merRemitPlan.payeeBank,
                payer = merRemitPlan.payeeName,
                payerIdno = null,
                repayDate = now,
                shouldAmount = amount,
                merId = merRemitPlan.merId,
                status = Progress.Ready,
                createBy = operator,
                modifyBy = operator,
                modifyTime = now,
                createdTime = now,
                updatedTime = now,
                loanReqNo = merRemitPlan.loanReqNo,
                loanNo = merRemitPlan.loanNo,
                contReqNo = merRemitPlan.contReqNo,
                contNo = merRemitPlan.contNo,
                type = BillType.Merchant,
                audit = AuditStatus.Normal.status
        ))
        billInTasksRepo.save(BillInTasksPO(
                bisTaskId = r.id,
                orderId = r.orderId,
                tradeId = r.tradeId,
                debitChannel = r.debitChannel,
                finishTime = null,
                fundChannel = r.fundChannel,
                payAccount = r.payAccount,
                payBank = r.payBank,
                payType = null,
                payer = r.payer,
                payerIdno = r.payerIdno,
                penalty = 0,
                planExecuteTime = now,
                nextExecuteTime = null,
                lastExecuteTime = null,
                overdueDays = 0,
                message = null,
                requestNo = null,
                seqNo = 1,
                shouldAmount = r.shouldAmount,
                status = Progress.Ready,
                checkStatus = CheckStatus.NoApplyCheck.status,
                taskType = TaskType.Repay,
                thirdOrderId = null,
                totalAmount = r.shouldAmount,
                createBy = operator,
                modifyBy = operator,
                modifyTime = now,
                createdTime = now,
                updatedTime = now,
                loanReqNo = r.loanReqNo,
                loanNo = r.loanNo,
                contReqNo = r.contReqNo,
                contNo = r.contNo,
                type = r.type,
                audit = AuditStatus.Normal.status
        ))
        return r
    }

    private fun cancelOutPlanForSuccess(outPlan: BillOutPlanPO, outTasks: List<BillOutTasksPO>, now: Date, operator: String) {
        logger.info("plan ${outPlan.id}开始取消打款任务:type = ${outPlan.type},audit =${outPlan.audit}，status = ${outPlan.status} .tasks数量: ${outTasks.size} ")
        outTasks.forEach {

            logger.info("tasks${it.id}更新前:type = ${it.type},audit =${it.audit}，status = ${it.status} ")
            if(outPlan.type == BillType.Reward || outPlan.type == BillType.PhoneBill || outPlan.type == BillType.PhoneBillNoAmount) {
                if (it.audit == AuditStatus.InRefundAudit.status) {
                    it.audit = AuditStatus.RefundSuccess.status
                }
                if (it.status != Progress.Success) {
                    it.status = Progress.Cancel
                }

            }
            it.modifyTime = now
            it.updatedTime = now
            it.modifyBy = operator
            billOutTasksRepo.save(it)
            logger.info("tasks${it.id}更新后:type = ${it.type},audit =${it.audit}，status = ${it.status} ")
        }
        if(outPlan.type == BillType.Reward || outPlan.type == BillType.PhoneBill || outPlan.type == BillType.PhoneBillNoAmount) {
            if (outPlan.audit == AuditStatus.InRefundAudit.status) {
                outPlan.audit = AuditStatus.RefundSuccess.status
            }
            if (outPlan.status != Progress.Success) {
                outPlan.status = Progress.Cancel
            }
        }
        outPlan.modifyTime = now
        outPlan.updatedTime = now
        outPlan.modifyBy = operator
        billOutPlanRepo.save(outPlan)
        logger.info("plan ${outPlan.id}结束取消打款任务:type = ${outPlan.type},audit =${outPlan.audit}，status = ${outPlan.status} ")
    }
    /*
     *
     * @author zhengqiyang@zhexinit.com
     * @date 2019/5/28 12:00
     * @param
     * @return Any
     * @description 像中原请款数据变为审核通过
     */

    private fun successZyInPlanForSuccess(zyInPlan: BillRepayPlanPO, zyInTasks: List<BillInTasksPO>, now: Date, operator: String) {
        zyInTasks.forEach {
            if (it.audit == AuditStatus.InRefundAudit.status) {
                it.audit = AuditStatus.RefundSuccess.status
            }
            billInTasksRepo.save(it)
        }
        if (zyInPlan.audit == AuditStatus.InRefundAudit.status) {
            zyInPlan.audit = AuditStatus.RefundSuccess.status
        }
        billRepayPlanRepo.save(zyInPlan)
    }
/*
 *
 * @author zhengqiyang@zhexinit.com
 * @date 2019/5/28 12:03
 * @param
 * @return Any
 * @description 给中原打款数据变为审核成功
 */

    private fun cancelZyOutPlanForSuccess(zyOutPlan: BillOutPlanPO, zyOutTasks: List<BillOutTasksPO>, now: Date, operator: String) {
        zyOutTasks.forEach {
            if (it.audit == AuditStatus.InRefundAudit.status) {
                it.audit = AuditStatus.RefundSuccess.status
            }
            billOutTasksRepo.save(it)
        }
        if (zyOutPlan.audit == AuditStatus.InRefundAudit.status) {
            zyOutPlan.audit = AuditStatus.RefundSuccess.status
        }
        billOutPlanRepo.save(zyOutPlan)
    }

    private fun restartOutPlan(outPlan: BillOutPlanPO, outTasks: List<BillOutTasksPO>, now: Date, operator: String) {
        outTasks.forEach {
            if (it.audit == AuditStatus.InRefundAudit.status) {
                it.audit = AuditStatus.Normal.status
                it.modifyTime = now
                it.updatedTime = now
                it.modifyBy = operator
                billOutTasksRepo.save(it)
            }
        }
        if (outPlan.audit == AuditStatus.InRefundAudit.status) {
            outPlan.audit = AuditStatus.Normal.status
            outPlan.modifyTime = now
            outPlan.updatedTime = now
            outPlan.modifyBy = operator
            billOutPlanRepo.save(outPlan)
        }
    }

    private fun restartRepayPlan(repayPlan: BillRepayPlanPO, inTasks: List<BillInTasksPO>, now: Date, operator: String) {
        inTasks.forEach {
            if (it.audit == AuditStatus.InRefundAudit.status) {
                it.audit = AuditStatus.Normal.status
                it.modifyTime = now
                it.updatedTime = now
                it.modifyBy = operator
                billInTasksRepo.save(it)
            }
        }
        if (repayPlan.audit == AuditStatus.InRefundAudit.status) {
            repayPlan.audit = AuditStatus.Normal.status
            repayPlan.modifyTime = now
            repayPlan.updatedTime = now
            repayPlan.modifyBy = operator
            billRepayPlanRepo.save(repayPlan)
        }
    }
    /*
     *
     * @author zhengqiyang@zhexinit.com
     * @date 2019/5/28 12:00
     * @param
     * @return Any
     * @description 类型为用户的数据，退款成功后更新完成时间和状态
     */

    private fun successRepayPlanForSuccess(repayPlan: BillRepayPlanPO, inTasks: List<BillInTasksPO>, now: Date, operator: String) {
        inTasks.forEach {
            if (it.status != Progress.Success) {
                it.status = Progress.Cancel
                it.finishTime = now
            }
            if (it.audit == AuditStatus.InRefundAudit.status) {
                it.audit = AuditStatus.RefundSuccess.status
            }
            it.modifyTime = now
            it.updatedTime = now
            it.modifyBy = operator
            it.lastExecuteTime = now
            billInTasksRepo.save(it)
        }
        if (repayPlan.status != Progress.Success) {
            repayPlan.status = Progress.Cancel
        }
        if (repayPlan.audit == AuditStatus.InRefundAudit.status) {
            repayPlan.audit = AuditStatus.RefundSuccess.status
        }
        repayPlan.modifyTime = now
        repayPlan.updatedTime = now
        repayPlan.modifyBy = operator
        billRepayPlanRepo.save(repayPlan)
    }

    private fun successRepayPlan(repayPlan: BillRepayPlanPO, inTasks: List<BillInTasksPO>, now: Date, operator: String) {
        inTasks.forEach {
            if (it.status != Progress.Success) {
                it.status = Progress.Success
                it.modifyTime = now
                it.updatedTime = now
                it.modifyBy = operator
                it.lastExecuteTime = now
                it.finishTime = now
                billInTasksRepo.save(it)
            }
        }
        if (repayPlan.status != Progress.Success) {
            repayPlan.status = Progress.Success
            repayPlan.modifyTime = now
            repayPlan.updatedTime = now
            repayPlan.modifyBy = operator
            billRepayPlanRepo.save(repayPlan)
        }
    }

    private fun cancelRepayPlanForSuccess(repayPlan: BillRepayPlanPO, inTasks: List<BillInTasksPO>, now: Date, operator: String) {
        logger.info( "开始取消任务")
        inTasks.forEach {
            if (it.status != Progress.Success) {
                it.status = Progress.Cancel
                it.finishTime = now
            }
            if (it.audit == AuditStatus.InRefundAudit.status) {
                it.audit = AuditStatus.RefundSuccess.status
            }
            it.modifyTime = now
            it.updatedTime = now
            it.modifyBy = operator
            billInTasksRepo.save(it)
        }
        if (repayPlan.status != Progress.Success) {
            repayPlan.status = Progress.Cancel
        }
        if (repayPlan.audit == AuditStatus.InRefundAudit.status) {
            repayPlan.audit = AuditStatus.RefundSuccess.status
        }
        repayPlan.modifyTime = now
        repayPlan.updatedTime = now
        repayPlan.modifyBy = operator
        billRepayPlanRepo.save(repayPlan)
        logger.info("取消任务结束")
    }

    private fun cancelRepayPlan(repayPlan: BillRepayPlanPO, inTasks: List<BillInTasksPO>, now: Date, operator: String) {
        inTasks.forEach {
            if (it.status != Progress.Success) {
                it.status = Progress.Cancel
                it.modifyTime = now
                it.updatedTime = now
                it.modifyBy = operator
                billInTasksRepo.save(it)
            }
        }
        if (repayPlan.status != Progress.Success) {
            repayPlan.status = Progress.Cancel
            repayPlan.modifyTime = now
            repayPlan.updatedTime = now
            repayPlan.modifyBy = operator
            billRepayPlanRepo.save(repayPlan)
        }
    }

    private fun diffDays(d1: Date, d2: Date): Int {
        return ((d2.time - d1.time) / (1000 * 3600 * 24)).toInt()
    }

    private fun uuId(): String {
        return "BOP${UUID.randomUUID().toString().substring(0, 21).replace("-", "")}"
    }

    /**
     * 回款任务生成
     */
    @Transactional
    fun moneyBack(orderId: String): RefundCheckListBO<BillRepayPlanPO> {
        val operator = "退款校验"
        val now = Date()
        var userAmount = 0
        var serviceChargeAmount = 0 //手续费金额
        var rewardAmount = 0 //红包金额
        var amount = 0 //商户回款金额
        var rewardStatus = "Nothing" //红包打款状态
        var list = mutableListOf<BillRepayPlanPO>()
        val repayPlanO = billRepayPlanRepo.findByOrderIdAndType(orderId, BillType.User)

        //判断该扣款计划是否有对应的红包
        val rewardRemitPlan = billOutPlanRepo.findByOrderIdAndType(orderId, BillType.Reward)
        val rewardRemitTasks = billOutTasksRepo.findByOrderIdAndType(orderId, BillType.Reward)

        //判断是否有红包回款任务
        val rewardRepayPlan = billRepayPlanRepo.findByOrderIdAndType(orderId, BillType.Reward)

        //判断是否有商户打款计划
        val merRemitPlan = billOutPlanRepo.findByOrderIdAndType(orderId, BillType.Merchant)
        if(merRemitPlan != null) {
            if(repayPlanO != null) {
                userAmount = repayPlanO.shouldAmount!!
            }
            // TODO 判断是否已经向商户打款, 若没打款，则取消；若有打款通知人工追回钱款
            val outTasks = billOutTasksRepo.findByBisTaskId(merRemitPlan.id!!)
            if (!CollectionUtils.isEmpty(outTasks)) {
                outTasks!!.forEach {
                    if (it.status != Progress.Cancel) {
                        amount += it.totalAmount!!
                    }else {
                        //存在向商户分期打款时逻辑错误
                        return RefundCheckListBO(amount = amount, serviceChargeAmount = serviceChargeAmount,
                                rewardAmount = rewardAmount, rewardStatus = rewardStatus, data = list)
                    }
                }
            }
            val orderTradeTime = merRemitPlan.orderTradeTime!!
            val time = diffDays(orderTradeTime, now)

            //判断是否有商户回款计划
            val merRepayPlan = billRepayPlanRepo.findByOrderIdAndType(orderId, BillType.Merchant)
            //判断 订单交易时间是否超过七天，有产生手续费，不超过没有
            if(time > exemptionTime) {
                val service = serviceCharge(merRemitPlan!!, now, userAmount, orderId, list)
                serviceChargeAmount = service.shouldAmount!!
                list.add(service)
            }
            //如果存在商户回款计划直接返回
            if (merRepayPlan != null) {
                if(rewardRemitPlan != null) {
                    rewardStatus = rewardRemitPlan.status.toString()
                    rewardAmount = rewardRemitPlan.shouldAmount!!
                    if(rewardRepayPlan != null){
                        rewardAmount = rewardRepayPlan.shouldAmount!!
                        list.add(rewardRepayPlan)
                    }
                }
                list.add(merRepayPlan)
                return RefundCheckListBO(amount = merRepayPlan.shouldAmount, serviceChargeAmount = serviceChargeAmount,
                        rewardAmount = rewardAmount, rewardStatus = rewardStatus, data = list)
            }
            if (amount > 0) {
                //生成商户回款任务
                var mer = createMerRepayPlan(merRemitPlan!!, amount, now, operator)
                list.add(mer)
            }
        }

        //存在红包打款任务，生成对应的红包收款任务
        if(rewardRemitPlan !=null && rewardRemitTasks != null){
            rewardAmount = rewardRemitPlan.shouldAmount!!
            rewardStatus = rewardRemitPlan.status.toString()
            if(rewardRemitPlan.status == Progress.Success && rewardRemitTasks.status == Progress.Success){
                if (rewardRepayPlan == null) {
                    val reward = createRewardRepayPlan(rewardRemitPlan, now, operator)
                    rewardAmount = reward.shouldAmount!!
                    list.add(reward)
                }else {
                    list.add(rewardRepayPlan)
                }
            }
        }
        return RefundCheckListBO(amount = amount, serviceChargeAmount = serviceChargeAmount,
                rewardAmount = rewardAmount, rewardStatus = rewardStatus, data = list)
    }

    //红包收款任务生成
    private fun createRewardRepayPlan(rewardRemitPlan: BillOutPlanPO, now: Date, operator: String) : BillRepayPlanPO{
        val repayPlanId = uuId()
        val r = billRepayPlanRepo.save(BillRepayPlanPO(
                id = repayPlanId,
                orderId = rewardRemitPlan.orderId,
                tradeId = rewardRemitPlan.tradeId,
                debitChannel = rewardRemitPlan.debitChannel,
                fundChannel = rewardRemitPlan.fundChannel,
                periodTimes = 1,
                orderTradeTime = rewardRemitPlan.orderTradeTime,
                payAccount = rewardRemitPlan.payeeAccount,
                payBank = rewardRemitPlan.payeeBank,
                payer = rewardRemitPlan.payeeName,
                payerIdno = null,
                repayDate = now,
                shouldAmount = rewardRemitPlan.shouldAmount,
                merId = rewardRemitPlan.merId,
                status = Progress.Ready,
                createBy = operator,
                modifyBy = operator,
                modifyTime = now,
                createdTime = now,
                updatedTime = now,
                loanReqNo = rewardRemitPlan.loanReqNo,
                loanNo = rewardRemitPlan.loanNo,
                contReqNo = rewardRemitPlan.contReqNo,
                contNo = rewardRemitPlan.contNo,
                type = BillType.Reward,
                audit = AuditStatus.Normal.status
        ))
        billInTasksRepo.save(BillInTasksPO(
                bisTaskId = r.id,
                orderId = r.orderId,
                tradeId = r.tradeId,
                debitChannel = r.debitChannel,
                finishTime = null,
                fundChannel = r.fundChannel,
                payAccount = r.payAccount,
                payBank = r.payBank,
                payType = null,
                payer = r.payer,
                payerIdno = r.payerIdno,
                penalty = 0,
                planExecuteTime = now,
                nextExecuteTime = null,
                lastExecuteTime = null,
                overdueDays = 0,
                message = null,
                requestNo = null,
                seqNo = 1,
                shouldAmount = r.shouldAmount,
                status = Progress.Ready,
                checkStatus = CheckStatus.NoApplyCheck.status,
                taskType = TaskType.Repay,
                thirdOrderId = null,
                totalAmount = r.shouldAmount,
                createBy = operator,
                modifyBy = operator,
                modifyTime = now,
                createdTime = now,
                updatedTime = now,
                loanReqNo = r.loanReqNo,
                loanNo = r.loanNo,
                contReqNo = r.contReqNo,
                contNo = r.contNo,
                type = r.type,
                audit = AuditStatus.Normal.status
        ))
        return r
    }

    //手续费收取任务生成
    private fun serviceCharge(merRemitPlan: BillOutPlanPO, now: Date, userAmount: Int, orderId: String, list: List<BillRepayPlanPO>) : BillRepayPlanPO {
        val feeAmount = (userAmount * rate).toInt()
        val operator = "手续费任务"
        //判断是否有手续费任务
        var serviceChargeRepayPlan = billRepayPlanRepo.findByOrderIdAndType(orderId, BillType.ServiceCharge)
        if(serviceChargeRepayPlan == null){
            serviceChargeRepayPlan = createFeePlan(merRemitPlan, now, feeAmount, operator)
        }
        return serviceChargeRepayPlan!!
    }

    //手续费任务生成
    private fun createFeePlan(merRemitPlan: BillOutPlanPO, now: Date, feeAmount: Int, operator: String) : BillRepayPlanPO{
        val repayPlanId = uuId()
        val r = billRepayPlanRepo.save(BillRepayPlanPO(
                id = repayPlanId,
                orderId = merRemitPlan.orderId,
                tradeId = merRemitPlan.tradeId,
                debitChannel = merRemitPlan.debitChannel,
                fundChannel = merRemitPlan.fundChannel,
                periodTimes = 1,
                orderTradeTime = merRemitPlan.orderTradeTime,
                payAccount = merRemitPlan.payeeAccount,
                payBank = merRemitPlan.payeeBank,
                payer = merRemitPlan.payeeName,
                payerIdno = null,
                repayDate = now,
                shouldAmount = feeAmount,
                merId = merRemitPlan.merId,
                status = Progress.Ready,
                createBy = operator,
                modifyBy = operator,
                modifyTime = now,
                createdTime = now,
                updatedTime = now,
                loanReqNo = merRemitPlan.loanReqNo,
                loanNo = merRemitPlan.loanNo,
                contReqNo = merRemitPlan.contReqNo,
                contNo = merRemitPlan.contNo,
                type = BillType.ServiceCharge,
                audit = AuditStatus.Normal.status
        ))
        billInTasksRepo.save(BillInTasksPO(
                bisTaskId = r.id,
                orderId = r.orderId,
                tradeId = r.tradeId,
                debitChannel = r.debitChannel,
                finishTime = null,
                fundChannel = r.fundChannel,
                payAccount = r.payAccount,
                payBank = r.payBank,
                payType = null,
                payer = r.payer,
                payerIdno = r.payerIdno,
                penalty = 0,
                planExecuteTime = now,
                nextExecuteTime = null,
                lastExecuteTime = null,
                overdueDays = 0,
                message = null,
                requestNo = null,
                seqNo = 1,
                shouldAmount = feeAmount,
                status = Progress.Ready,
                checkStatus = CheckStatus.NoApplyCheck.status,
                taskType = TaskType.Repay,
                thirdOrderId = null,
                totalAmount = feeAmount,
                createBy = operator,
                modifyBy = operator,
                modifyTime = now,
                createdTime = now,
                updatedTime = now,
                loanReqNo = r.loanReqNo,
                loanNo = r.loanNo,
                contReqNo = r.contReqNo,
                contNo = r.contNo,
                type = r.type,
                audit = AuditStatus.Normal.status
        ))
        return r
    }

    //未打款的红包发放任务变为审核中
    fun cancelRewardOutPlan(rewardRemitPlan: BillOutPlanPO, rewardRemitTasks: BillOutTasksPO, now: Date) {
        val operator = "退款"
        rewardRemitPlan.modifyTime = now
        rewardRemitPlan.updatedTime = now
        rewardRemitPlan.modifyBy = operator
        rewardRemitPlan.audit = AuditStatus.InRefundAudit.status
        billOutPlanRepo.save(rewardRemitPlan)

        rewardRemitTasks.modifyBy = operator
        rewardRemitTasks.modifyTime = now
        rewardRemitTasks.updatedTime = now
        rewardRemitTasks.message = operator
        rewardRemitTasks.audit = AuditStatus.InRefundAudit.status
        billOutTasksRepo.save(rewardRemitTasks)
    }

    /**
     * 退款审核状态修改
     */
    @Transactional
    fun refundModification(orderId: String, type: BillType, moneyBack: String){
        val now = Date()
        val operator = "退款"
        var status= if(moneyBack == "0") Progress.Ready else Progress.Success
        val rewardPlan = billRepayPlanRepo.findByOrderIdAndType(orderId, BillType.Reward)
        val rewardTasks = billInTasksRepo.findByOrderIdAndType(orderId, BillType.Reward)
        val serviceChargePlan = billRepayPlanRepo.findByOrderIdAndType(orderId, BillType.ServiceCharge)
        val serviceChargeTasks = billInTasksRepo.findByOrderIdAndType(orderId, BillType.ServiceCharge)
        val merchantPlan = billRepayPlanRepo.findByOrderIdAndType(orderId, BillType.Merchant)
        val merchantTasks = billInTasksRepo.findByOrderIdAndType(orderId, BillType.Merchant)
        if(type == BillType.Merchant) {
            if(serviceChargePlan != null) {
                if(!CollectionUtils.isEmpty(serviceChargeTasks)) {
                    //手续回款任务状态变更
                    successServiceChargePlanForSuccess(serviceChargePlan, serviceChargeTasks!!, now, operator, status)
                }
            }
            if(merchantPlan != null) {
                if(!CollectionUtils.isEmpty(merchantTasks)) {
                    //商家回款任务状态变更
                    successMerchantForSuccess(merchantPlan, merchantTasks!!, now, operator, status)
                }
            }
        }else if(type == BillType.Reward){
            if(rewardPlan != null) {
                if(!CollectionUtils.isEmpty(rewardTasks)) {
                    //红包回款任务状态变更
                    successRewardPlanForSuccess(rewardPlan, rewardTasks!!, now, operator, status)
                }
            }
        }
    }

    //红包收款任务修改
    private fun successRewardPlanForSuccess(repayPlan: BillRepayPlanPO, inTasks: List<BillInTasksPO>, now: Date, operator: String,
                                            status: Progress) {
        val msg = "红包退款"
        inTasks.forEach {
            it.status = status
            it.modifyTime = now
            it.updatedTime = now
            it.modifyBy = operator
            it.finishTime = now
            it.lastExecuteTime = now
            billInTasksRepo.save(it)

            //添加流水信息
            billInFlowsRepo.save(BillInFlowsPO(
                    taskId = it.id,
                    bisTaskId = it.bisTaskId,
                    thirdOrderId = it.orderId,
                    amount = it.totalAmount,
                    requestNo = it.requestNo,
                    payAccount = it.payAccount,
                    payer = it.payer,
                    tradeId = it.tradeId,
                    status = it.status,
                    payType = it.payType,
                    payerIdno = it.payerIdno,
                    updatedTime = now,
                    modifyBy = operator,
                    payBank = it.payBank,
                    debitChannel = it.debitChannel,
                    finishTime = now,
                    fundChannel = it.fundChannel,
                    lastExecuteTime = now,
                    seqNo = it.seqNo,
                    shouldAmount = it.shouldAmount,
                    checkStatus = it.checkStatus,
                    taskType = it.type,
                    createBy = it.createBy,
                    modifyTime = now,
                    loanReqNo = it.loanReqNo,
                    loanNo = it.loanNo,
                    contReqNo = it.contReqNo,
                    contNo = it.contNo,
                    audit = it.audit,
                    message = msg
            ))
        }
        repayPlan.status = status
        repayPlan.modifyTime = now
        repayPlan.updatedTime = now
        repayPlan.modifyBy = operator
        billRepayPlanRepo.save(repayPlan)
    }

    //商家回款任务修改
    private fun successMerchantForSuccess(repayPlan: BillRepayPlanPO, inTasks: List<BillInTasksPO>, now: Date, operator: String,
                                          status: Progress) {
        val msg = "商家退款"
        inTasks.forEach {
            it.status = status
            it.modifyTime = now
            it.updatedTime = now
            it.modifyBy = operator
            it.finishTime = now
            it.lastExecuteTime = now
            billInTasksRepo.save(it)

            //添加流水信息
            billInFlowsRepo.save(BillInFlowsPO(
                    taskId = it.id,
                    bisTaskId = it.bisTaskId,
                    thirdOrderId = it.orderId,
                    amount = it.totalAmount,
                    requestNo = it.requestNo,
                    payAccount = it.payAccount,
                    payer = it.payer,
                    tradeId = it.tradeId,
                    status = it.status,
                    payType = it.payType,
                    payerIdno = it.payerIdno,
                    updatedTime = now,
                    modifyBy = operator,
                    payBank = it.payBank,
                    debitChannel = it.debitChannel,
                    finishTime = now,
                    fundChannel = it.fundChannel,
                    lastExecuteTime = now,
                    seqNo = it.seqNo,
                    shouldAmount = it.shouldAmount,
                    checkStatus = it.checkStatus,
                    taskType = it.type,
                    createBy = it.createBy,
                    modifyTime = now,
                    loanReqNo = it.loanReqNo,
                    loanNo = it.loanNo,
                    contReqNo = it.contReqNo,
                    contNo = it.contNo,
                    audit = it.audit,
                    message = msg
            ))
        }
        repayPlan.status = status
        repayPlan.modifyTime = now
        repayPlan.updatedTime = now
        repayPlan.modifyBy = operator
        billRepayPlanRepo.save(repayPlan)
    }

    //手续费回款任务修改
    private fun successServiceChargePlanForSuccess(repayPlan: BillRepayPlanPO, inTasks: List<BillInTasksPO>, now: Date, operator: String,
                                                   status: Progress) {
        val msg = "手续费"
        inTasks.forEach {
            it.status = status
            it.modifyTime = now
            it.updatedTime = now
            it.modifyBy = operator
            it.finishTime = now
            it.lastExecuteTime = now
            billInTasksRepo.save(it)

            //添加流水信息
            billInFlowsRepo.save(BillInFlowsPO(
                    taskId = it.id,
                    bisTaskId = it.bisTaskId,
                    thirdOrderId = it.orderId,
                    amount = it.totalAmount,
                    requestNo = it.requestNo,
                    payAccount = it.payAccount,
                    payer = it.payer,
                    tradeId = it.tradeId,
                    status = it.status,
                    payType = it.payType,
                    payerIdno = it.payerIdno,
                    updatedTime = now,
                    modifyBy = operator,
                    payBank = it.payBank,
                    debitChannel = it.debitChannel,
                    finishTime = now,
                    fundChannel = it.fundChannel,
                    lastExecuteTime = now,
                    seqNo = it.seqNo,
                    shouldAmount = it.shouldAmount,
                    checkStatus = it.checkStatus,
                    taskType = it.type,
                    createBy = it.createBy,
                    modifyTime = now,
                    loanReqNo = it.loanReqNo,
                    loanNo = it.loanNo,
                    contReqNo = it.contReqNo,
                    contNo = it.contNo,
                    audit = it.audit,
                    message = msg
            ))
        }
        repayPlan.status = status
        repayPlan.modifyTime = now
        repayPlan.updatedTime = now
        repayPlan.modifyBy = operator
        billRepayPlanRepo.save(repayPlan)
    }

    /**
     * 拒绝退款
     */
    @Transactional
    fun refusalWithdrawal(orderId: String) {
        val plan = billRepayPlanRepo.findByOrderIdAndType(orderId, BillType.User)
        if(plan != null) {
            val bisTaskId = plan.id!!
            //开始用户收款任务
            startUserRepayPlan(bisTaskId)
        }
        val rewardPlan = billRepayPlanRepo.findByOrderIdAndType(orderId, BillType.Reward)
        if(rewardPlan != null) {
            val rpOrderId = rewardPlan.orderId!!
            val rpType = rewardPlan.type!!.toString()
            //删除红包收款任务
            stopRepayPlan(rpOrderId, rpType)
        }
        val merchantChargePlan = billRepayPlanRepo.findByOrderIdAndType(orderId, BillType.ServiceCharge)
        if(merchantChargePlan != null) {
            val scpOrderId = merchantChargePlan.orderId!!
            val scpType = merchantChargePlan.type!!.toString()
            //删除手续费任务
            stopRepayPlan(scpOrderId, scpType)
        }
        val serviceChargePlan = billRepayPlanRepo.findByOrderIdAndType(orderId, BillType.Merchant)
        if(serviceChargePlan != null) {
            val scpOrderId = serviceChargePlan.orderId!!
            val scpType = serviceChargePlan.type!!.toString()
            //删除商户收款任务
            stopRepayPlan(scpOrderId, scpType)
        }
        val merchantOutPlan = billOutPlanRepo.findByOrderIdAndType(orderId, BillType.Merchant)
        if(merchantOutPlan != null) {
            val bisTaskId = merchantOutPlan.id!!
            //开始商户打款任务
            startMerchantRepayPlan(bisTaskId)
        }
        val rewardOutPlan = billOutPlanRepo.findByOrderIdAndType(orderId, BillType.Reward)
        if(rewardOutPlan != null) {
            if(rewardOutPlan.audit == AuditStatus.InRefundAudit.status) {
                val bisTaskId = rewardOutPlan.id!!
                //开始红包打款任务
                rewardOutPlan(bisTaskId)
            }
        }
        val phoneBillInPlan = billRepayPlanRepo.findByOrderIdAndType(orderId, BillType.PhoneBill)
        if(phoneBillInPlan != null) {
            if(phoneBillInPlan.audit == AuditStatus.InRefundAudit.status) {
                val bisTaskId = phoneBillInPlan.id!!
                //开始话费代扣任务
                startUserRepayPlan(bisTaskId)
            }
        }
        val phoneBillOutPlan = billOutPlanRepo.findByOrderIdAndType(orderId, BillType.PhoneBill)
        if(phoneBillOutPlan != null) {
            if(phoneBillOutPlan.audit == AuditStatus.InRefundAudit.status) {
                val bisTaskId = phoneBillOutPlan.id!!
                //开始话费代充任务
                startMerchantRepayPlan(bisTaskId)
            }
        }
        val phoneBillNoAmountInPlan = billRepayPlanRepo.findByOrderIdAndType(orderId, BillType.PhoneBillNoAmount)
        if(phoneBillNoAmountInPlan != null) {
            if(phoneBillNoAmountInPlan.audit == AuditStatus.InRefundAudit.status) {
                val bisTaskId = phoneBillNoAmountInPlan.id!!
                //开始话费代扣任务
                startUserRepayPlan(bisTaskId)
            }
        }
        val phoneBilNoAmountlOutPlan = billOutPlanRepo.findByOrderIdAndType(orderId, BillType.PhoneBillNoAmount)
        if(phoneBilNoAmountlOutPlan != null) {
            if(phoneBilNoAmountlOutPlan.audit == AuditStatus.InRefundAudit.status) {
                val bisTaskId = phoneBilNoAmountlOutPlan.id!!
                //开始话费代充任务
                startMerchantRepayPlan(bisTaskId)
            }
        }
    }

    //开始红包打款任务
    fun rewardOutPlan(bisTaskId: String) {
        val now = Date()
        val operator = "ceres"

        val repayPlan = billOutPlanRepo.findById(bisTaskId).get()
        val tasks = billOutTasksRepo.findByBisTaskId(bisTaskId) ?: listOf()
        // TODO 若用户在 完全生成全部期数task数据前 就取消了订单, 需要的处理?
        // TODO 订单取消(未还款task audit状态修改为 1)
        tasks.forEach {
            it.audit = AuditStatus.Normal.status
            it.modifyBy = operator
            it.modifyTime = now
            it.updatedTime = now
            it.status = Progress.Ready

            billOutTasksRepo.save(it)
        }
        // TODO 总表状态设置为取消
        repayPlan.audit = AuditStatus.Normal.status
        repayPlan.modifyBy = operator
        repayPlan.modifyTime = now
        repayPlan.updatedTime = now
        repayPlan.status = Progress.Ready
        billOutPlanRepo.save(repayPlan)
    }

    //开始商户打款任务
    fun startMerchantRepayPlan(bisTaskId: String) {
        val now = Date()
        val operator = "ceres"

        val repayPlan = billOutPlanRepo.findById(bisTaskId).get()
        val tasks = billOutTasksRepo.findByBisTaskId(bisTaskId) ?: listOf()
        // TODO 若用户在 完全生成全部期数task数据前 就取消了订单, 需要的处理?
        // TODO 订单取消(未还款task audit状态修改为 1)
        tasks.forEach {
            it.audit = AuditStatus.Normal.status
            it.modifyBy = operator
            it.modifyTime = now
            it.updatedTime = now

            billOutTasksRepo.save(it)
        }
        // TODO 总表状态设置为取消
        repayPlan.audit = AuditStatus.Normal.status
        repayPlan.modifyBy = operator
        repayPlan.modifyTime = now
        repayPlan.updatedTime = now
        billOutPlanRepo.save(repayPlan)
    }

    //开始用户收款任务
    fun startUserRepayPlan(bisTaskId: String) {
        val now = Date()
        val operator = "ceres"

        val repayPlan = billRepayPlanRepo.findById(bisTaskId).get()
        val tasks = billInTasksRepo.findByBisTaskId(bisTaskId) ?: listOf()
        // TODO 若用户在 完全生成全部期数task数据前 就取消了订单, 需要的处理?
        // TODO 订单取消(未还款task audit状态修改为 1)
        tasks.forEach {
            it.audit = AuditStatus.Normal.status
            it.modifyBy = operator
            it.modifyTime = now
            it.updatedTime = now

            billInTasksRepo.save(it)
        }
        // TODO 总表状态设置为取消
        repayPlan.audit = AuditStatus.Normal.status
        repayPlan.modifyBy = operator
        repayPlan.modifyTime = now
        repayPlan.updatedTime = now
        billRepayPlanRepo.save(repayPlan)
    }

    //删除红包收款任务/商户收款任务
    fun stopRepayPlan(orderId: String, type: String) {
        billRepayPlanRepo.deleteData(orderId, type)
        billInTasksRepo.deleteData(orderId, type)
    }

    //关闭商户收款任务
    fun stopServiceChargeRepayPlan(bisTaskId: String) {
        val now = Date()
        val operator = "ceres"

        val repayPlan = billRepayPlanRepo.findById(bisTaskId).get()
        val tasks = billInTasksRepo.findByBisTaskId(bisTaskId) ?: listOf()
        // TODO 若用户在 完全生成全部期数task数据前 就取消了订单, 需要的处理?
        // TODO 订单取消(未还款task audit状态修改为 1)
        tasks.forEach {
            it.status = Progress.Cancel
            it.modifyBy = operator
            it.modifyTime = now
            it.updatedTime = now

            billInTasksRepo.save(it)
        }
        // TODO 总表状态设置为取消
        repayPlan.status = Progress.Cancel
        repayPlan.modifyBy = operator
        repayPlan.modifyTime = now
        repayPlan.updatedTime = now
        billRepayPlanRepo.save(repayPlan)
    }

    //回款数据提供
    fun receivedPayments(orderId: String) : RefundCheckListBO<BillRepayPlanPO>{
        val operator = "退款校验"
        val now = Date()
        var userAmount = 0
        var serviceChargeAmount = 0 //手续费金额
        var rewardAmount = 0 //红包金额
        var amount = 0 //商户回款金额
        var rewardStatus = "Nothing" //红包打款状态
        var list = mutableListOf<BillRepayPlanPO>()
        val repayPlanO = billRepayPlanRepo.findByOrderIdAndType(orderId, BillType.User)

        //判断该扣款计划是否有对应的红包
        val rewardRemitPlan = billOutPlanRepo.findByOrderIdAndType(orderId, BillType.Reward)
        val rewardRemitTasks = billOutTasksRepo.findByOrderIdAndType(orderId, BillType.Reward)

        //判断是否有红包回款任务
        val rewardRepayPlan = billRepayPlanRepo.findByOrderIdAndType(orderId, BillType.Reward)

        //判断是否有商户打款计划
        val merRemitPlan = billOutPlanRepo.findByOrderIdAndType(orderId, BillType.Merchant)
        if(merRemitPlan != null) {
            if(repayPlanO != null) {
                userAmount = repayPlanO.shouldAmount!!
            }
            // TODO 判断是否已经向商户打款, 若没打款，则取消；若有打款通知人工追回钱款
            val outTasks = billOutTasksRepo.findByBisTaskId(merRemitPlan.id!!)
            if (!CollectionUtils.isEmpty(outTasks)) {
                outTasks!!.forEach {
                    if (it.status != Progress.Cancel) {
                        amount += it.totalAmount!!
                    }else {
                        //存在向商户分期打款时逻辑错误
                        return RefundCheckListBO(amount = amount, serviceChargeAmount = serviceChargeAmount,
                                rewardAmount = rewardAmount, rewardStatus = rewardStatus, data = list)
                    }
                }
            }
            val orderTradeTime = merRemitPlan.orderTradeTime!!
            val time = diffDays(orderTradeTime, now)

            //判断是否有商户回款计划
            val merRepayPlan = billRepayPlanRepo.findByOrderIdAndType(orderId, BillType.Merchant)
            //判断 订单交易时间是否超过七天，有产生手续费，不超过没有
            if(time > exemptionTime) {
                val service = serviceCharges(merRemitPlan!!, now, userAmount, orderId, list)
                serviceChargeAmount = service.shouldAmount!!
                list.add(service)
            }
            //如果存在商户回款计划直接返回
            if (merRepayPlan != null) {
                if(rewardRepayPlan != null){
                    list.add(rewardRepayPlan)
                }
                list.add(merRepayPlan)
                return RefundCheckListBO(amount = merRepayPlan.shouldAmount, serviceChargeAmount = serviceChargeAmount,
                        rewardAmount = rewardAmount, rewardStatus = rewardStatus, data = list)
            }
            if (amount > 0) {
                //生成商户回款任务
                var mer = merRepayPlanData(merRemitPlan!!, amount, now, operator)
                list.add(mer)
            }
        }

        //存在红包打款任务，生成对应的红包收款任务
        if(rewardRemitPlan !=null && rewardRemitTasks != null){
            rewardAmount = rewardRemitPlan.shouldAmount!!
            rewardStatus = rewardRemitPlan.status.toString()
            if(rewardRemitPlan.status == Progress.Success && rewardRemitTasks.status == Progress.Success){
                if (rewardRepayPlan == null) {
                    val reward = rewardData(rewardRemitPlan, now, operator)
                    rewardAmount = reward.shouldAmount!!
                    list.add(reward)
                }else {
                    list.add(rewardRepayPlan)
                }
            }
        }
        return RefundCheckListBO(amount = amount, serviceChargeAmount = serviceChargeAmount,
                rewardAmount = rewardAmount, rewardStatus = rewardStatus, data = list)
    }

    //红包回款数据
    fun rewardData(rewardRemitPlan: BillOutPlanPO, now: Date, operator: String) :BillRepayPlanPO{
        val repayPlanId = uuId()
        return BillRepayPlanPO(
                id = repayPlanId,
                orderId = rewardRemitPlan.orderId,
                tradeId = rewardRemitPlan.tradeId,
                debitChannel = rewardRemitPlan.debitChannel,
                fundChannel = rewardRemitPlan.fundChannel,
                periodTimes = 1,
                orderTradeTime = rewardRemitPlan.orderTradeTime,
                payAccount = rewardRemitPlan.payeeAccount,
                payBank = rewardRemitPlan.payeeBank,
                payer = rewardRemitPlan.payeeName,
                payerIdno = null,
                repayDate = now,
                shouldAmount = rewardRemitPlan.shouldAmount,
                merId = rewardRemitPlan.merId,
                status = Progress.Ready,
                createBy = operator,
                modifyBy = operator,
                modifyTime = now,
                createdTime = now,
                updatedTime = now,
                loanReqNo = rewardRemitPlan.loanReqNo,
                loanNo = rewardRemitPlan.loanNo,
                contReqNo = rewardRemitPlan.contReqNo,
                contNo = rewardRemitPlan.contNo,
                type = BillType.Reward,
                audit = AuditStatus.Normal.status
        )
    }

    //商户回款数据
    fun merRepayPlanData(merRemitPlan: BillOutPlanPO, amount:Int, now: Date, operator: String) :BillRepayPlanPO{
        val repayPlanId = uuId()
        return BillRepayPlanPO(
                id = repayPlanId,
                orderId = merRemitPlan.orderId,
                tradeId = merRemitPlan.tradeId,
                debitChannel = merRemitPlan.debitChannel,
                fundChannel = merRemitPlan.fundChannel,
                periodTimes = 1,
                orderTradeTime = merRemitPlan.orderTradeTime,
                payAccount = merRemitPlan.payeeAccount,
                payBank = merRemitPlan.payeeBank,
                payer = merRemitPlan.payeeName,
                payerIdno = null,
                repayDate = now,
                shouldAmount = amount,
                merId = merRemitPlan.merId,
                status = Progress.Ready,
                createBy = operator,
                modifyBy = operator,
                modifyTime = now,
                createdTime = now,
                updatedTime = now,
                loanReqNo = merRemitPlan.loanReqNo,
                loanNo = merRemitPlan.loanNo,
                contReqNo = merRemitPlan.contReqNo,
                contNo = merRemitPlan.contNo,
                type = BillType.Merchant,
                audit = AuditStatus.Normal.status
        )
    }

    //手续费回款数据
    fun serviceChargeData(merRemitPlan: BillOutPlanPO, now: Date, feeAmount:Int, operator: String) :BillRepayPlanPO{
        val repayPlanId = uuId()
        return BillRepayPlanPO(
                id = repayPlanId,
                orderId = merRemitPlan.orderId,
                tradeId = merRemitPlan.tradeId,
                debitChannel = merRemitPlan.debitChannel,
                fundChannel = merRemitPlan.fundChannel,
                periodTimes = 1,
                orderTradeTime = merRemitPlan.orderTradeTime,
                payAccount = merRemitPlan.payeeAccount,
                payBank = merRemitPlan.payeeBank,
                payer = merRemitPlan.payeeName,
                payerIdno = null,
                repayDate = now,
                shouldAmount = feeAmount,
                merId = merRemitPlan.merId,
                status = Progress.Ready,
                createBy = operator,
                modifyBy = operator,
                modifyTime = now,
                createdTime = now,
                updatedTime = now,
                loanReqNo = merRemitPlan.loanReqNo,
                loanNo = merRemitPlan.loanNo,
                contReqNo = merRemitPlan.contReqNo,
                contNo = merRemitPlan.contNo,
                type = BillType.ServiceCharge,
                audit = AuditStatus.Normal.status
        )
    }

    //手续费收取任务生成不入库
    private fun serviceCharges(merRemitPlan: BillOutPlanPO, now: Date, userAmount: Int, orderId: String, list: List<BillRepayPlanPO>) : BillRepayPlanPO {
        val feeAmount = (userAmount * rate).toInt()
        val operator = "手续费任务"
        //判断是否有手续费任务
        var serviceChargeRepayPlan = billRepayPlanRepo.findByOrderIdAndType(orderId, BillType.ServiceCharge)
        if(serviceChargeRepayPlan == null){
            serviceChargeRepayPlan = serviceChargeData(merRemitPlan, now, feeAmount, operator)
        }
        return serviceChargeRepayPlan!!
    }
}