package com.fina.summer.manager.entity.bo

import com.fina.summer.core.utils.DataUtil
import io.swagger.annotations.ApiModelProperty
import java.io.Serializable

data class RiskReportBO(

        @ApiModelProperty("准入：拒绝人数/审核人数")
        var admittanceRatio: String? = null,

        @ApiModelProperty("黑名单：拒绝人数/审核人数")
        var blackListRatio: String? = null,

        @ApiModelProperty("反欺诈：拒绝人数/审核人数")
        var antiFraudRatio: String? = null,

        @ApiModelProperty("授信：拒绝人数/审核人数")
        var grantCreditRatio: String? = null,

        @ApiModelProperty("风控：拒绝人数/审核人数")
        var riskManageRatio: String? = null,

        @ApiModelProperty("资方：拒绝人数/审核人数")
        var capitalSideRatio: String? = null

) : Serializable {
    @ApiModelProperty("准入：通过率")
    var admittancePassRate: String? = null
        get() = DataUtil.convertRate(field)


    @ApiModelProperty("黑名单：通过率")
    var blackListPassRate: String? = null
        get() = DataUtil.convertRate(field)


    @ApiModelProperty("反欺诈：通过率")
    var antiFraudPassRate: String? = null
        get() = DataUtil.convertRate(field)


    @ApiModelProperty("授信：通过率")
    var grantCreditPassRate: String? = null
        get() = DataUtil.convertRate(field)


    @ApiModelProperty("风控：通过率")
    var riskManagePassRate: String? = null
        get() = DataUtil.convertRate(field)


    @ApiModelProperty("资方：通过率")
    var capitalSidePassRate: String? = null
        get() = DataUtil.convertRate(field)

    @ApiModelProperty("地区")
    var areaName: String? = null
        get() = if (DataUtil.AREA_NAME_ANY == field) "全部地区" else field
}