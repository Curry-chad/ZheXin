package com.fina.summer.manager.batch

import com.fina.summer.manager.impl.operate.OperateTopupService
import org.slf4j.Logger
import org.slf4j.LoggerFactory
import org.springframework.stereotype.Component
import org.springframework.util.CollectionUtils

/**
 * @author zhengqiyang@zhexinit.com
 * @version V1.0
 * @since 1.0 2019/5/16 14:12
 * @description 批量待缴定时任务
 */
@Component
class BatchRecharge(
        private val operateTopupService : OperateTopupService
        ) {
    private val logger: Logger = LoggerFactory.getLogger(BatchRecharge::class.java)
    //每个月1号的12点，14点，17点，20点各执行一次
    //@Scheduled(cron = "0 0 12,14,17,20 1 1/1 ?")
    fun batchRechargeTiming(){
        //查询当期需要进行话费代缴任务的数据
        var findRechargeListByItem = operateTopupService.findRechargeListByItem()
        if(CollectionUtils.isEmpty(findRechargeListByItem)) {
            logger.info("没有需要进行话费代缴任务的订单数据")
            return
        }
        logger.info("本期需要进行话费代缴任务的订单数据为:$findRechargeListByItem")
        operateTopupService.recharge(findRechargeListByItem!!)
    }

}
