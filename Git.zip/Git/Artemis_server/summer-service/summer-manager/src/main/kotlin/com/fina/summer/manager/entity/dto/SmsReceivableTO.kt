package com.fina.summer.manager.entity.dto

import io.swagger.annotations.ApiModelProperty
import java.io.Serializable

data class SmsReceivableTO(
        @ApiModelProperty("短信模板id")
        var id: Long? = null,

        @ApiModelProperty("还款任务id集合")
        var taskIds: List<String>? = null
): Serializable