package com.fina.summer.manager.batch

import com.alibaba.excel.util.CollectionUtils
import com.fina.summer.core.utils.DateUtils
import com.fina.summer.persistent.ceres.entity.domain.BillInTasksPO
import com.fina.summer.persistent.ceres.entity.domain.BillOutTasksPO
import com.fina.summer.persistent.ceres.mapper.BillInTasksMapper
import com.fina.summer.persistent.ceres.mapper.BillOutTasksMapper
import org.slf4j.Logger
import org.slf4j.LoggerFactory
import org.springframework.stereotype.Component
import java.util.*
import kotlin.streams.toList

/**
 * @author zhengqiyang@zhexinit.com
 * @version V1.0
 * @since 1.0 2019/5/7 14:12
 * @description 计算逾期金额定时任务
 */
const val OverduePercent = 0.001
@Component
class OverdueAmountService(

        private val billOutTasksMapper: BillOutTasksMapper,

        private val billInTasksMapper: BillInTasksMapper
) {

    private val logger: Logger = LoggerFactory.getLogger(OverdueAmountService::class.java)


    /**
     *
     * @author zhengqiyang@zhexinit.com
     * @date 2019/5/22 16:46
     * @param []
     * @return Any
     * @description 计算中原违约金
     */
    //@Scheduled(cron = "0 0 1 * * ?")
    fun overdueAmountBatch() {
        logger.info("计算中原违约金任务开始了------------")
        //更新逾期天数
        billOutTasksMapper.updateOverdueDays()
        //查询出所有订单首期逾期的期次列表
        val findFirstOverdueSeqnoList = billOutTasksMapper.findFirstOverdueSeqnoList()
        if (CollectionUtils.isEmpty(findFirstOverdueSeqnoList)) {
            logger.info("未查到逾期订单")
            return
        }
        // overdueService.calculateAndUpdateOverdueAmount(findFirstOverdueSeqnoList!!)
        //转成bisTaskId和期次的map
        val idAndSeqnoMap = findFirstOverdueSeqnoList!!.map { it.bisTaskId!! to it.seqNo!! }.toMap()
        //查询出前1000条符合条件的逾期数据
        val pageSize = 1000
        var maxOrderId = "ORD000"
        var findOverdueDataByPage = billOutTasksMapper.findOverdueDataByPage(pageSize,maxOrderId)
        /*val testList = arrayListOf<String>()
        testList.add("ORD270948698677465088")
        var findOverdueDataByPage = billOutTasksMapper.findInOrders(testList)*/
        while (!CollectionUtils.isEmpty(findOverdueDataByPage)) {
            //查出本次查询出来的最大的order_id
            maxOrderId = findOverdueDataByPage!![findOverdueDataByPage.size-1].orderId!!
            logger.info("本次查询出来的最大的order_id为:$maxOrderId")
            //计算违约金和应还金额
            val updateOverDueBillOutTasks = calculateOverAmount(idAndSeqnoMap, findOverdueDataByPage)
            //批量更新到数据库
            billOutTasksMapper.batchUpdateOverdueAmount(updateOverDueBillOutTasks)
            //再查出下一1000条
            findOverdueDataByPage = billOutTasksMapper.findOverdueDataByPage(pageSize,maxOrderId)
        }
        logger.info("计算中原违约金任务结束了------------")
    }


    /*
     *
     * @author zhengqiyang@zhexinit.com
     * @date 2019/5/22 16:39
     * @param
     * @return 需要进行更新的对象列表
     * @description 计算违约金和应还金额
     */

    private fun calculateOverAmount(idAndSeqnoMap: Map<String, Int>, findOverdueDataByPage: List<BillOutTasksPO>): MutableList<BillOutTasksPO> {
        val updateOverDueBillOutTasks = mutableListOf<BillOutTasksPO>()
        //违约金比例
        var penalty: Double
        for (it in findOverdueDataByPage) {
            val updateBillOutTask = BillOutTasksPO()
            penalty = if (it.seqNo == 1) {
                firstSeqAmountCalculate(it, updateBillOutTask)
            } else {
                moreSeqAmountCalculate(it, idAndSeqnoMap, updateBillOutTask)
            }
            updateBillOutTask.id = it.id
            updateBillOutTask.totalAmount = it.shouldAmount!! + penalty.toInt()
            updateOverDueBillOutTasks.add(updateBillOutTask)
        }
        return updateOverDueBillOutTasks
    }

    /*
     *
     * @author zhengqiyang@zhexinit.com
     * @date 2019/5/22 16:40
     * @param
     * @return 违约金
     * @description 期次大于1的期次计算违约金方法
     */

    private fun moreSeqAmountCalculate(it: BillOutTasksPO, idAndSeqnoMap: Map<String, Int>, updateBillOutTask: BillOutTasksPO): Double {
        var penalty = 0.00
        val today = DateUtils.getDateWithFormat(Date())
        if (it.planExecuteTime == null) {
            throw IllegalArgumentException("应还时间为空导致报错，报错任务id为${it.id}")
        }
        //将应还时间设为yyyyMMdd 00:00:00的格式，统一违约金天数
        it.planExecuteTime = DateUtils.getDateWithFormat(it.planExecuteTime!!)
        //计算违约金收取截止日期
        val endDate: Date = calculateMoreSeqEndDate(it, today)
        if (DateUtils.compare(today, endDate) != -1) {
            val receivedList = billInTasksMapper.findReceivedByBetweenTime(it.tradeId!!, it.planExecuteTime!!, endDate)
            logger.info("订单大于截止日，订单任务id为${it.id},在这段时间内的还款记录为: $receivedList")
            penalty = getReceivedPenalty(it, endDate, receivedList, idAndSeqnoMap, today)
            updateBillOutTask.penalty = penalty.toInt()
            updateBillOutTask.penaltyStatus = 1
        } else {
            if (it.seqNo == idAndSeqnoMap[it.bisTaskId]) {
                penalty = firstOverduePenaltyCalculate(it, today)
                updateBillOutTask.penalty = penalty.toInt()
                updateBillOutTask.penaltyStatus = 0
            }
            if (it.seqNo!! > idAndSeqnoMap[it.bisTaskId]!!) {
                val receivedList = billInTasksMapper.findReceivedByBetweenTime(it.tradeId!!, it.planExecuteTime!!, today)
                penalty = getReceivedPenalty(it, today, receivedList, idAndSeqnoMap, today)
                updateBillOutTask.penalty = penalty.toInt()
                updateBillOutTask.penaltyStatus = 0
            }
            logger.info("订单小于截止日，订单任务id为${it.id},计算出的违约金为:$penalty ")
        }
        return penalty
    }
/*
 *
 * @author zhengqiyang@zhexinit.com
 * @date 2019/5/24 17:14
 * @param
 * @return Any
 * @description 计算期次大于1的违约金截止日
 */

    private fun calculateMoreSeqEndDate(it: BillOutTasksPO, today: Date): Date {
        val nextSeqInfo = billOutTasksMapper.findRecordByOrderIdAndSeqNoAndType(it.orderId!!, it.seqNo!! + 1, "Zyxf")
        val endDate: Date
        if (nextSeqInfo == null) {
            //如果最后一期逾期，则没有截止日
            endDate = DateUtils.getDayByDays(today, +1)
            logger.info("最后一期逾期，算的违约金截止日为$endDate")
        } else {
            endDate = DateUtils.getDateWithFormat(nextSeqInfo.planExecuteTime!!)
            logger.info("期次大于1期场景逾期，算的违约金截止日为$endDate")
        }
        return endDate
    }
/*
 *
 * @author zhengqiyang@zhexinit.com
 * @date 2019/5/22 16:45
 * @param
 * @return 违约金
 * @description 计算小于违约金截止日，且为首期逾期期次时的违约金
 */

    private fun firstOverduePenaltyCalculate(it: BillOutTasksPO, today: Date): Double {
        val overduePercent = OverduePercent
        var penalty = 0.00
        val receivedList = billInTasksMapper.findReceivedByBetweenTime(it.tradeId!!, it.planExecuteTime!!, today)
        if (DateUtils.compare(DateUtils.getDayByDays(it.planExecuteTime!!, 3), today) != -1) {
            //逾期天数少于3天
            if (CollectionUtils.isEmpty(receivedList)) {
                return penalty
            } else {
                //还款
                for (receivedItem in receivedList) {
                    val receivedDays = DateUtils.differDateInDays(it.planExecuteTime!!, receivedItem.finishTime!!, timeType = DateUtils.TimeType.DAY).toInt()
                    penalty += it.shouldAmount!! * overduePercent * receivedDays
                }
                //当期这部分的违约金
                val itDays = DateUtils.differDateInDays(it.planExecuteTime!!, today, timeType = DateUtils.TimeType.DAY).toInt()
                val itPenalty = it.shouldAmount!! * overduePercent * itDays
                penalty += itPenalty
            }
        } else {
            if (CollectionUtils.isEmpty(receivedList)) {
                penalty = it.shouldAmount!! * overduePercent * (DateUtils.differDateInDays(it.planExecuteTime!!, today, timeType = DateUtils.TimeType.DAY).toInt())
                return penalty
            } else {
                //还款
                for (receivedItem in receivedList) {
                    val receivedDays = DateUtils.differDateInDays(it.planExecuteTime!!, receivedItem.finishTime!!, timeType = DateUtils.TimeType.DAY).toInt()
                    penalty += it.shouldAmount!! * overduePercent * receivedDays
                }
                //当期这部分的违约金
                val itDays = DateUtils.differDateInDays(it.planExecuteTime!!, today, timeType = DateUtils.TimeType.DAY).toInt()
                val itPenalty = it.shouldAmount!! * overduePercent * itDays
                penalty += itPenalty
            }
        }
        return penalty
    }

    /*
     *
     * @author zhengqiyang@zhexinit.com
     * @date 2019/5/22 16:41
     * @param
     * @return 违约金
     * @description 计算期次为1的期次违约金
     */

    fun firstSeqAmountCalculate(it: BillOutTasksPO, updateBillOutTask: BillOutTasksPO): Double {
        val overduePercent = OverduePercent
        var penalty = 0.00
        val today = DateUtils.getDateWithFormat(Date())
        if (it.planExecuteTime == null) {
            throw IllegalArgumentException("应还时间为空导致报错，报错任务id为${it.id}")
        }
        //将应还时间设为yyyyMMdd 00:00:00的格式，统一违约金天数
        it.planExecuteTime = DateUtils.getDateWithFormat(it.planExecuteTime!!)
        //计算违约金收取截止日期
        val nextSeqInfo = billOutTasksMapper.findRecordByOrderIdAndSeqNoAndType(it.orderId!!, it.seqNo!! + 1, "Zyxf")
        val endDate = DateUtils.getDateWithFormat(nextSeqInfo!!.planExecuteTime!!)
        logger.info("首期期次场景，计算出的截止日为$endDate")
        if (DateUtils.compare(today, endDate) != -1) {
            //当前日>=违约金截止日
            val days = DateUtils.differDateInDays(it.planExecuteTime!!, endDate, timeType = DateUtils.TimeType.DAY).toInt() //算头不算尾
            penalty = it.shouldAmount!! * overduePercent * days
            updateBillOutTask.penalty = penalty.toInt()
            updateBillOutTask.penaltyStatus = 1
            logger.info("订单大于截止日，订单任务id为${it.id},计算出的违约金为:$penalty ")
        } else {
            if (DateUtils.compare(DateUtils.getDayByDays(it.planExecuteTime!!, 3), today) != -1) {
                updateBillOutTask.penalty = 0
                updateBillOutTask.penaltyStatus = 0
            } else {
                logger.info("it.planExecuteTime 是 ${it.planExecuteTime}")
                logger.info("today 是 $today")
                logger.info("相差天数 是" + (DateUtils.differDateInDays(it.planExecuteTime!!, today, timeType = DateUtils.TimeType.DAY).toInt()))
                penalty = it.shouldAmount!! * overduePercent * (DateUtils.differDateInDays(it.planExecuteTime!!, today, timeType = DateUtils.TimeType.DAY).toInt())
                updateBillOutTask.penalty = penalty.toInt()
                updateBillOutTask.penaltyStatus = 0
            }
            logger.info("订单小于截止日，订单任务id为${it.id},计算出的违约金为:$penalty ")
        }
        return penalty
    }

    /*
     *
     * @author zhengqiyang@zhexinit.com
     * @date 2019/5/22 16:43
     * @param
     * @return 违约金
     * @description 计算可能存在还款记录时的违约金
     */

    fun getReceivedPenalty(it: BillOutTasksPO, endDate: Date, receivedList: List<BillInTasksPO>, idAndSeqnoMap: Map<String, Int>, today: Date): Double {
        //查询应还款日到截止日期间，用户对于当前订单的还款记录列表
        val overduePercent = OverduePercent
        var penalty = 0.00
        if (CollectionUtils.isEmpty(receivedList)) {
            val days = DateUtils.differDateInDays(it.planExecuteTime!!, endDate, timeType = DateUtils.TimeType.DAY).toInt()
            logger.info("查询出的首期逾期期次为" + idAndSeqnoMap[it.bisTaskId!!] + "id为${it.id}")
            val afterReceivedList = billInTasksMapper.findReceivedByBetweenTime(it.tradeId!!, endDate, today)
            if (CollectionUtils.isEmpty(afterReceivedList)) {
                penalty = it.shouldAmount!! * overduePercent * days * (it.seqNo!! - (idAndSeqnoMap[it.bisTaskId!!]!!) + 1)
            } else {
                logger.info("历史数据，还款时间大于截止日场景，查询出的当前id为${it.id}，最早还款期次为${afterReceivedList[0].seqNo!!}")
                penalty = it.shouldAmount!! * overduePercent * days * (it.seqNo!! - afterReceivedList[0].seqNo!! + 1)
            }

            logger.info("计算出的违约金为$penalty,id为${it.id}")
        } else {
            //还款
            val totalSeqList = receivedList.stream().map { it.seqNo }.toList()
            if (totalSeqList.contains(it.seqNo)) {
                for (receivedItem in receivedList) {
                    if (receivedItem.seqNo!! <= it.seqNo!!) {
                        val receivedDays = DateUtils.differDateInDays(it.planExecuteTime!!, receivedItem.finishTime!!, timeType = DateUtils.TimeType.DAY).toInt()
                        penalty += it.shouldAmount!! * overduePercent * receivedDays
                    }
                    logger.info("存在还款记录，且当期已还款。计算出的违约金为$penalty,id为${it.id}")
                }
                return penalty
            } else {
                for (receivedItem in receivedList) {
                    val receivedDays = DateUtils.differDateInDays(it.planExecuteTime!!, receivedItem.finishTime!!, timeType = DateUtils.TimeType.DAY).toInt()
                    penalty += it.shouldAmount!! * overduePercent * receivedDays
                }
                //当期这部分的违约金
                val itDays = DateUtils.differDateInDays(it.planExecuteTime!!, endDate, timeType = DateUtils.TimeType.DAY).toInt()
                val itPenalty = it.shouldAmount!! * overduePercent * itDays * (it.seqNo!! - (idAndSeqnoMap[it.bisTaskId!!]!!) + 1)
                penalty += itPenalty
                logger.info("存在还款记录，计算出的违约金为$penalty,id为${it.id}")
            }

        }
        return penalty
    }
}