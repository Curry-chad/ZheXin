package com.fina.summer.manager.client.util

import com.google.gson.Gson
import java.util.*

class TimeCalculationUtils {
    companion object {
        fun startTime(): Long {
            return Date().time
        }

        fun endTime(time: Long): Long {
            return Date().time-time
        }

        /**
         * 参数校验
         */
        fun isNotEmptyBatch(obj: Any, vararg str: String): List<String>{
            val json = Gson()
            val string = json.toJson(obj)
            val map = HashMap<String, Any>()
            val maps = json.fromJson(string,map.javaClass)
            val list = mutableListOf<String>()
            str.forEach {
                if(maps[it] == null){
                    list.add(it)
                }
            }
            return list
        }
    }
}