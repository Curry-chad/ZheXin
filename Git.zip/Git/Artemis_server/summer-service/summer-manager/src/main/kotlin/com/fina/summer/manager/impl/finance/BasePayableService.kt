package com.fina.summer.manager.impl.finance

import com.fina.summer.core.handler.SimpleException
import com.fina.summer.core.respone.ResEnum
import com.fina.summer.manager.client.SummerClient
import com.fina.summer.manager.entity.dto.PayableDTO
import com.fina.summer.manager.impl.user.UserService
import com.fina.summer.persistent.ceres.entity.constant.FlowStatus
import com.fina.summer.persistent.ceres.entity.constant.PayType
import com.fina.summer.persistent.ceres.entity.constant.TaskStatus
import com.fina.summer.persistent.ceres.entity.constant.TotalMerStatus
import com.fina.summer.persistent.ceres.entity.domain.BillOutFlowDO
import com.fina.summer.persistent.ceres.mapper.BillOutMapper
import com.fina.summer.persistent.ceres.repo.BillOutFlowRepo
import com.fina.summer.persistent.ceres.repo.BillOutTaskRepo
import com.fina.summer.persistent.ceres.repo.TotalMerRemitRepo
import org.springframework.stereotype.Service
import org.springframework.transaction.annotation.Transactional
import org.springframework.util.StringUtils
import java.util.*

@Service
class BasePayableService(
        private val billOutMapper: BillOutMapper,
        private val userService: UserService,
        private val billOutFlowRepo: BillOutFlowRepo,
        private val billOutTaskRepo: BillOutTaskRepo,
        private val totalMerRemitRepo: TotalMerRemitRepo,
        private val summerClient: SummerClient
) {



    @Transactional
    fun submitOne(it: PayableDTO, operatorName: String, now: Date) {
        val id = it.id!!
        val outTask = billOutTaskRepo.findById(id).get()
        val outFlowList = billOutFlowRepo.findByTaskId(id)
        val totalMerRemitDO = totalMerRemitRepo.findById(outTask.bisTaskId!!).get()

        val payVoucher = it.payVoucher
        val actualAmount = outTask.totalAmount
        if (outTask.status != TaskStatus.Success) {
            billOutFlowRepo.save(BillOutFlowDO(
                    amount = actualAmount,
                    createBy = operatorName,
                    createTime = now,
                    executeTime = now,
                    payAccount = it.payerAccount,
                    payBank = it.payerBank,
                    payType = PayType.Debit,
                    payee = outTask.payee,
                    payeeAccount = outTask.payeeAccount,
                    payeeOpenInstitution = outTask.payeeOpenInstitution,
                    payer = it.payerName,
                    paymentVoucher = payVoucher,
                    penalty = 0, // 本版本不处理【付款】违约金
                    status = FlowStatus.Success,
                    taskId = id,
                    thirdOrderId = outTask.thirdOrderId,
                    tradeId = outTask.tradeId
            ))
            outTask.payer = it.payerName
            outTask.payAccount = it.payerAccount
            outTask.payBank = it.payerBank
            outTask.status = TaskStatus.Success
            outTask.finishTime = now
            outTask.modifyBy = operatorName
            outTask.modifyTime = now

            billOutTaskRepo.save(outTask)

            totalMerRemitDO.actualAmount = actualAmount
            totalMerRemitDO.leftPeriodTimes = 0
            totalMerRemitDO.modifyBy = operatorName
            totalMerRemitDO.modifyTime = now
            totalMerRemitDO.status = TotalMerStatus.Success

            totalMerRemitRepo.save(totalMerRemitDO)
            val result = summerClient.zxReceipt(mapOf(
                    "orderId" to totalMerRemitDO.orderId.toString(),
                    "tradeId" to totalMerRemitDO.tradeId.toString(),
                    "receiptCardNumber" to totalMerRemitDO.payeeAccount.toString(),
                    "status" to true
            )) ?: throw SimpleException(totalMerRemitDO.orderId!!, "系统错误")
            if (result.code != ResEnum.Success.getCode()) {
                throw SimpleException(totalMerRemitDO.orderId!!, result.msg!!)
            }
        } else {
            val outFlow = outFlowList[0]
            outFlow.paymentVoucher = if (StringUtils.isEmpty(outFlow.paymentVoucher))
                payVoucher
            else if (!StringUtils.isEmpty(payVoucher))
                "${outFlow.paymentVoucher},$payVoucher"
            else outFlow.paymentVoucher
            billOutFlowRepo.save(outFlow)
        }
    }

}