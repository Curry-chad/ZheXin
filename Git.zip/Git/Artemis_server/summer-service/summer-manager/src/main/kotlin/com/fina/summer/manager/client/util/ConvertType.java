package com.fina.summer.manager.client.util;

public enum ConvertType {
	XML, JSON
}
