package com.fina.summer.manager.entity.dto

import io.swagger.annotations.ApiModelProperty
import java.io.Serializable

data class PayableDTO(

        @ApiModelProperty("应付账单单号")
        var id: String? = null,

        @ApiModelProperty("凭证")
        var payVoucher: String? = null,

        @ApiModelProperty("付款人姓名")
        var payerName: String? = null,

        @ApiModelProperty("付款人账号")
        var payerAccount: String? = null,

        @ApiModelProperty("付款人银行")
        var payerBank: String? = null

) : Serializable