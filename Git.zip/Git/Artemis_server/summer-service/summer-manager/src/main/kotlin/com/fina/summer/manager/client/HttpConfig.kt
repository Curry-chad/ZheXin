package com.fina.summer.manager.client

import org.springframework.beans.factory.annotation.Value
import org.springframework.stereotype.Component
import java.io.Serializable

@Component
data class HttpConfig(

        @Value("\${summer.url}")
        var summerBase: String? = null,

        @Value("\${summer.ceres.url}")
        var summerCeresBase: String? = null,

        @Value("\${finance.deductCallBack.url}")
        var financeDeductCallBack: String? = null

): Serializable