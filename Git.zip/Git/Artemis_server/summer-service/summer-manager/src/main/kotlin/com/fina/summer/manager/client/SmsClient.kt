package com.fina.summer.manager.client

import com.fina.summer.core.handler.SimpleException
import com.fina.summer.core.respone.ResEnum
import com.fina.summer.manager.client.entity.Returnsms
import com.fina.summer.manager.client.util.ConvertTo
import com.fina.summer.manager.client.util.ConvertType
import com.fina.summer.manager.client.util.HttpRequestVO
import org.slf4j.LoggerFactory
import org.springframework.beans.factory.annotation.Value
import org.springframework.stereotype.Component
import org.springframework.util.LinkedMultiValueMap
import org.springframework.util.MultiValueMap
import org.springframework.util.StringUtils

@Component
class SmsClient(
        private val baseHttpClient: BaseHttpClient
) {

    val contents = mapOf(
            "扣款前三天短信提示" to "【和分享】尊敬的客户您好，您办理的分期业务，本期账单{1}元。系统将于{2}对您尾号{3}的储蓄卡进行扣款，若您卡内余额不足，请及时预存，逾期将影响您的个人征信。退订回T",
            "扣款当天短信提示" to "【和分享】尊敬的客户您好，您办理的分期业务，本期账单{1}元。今日系统将对您尾号{2}的储蓄卡进行扣款，若您卡内余额不足，请及时预存，逾期将影响您的个人征信。退订回T",
            "10:00扣款失败短信提示" to "【和分享】尊敬的客户您好，您办理的分期业务，本期账单{1}元。您绑定的尾号{2}储蓄卡余额不足扣款失败，请在{3}前预存足额月供，逾期将影响您的个人征信。退订回T",
            "22:00扣款失败短信提示" to "【和分享】尊敬的客户您好，您办理的分期业务，本期账单{1}元。您绑定的尾号{2}储蓄卡余额不足扣款失败，请在{3}前预存足额月供，逾期将影响您的个人征信。退订回T",
            "扣款成功短信提示" to "【和分享】尊敬的客户您好，您办理的分期业务，本期账单{1}元已结清，感谢您的支持和配合。退订回T"
    )

    private val logger = LoggerFactory.getLogger(SmsClient::class.java)


    @Value("\${sms.receivable.url}")
    private val url: String? = null

    @Value("\${sms.receivable.action}")
    private val action: String? = "send"

    @Value("\${sms.receivable.userId.cm}")
    private val cmUserId: String? = null

    @Value("\${sms.receivable.account.cm}")
    private val cmAccount: String? = null

    @Value("\${sms.receivable.password.cm}")
    private val cmPassword: String? = null

    @Value("\${sms.receivable.userId.ctcu}")
    private val ctcuUserId: String? = null

    @Value("\${sms.receivable.account.ctcu}")
    private val ctcuAccount: String? = null

    @Value("\${sms.receivable.password.ctcu}")
    private val ctcuPassword: String? = null

    // 移动
    val supportCM = "134,135,136,137,138,139,1340,1341,1342,1343,1344,1345,1346,1347,1348,1349," +
            "147,148,150,151,152,157,158,159,182,183,184,187,188"

    // 电信 and 联通
    val supportCTAndCU = "133,1349,149,153,180,181,189,199,130,131,132,145,146,155,156,166,185,186"

    @ConvertTo(value = Returnsms::class, type = ConvertType.XML)
    fun send(mobile: String, content: String): Any? {
        var userId: String? = null
        var account: String? = null
        var password: String? = null
        if (isSupportCMPhone(mobile)) {
            userId = cmUserId
            account = cmAccount
            password = cmPassword
        } else if (isSupportCTAndCU(mobile)) {
            userId = ctcuUserId
            account = ctcuAccount
            password = ctcuPassword
        }
        if (StringUtils.isEmpty(userId) || StringUtils.isEmpty(account) || StringUtils.isEmpty(password)) {
            throw SimpleException(ResEnum.ParamErr.getCode(), "手机号【$mobile】不符合格式")
        }

        val bodyMap: MultiValueMap<String, String> = LinkedMultiValueMap()
        bodyMap["action"] = action
        bodyMap["userid"] = userId
        bodyMap["account"] = account
        bodyMap["password"] = password
        bodyMap["mobile"] = mobile
        bodyMap["content"] = content
        val request = HttpRequestVO()
        request.url = url
        request.body = bodyMap
        return baseHttpClient.restPostByForm(request)
    }

    fun replaceContent(content: String, str: Array<String>): String {
        var i = 1
        var contentStr = content
        while (contentStr.contains("{$i}")) {
            contentStr = contentStr.replace("{$i}", str[i - 1])
            i++
        }
        return contentStr
    }

    fun isSupportCMPhone(phone: String): Boolean {
        return isSupportPhone(phone, supportCM)
    }

    fun isSupportCTAndCU(phone: String): Boolean {
        return isSupportPhone(phone, supportCTAndCU)
    }

    fun isSupportPhone(phone: String, supportPhone: String): Boolean {
        logger.debug(phone)
        //去掉手机号后7位 剩下的看是否匹配 1595 15958023610
        val phoneS = phone.substring(0, phone.length - 7)
        val phoneSS = phoneS.substring(phoneS.length - 4, phoneS.length)
        logger.debug("前4位 $phoneSS ")
        return if (supportPhone.contains(phoneSS)) {
            logger.debug("手机号前3/4位 是否支持 true ")
            true
        } else {
            //去掉手机号后8位 剩下的看是否匹配 159
            val phoneSSS = phoneSS.substring(0, phoneSS.length - 1)
            logger.debug("前3位 $phoneSSS ")
            val s = supportPhone.contains(phoneSSS)
            logger.debug("手机号前3/4位 是否支持 $s ")
            s
        }
    }
}