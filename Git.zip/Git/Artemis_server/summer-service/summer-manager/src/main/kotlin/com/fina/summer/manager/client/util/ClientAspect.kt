package com.fina.summer.manager.client.util

import com.alibaba.fastjson.JSONObject
import com.fina.summer.core.handler.SimpleException
import org.aspectj.lang.ProceedingJoinPoint
import org.aspectj.lang.annotation.Around
import org.aspectj.lang.annotation.Aspect
import org.aspectj.lang.annotation.Pointcut
import org.slf4j.LoggerFactory
import org.springframework.stereotype.Component
import org.springframework.util.StringUtils

@Aspect
@Component
class ClientAspect {

    private fun process(joinPoint: ProceedingJoinPoint): Any? {
        var result: Any? = null
        try {
            result = joinPoint.proceed()
        } catch (e: Throwable) {
            LOGGER.error("around aspect [proceed] happened error ... {}", e)
            return null
        }

        return result
    }

    /**
     *
     * ConvertTo:TODO 数据转化注解切点
     *
     * @author chenjibin
     */
    @Pointcut("@annotation(com.fina.summer.manager.client.util.ConvertTo)")
    private fun ConvertTo() {
    }

    /**
     *
     * clientlog:TODO 平台接口请求日志切点
     *
     * @author chenjibin
     */
    @Pointcut("@annotation(com.fina.summer.manager.client.util.Log)")
    private fun log() {
    }

    /**
     * 轮询切点
     */
    @Pointcut("@annotation(com.fina.summer.manager.client.util.Polling)")
    private fun polling() {
    }

    /**
     *
     * around:TODO 将返回值从Map转换成实体类
     *
     * @author chenjibin
     * @param joinPoint
     * @param convertTo
     * @return
     */
    @Around("ConvertTo()&&@annotation(convertTo)")
    fun aroundConvertTo(joinPoint: ProceedingJoinPoint, convertTo: ConvertTo): Any? {
        var result: Any? = null
        try {
            result = joinPoint.proceed()
        } catch (e: Throwable) {
            if(e is SimpleException){
                LOGGER.warn("请求出现异常！---${e.getCode()}, ${e.getMsg()}" )
            }else{
                LOGGER.error("convertTo around aspect [proceed] happened error ... {}", e)
            }
            throw e
        }

        if (result == null) {
            return result
        }
        val clazz = convertTo.value
        val type = convertTo.type

        if (result is String) {
            result = ConvertUtils.convertOperate(type, result as String?, clazz.java)
        }
        return result
    }

    /**
     *
     * arountClientRequest:TODO 平台接口请求日志
     *
     * @author chenjibin
     * @param joinPoint
     * @return
     */
    @Around("log()")
    fun arountClientlog(joinPoint: ProceedingJoinPoint): Any? {
        LOGGER.info("================ 平台接口请求日志:start ==================")
        val args = joinPoint.args

        LOGGER.info("params json : [{}]", JSONObject.toJSONString(args))

        val arg0 = args[0]
        val requestVO = arg0 as HttpRequestVO

        val startTime = System.currentTimeMillis()
        val result = process(joinPoint)
        val endTime = System.currentTimeMillis()
        val time = endTime - startTime

        LOGGER.info("result: [{}], time: [{}]", result, time)

        LOGGER.info("================= 平台接口请求日志:end ==================")
        return result
    }

    @Around("polling()&&@annotation(poll)")
    fun aroundPolling(joinPoint: ProceedingJoinPoint, poll: Polling): Any? {
        var maxCount = poll.maxCount
        var index = 1
        if (maxCount > 0) {
            var result = process(joinPoint)
            maxCount--
            if (result is Boolean) {
                var resultFlag = result as Boolean
                if (resultFlag) {
                    return result
                }

                while (maxCount > 0 && !resultFlag) {
                    LOGGER.info("开始尝试第{}次重试...", index)
                    result = process(joinPoint)
                    resultFlag = result as Boolean
                    maxCount--
                    index++
                }
                return result
            }
            if (!StringUtils.isEmpty(result)) {
                return result
            }

            while (maxCount > 0 && StringUtils.isEmpty(result)) {
                LOGGER.info("开始尝试第{}次重试...", index)
                result = process(joinPoint)
                maxCount--
                index++
            }
            return result
        }

        return null
    }

    companion object {

        private val LOGGER = LoggerFactory.getLogger(ClientAspect::class.java)
    }
}
