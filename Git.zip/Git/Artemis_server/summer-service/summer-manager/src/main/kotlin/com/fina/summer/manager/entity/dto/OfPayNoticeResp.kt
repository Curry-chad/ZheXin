package com.fina.summer.manager.entity.dto

import java.io.Serializable

data class OfPayNoticeResp(

        var tradeId: String? = null,

        var productId: String? = null,

        var phoneNumber: String? = null,

        var money: Int? = null,

        var status: String? = null,

        var msg: String? = null,

        var tradeTime: String? = null

) : Serializable