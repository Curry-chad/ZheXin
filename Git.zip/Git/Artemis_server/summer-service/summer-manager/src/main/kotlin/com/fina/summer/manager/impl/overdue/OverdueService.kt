package com.fina.summer.manager.impl.overdue

import com.alibaba.excel.util.CollectionUtils
import com.fina.summer.core.utils.DateUtils
import com.fina.summer.persistent.ceres.entity.domain.BillOutTasksPO
import com.fina.summer.persistent.ceres.entity.vo.FirstOverdueSeqnoVo
import com.fina.summer.persistent.ceres.mapper.BillOutTasksMapper
import org.springframework.stereotype.Service
import java.util.*
import javax.transaction.Transactional

/**
 * @author zhengqiyang@zhexinit.com
 * @version V1.0
 * @since 1.0 2019/5/8 11:00
 * @description 请输入功能描述
 */
@Service
class OverdueService(
        private val billOutTasksMapper: BillOutTasksMapper
) {
    @Transactional
    fun calculateAndUpdateOverdueAmount(findFirstOverdueSeqnoList:List<FirstOverdueSeqnoVo>){

        //转成bisTaskId和期次的map
        val idAndSeqnoMap = findFirstOverdueSeqnoList!!.map { it.bisTaskId!! to it.seqNo!! }.toMap()
        //查询出前1000条符合条件的逾期数据
        val pageSize: Int = 1000
        /*var findOverdueDataByPage = billOutTasksMapper.findOverdueDataByPage(pageSize)
        while (!CollectionUtils.isEmpty(findOverdueDataByPage)) {
            //计算违约金和应还金额
            val updateOverDueBillOutTasks = calculateOverAmount(idAndSeqnoMap, findOverdueDataByPage!!)
            //批量更新到数据库
            billOutTasksMapper.batchUpdateOverdueAmount(updateOverDueBillOutTasks)
            //再查出下一1000条
            findOverdueDataByPage = billOutTasksMapper.findOverdueDataByPage(pageSize)
        }*/
    }

    //计算违约金和应还金额
    private fun calculateOverAmount(idAndSeqnoMap: Map<String, Int>, findOverdueDataByPage: List<BillOutTasksPO>): MutableList<BillOutTasksPO> {
        var updateOverDueBillOutTasks = mutableListOf<BillOutTasksPO>()
        //违约金比例
        var overduePercent = 0.001
        var penalty: Int
        var totalAmount: Int
        for( it in findOverdueDataByPage){

            var updateBillOutTask = BillOutTasksPO()
            //计算违约金收取截止日期
            val endDate = DateUtils.getMonthByMonths(it.planExecuteTime!!, 1)
            if (DateUtils.compare(DateUtils.getDateWithFormat(Date()), endDate) != -1) {
                //逾期天数
                var diffDay = DateUtils.differDateInDays(it.planExecuteTime!!,endDate , timeType = DateUtils.TimeType.DAY).toInt()
                //违约本金积数
                var overdueShouldAmount = (it.seqNo!! - (idAndSeqnoMap.get(it.bisTaskId)!!) + 1) * it.shouldAmount!!

                //违约金(为整数，因为单位：分)
                penalty = (diffDay * overduePercent * overdueShouldAmount).toInt()
                //应还总金额
                totalAmount = penalty + it.shouldAmount!!
                updateBillOutTask.penaltyStatus = 1
            } else {
                //违约本金积数
                var overdueShouldAmount = (it.seqNo!! - (idAndSeqnoMap.get(it.bisTaskId)!!) + 1) * it.shouldAmount!!
                //当天产生的违约金
                var todayOverdueAmount = 1 * overduePercent * overdueShouldAmount
                //违约金=之前已有的违约金+当天的违约金
                penalty = (todayOverdueAmount + it.penalty!!).toInt()
                //应还总金额
                totalAmount = penalty + it.shouldAmount!!

                updateBillOutTask.penaltyStatus = 0
            }
            updateBillOutTask.id = it.id
            updateBillOutTask.penalty = penalty
            updateBillOutTask.totalAmount = totalAmount
            updateOverDueBillOutTasks.add(updateBillOutTask)
        }
        return updateOverDueBillOutTasks
    }
}