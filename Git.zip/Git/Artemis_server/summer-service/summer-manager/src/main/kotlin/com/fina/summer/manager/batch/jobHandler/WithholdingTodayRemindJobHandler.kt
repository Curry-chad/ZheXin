package com.fina.summer.manager.batch.jobHandler

import com.fina.summer.manager.batch.SmsNotificationService
import com.xxl.job.core.biz.model.ReturnT
import com.xxl.job.core.handler.IJobHandler
import com.xxl.job.core.handler.annotation.JobHandler
import com.xxl.job.core.log.XxlJobLogger
import org.springframework.stereotype.Component

@JobHandler(value = "withholdingTodayRemindJobHandler") //注册到执行器工厂,value值对应的是调度中心新建任务的JobHandler属性的值
@Component //注册到Spring容器
class WithholdingTodayRemindJobHandler (
        private val smsNotificationService: SmsNotificationService
): IJobHandler(){
    @Throws
    override fun execute(p0: String?): ReturnT<String>? {
        try {
            XxlJobLogger.log("===Start代扣代缴批量当日提醒短信发送任务Start===")
            val res = smsNotificationService.getInfoAboutWithholding()
            val result = if (res.isSuccess) {
                XxlJobLogger.log("请求成功")
                ReturnT.SUCCESS
            } else {
                XxlJobLogger.log("接口请求失败")
                ReturnT(500, res.msg)
            }
            XxlJobLogger.log("===End代扣代缴批量当日提醒短信发送任务End===")
            return result
        } catch (e: Exception) {
            XxlJobLogger.log("请求异常,异常信息：", e)
            throw e
        }
    }
}