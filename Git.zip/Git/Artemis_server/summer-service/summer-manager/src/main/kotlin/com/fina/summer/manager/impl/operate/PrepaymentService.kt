package com.fina.summer.manager.impl.operate

import com.fina.summer.core.respone.ResEnum
import com.fina.summer.core.respone.WebResult
import com.fina.summer.persistent.ceres.entity.constant.OperateType
import com.fina.summer.persistent.ceres.entity.constant.PayType
import com.fina.summer.persistent.ceres.entity.constant.Progress
import com.fina.summer.persistent.ceres.entity.domain.BillInFlowsPO
import com.fina.summer.persistent.ceres.entity.domain.BillInTasksPO
import com.fina.summer.persistent.ceres.entity.vo.PrepaymentVO
import com.fina.summer.persistent.ceres.mapper.BillInMapper
import com.fina.summer.persistent.ceres.repo.BillInFlowsRepo
import com.fina.summer.persistent.ceres.repo.BillInTasksRepo
import org.apache.commons.lang3.StringUtils
import org.springframework.stereotype.Service
import org.springframework.util.CollectionUtils
import java.util.*

@Service
class PrepaymentService(
        private val billInTasksRepo: BillInTasksRepo,
        private val billInFlowsRepo: BillInFlowsRepo,
        private val billInMapper: BillInMapper

) {

    private var operator = "支付成功"


    fun getPrepaymentList(prepayment: PrepaymentVO): WebResult<PrepaymentVO> {
        val str = PrepaymentVO()
           try {
               //分页查询
               if (prepayment.pageNo != null || prepayment.pageSize != null) {
                   var pageNo: Int = (((prepayment.pageNo!!) - 1) * prepayment.pageSize!!)
                   prepayment.pageNo = pageNo
               }
               if(StringUtils.isBlank(prepayment.name) && StringUtils.isBlank(prepayment.account) && StringUtils.isBlank(prepayment.orderId)){
                    return ResEnum.success()
               }
               val list = mutableListOf<List<BillInTasksPO>>()
               val inTasks = billInMapper.findByBisTaskId(prepayment)
               if(CollectionUtils.isEmpty(inTasks)){
                   return ResEnum.fail("订单主表任务不存在或者订单分期任务不存在")
               }
               val total = billInMapper.findByCount(prepayment)
               list.add(inTasks)
               str.total = total
               str.data = list
           } catch (e: Exception) {
               return ResEnum.fail(code = "99",msg = "${prepayment.name}和${prepayment.account}对应bisRepayplanId或billInTaskId不存在")
           }

        return ResEnum.success(str)
    }

    fun prepayment(prepayment: PrepaymentVO) : WebResult<Void> {
            var now=Date()
            val tasks = prepayment.tasks
            if (tasks!=null && !tasks.isEmpty()){
                tasks.forEachIndexed { index, taskId ->
                    val billInTask = this.billInTasksRepo.findById(taskId).get()
                    billInTask.status = Progress.Success
                    billInTask.finishTime=now
                    billInTask.lastExecuteTime=now
                    billInTask.message=operator
                    billInTask.totalAmount =prepayment.amount!!.get(index)
                    billInTask.modifyBy=prepayment.modifyBy
                    billInTask.modifyTime=now
                    billInTask.updatedTime=now
                    this.billInTasksRepo.save(billInTask)
                    this.billInFlowsRepo.save(BillInFlowsPO(
                            taskId = billInTask.id,
                            requestNo = billInTask.requestNo,
                            thirdOrderId = billInTask.thirdOrderId,
                            tradeId = billInTask.tradeId,
                            message = operator,
                            bisTaskId = billInTask.bisTaskId,
                            payBank = billInTask.payBank,
                            payType = PayType.Debit,
                            payer = billInTask.payer,
                            payerIdno = billInTask.payerIdno,
                            status = billInTask.status,
                            payAccount = billInTask.payAccount,
                            penalty = billInTask.penalty,
                            createdTime = now,
                            updatedTime = now,
                            orderId = billInTask.orderId,
                            debitChannel = billInTask.debitChannel,
                            finishTime = billInTask.finishTime,
                            fundChannel = billInTask.fundChannel,
                            planExecuteTime = billInTask.planExecuteTime,
                            nextExecuteTime = billInTask.nextExecuteTime,
                            lastExecuteTime = billInTask.lastExecuteTime,
                            overdueDays = billInTask.overdueDays,
                            seqNo = billInTask.seqNo,
                            shouldAmount = billInTask.shouldAmount,
                            checkStatus = billInTask.checkStatus,
                            amount = billInTask.totalAmount,
                            createBy = billInTask.createBy,
                            modifyBy =billInTask.modifyBy,
                            modifyTime = billInTask.modifyTime,
                            loanNo = billInTask.loanNo,
                            loanReqNo = billInTask.loanReqNo,
                            contNo = billInTask.contNo,
                            contReqNo = billInTask.contReqNo,
                            taskType = billInTask.type,
                            audit = billInTask.audit,
                            operateType = OperateType.Prepay
                    ))
                }
            }
        return ResEnum.success()
    }

}




