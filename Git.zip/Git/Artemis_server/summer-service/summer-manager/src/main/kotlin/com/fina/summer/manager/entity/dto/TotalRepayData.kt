package com.fina.summer.manager.entity.dto

import com.fina.summer.persistent.ceres.entity.constant.BillType
import com.fina.summer.persistent.ceres.entity.constant.DeductChannel
import com.fina.summer.persistent.ceres.entity.constant.FundChannel
import com.fina.summer.persistent.ceres.entity.constant.Progress
import java.io.Serializable
import javax.persistence.EnumType
import javax.persistence.Enumerated

data class TotalRepayData (

        var id: String? = null,

        var tradeId: String? = null,

        var orderId: String? = null,

        @Enumerated(EnumType.STRING)
        var fundChannel: FundChannel? = null,

        var debitChannel: DeductChannel? = null,

        var merId: String? = null,

        var repayDate: Long? = null,

        var periodTimes: Int? = null,

        var leftPeriod: Int? = null,

        var payerIdno: String? = null,

        var payer: String? = null,

        var payBank: String? = null,

        var payAccount: String? = null,

        var shouldAmount: Int? = null,

        var leftAmount: Int? = null,

        var totalPenalty: Int? = null,

        var orderTradeTime: Long? = null,

        var lastRepayStatus: Progress? = null,

        var status: Progress? = null,

        var createBy: String? = null,

        var createTime: Long? = null,

        var modifyBy: String? = null,

        var modifyTime: Long? = null,

        var loanReqNo: String? = null,

        var loanNo: String? = null,

        var contReqNo: String? = null,

        var contNo: String? = null,

        var type: BillType? = null,

        var signAccountId: String? = null
): Serializable