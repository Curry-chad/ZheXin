package com.fina.summer.manager.entity.bo

import io.swagger.annotations.ApiModelProperty
import java.io.Serializable

data class FileImportBO (

        var fileSuccessCount: Int = 0,

        var fileFailCount: Int = 0,

        @ApiModelProperty("部分数据为null")
        var orderIdFail: List<String>? = null,

        @ApiModelProperty("金额错误订单")
        var amountFail: List<String>? = null,

        @ApiModelProperty("还款期数不对订单")
        var repaymentNumFail: List<String>? = null,

        @ApiModelProperty("订单不存在")
        var orderNullFail: List<String>? = null,

        @ApiModelProperty("订单已还款")
        var orderSuccess: List<String>? = null,

        @ApiModelProperty("催收任务已存在")
        var collectionExists: List<String>? = null

): Serializable