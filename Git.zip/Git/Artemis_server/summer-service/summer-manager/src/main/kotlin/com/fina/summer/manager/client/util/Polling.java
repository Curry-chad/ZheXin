package com.fina.summer.manager.client.util;

import org.springframework.web.bind.annotation.Mapping;

import java.lang.annotation.*;

@Target(ElementType.METHOD)  
@Retention(RetentionPolicy.RUNTIME)  
@Documented  
@Mapping
public @interface Polling {

	int maxCount() default 1;
	
}
