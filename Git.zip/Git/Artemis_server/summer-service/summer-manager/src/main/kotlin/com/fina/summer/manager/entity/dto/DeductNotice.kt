package com.fina.summer.manager.entity.dto

import com.fina.summer.persistent.ceres.entity.constant.Progress
import java.io.Serializable
import java.util.*

data class DeductNotice(

        var result: Progress? = null,

        var message: String? = null,

        var tradeTime: Date? = null,

        var amount: Int? = null,

        var thirdOrderId: String? = null,

        var requestNo: String? = null

) : Serializable