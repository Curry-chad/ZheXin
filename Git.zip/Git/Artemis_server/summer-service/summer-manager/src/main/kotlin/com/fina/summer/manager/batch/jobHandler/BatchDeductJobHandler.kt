package com.fina.summer.manager.batch.jobHandler

import com.fina.summer.manager.batch.BatchDeductService
import com.xxl.job.core.biz.model.ReturnT
import com.xxl.job.core.handler.IJobHandler
import com.xxl.job.core.handler.annotation.JobHandler
import com.xxl.job.core.log.XxlJobLogger
import org.springframework.stereotype.Component

/**
 * @author zhengqiyang@zhexinit.com
 * @version V1.0
 * @since 1.0 2019/5/22 15:47
 * @description 批量代扣(不兜底)--xxl定时任务
 */
@JobHandler(value = "batchDeductJobHandler")
@Component
class BatchDeductJobHandler(
        private val batchDeductService: BatchDeductService
) : IJobHandler() {
    @Throws
    override fun execute(p0: String?): ReturnT<String> {
        XxlJobLogger.log("-------开始执行批量代扣不兜底定时任务：------------")
        batchDeductService.batchDeduct()
        XxlJobLogger.log("----结束执行批量代扣不兜底定时任务--------")
        val result = ReturnT<String>()
        result.msg = "执行完成"
        return result
    }
}