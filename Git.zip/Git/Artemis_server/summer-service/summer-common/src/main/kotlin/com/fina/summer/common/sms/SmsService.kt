package com.fina.summer.common.sms

import com.fina.summer.common.http.JsonRequest
import com.fina.summer.core.enum.SmsType
import com.fina.summer.core.handler.SimpleException
import org.slf4j.LoggerFactory
import org.springframework.beans.factory.annotation.Value
import org.springframework.data.redis.core.StringRedisTemplate
import org.springframework.stereotype.Service
import java.util.*
import java.util.concurrent.TimeUnit

@Service
class SmsService(
        private val stringRedisTemplate: StringRedisTemplate
) {

    @Value("\${sms.url}")
    lateinit var url: String

    private val time = 15L

    private val serverDescp = "fina_h_share"

    val orderMobile = "ORDER_MOBILE"

    private val logger = LoggerFactory.getLogger(SmsService::class.java)

    private val map = mapOf("15056587712" to "150712", "18868442573" to "123456")


    fun checkCode(mobile: String, code: String, type: SmsType): Boolean {
        return map[mobile] == code || stringRedisTemplate.opsForValue()["$type-$mobile"] == code
    }

    fun send(smsType: SmsType, mobile: String) {

        logger.info("url=================={}", url)
        val verifyCode = String.format("%06d", Random().nextInt(999999))
        stringRedisTemplate.opsForValue().set("$smsType-$mobile", verifyCode, time, TimeUnit.MINUTES)

        val map = send(mobile, "$verifyCode,$time", smsType.templateId)

        if (map["code"] != "00000") {
            throw SimpleException(map["codeMsg"].toString())
        }
    }


    fun sendNotice(smsType: SmsType, mobile: String) {
        val map = send(mobile, "1", smsType.templateId)
        if (map["code"] != "00000") {
            throw SimpleException(map["codeMsg"].toString())
        }
    }


    fun send(phoneNumber: String, msgInfo: String, smsTemplateId: String): Map<String, Any> {
        val map = mapOf("phoneNumber" to phoneNumber, "msgInfo" to msgInfo, "smsTemplateId" to smsTemplateId, "serverDescp" to serverDescp)
        return JsonRequest.jsonPostForMap(url, map)
    }

}