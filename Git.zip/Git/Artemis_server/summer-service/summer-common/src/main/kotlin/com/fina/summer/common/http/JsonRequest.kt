/*
 * Copyright (C) 2016 Square, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
@file:Suppress("UNCHECKED_CAST")

package com.fina.summer.common.http

import com.fina.summer.core.handler.SimpleException
import com.fina.summer.core.utils.Id
import com.fina.summer.core.utils.IdGenerator
import com.fina.summer.core.utils.SpringContextUtils
import com.fina.summer.persistent.entity.summer.HttpReqLog
import com.fina.summer.persistent.repo.summer.HttpReqLogRepo
import com.google.gson.*
import com.google.gson.reflect.TypeToken
import okhttp3.*
import okio.Buffer
import org.slf4j.LoggerFactory
import org.springframework.web.bind.annotation.RequestMethod
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import java.io.IOException
import java.lang.reflect.Type
import java.security.KeyManagementException
import java.security.NoSuchAlgorithmException
import java.security.SecureRandom
import java.security.cert.CertificateException
import java.security.cert.X509Certificate
import java.util.*
import java.util.concurrent.TimeUnit
import javax.net.ssl.SSLContext
import javax.net.ssl.TrustManager
import javax.net.ssl.X509TrustManager


/**
 * Both the Gson converter and the Simple Framework converter accept all types. Because of this,
 * you cannot use both in a single service by default. In order to work around this, we can create
 * an @Json and @Xml annotation to declare which serialization format each endpoint should use and
 * then write our own Converter.Factory which delegates to either the Gson or Simple Framework
 * converter.
 */
object JsonRequest {

    private const val HTTP_REQUEST_LOG = "HTTP_REQUEST_LOG_SET"

    private val LOGGER = LoggerFactory.getLogger(JsonRequest::class.java)

    private val gson = GsonBuilder().setDateFormat(1).create()




    private class DateTimeSerializer : JsonSerializer<Date> {
        override fun serialize(src: Date, typeOfSrc: Type, context: JsonSerializationContext): JsonElement {
            return JsonPrimitive(src.time.toString())
        }
    }



    private val retrofit = Retrofit.Builder()
            .addConverterFactory(GsonConverterFactory.create())
            .baseUrl("http://www.baidu.com")
            .build()

    @Throws(IOException::class)
    fun <T> getResponseBean(url: String, type: Type): T? {

        LOGGER.debug("请求url:{}", url)
        val build = Request.Builder()
                .url(url)
                .build()
        val response = OkHttpClient().newCall(build)
                .execute()
        val resp = Objects.requireNonNull<ResponseBody>(response.body()).string()
        if (type == String::class.java) {
            return resp as T
        }
        val gson = GsonBuilder()
                .setDateFormat("yyyy-MM-dd HH:mm:ss").create()
        return gson.fromJson<T>(resp, type)
    }


    fun jsonPostForString(url: String, body: Any): String {
        return jsonPost(url, body, String::class.java)
    }

    @Suppress("UNCHECKED_CAST")
    fun <T> jsonPost(url: String, body: Any, type: Type,gson:Gson=Gson()): T {

        val s = gson.toJson(body)
        val requestBody = RequestBody.create(MediaType.parse("application/json"), s)

        val resp = post(url, requestBody)
        return if (type == String::class.java) {
            resp as T
        } else Gson().fromJson<T>(resp, type)
    }

    @Throws(IOException::class)
    private fun <T> formPost(url: String, formBody: FormBody, type: Type): T {
        val resp = post(url, formBody)
        return if (type == String::class.java) {
            resp as T
        } else Gson().fromJson<T>(resp, type)
    }

    fun <T> formGet(url: String,type: Type): T{
        val resp = get(url)
        return if (type == String::class.java) {
            resp as T
        } else Gson().fromJson<T>(resp, type)
    }

    fun get(url: String): String{
        val id = IdGenerator.nextId(Id.Request)
        LOGGER.info("HTTP请求流水号：{}", id)
        val log = HttpReqLog(id, url = url,
                method = RequestMethod.GET)
        try {
            val request = Request.Builder()
                    .url(url)
                    .get()
                    .build()
            val client = OkHttpClient.Builder().readTimeout(100,TimeUnit.SECONDS).build()
            val response = client.newCall(request).execute()
            log.httpCode = response.code()
            log.cost = response.receivedResponseAtMillis().minus(response.sentRequestAtMillis())
            if (log.httpCode == 200) {
                val res = response.body()!!.string()
                log.responseBody = res
                return res
            } else {
                log.responseBody = response.body()?.string()
                LOGGER.warn("接口请求失败:{}", log)
                throw SimpleException("接口请求失败！")
            }
        } catch (e: SimpleException) {
            throw e
        } catch (e: Exception) {
            log.httpCode = -1
            log.responseBody = e.cause.toString()
            throw e
        } finally {
            Thread {
                try {
                    val repo = SpringContextUtils.getBeanByClass(HttpReqLogRepo::class.java)
                    repo.save(log)
                } catch (e: Exception) {
                    LOGGER.warn("报错请求记录失败:{}", log)
                    LOGGER.warn("报错请求记录失败：", e)
                }
            }.start()
        }
    }


    private fun post(url: String, requestBody: RequestBody): String {
        val id = IdGenerator.nextId(Id.Request)
        LOGGER.info("HTTP请求流水号：{}", id)
        val log = HttpReqLog(id, url = url, requestBody = parseToString(requestBody),
                method = RequestMethod.POST,
                contentType = requestBody.contentType().toString())
        try {
            val request = Request.Builder()
                    .url(url)
                    .post(requestBody)
                    .build()
            val client = OkHttpClient.Builder().readTimeout(100,TimeUnit.SECONDS).build()
            val response = client.newCall(request).execute()
            log.httpCode = response.code()
            log.cost = response.receivedResponseAtMillis().minus(response.sentRequestAtMillis())
            if (log.httpCode == 200) {
                val res = response.body()!!.string()
                log.responseBody = res
                return res
            } else {
                log.responseBody = response.body()?.string()
                LOGGER.warn("接口请求失败:{}", log)
                throw SimpleException("接口请求失败！")
            }
        } catch (e: SimpleException) {
            throw e
        } catch (e: Exception) {
            log.httpCode = -1
            log.responseBody = e.cause.toString()
            throw e
        } finally {
            Thread {
                try {
                    val repo = SpringContextUtils.getBeanByClass(HttpReqLogRepo::class.java)
                    repo.save(log)
                } catch (e: Exception) {
                    LOGGER.warn("报错请求记录失败:{}", log)
                    LOGGER.warn("报错请求记录失败：", e)
                }
            }.start()
        }
    }


    private fun parseToString(requestBody: RequestBody): String? {
        val buffer = Buffer()
        requestBody.writeTo(buffer)
        return buffer.readUtf8()

    }


    @Throws(IOException::class)
    fun <T> formPost(url: String, params: Map<String, String>, type: Type): T {

        val builder = FormBody.Builder()
        params.forEach { name, value -> builder.add(name, value) }
        LOGGER.debug("请求url:{},keys:{}", url, params)

        return formPost(url, builder.build(), type)
    }

    @Throws(IOException::class)
    fun formPostForStr(url: String, params: Map<String, String>): String? {
        return formPost<String>(url, params, String::class.java)
    }


    private val trustAllCerts = arrayOf<TrustManager>(object : X509TrustManager {
        override fun getAcceptedIssuers(): Array<X509Certificate> {
            return arrayOf()
        }

        @Throws(CertificateException::class)
        override fun checkClientTrusted(chain: Array<java.security.cert.X509Certificate>, authType: String) {
        }

        @Throws(CertificateException::class)
        override fun checkServerTrusted(chain: Array<java.security.cert.X509Certificate>, authType: String) {
        }
    })


    private var trustAllSslContext: SSLContext

    init {
        try {
            trustAllSslContext = SSLContext.getInstance("SSL");
            trustAllSslContext.init(null, trustAllCerts, SecureRandom());
        } catch (e: NoSuchAlgorithmException) {
            throw  RuntimeException(e)
        } catch (e: KeyManagementException) {
            throw  RuntimeException(e)
        }
    }

    private val trustAllSslSocketFactory = trustAllSslContext.socketFactory

    private fun trustAllSslClient(client: OkHttpClient): OkHttpClient {
        val builder = client.newBuilder();
        builder.sslSocketFactory(trustAllSslSocketFactory, trustAllCerts[0] as X509TrustManager);
        builder.hostnameVerifier { _, _ -> true; };
        return builder.build();
    }

    fun jsonPostForMap(url: String, map: Map<String, String>): Map<String, Any> {
        return jsonPost(url, map, object : TypeToken<Map<String, Any>>() {}.type)
    }


}
