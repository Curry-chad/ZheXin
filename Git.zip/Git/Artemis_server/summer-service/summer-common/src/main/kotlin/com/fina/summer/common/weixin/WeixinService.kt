package com.fina.summer.common.weixin

import com.fina.summer.common.http.JsonRequest
import com.fina.summer.core.utils.SHA1Coder
import net.sf.json.JSONObject
import org.springframework.data.redis.core.StringRedisTemplate
import org.springframework.stereotype.Service
import java.util.*
import java.util.concurrent.TimeUnit

@Service
class WeixinService(
        private val redisTemplate: StringRedisTemplate
) {

    private val appId = ""
    private val appSecret = ""

    private val jsApiUrl = "https://api.weixin.qq.com/cgi-bin/ticket/getticket"

    fun getAccessToken(): String{
        return ""
    }

    fun getJsApiTicket(accessToken: String): String{

        val redisTicket = redisTemplate.opsForValue()["ticket"]
        if(redisTicket != null){
            return redisTicket
        }

        val result: JSONObject = JsonRequest.formGet("https://api.weixin.qq.com/cgi-bin/ticket/getticket?access_token=$accessToken&type=jsapi",JSONObject::class.java)
        if(result.get("errcode") == 0){
            //生成成功
            val ticket = result.getString("ticket")
            val expiresIn = result.getLong("expires_in")
            redisTemplate.opsForValue().set("ticket",ticket,expiresIn,TimeUnit.SECONDS)
            return ticket
        }
        return ""
    }

    fun getJsConfig(url: String,debug: Boolean): String{
        val nonceStr = ""   //生成签名的随机串
        val timestamp = Calendar.getInstance().timeInMillis  //生成签名的时间戳

        val accessToken = getAccessToken()
        val jsApiTicket = getJsApiTicket(accessToken)

        val jsApiList = Array(1){"onMenuShareTimeline"}
        val signature = getSign(nonceStr,jsApiTicket,timestamp,url)

        val config = "wx.config({"+
                "debug: "+debug+","+
                "appId: '"+appId+"',"+"timestamp: "+timestamp+","+
                "nonceStr: '"+nonceStr+"',"+"signature: '"+signature+"',"+
                "jsApiList: ["+jsApiList+"]"+
                "});"

        return config
    }

    fun getSign(noncestr: String,jsapi_ticket : String, timestamp: Long,url: String): String? {

        val resource = "jsapi_ticket=$jsapi_ticket&noncestr=$noncestr&timestamp=$timestamp&url=$url"
        return SHA1Coder.encode(resource)
    }

}

//fun main(args: Array<String>){
//    val jsonObject: JSONObject = JsonRequest.formGet("https://api.weixin.qq.com/cgi-bin/ticket/getticket?access_token=ACCESS_TOKEN&type=jsapi",JSONObject::class.java)
//
//    println(jsonObject)
//}