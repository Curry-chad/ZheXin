package com.fina.summer.common.weixin

import me.chanjar.weixin.mp.api.WxMpConfigStorage
import me.chanjar.weixin.mp.api.impl.WxMpServiceImpl
import org.springframework.stereotype.Component
import org.springframework.stereotype.Service
import javax.annotation.Resource

@Component
class WxService: WxMpServiceImpl(){

    @Resource(name = "wxShareConfig")
    override fun setWxMpConfigStorage(wxConfigProvider: WxMpConfigStorage?) {
        super.setWxMpConfigStorage(wxConfigProvider)
    }
}