package com.fina.summer.common.config

import me.chanjar.weixin.mp.api.WxMpConfigStorage
import me.chanjar.weixin.mp.api.WxMpInRedisConfigStorage
import org.apache.commons.pool2.impl.GenericObjectPoolConfig
import org.springframework.boot.autoconfigure.data.redis.RedisProperties
import org.springframework.boot.context.properties.ConfigurationProperties
import org.springframework.context.annotation.Bean
import org.springframework.context.annotation.Configuration
import redis.clients.jedis.JedisPool

@Configuration
open class WxConfigStorage {

    @Bean
    open fun jedisPool(redisProperties: RedisProperties): JedisPool {
        return JedisPool(GenericObjectPoolConfig(), redisProperties.host, redisProperties.port,
                redisProperties.timeout.seconds.toInt(), redisProperties.password)
    }

    @Bean(name = ["wxShareConfig"])
    @ConfigurationProperties(prefix = "wx.mp.share")
    open fun getConfigStorage(jedisPool: JedisPool): WxMpConfigStorage {
        return WxMpInRedisConfigStorage(jedisPool)
    }

}
