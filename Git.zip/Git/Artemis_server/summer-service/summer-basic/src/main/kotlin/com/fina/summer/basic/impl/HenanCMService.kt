package com.fina.summer.basic.impl

import com.alibaba.fastjson.JSONObject
import com.fina.summer.basic.client.HenanCMClient
import com.fina.summer.basic.client.constant.CanSel
import com.fina.summer.basic.client.constant.CreditReturnCode
import com.fina.summer.basic.client.constant.Flag
import com.fina.summer.basic.client.constant.HenanRespCode
import com.fina.summer.basic.client.entity.*
import com.fina.summer.basic.util.CamlUtils
import com.fina.summer.core.handler.SimpleException
import com.fina.summer.core.respone.ResEnum
import com.google.gson.Gson
import org.slf4j.Logger
import org.slf4j.LoggerFactory
import org.springframework.stereotype.Service
import java.lang.reflect.Type
import java.text.SimpleDateFormat
import java.util.*

@Service
class HenanCMService(
        private val henanCMClient: HenanCMClient
) {

    private val logger: Logger = LoggerFactory.getLogger(HenanCMService::class.java)

    fun prodAccept(prodAcceptReq: ProdAcceptReq): CloudResp<ProdAcceptResp> {
        val resp = henanCMClient.prodAccept(prodAcceptReq.mobile!!, prodAcceptReq.offerId!!)!!
        if (resp.respCode != HenanRespCode.Success.code) {
            return CloudResp(code = resp.respCode!!, msg = resp.respDesc)
        }
        val result = resp.result!!
        val json = henanCMClient.decode(result)
        val jsonO = JSONObject.parseObject(json)
        val jsonArray = jsonO.getJSONArray("SO_MEMBER_DEAL")
        jsonArray.forEach {
            val o = it as JSONObject
            return CloudResp.success(ProdAcceptResp(
                    offerId = o.getString("OFFER_ID"),
                    canSel = CanSel.codeOf(o.getString("CAN_SEL")),
                    errMsg = o.getString("ERR_MSG"),
                    selFee = o.getString("SEL_FEE"),
                    offerCode = o.getString("OFFER_CODE")
            ))
        }
        throw SimpleException(ResEnum.Fail.getCode(), "接口返回信息异常")
    }

    fun crepchase(crepchaseReq: CrepchaseReq): CloudResp<CrepchaseBusiResp> {
        val resp = henanCMClient.crepchase(crepchaseReq.mobile!!, crepchaseReq.prodPrcId!!, crepchaseReq.orderType!!)!!
        if (resp.respCode != HenanRespCode.Success.code) {
            return CloudResp(code = resp.respCode!!, msg = resp.respDesc)
        }
        val result = resp.result!!
        val json = henanCMClient.decode(result)
        val jsonO = JSONObject.parseObject(json)
        val jsonArray = jsonO.getJSONArray("SO_MEMBER_DEAL")
        jsonArray.forEach {
            val o = it as JSONObject
            /*return CloudResp.success(CrepchaseResp(
                    flag = o.getString("FLAG"),
                    ordCode = o.getString("ORD_CODE"),
                    message = o.getString("MESSAGE")
            ))*/
            return CloudResp.success(CrepchaseBusiResp(
                    flag = Flag.valueOf(o.getString("FLAG")),
                    ordCode = o.getString("ORD_CODE"),
                    message = o.getString("MESSAGE"),
                    ordDateTime = Date(),
                    mobile = crepchaseReq.mobile
            ))
        }
        throw SimpleException(ResEnum.Fail.getCode(), "接口返回信息异常")
    }

    fun crepchaseOrder(crepchaseOrderReq: CrepchaseOrderReq): CloudResp<CrepchaseBusiResp> {
        val resp = henanCMClient.crepchaseOrder(crepchaseOrderReq.mobile!!, crepchaseOrderReq.prodPrcId!!)!!
        if (resp.respCode != HenanRespCode.Success.code) {
            return CloudResp(code = resp.respCode!!, msg = resp.respDesc)
        }
        val result = resp.result!!
        val crepchase = getCrepchaseResult(result)
        return CloudResp.success(crepchase)
    }

    fun crepchaseRollBack(crepchaseRollBackReq: CrepchaseRollBackReq): CloudResp<CrepchaseBusiResp> {
        val resp = henanCMClient.crepchaseRollBack(crepchaseRollBackReq.mobile!!, crepchaseRollBackReq.prodPrcId!!, crepchaseRollBackReq.ordCode!!)!!
        if (resp.respCode != HenanRespCode.Success.code) {
            return CloudResp(code = resp.respCode!!, msg = resp.respDesc)
        }
        val result = resp.result!!
        val crepchase = getCrepchaseResult(result)
        return CloudResp.success(crepchase)
    }

    fun credit(creditReq: CreditReq): CloudResp<CreditResp> {
        val resp = henanCMClient.credit(creditReq.mobile!!, creditReq.prodPrcId!!, creditReq.ordFee!!, creditReq.ordState!!, creditReq.idCard!!)!!
        if (resp.respCode != HenanRespCode.Success.code) {
            return CloudResp(code = resp.respCode!!, msg = resp.respDesc)
        }
        val result = resp.result!!
        val json = henanCMClient.decode(result)
        val jsonO = JSONObject.parseObject(json)
        val jsonArray = jsonO.getJSONArray("SO_MEMBER_DEAL")

        jsonArray.forEach {
            val o = it as JSONObject
            return CloudResp.success(CreditResp(
                    returnCode = CreditReturnCode.codeOf(o.getString("RETURN_CODE")),
                    returnMessage = o.getString("RETURN_MESSAGE")
            ))
        }
        throw SimpleException(ResEnum.Fail.getCode(), "接口返回信息异常")
    }

    private fun getCrepchaseResult(result: String): CrepchaseBusiResp {
        val json = henanCMClient.decode(result)
        val jsonO = JSONObject.parseObject(json)
        val jsonArray = jsonO.getJSONArray("SO_MEMBER_DEAL")

        var crepchase: CrepchaseBusiResp? = null
        val sf = SimpleDateFormat("yyyy-MM-dd HH:mm:ss")
        var date: Date? = null
        jsonArray.forEach {
            val o = it as JSONObject
            val flag = o.getString("FLAG")
            if (flag != null && flag == Flag.N.name) {
                val f = Flag.valueOf(flag)
                val message = o.getString("MESSAGE")
                return CrepchaseBusiResp(flag = f, message = message)
            }

            val ordDateTime = o.getString("OrdDateTime")!!
            val ordDate = sf.parse(ordDateTime)!!
            if (date == null || ordDate.after(date)) {
                val mobile = o.getString("SvcNum")
                val prodPrcId = o.getString("ProdPrcId")
                val ordCode = o.getString("OrdCode")

                crepchase = CrepchaseBusiResp(mobile = mobile, prodPrcId = prodPrcId, ordCode = ordCode, ordDateTime = ordDate, flag = Flag.Y)
                date = ordDate
            }
        }
        if (crepchase == null) {
            throw SimpleException(ResEnum.Fail.getCode(), "[ERROR]: 结果集大小为0")
        }
        return crepchase!!
    }

    private fun <T> convert(result: String,type: Type): T {
        var json = henanCMClient.decode(result)
        logger.debug("origin result json: $json")
        json = CamlUtils.camel(StringBuffer(json.toLowerCase())).toString()
        logger.debug("final result json: $json")
        return Gson().fromJson<T>(json, type)
    }
}