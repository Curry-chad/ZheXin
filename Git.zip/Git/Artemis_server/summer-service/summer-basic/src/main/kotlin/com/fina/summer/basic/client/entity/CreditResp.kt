package com.fina.summer.basic.client.entity

import com.fina.summer.basic.client.constant.CreditReturnCode
import java.io.Serializable

data class CreditResp(

        /**
         * 业务返回代码
         */
        var returnCode: CreditReturnCode? = null,

        /**
         * 业务返回信息
         */
        var returnMessage: String? = null

): Serializable