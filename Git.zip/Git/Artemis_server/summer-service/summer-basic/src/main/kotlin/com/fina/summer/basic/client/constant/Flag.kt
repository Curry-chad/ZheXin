package com.fina.summer.basic.client.constant

enum class Flag{
    Y,
    N
}