package com.fina.summer.basic.client.entity

import com.fina.summer.basic.client.constant.OrderType
import java.io.Serializable

data class CrepchaseReq(

        var mobile: String? = null,

        var prodPrcId: String? = null,

        var orderType: OrderType? = null

): Serializable