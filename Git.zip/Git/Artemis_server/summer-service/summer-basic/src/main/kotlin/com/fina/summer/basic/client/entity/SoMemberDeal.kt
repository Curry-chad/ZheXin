package com.fina.summer.basic.client.entity

import java.io.Serializable

data class SoMemberDeal<T>(

        // 结果集
        var soMemberDeal: List<T>? = null

): Serializable