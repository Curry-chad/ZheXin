package com.fina.summer.basic.client.constant

enum class CreditReturnCode(var code: String) {
    Success("0000"),
    Fail("9999"),

    Error("-1")
    ;

    companion object {
        val values = CreditReturnCode.values()

        fun codeOf(code: String): CreditReturnCode {
            values.forEach {
                if (it.code == code) {
                    return it
                }
            }
            return Error
        }
    }
}