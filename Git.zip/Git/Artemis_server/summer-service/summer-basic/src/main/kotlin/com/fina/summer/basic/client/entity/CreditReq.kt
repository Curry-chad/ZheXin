package com.fina.summer.basic.client.entity

import java.io.Serializable

data class CreditReq(
        /**
         * 手机号
         */
        var mobile: String? = null,

        /**
         * 产品代码
         */
        var prodPrcId: String? = null,

        /**
         * 订单费用(单位: 分)
         */
        var ordFee: String? = null,

        /**
         * 订单状态 0：失败, 1：成功

         */
        var ordState: String? = null,

        /**
         * 用户身份证号码
         */
        var idCard: String? = null
): Serializable