package com.fina.summer.basic.client.constant

enum class CanSel(var code: String){
    Y("1"),
    N("2"),
    ;
    companion object {
        val values = CanSel.values()

        fun codeOf(code: String): CanSel? {
            values.forEach {
                if (it.code == code) {
                    return it
                }
            }
            return null
        }
    }
}