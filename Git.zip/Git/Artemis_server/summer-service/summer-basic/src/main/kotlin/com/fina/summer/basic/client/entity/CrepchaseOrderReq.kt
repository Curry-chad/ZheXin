package com.fina.summer.basic.client.entity

import java.io.Serializable

data class CrepchaseOrderReq(

        /**
         * 手机号
         */
        var mobile: String? = null,

        /**
         * 产品代码
         */
        var prodPrcId: String? = null

): Serializable