package com.fina.summer.basic.client.entity

import java.io.Serializable

data class HenanResp(
        var respCode: String? = null,

        var respDesc: String? = null,

        var result: String? = null
): Serializable