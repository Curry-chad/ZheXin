package com.fina.summer.basic.client.entity

import com.fina.summer.basic.client.constant.CanSel
import java.io.Serializable

data class ProdAcceptResp(

        /**
         * 营销活动id
         */
        var offerId: String? = null,

        /**
         * 是否能够办理
         */
        var canSel: CanSel? = null,

        /**
         * 不能办理的原因
         */
        var errMsg: String? = null,

        /**
         * 活动费用
         */
        var selFee: String? = null,

        /**
         * 活动code
         */
        var offerCode: String? = null

): Serializable