package com.fina.summer.basic.client

import com.alibaba.fastjson.JSONObject
import com.asiainfo.openplatform.common.util.SecurityUtils
import com.asiainfo.openplatform.common.util.SignUtil
import com.fina.summer.basic.client.constant.OrderType
import com.fina.summer.basic.client.entity.AccessToken
import com.fina.summer.basic.client.entity.HenanResp
import com.fina.summer.common.http.JsonRequest
import com.google.gson.reflect.TypeToken
import org.slf4j.Logger
import org.slf4j.LoggerFactory
import org.springframework.beans.factory.annotation.Value
import org.springframework.data.redis.core.StringRedisTemplate
import org.springframework.stereotype.Component
import java.text.SimpleDateFormat
import java.util.*
import java.util.concurrent.TimeUnit

@Component
class HenanCMClient(
        private val stringRedisTemplate: StringRedisTemplate
) {

    @Value("\${cmcc.henan.appId}")
    private val appId: String? = null

    @Value("\${cmcc.henan.appKey}")
    private val appKey: String? = null

    @Value("\${cmcc.henan.grantType}")
    private val grantType: String? = null

    @Value("\${cmcc.henan.opcode}")
    private val opcode: String? = null // 工号X519092

    @Value("\${cmcc.henan.url}")
    private val url: String? = null

    private val time = 60L

    private val ordSource = "02"

    private val phone = "15837135522"

    private val offerId = "600000595559"

    private val productId = "600000595559"

    private val logger: Logger = LoggerFactory.getLogger(HenanCMClient::class.java)


    /**
     * 获取accessToken的接口（据说有24小时的有效期）
     */
    fun getToken(): String {
        var token = stringRedisTemplate.opsForValue()["cmcc_henan_access_token"]
        if (token == null) {
            val url = "http://211.138.17.10:20200/aopoauth/oauth/token?app_id=$appId&app_key=$appKey&grant_type=$grantType"
            val type = object : TypeToken<AccessToken>() {}.type
            val result = JsonRequest.formGet<AccessToken>(url, type)
            token = result.access_token!!
            stringRedisTemplate.opsForValue().set("cmcc_henan_access_token", token, time, TimeUnit.MINUTES)
        }
        return token
    }

    /**
     * 营销活动预校验接口
     */
    fun prodAccept(mobile: String, offerId: String): HenanResp? {
        return oppt("G3_PROD_ACCEPT_CHECK_F200604", JSONObject.toJSONString(mapOf(
                "SVC_NUM" to mobile, // 号码
                "OFFER_ID" to offerId
                /*"FILT_MARKET" to "Y",
                "FILT_RESGOODS" to "Y"*/
        )))
    }

    /**
     * 信用购机业务订购/返销是否成功接口
     */
    fun crepchase(mobile: String, prodPrcId: String, orderType: OrderType): HenanResp? {
        return oppt("OSP_CREPCHASE_SUCCESS_181218", JSONObject.toJSONString(mapOf(
                "SvcNum" to mobile, // 号码
                "ProdPrcId" to prodPrcId, // 产品代码
                "OprType" to orderType.name // 枚举值： ORDER：订购 ROLLBACK：返销

        )))
    }

    fun crepchaseOrder(mobile: String, prodPrcId: String): HenanResp? {
        return oppt("OSP_CREPCHASE_SUCCESS_181218", JSONObject.toJSONString(mapOf(
                "SvcNum" to mobile, // 号码
                "ProdPrcId" to prodPrcId, // 产品代码
                "OrdSource" to ordSource
        )))
    }

    fun crepchaseRollBack(mobile: String, prodPrcId: String, ordCode: String): HenanResp? {
        return oppt("OSP_CREPCHASE_SUCCESS_181229", JSONObject.toJSONString(mapOf(
                "SvcNum" to mobile, // 号码
                "ProdPrcId" to prodPrcId, // 产品代码
                "OrdSource" to ordSource,
                "OrdCode" to ordCode
        )))
    }

    /**
     * 信用购机消费分期信息记录接口
     */
    fun credit(mobile: String, prodPrcId: String, ordFee: String, ordState: String, idCard: String): HenanResp? {
        return oppt("OSP_CREDIT_PURCHASE_181217", JSONObject.toJSONString(mapOf(
                "SvcNum" to mobile, // 号码
                "ProdPrcId" to prodPrcId, // 产品代码
                "OrdSource" to ordSource, // 02 金科
                "OrdFee" to ordFee, // 分期金额（分）
                "OrdState" to ordState, // 0 or 1
                "IdCard" to idCard
        )))
    }

    fun oppt(method: String, bodyJson: String): HenanResp? {
        val timestamp = getTimestamp()
        val busiParam = getBusiParam(bodyJson)
        val token = getToken()

        val sign = getSign(method, timestamp, busiParam, token)

        val url = "$url?postSysParam=true&busiKey=cmcc_json_paras"
        val bodyMap = mapOf(
                "method" to method,
                "format" to "json",
                "appId" to appId!!,
                "version" to "1.0",
                "accessToken" to token,
                "sign" to sign,
                "timestamp" to timestamp,
                "busiSerial" to "1",
                "OPCODE" to opcode!!, // 工号
                "cmcc_json_paras" to busiParam
        )
        val type = object : TypeToken<HenanResp>() {}.type
        return JsonRequest.formPost<HenanResp>(url, bodyMap, type)
    }

    fun decode(result: String): String {
        val json = SecurityUtils.decodeAES256HexUpper(result, SecurityUtils.decodeHexUpper(appKey))
        logger.debug("result: $json")
        return json
    }

    private fun getBusiParam(bodyJson: String): String {
        return SecurityUtils.encodeAES256HexUpper(bodyJson, SecurityUtils.decodeHexUpper(appKey))
    }

    private fun getSign(method: String, timestamp: String, busiParam: String, token: String): String {
        val sysParam = mapOf(
                "method" to method,
                "format" to "json",
                "timestamp" to timestamp,
                "appId" to appId,
                "version" to "1.0",
                "OPCODE" to opcode,
                "accessToken" to token,
                "busiSerial" to "1"
        )
        return SignUtil.sign(sysParam, busiParam, "HmacSHA256", appKey)
    }

    private fun getTimestamp(): String {
        return SimpleDateFormat("yyyyMMddHHmmss").format(Date())
    }
}

