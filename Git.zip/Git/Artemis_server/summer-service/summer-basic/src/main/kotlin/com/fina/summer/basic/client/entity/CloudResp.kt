package com.fina.summer.basic.client.entity

import java.io.Serializable

data class CloudResp<T>(
        var code: String = "0",
        var msg: String? = "",
        var data: T? = null
) : Serializable {

    var isSuccess: Boolean = false
        get() = this.code == "0"

    companion object {
        private const val serialVersionUID = 4069665110575916039L


        fun <T> success(data: T): CloudResp<T> {
            return CloudResp(
                    "0","请求成功",data
            )
        }

        fun <T> success(): CloudResp<T> {
            return CloudResp(
                    "0","请求成功"
            )
        }

        fun <T> fail(msg: String): CloudResp<T> {
            return CloudResp("99",msg)
        }

        fun <T> exception(e: Throwable): CloudResp<T>  {
            return CloudResp("-99",e.message)
        }

        fun <T> fail(code: String, msg: String):  CloudResp<T> {
            return CloudResp(code,msg)
        }


    }

}