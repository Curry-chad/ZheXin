package com.fina.summer.basic.client.entity

import com.fina.summer.basic.client.constant.Flag
import java.io.Serializable
import java.util.*

data class CrepchaseBusiResp(

        /**
         * 手机号
         */
        var mobile: String? = null,

        /**
         * 产品代码
         */
        var prodPrcId: String? = null,

        /**
         * 订单编号（查询的类型）
         */
        var ordCode: String ? = null,

        /**
         * 订单时间（查询的类型）
         */
        var ordDateTime: Date? = null,

        /**
         * 错误信息
         */
        var message: String? = null,

        /**
         * 是否存在成功的订单 Y-是；N-否
         */
        var flag: Flag? = null

): Serializable