package com.fina.summer.basic.client.entity

import java.io.Serializable

data class CrepchaseResp(
        var flag: String? = null,

        var ordCode: String? = null,

        var message: String? = null
): Serializable