package com.fina.summer.basic.client.entity

import java.io.Serializable

data class ProdAcceptReq(

        /**
         * 手机号
         */
        var mobile: String? = null,

        /**
         * 营销活动id
         */
        var offerId: String? = null

): Serializable