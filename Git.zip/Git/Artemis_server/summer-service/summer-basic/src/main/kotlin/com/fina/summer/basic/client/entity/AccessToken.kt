package com.fina.summer.basic.client.entity

import java.io.Serializable

data class AccessToken(
        var access_token: String? = null,

        var token_type: String? = null,

        var expires_in: Int? = null
): Serializable