package com.fina.summer.basic.util

import java.util.regex.Pattern

class CamlUtils {
    companion object {
        fun camel(str: StringBuffer): StringBuffer {
            //利用正则删除下划线，把下划线后一位改成大写
            val pattern = Pattern.compile("_(\\w)")
            val matcher = pattern.matcher(str)
            var sb = StringBuffer(str)
            if (matcher.find()) {
                sb = StringBuffer()
                matcher.appendReplacement(sb, matcher.group(1).toUpperCase())
                matcher.appendTail(sb)
            } else {
                return sb
            }
            return camel(sb)
        }
    }
}