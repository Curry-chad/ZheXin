package com.fina.summer.basic.client.constant

enum class HenanRespCode(var code: String){
    Success("00000")
}