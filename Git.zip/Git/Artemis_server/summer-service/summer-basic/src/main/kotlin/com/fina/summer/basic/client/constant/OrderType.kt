package com.fina.summer.basic.client.constant

enum class OrderType{
    ORDER, // 订购
    ROLLBACK // 返销
}