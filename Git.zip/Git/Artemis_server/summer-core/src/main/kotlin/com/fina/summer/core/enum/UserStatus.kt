package com.fina.summer.core.enum

enum class UserStatus {
    Waiting,
    Ready,
    Normal,
    Lock
}