package com.fina.summer.core.handler

import com.fina.summer.core.respone.ResEnum

class ServiceException(private var code: ResEnum) : SimpleException(code.getCode(), code.getMsg()) {

    fun getException(): ResEnum {
        return code
    }
}