package com.fina.summer.core.bean

import java.io.Serializable

/**
 * 封装分页列表
 */
class PageResult<T> : Serializable {

    var total: Int = 0

    var data: List<T>? = null

    var other: Map<String, Any>? = null

    constructor()

    constructor(total: Int) {
        this.total = total
    }

    constructor(total: Int, data: List<T>) {
        this.total = total
        this.data = data
    }

    constructor(total: Long, data: List<T>) : this(total.toInt(), data)

    constructor(total: Int, data: List<T>, other: Map<String, Any>) {
        this.total = total
        this.data = data
        this.other = other
    }
}
