package com.fina.summer.core.enum

enum class OrderStatus {

    WaitAudit,//待提交信审 对应-1
    Auditing,//信审中 对应0
    AuditRefused,//信审拒绝 对应2
    AuditPass,//信审通过 对应1
    NoApply,//待确认
    WaitPay,//待支付
    Paying,//支付中
    FailApply,//支付申请失败
    Cancel,//订单取消
    PayedWithoutAdvance,//已支付未到账
    PayedWithoutCashApply,//已支付未请款
    PayedCashApplying,//已支付请款中
    Payed,//已支付已到账
    PayedCashApplyFail,//已支付请款失败
    PayedCashApplyCancel,//已支付请款取消
    FailPayed,//支付失败
    ChargeBackAuditing,//退款审核中
    ChargeBacking,//退款中
    ChargeBacked,//已退款
    ChargeBackFail//退款失败


}