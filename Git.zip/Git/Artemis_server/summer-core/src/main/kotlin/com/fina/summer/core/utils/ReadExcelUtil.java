package com.fina.summer.core.utils;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.util.*;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class ReadExcelUtil {

    public static Map<String,List<Map<String,String>>> read(String filePath) {
        Workbook wb =null;
        Sheet sheet = null;
        Row row = null;
        String cellData = null;
        List<String> columns = new ArrayList<>();
        wb = readExcel(filePath);
        Map<String,List<Map<String,String>>> excel = new HashMap<>();
        if(wb != null){
            int sheetCnt = wb.getNumberOfSheets();

            for( int k=0 ; k< sheetCnt ; k++) {
                //获取第一个sheet
                sheet = wb.getSheetAt(k);
                //获取sheet名称
                String sheetName = sheet.getSheetName();
                //用来存放sheet中数据
                List<Map<String,String>> list = new ArrayList<Map<String,String>>();
                //获取最大行数
                int rownum = sheet.getPhysicalNumberOfRows();
                //获取第一行
                row = sheet.getRow(0);
                //获取最大列数
                int colnum = row.getPhysicalNumberOfCells();
                for (int j = 0; j < colnum; j++) {
                    cellData = row.getCell(j).getStringCellValue();
                    columns.add(cellData);
                }
                for (int i = 1; i < rownum; i++) {
                    Map<String, String> map = new LinkedHashMap<String, String>();
                    row = sheet.getRow(i);
                    if (row != null) {
                        for (int j = 0; j < colnum; j++) {
                            Cell cell = row.getCell(j);
                            cell.setCellType(CellType.STRING);
                            cellData = cell.getStringCellValue();
                            map.put(columns.get(j), cellData);
                        }
                    } else {
                        break;
                    }
                    list.add(map);
                }
                excel.put(sheetName,list);
            }
        }
        return excel;
//        //遍历解析出来的list
//        for (String sheetName : excel.keySet()) {
//            System.out.println(sheetName);
//            List<Map<String,String>> list = excel.get(sheetName);
//            for (Map<String,String> map : list) {
//                for (Entry<String,String> entry : map.entrySet()) {
//                    System.out.println(entry.getKey()+":"+entry.getValue()+",");
//                }
//            }
//        }

    }
    //读取excel
    private static Workbook readExcel(String filePath){
        Workbook wb = null;
        if(filePath==null){
            return null;
        }
        String extString = filePath.substring(filePath.lastIndexOf("."));
        InputStream is = null;
        try {
            is = new FileInputStream(filePath);
            if(".xls".equals(extString)){
                return wb = new HSSFWorkbook(is);
            }else if(".xlsx".equals(extString)){
                return wb = new XSSFWorkbook(is);
            }else{
                return wb = null;
            }

        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return wb;
    }
    public static Object getCellFormatValue(Cell cell){
        Object cellValue = null;
        if(cell!=null){
//            cellValue = cell.getStringCellValue();
            //判断cell类型
            CellType cellType = cell.getCellTypeEnum();
            if(cellType == CellType.NUMERIC){
                cellValue = String.valueOf(cell.getNumericCellValue());
            }else
            if(cellType == CellType.FORMULA){
                //判断cell是否为日期格式
//                if(DateUtil.isCellDateFormatted(cell)){
//                    转换为日期格式YYYY-mm-dd
//                    cellValue = cell.getDateCellValue();
//                }else{
                    //数字
//                    cellValue = String.valueOf(cell.getNumericCellValue());
//                }
                cellValue = cell.getRichStringCellValue().getString();
            }else
            if(cellType == CellType.STRING){
                cellValue = cell.getRichStringCellValue().getString();
            }else {
                cellValue = "";
            }
        }else{
            cellValue = "";
        }
        return cellValue;
    }

}
