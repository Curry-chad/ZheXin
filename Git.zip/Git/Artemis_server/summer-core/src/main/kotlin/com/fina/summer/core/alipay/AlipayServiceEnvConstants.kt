/**
 *
 * Alipay.com Inc.
 *
 * Copyright (c) 2004-2014 All Rights Reserved.
 *
 */

package com.fina.summer.core.alipay


/**
 * 支付宝服务窗环境常量（demo中常量只是参考，需要修改成自己的常量值）
 *
 * @author taixu.zqq
 * @version $Id: AlipayServiceConstants.java, v 0.1 2014年7月24日 下午4:33:49 taixu.zqq Exp $
 */
object AlipayServiceEnvConstants {

    /**支付宝公钥-从支付宝生活号详情页面获取 */
    const val ALIPAY_PUBLIC_KEY = "MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAsbmhk3Abe958bXbQhYPNIHVbqe9L2Bxz3zoDLn3n1ooD/0H5BRgoquJ00SRJsKV+YfiXUFf1g/X8oKIi/g3EJFLKPiRe4bRjsWofJC29iE/+mSJ3nhJz858xsjtcnOiWrz+F7Xeldb7NyjWUiY6KJVW0yfCMcMM2qEtNn/yfxxiuVMd/ufSh0bvzAE9Orzvo301JgZKDx2SlKit6zIN7Jg7ZJwS1W3LbOdQo61lF5C2BnSR0HpFilPfFEtnoSe5i4+eaNBw+2F3ZNhYGmErVmNv3cfEBAk+wpp02Ky4GiBlKqa3amrmXB6+K6YPeZFhP0EvWLgrsJUyEPgBBqzZ+xwIDAQAB"

    /**签名编码-视支付宝服务窗要求 */
    const val SIGN_CHARSET = "GBK"

    /**字符编码-传递给支付宝的数据编码 */
    const val CHARSET = "GBK"

    /**签名类型-视支付宝服务窗要求 */
    const val SIGN_TYPE = "RSA2"

    /**开发者账号PID */
    const val PARTNER = "2088231104061011"

    /** 服务窗appId-安卓   */
    //TODO !!!! 注：该appId必须设为开发者自己的生活号id,现为安卓APP开发的id
    const val APP_ID = "2018092661543485"

    //TODO !!!! 注：该私钥为测试账号私钥  开发者必须设置自己的私钥 , 否则会存在安全隐患
    const val PRIVATE_KEY = "MIIEvgIBADANBgkqhkiG9w0BAQEFAASCBKgwggSkAgEAAoIBAQC8GiBRTW4taOGG6aUrZN0jhtBEUButOAXCm8AGMI1OnSyd0v9WviuaYvE5yt6PHH3cy/764hwomxMZc6ENTIEKp9QUyfXHnZ9jlNz4mivXfe1pJUNRUgfdwsWh3RwOKi1wMb7BgYI/eKD60fy/r8w2YPkbIUgyvHkTN1Govx2Wi4+0QhFspxKr05/mhUFCfe4lONeC6J1rtIqkCm7oGKCpevk0Zr+ZT+sgUfZFLEJzQfOibJZDUwSLtDolHjhhxK0siPWiPApLUwGW8IXqCZJBg8MU/N83MZ7mUo6d2lY3YUW1CHd6fnVCZjIOWiEjfPSP+ho9jDwKGWJRBAve2E0nAgMBAAECggEARysrZxeAxDWWftEP6Sc0dCihy/bzQcqcg1EiijT8ge3934jhixRQsw0Ub+VN55/EDzIvuwSp2sMxqsOQ/9MeT8XH/EWddHUyxR6hrH3IcLP4i3vJyI7c4w66b8+UuddDcdugbN5vRUyCu+OPWYdOIJT4K0egZXHh7V9Uyh/lNfvZjdZDnuUkLP+pF8w+xc5SKDZXpPxLGoNj6qS5KpcYhr3L9vzjlCPq1IXVEA40RNCwyKD3hkUrbn46aSlSoavYRQ5FP9dze9dpq5qcGmcnP2hKfGJ+7o8MuDuXPYk5oksxVqeAufMORX2PjoaWQZ2bIMCaccZip6LvT218b3EToQKBgQDnYSS7qGUQrYM/rnWFexnh/kz5RtUlApEJ04uZS837Cl0oWWi5u7wpRBmGAzbcVTWP1l5X8i6MxLv4j25jqN2ziaGNmgv3mccCA6HMkCm780SdfctpkJphdryhDZwuuia2t7CD9RqyQ1BMPOtwUZxH1tXRSeFf4Nk4INtw8PlL7QKBgQDQHhdU+FNSIPa9Y/zVkXypLaXJ4dfBBermtuJ8aoapHOISjQPHKoTG72quOZU3AfTgFl9EOvV0T8+Rv5skrwG3LiGR7TawAEUzH8wFqE4VQdIvk9aH2hFSQci6jM9yE5UgayS/1/HSMCXo/z/5yh1/WtJ740OSYkPvBsVUIvai4wKBgBZb183ehu2mpsE3nZmpfKXPCicohh5Oci+N5raIkb4JkVj90tXn41Xlg8Xkd5+xCDz/DRzYhVELDdMGITe2ML5RtW/WjAOAM6/pI/B9mdrUtjO13Ts1QwXaEH5Lr2UAjg8oDwGhZNQHFzJWzLWM3Vo/02enCQVX2AXJfwsZ7i09AoGBAKd0TtmzpXcjxuTEmx9MnL2TWR6DdZJ+LG/PH5V0MT3JW64JgMy0TXm0EmZ1Nra4AEx+M9E2j2EzBpUDUtXFat/1YlWERMiAry1fnE3BCnLYL0LQ9YEB2YYSIGzZ9+CWGRuomj0yiATTcO101Akss2dRsKK2ThxurLKbBBOavlB5AoGBAIt7aTCH/PacbZY9wh2TK9e2SZQ6y+QdtDXNgzN0rfjzmPx363DrVnN/MsKbjI7FqfvEN87mEtJ5atNRgOKVXARYUApaCrSBGrRO4QeVSvx1OVQOt+Y1CJnpQPnUzUPJoCjxyQW3vl8QAsOl224Y6JrMxqICBAaOwTi7b9XvnnVw"

    //TODO !!!! 注：该公钥为测试账号公钥  开发者必须设置自己的公钥 ,否则会存在安全隐患
    const val PUBLIC_KEY = "MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAvBogUU1uLWjhhumlK2TdI4bQRFAbrTgFwpvABjCNTp0sndL/Vr4rmmLxOcrejxx93Mv++uIcKJsTGXOhDUyBCqfUFMn1x52fY5Tc+Jor133taSVDUVIH3cLFod0cDiotcDG+wYGCP3ig+tH8v6/MNmD5GyFIMrx5EzdRqL8dlouPtEIRbKcSq9Of5oVBQn3uJTjXguida7SKpApu6BigqXr5NGa/mU/rIFH2RSxCc0HzomyWQ1MEi7Q6JR44YcStLIj1ojwKS1MBlvCF6gmSQYPDFPzfNzGe5lKOndpWN2FFtQh3en51QmYyDlohI3z0j/oaPYw8ChliUQQL3thNJwIDAQAB"
    /**支付宝网关 */
    const val ALIPAY_GATEWAY = "https://openapi.alipay.com/gateway.do"

    /**授权访问令牌的授权类型 */
    const val GRANT_TYPE = "authorization_code"

    /** 商户唯一标示 自定义 */
    const val TARGET_ID = "finance"

    /** 服务窗appId-支付宝生活号   */
    //TODO !!!! 注：该appId必须设为开发者自己的生活号id
    const val ALIPAY_APP_ID = "2018080660949323"
}