package com.fina.summer.core.utils


object FinanceUtil {

    fun getInterestRate(areaCode: String): Double{
        if(areaCode.startsWith("61")){
            return 0.19
        }else {
            return 0.21875
        }
    }

    fun getInterest(principal: Int,areaCode: String): Int{
        return Math.ceil(principal * getInterestRate(areaCode)).toInt()
    }

    fun getNeedReceipt(principal: Int,areaCode: String): Int{
        return Math.ceil(principal * (1- getInterestRate(areaCode))).toInt()
    }

    fun getAdvanceFee(principal: Int): Int{ //支付宝手续费
        return Math.ceil(principal * 0.125).toInt()
    }
}