package com.fina.summer.core.enum

enum class JobStatus {
    Active, //在职
    Leave   //离职
}