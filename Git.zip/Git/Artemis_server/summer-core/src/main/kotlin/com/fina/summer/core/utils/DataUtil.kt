package com.fina.summer.core.utils

import org.springframework.util.StringUtils
import java.text.SimpleDateFormat
import java.util.*

class DataUtil {

    companion object {

        const val DEFAULT_AMOUNT: String = "0.00"

        const val DEFAULT_SUC_RATE: String = "0.00"

        const val AREA_NAME_ANY: String = "@ANY"

        const val DEFAULT_NONE: String = "--:--"

        fun convertDecimal(value: String?): String {
            if (StringUtils.isEmpty(value)) {
                return DEFAULT_AMOUNT
            }
            return String.format("%.2f", (value!!.toDouble() / 100))
        }

        fun convertDecimalByDefault(value: String?, default: String): String {
            if (StringUtils.isEmpty(value)) {
                return default
            }
            return String.format("%.2f", (value!!.toDouble() / 100))
        }

        fun convertDecimalReturnA(value: String?): String? {
            if (StringUtils.isEmpty(value)) {
                return "--"
            }
            return String.format("%.2f", (value!!.toDouble() / 100))
        }

        fun convertRate(value: String?) : String {
            if (StringUtils.isEmpty(value)) {
                return DEFAULT_AMOUNT
            }
            return String.format("%.2f%%", value!!.toDouble())
        }

        fun intToString(i: Int?) : String? {
            return if (i != null) "$i" else null
        }

        fun longToDate(l: Long?): Date? {
            return if (l != null) Date(l) else null
        }

        fun longToString(l: Long?): String? {
            return if (l != null) "$l" else null
        }

        fun dateToString(d: Date?, p: String): String {
            return if (d != null) SimpleDateFormat(p).format(d) else "无"
        }

    }
}