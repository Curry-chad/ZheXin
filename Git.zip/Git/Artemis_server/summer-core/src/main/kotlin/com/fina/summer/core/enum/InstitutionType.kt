package com.fina.summer.core.enum

enum class InstitutionType {

    ALIPAY,//支付宝
    CREDIT,//信用卡
    DEBIT  //储蓄卡
}

object InstitutionTypeMap {

    val map = mapOf(PaymentChannel.FyAlipayYEB to InstitutionType.ALIPAY,
                    PaymentChannel.FyAntCheckLater to InstitutionType.ALIPAY,
                    PaymentChannel.FyLbfCredit to InstitutionType.CREDIT,
                    PaymentChannel.ZyxjDebit to InstitutionType.DEBIT,
                    PaymentChannel.UnionPay to InstitutionType.DEBIT,
                    PaymentChannel.ZxPay to InstitutionType.DEBIT)

    val receiveMap = mapOf(PaymentChannel.FyAlipayYEB to InstitutionType.ALIPAY,
            PaymentChannel.FyAntCheckLater to InstitutionType.ALIPAY,
            PaymentChannel.FyLbfCredit to InstitutionType.ALIPAY,
            PaymentChannel.ZyxjDebit to InstitutionType.DEBIT,
            PaymentChannel.UnionPay to InstitutionType.DEBIT,
            PaymentChannel.ZxPay to InstitutionType.DEBIT)

    fun getPayerInstitutionType(paymentChannel: PaymentChannel): InstitutionType {
        return map[paymentChannel] ?: InstitutionType.ALIPAY
    }

    fun getReceiveInstitutionType(paymentChannel: PaymentChannel): InstitutionType {
        return receiveMap[paymentChannel] ?: InstitutionType.ALIPAY
    }
}