package com.fina.summer.core.utils

import lombok.Getter
import org.hibernate.type.TimeType
import java.text.SimpleDateFormat
import java.util.*



/**
 * @Package: com.hisun.catPayMail.common.util
 * @Description: 日期工具类
 * @Author: zhouxi
 * @Date: 2018/3/12 11:01
 */
object DateUtils {

    /**
     * @ClassName: DateUtils
     * @Description: 得到昨天日期 yyyy-MM-dd
     * @Date 2018/3/12 11:03
     */
    val yesterdayDateStr: String
        get() = SimpleDateFormat("yyyy-MM-dd").format(yesterdayDate)

    val yesterdayDate: Date
        get() {
            val calendar = Calendar.getInstance()
            calendar.add(Calendar.DATE, -1)
            return calendar.time
        }

    /**
     * @ClassName: DateUtils
     * @Description: TODD
     * @Params:
     * @Date 2018/3/12 13:48
     */
    val todayDateStr: String
        get() {
            val dateFormat = SimpleDateFormat("yyyy-MM-dd")
            return dateFormat.format(Date())
        }

    fun getTimeByBeforeDays(o: Date, beforeN: Int): Date {
        val calendar = Calendar.getInstance()
        calendar.time = o
        calendar.add(Calendar.DATE, - beforeN)
        return calendar.time
    }

    fun getMonthByMonths(o: Date, n: Int): Date {
        val calendar = Calendar.getInstance()
        calendar.time = o
        calendar.add(Calendar.MONTH, n)
        return calendar.time
    }

    fun getDayByDays(o: Date, n: Int): Date {
        val calendar = Calendar.getInstance()
        calendar.time = o
        calendar.add(Calendar.DATE, n)
        return calendar.time
    }

    fun getStringToDate(date: String): Date{
        val sf = SimpleDateFormat("yyyy-MM-dd HH:mm:ss")
        return sf.parse(date)
    }

    fun getStringToDateDay(date: String): Date{
        val sf = SimpleDateFormat("yyyy-MM-dd")
        return sf.parse(date)
    }

    fun getDateToString(date: Date): String{
        val sf = SimpleDateFormat("yyyy-MM-dd HH:mm:ss")
        return sf.format(date)
    }

    /**
     * 获取入参时间的当月1号零点零分零秒
     * @author 郑齐阳
     * @param date 要计算的时间
     * @return 入参时间的当月1号零点零分零秒
     */
    fun getBeginDayOfMonth(date: Date): Date {
        val calendar = Calendar.getInstance()
        calendar.time = date
        calendar.set(Calendar.DAY_OF_MONTH, 1)
        calendar.set(Calendar.HOUR_OF_DAY, 0)
        calendar.set(Calendar.MINUTE, 0)
        calendar.set(Calendar.SECOND, 0)
        calendar.set(Calendar.MILLISECOND, 0)

        return Date(calendar.timeInMillis)
    }
    /**
     * 获取入参时间的当月最后一天
     * @author 郑齐阳
     * @param date 要计算的时间
     * @return 入参时间的当月最后一天
     */
    fun getLastDayOfMonth(date: Date): Date {
        val calendar = Calendar.getInstance()
        calendar.time = date
        val maxDay = calendar.getActualMaximum(Calendar.DAY_OF_MONTH)
        calendar.set(Calendar.DAY_OF_MONTH, maxDay)
        calendar.set(Calendar.HOUR_OF_DAY, 23)
        calendar.set(Calendar.MINUTE, 59)
        calendar.set(Calendar.SECOND, 59)
        date.time = calendar.timeInMillis
        return date
    }

   fun getDateWithFormat(date: Date):Date{
        val dateFormat = SimpleDateFormat("yyyy-MM-dd")
       val format = dateFormat.format(date)
       return dateFormat.parse(format)
    }
    /**
     * 比较两个时间
     *
     * @param beginDate 开始时间
     * @param endDate 结束时间
     * @return 如果时间相同，返回0；如果beginDate早于endDate，返回-1；如果beginDate晚于endDate，返回1；
     */
    fun compare(beginDate: Date, endDate: Date): Int {
        val beginTime = beginDate.time
        val endTime = endDate.time
        return java.lang.Long.compare(beginTime, endTime)
    }

    /**
     * 计算两个日期之间的差距
     *
     * @param beginDate beginDate
     * @param endDate endDate
     * @param timeType 0:秒级；1:分级:；2:小时级；3:天级；
     * @return 差距
     */
    fun differDateInDays(beginDate: Date, endDate: Date, timeType: TimeType): Long {
        val begin = beginDate.time
        val end = endDate.time
        var surplus = end - begin

        val calendarBeginDate = Calendar.getInstance()
        calendarBeginDate.time = beginDate

        val calendarEndDate = Calendar.getInstance()
        calendarEndDate.time = endDate
        val dstOffset = calendarBeginDate.get(Calendar.DST_OFFSET) - calendarEndDate.get(Calendar.DST_OFFSET)
        surplus += dstOffset.toLong()

        var ret: Long = 0
        when (timeType) {
            DateUtils.TimeType.SECOND ->
                // 秒
                ret = surplus / 1000
            DateUtils.TimeType.MINUTE ->
                // 分
                ret = surplus / 1000 / 60
            DateUtils.TimeType.HOUR ->
                // 时
                ret = surplus / 1000 / 60 / 60
            DateUtils.TimeType.DAY ->
                // 天
                ret = surplus / 1000 / 60 / 60 / 24
            else -> {
            }
        }
        return ret
    }

    @Getter
    enum class TimeType private constructor(private val code: Int) {
        /** 秒  */
        SECOND(0),
        /** 分钟  */
        MINUTE(1),
        /** 小时  */
        HOUR(2),
        /** 天  */
        DAY(3)
    }
}
