package com.fina.summer.core.utils

import java.io.UnsupportedEncodingException
import java.net.URLEncoder
import java.util.*
import javax.servlet.http.Cookie
import javax.servlet.http.HttpServletRequest
import javax.servlet.http.HttpServletResponse

object CookiesUtil {

    /**
     * 根据名字获取cookie
     *
     * @param request
     * @param name
     * cookie名字
     * @return
     */
    fun getCookieByName(request: HttpServletRequest, name: String): Cookie? {
        val cookieMap = ReadCookieMap(request)
        return if (cookieMap.containsKey(name)) {
            cookieMap[name] as Cookie
        } else {
            null
        }
    }

    /**
     * 将cookie封装到Map里面
     *
     * @param request
     * @return
     */
    private fun ReadCookieMap(request: HttpServletRequest): Map<String, Cookie> {
        val cookieMap = HashMap<String, Cookie>()
        val cookies = request.cookies
        if (null != cookies) {
            for (cookie in cookies) {
                cookieMap[cookie.name] = cookie
            }
        }
        return cookieMap
    }

    /**
     * 保存Cookies
     *
     * @param response
     * servlet请求
     * @param value
     * 保存值
     * @author jxf
     */
    fun setCookie(response: HttpServletResponse, name: String, value: String, time: Int): HttpServletResponse {
        // new一个Cookie对象,键值对为参数
        val cookie = Cookie(name, value)
        // tomcat下多应用共享
        cookie.path = "/"
        // 如果cookie的值中含有中文时，需要对cookie进行编码，不然会产生乱码
        try {
            URLEncoder.encode(value, "utf-8")
        } catch (e: UnsupportedEncodingException) {
            e.printStackTrace()
        }

        cookie.maxAge = time
        // 将Cookie添加到Response中,使之生效
        response.addCookie(cookie) // addCookie后，如果已经存在相同名字的cookie，则最新的覆盖旧的cookie
        return response
    }

}
