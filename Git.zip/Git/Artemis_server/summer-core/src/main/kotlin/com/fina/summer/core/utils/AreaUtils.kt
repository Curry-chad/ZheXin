package com.fina.summer.core.utils

import org.apache.commons.lang3.StringUtils
import org.springframework.beans.BeanUtils

/**
 * @author zhuqingwei@zhexinit.com
 * @version V1.0
 * @since 1.0 2019/5/15 16:14
 * @description 请输入功能描述
 */
object AreaUtils {

    fun  getAreaPrefix( source: String?) :String {
        if(StringUtils.isNotEmpty(source)){
            println(source)
             if(source!!.length == 9 && source!!.endsWith("000") ){
                 return getAreaPrefix(source!!.removeSuffix("000"))
             }
            if(source!!.length == 8 && source!!.endsWith("00") ){
                return getAreaPrefix(source!!.removeSuffix("00"))
            }
            if(source!!.length == 6 && source!!.endsWith("00") ){
                return getAreaPrefix(source!!.removeSuffix("00"))
            }
            if(source!!.length == 4 && source!!.endsWith("00") ){
                return getAreaPrefix(source!!.removeSuffix("00"))
            }
            return source!!;
        }
        return ""
    }

}

fun main(args: Array<String>) {
   print( AreaUtils.getAreaPrefix("421000"))
}