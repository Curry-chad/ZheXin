package com.fina.summer.core.utils

fun <T> ifnull(a: T?, b: T): T {
    return a ?: b
}