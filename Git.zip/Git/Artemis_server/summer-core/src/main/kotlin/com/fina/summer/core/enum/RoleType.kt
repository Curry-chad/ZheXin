package com.fina.summer.core.enum

enum class RoleType {
    Seller,
    Merchant
}