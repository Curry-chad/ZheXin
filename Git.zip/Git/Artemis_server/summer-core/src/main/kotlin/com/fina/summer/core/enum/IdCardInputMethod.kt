package com.fina.summer.core.enum

enum class IdCardInputMethod {
    AutoOcr,    //自动ocr识别
    ManualInput //手动输入
}