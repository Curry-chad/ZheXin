package com.fina.summer.core.utils

import com.fasterxml.jackson.core.JsonParser
import com.fasterxml.jackson.core.JsonToken
import com.fasterxml.jackson.databind.DeserializationContext
import com.fasterxml.jackson.databind.deser.std.StringDeserializer
import org.springframework.stereotype.Component

import java.io.IOException

@Component("customObjectMapper")
class TrimStringDeserializer : StringDeserializer() {
    @Throws(IOException::class)
    override fun deserialize(p: JsonParser, ctxt: DeserializationContext): String {
        return if (p.hasToken(JsonToken.VALUE_STRING)) {
            p.text.trim()
        } else super.deserialize(p, ctxt)
    }
}