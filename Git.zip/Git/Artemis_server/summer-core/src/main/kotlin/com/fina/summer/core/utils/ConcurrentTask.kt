package com.fina.summer.core.utils

import java.util.*
import java.util.concurrent.*

class ConcurrentTask<V>(private val es: ThreadPoolExecutor) {

//    private val es: ThreadPoolExecutor? = null
    private val list: MutableList<Future<V>>
    private val result: MutableList<V>

    init {
        list = ArrayList()
        result = ArrayList()

    }


    fun submit(callable: Callable<V>) {
        val f = es.submit(callable)

        list.add(f)
    }



//    fun shutdown() {
//        es.shutdown()
//    }

    @Throws(InterruptedException::class, ExecutionException::class)
    operator fun get(index: Int): V {
        val value = result[index]
        return value ?: list[index].get()
    }

    @Throws(InterruptedException::class, ExecutionException::class)
     fun getAll(): MutableList<V>{
        for (temp in list) {
            result.add(list.indexOf(temp), temp.get(30L, TimeUnit.SECONDS))
        }
        return result
    }
}
