package com.fina.summer.core.utils

import org.springframework.beans.BeansException
import org.springframework.context.ApplicationContext
import org.springframework.context.ApplicationContextAware
import org.springframework.stereotype.Component

/**
 * 获取ApplicationContext和Object的工具类
 * @author yzl
 */
@Component
class SpringContextUtils : ApplicationContextAware {

    @Throws(BeansException::class)
    override fun setApplicationContext(arg0: ApplicationContext) {
        applicationContext = arg0
    }

    companion object {
        var applicationContext: ApplicationContext? = null

        /**
         * 根据bean的id来查找对象
         * @param id
         * @return
         */
        fun getBeanById(id: String): Any {
            return applicationContext!!.getBean(id)
        }

        /**
         * 根据bean的class来查找对象
         * @param c
         * @return
         */
        fun <T> getBeanByClass(c: Class<T>): T {
            return applicationContext!!.getBean(c)
        }

        /**
         * 根据bean的class来查找所有的对象(包括子类)
         * @param c
         * @return
         */
        fun <T> getBeansByClass(c: Class<T>): Map<String, T> {
            return applicationContext!!.getBeansOfType(c)
        }
    }
}