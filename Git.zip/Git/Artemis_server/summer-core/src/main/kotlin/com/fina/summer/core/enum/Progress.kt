package com.fina.summer.core.enum

enum class Progress {
    Ready,
    Cancel,
    Doing,
    Interrupt,
    Success,
    Fail
}