package com.fina.summer.core.utils.Test

import com.fina.summer.core.utils.DateUtils

/**
 * @author zhengqiyang@zhexinit.com
 * @version V1.0
 * @since 1.0 2019/5/7 17:07
 * @description 请输入功能描述
 */
fun main(args: Array<String>) {
    var date1 = DateUtils.getStringToDateDay("2019-04-10 16:15:38")
    var date2 = DateUtils.getStringToDateDay("2019-03-31 00:00:00")
    val monthByMonths = DateUtils.getMonthByMonths(date1, 1)
    println("aaa:" + DateUtils.differDateInDays(date1, monthByMonths, timeType = DateUtils.TimeType.DAY).toInt())
    println("bbb:" + DateUtils.differDateInDays(date2, date1, timeType = DateUtils.TimeType.DAY).toInt())
    /* println("日期为"+ monthByMonths)
     val differDateInDays = DateUtils.differDateInDays(date1, date2, timeType = DateUtils.TimeType.DAY)
     println("比大小结果：" +DateUtils.compare(date1,date2))
     println("相差"+ differDateInDays)
     println("当前时间"+ DateUtils.getDateWithFormat(date1))
     println("当前时间qq"+DateUtils.getMonthByMonths(DataUtil.longToDate(1559318400000)!!,-1))
     //DateUtils.getMonthByMonths(DataUtil.longToDate(date2)!!,-1)
     var today = DateUtils.getStringToDateDay("2019-05-21 00:00:00")
     println("时间为："+DateUtils.compare(DateUtils.getDayByDays(date2!!, 2), today))
     println("jiange1:"+DateUtils.differDateInDays(date2, today, timeType = DateUtils.TimeType.DAY).toInt())

     println("it.planExecuteTime 是 $date2")
     println("today 是 $today")
     println("jiange1:"+DateUtils.differDateInDays(date2, today, timeType = DateUtils.TimeType.DAY).toInt())

     println("jiange2:"+DateUtils.differDateInDays(date1, date2, timeType = DateUtils.TimeType.DAY).toInt())*/
}