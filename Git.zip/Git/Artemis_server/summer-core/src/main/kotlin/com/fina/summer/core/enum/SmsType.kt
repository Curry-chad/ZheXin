package com.fina.summer.core.enum

enum class SmsType(val templateId:String,val content:String) {
    Login("395700", "【Artemis】你好，你的验证码是{1}，切勿告知他人，有效时间{2}分钟。"),

    RepayNotice("", ""),

    RepaySuccess("", ""),

    RepayOverdue("", "")



}