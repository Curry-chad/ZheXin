package com.fina.summer.core.enum

enum class AuditStatus {

    WaitAudit,//待提交信审 对应-1
    Auditing,//信审中 对应0
    AuditRefused,//信审拒绝 对应2
    AuditPass,//信审通过 对应1
}