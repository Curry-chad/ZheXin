package com.fina.summer.core.utils

import java.text.SimpleDateFormat

/**
 * ClassName:IdGenerator <br></br>
 * Function: TODO ADD FUNCTION. <br></br>
 * Reason: TODO ADD REASON. <br></br>
 * Date: 2017年2月17日 下午3:08:34 <br></br>
 *
 * @author chiwei
 * @version
 * @since JDK 1.6
 * @see
 */

object IdGenerator// 10位进程ID标识
{

    private var lastTs = 0L
    private const val processIdBits = 10

    private var sequence = 0L
    private const val sequenceBits = 12
    @Suppress("CAST_NEVER_SUCCEEDS")
    private val processId: Long = System.getProperty("server.no", "999").toLong()

    private const val beginTs = 1483200000000L

    init {
        if (processId > (1 shl processIdBits) - 1) {
            throw RuntimeException("进程ID超出范围，设置位数" + processIdBits + "，最大"
                    + ((1 shl processIdBits) - 1))
        }
    }

    private fun timeGen(): Long {
        return System.currentTimeMillis()
    }

    @Synchronized
    fun nextId(): Long {
        var ts = timeGen()
        if (ts < lastTs) {// 刚刚生成的时间戳比上次的时间戳还小，出错
            throw RuntimeException("时间戳顺序错误")
        }
        if (ts == lastTs) {// 刚刚生成的时间戳跟上次的时间戳一样，则需要生成一个sequence序列号
            // sequence循环自增
            sequence = sequence + 1 and (1L shl sequenceBits) - 1
            // 如果sequence=0则需要重新生成时间戳
            if (sequence == 0L) {
                // 且必须保证时间戳序列往后
                ts = nextTs(lastTs)
            }
        } else {// 如果ts>lastTs，时间戳序列已经不同了，此时可以不必生成sequence了，直接取0
            sequence = 0L
        }
        lastTs = ts// 更新lastTs时间戳
        return (ts - beginTs shl processIdBits + sequenceBits or (processId shl sequenceBits) or sequence)
    }


    fun nextId(type: Id): String {
        return type.prefix + nextId()
    }


    private fun nextTs(lastTs: Long): Long {
        var ts = timeGen()
        while (ts <= lastTs) {
            ts = timeGen()
        }
        return ts
    }


    @Throws(Exception::class)
    @JvmStatic
    fun main(args: Array<String>) {
        // TODO Auto-generated method stub
        val str = "20170101"
        println(SimpleDateFormat("YYYYMMDD").parse(str).time)
//        val set = HashSet<String>()
//        val begin = System.nanoTime()
//        for (i in 0..100) {
//            set.add(nextId(Id.Order))
//        }
//        println("time=" + (System.nanoTime() - begin) / 1000.0 + " us")
//        println(set.size)
//        println(set)
        val a = nextId(Id.Order)
        println(a)
        println(a.length)
    }
}

enum class Id(val prefix: String) {
    Merchant("MER"),
    Store("STO"),
    Seller("SEL"),
    Order("ORD"),
    Error("ERR"),
    ChargeBack("CBK"),
    Phone("PHO"),
    Brand("BRA"),
    Request("REQ"),

    Bill("B"),
    SMS("SMS")

}
