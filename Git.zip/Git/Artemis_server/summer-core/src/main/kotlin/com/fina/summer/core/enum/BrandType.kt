package com.fina.summer.core.enum

enum class BrandType {
    HOT,
    FAMOUS,
    OTHERS
}