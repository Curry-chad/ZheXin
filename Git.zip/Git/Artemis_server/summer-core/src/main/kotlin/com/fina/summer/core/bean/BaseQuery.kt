package com.fina.summer.core.bean

import java.io.Serializable
import javax.persistence.EnumType
import javax.persistence.Enumerated

open class BaseQuery(

        var offset: Int? = null,

        var pageSize: Int? = null,

        var sortList: List<Sort>? = null

) : Serializable

class Sort (

        var sort: String? = null,

        @Enumerated(EnumType.STRING)
        var order: Order? = Order.DESC

): Serializable

enum class Order {
    DESC,
    ASC
}