package com.fina.summer.core.utils

import java.io.UnsupportedEncodingException
import java.security.MessageDigest
import java.security.NoSuchAlgorithmException
import java.util.logging.Level
import java.util.logging.Logger

object Md5Util {
    fun md5(str: String?): String? {
        if (str == null) {
            return ""
        } else {
            var value: String? = null
            var md5: MessageDigest? = null
            val buf = StringBuffer("")

            try {
                md5 = MessageDigest.getInstance("MD5")
                md5!!.update(str.toByteArray(charset("utf-8")))
                val b = md5.digest()

                var temp: Int
                for (n in b.indices) {
                    temp = b[n].toInt()
                    if (temp < 0)
                        temp += 256
                    if (temp < 16)
                        buf.append("0")
                    buf.append(Integer.toHexString(temp))
                }
            } catch (ex: NoSuchAlgorithmException) {
                Logger.getLogger(Md5Util::class.java.name).log(Level.SEVERE, null, ex)
            } catch (e: UnsupportedEncodingException) {
                e.printStackTrace()
            }

            // sun.misc.BASE64Encoder baseEncoder = new
            // sun.misc.BASE64Encoder();
            try {
                // value = baseEncoder.encode(md5.digest(s.getBytes("utf-8")));
                value = buf.toString().toUpperCase()
            } catch (ex: Exception) {

            }

            return value
        }
    }

    fun enMd5(str: String): String? {
        try {
            val md = MessageDigest.getInstance("MD5")
            md.update(str.toByteArray())
            return byte2Hex(md.digest())
        } catch (e: NoSuchAlgorithmException) {
            e.printStackTrace()
        }

        return null
    }

    fun byte2Hex(byteArray: ByteArray): String {
        var result = ""
        for (offset in byteArray.indices) {
            val toHexString = Integer.toHexString(byteArray[offset].toInt() and 0xFF)
            if (toHexString.length == 1) {
                result += "0$toHexString"
            } else {
                result += toHexString
            }
        }
        return result
    }
}
