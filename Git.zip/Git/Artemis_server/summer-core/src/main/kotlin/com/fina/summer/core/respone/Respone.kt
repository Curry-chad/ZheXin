package com.fina.summer.core.respone

import com.fasterxml.jackson.annotation.JsonIgnore
import org.slf4j.LoggerFactory
import java.io.Serializable
import java.lang.reflect.UndeclaredThrowableException

enum class ResEnum(private val code: String, private val msg: String) {

    Success("0", "success"),
    Exception("-1", "异常抛出！！"),
    Fail("99", "非指定性失败！"),
    ParamErr("1", "参数缺失或不合法！"),

    OutsideFail("1999", "外部接口返回失败"),
    FailGetAlipayInfo("1991","获取支付宝用户信息失败！"),

    //支付模块
    PayApplyFail("1101", "支付申请失败"),
    IDCheckFail("1102", "用户身份信息校验失败"),
    MobileCheckFail("1103", "手机号验证不一致"),
    ChargeBackApplyFail("1104", "退款申请失败"),
    NotOrderRePay("1105", "当前订单不允许支付"),
    NotOrderCancel("1106", "当前订单不允许取消"),
    NotOrderChargeBack("1107", "当前订单不允许退款"),
    PayChannelNotSupport("1108", "该支付渠道暂不支持相应服务"),
    TradeNotExist("1109", "交易单不存在"),
    NotOrderPay("1110","当前订单不允许支付"),
    OrderRePay("1111","当前订单尚未支付完成，请不要重复支付"),
    NotPayee("1112","商户暂未设置该支付渠道的收款账户，请更换支付渠道重新支付"),
    NotifyCheckFail("1113", "回调校验不通过"),
    ApplicantChange("1114","表单发生修改，请重新获取验证码"),

    //用户模块
    Unauthorized("1401", "用户角色权限限制"),
    FORBIDDEN("1403", "用户未登录"),
    IncorrectCredentials("1404", "用户名或密码错误"),
    UserNotExist("1405", "用户不存在"),
    CodeWrong("1406", "验证码错误"),
    UserLogout("1407", "用户已注销"),
    NotUserInfo("1408", "尚未成为店员，不可办单！"),
    NotSeller("1409","抱歉，你的店员账户未报备，请在商户端添加"),   //不允许修改此code，前端有用
    NotMerchant("1410","用户非商户"),
    AlipayAccountIdExists("1411","支付宝账户已被其它用户绑定!"),
    UserSameStoreExists("1412","店员已存在"),
    UserNotStoreExists("1413","店员已在其他门店下服务"),
    UserLock("1414","用户已被锁定"),

    //商户模块
    MerChecking("1501", "商户审核中,禁止修改！"),
    MerNotChecked("1502", "商户审核未审核通过！"),
    PayeeExists("1503","该收款方式下已有收款账户，不可重复添加"),
    MerchantExists("1504","该用户名下已创建商户"),
    CertNoExists("1505","营业执照号已被使用"),
    MerAuditReject("1506","商户审核拒绝，请修改资料后重新提交"),

    //门店
    StoreChecking("1601", "门店审核中，禁止修改！"),
    StoreNotExists("1602", "门店不存在！"),
    OrganizationCodeExists("1603","门店编码已被使用"),
    StoreAuditReject("1604","门店审核拒绝，请修改资料后重新提交"),
    AreaPermissionFalse("1605","由于安康移动本月赠费额度到达上限，营销包无法办理，因此暂停和分享业务办理，详情见群通知"),
    StoreAreaCodeNotExists("1606","门店地区编码不存在"),
    OrganizationCodeFail("1607","请正确填写门店渠道编码"),

    //订单模块
    NotOrderPower("1701", "您暂不可办理订单，请先完善资料后再行操作！"),
    MerOrStoreCheckFail("1702", "商户或门店或店员未审核通过，禁止创建订单"),
    OrderCancelFail("1703", "取消订单失败"),
    OrderApplyFail("1704", "订单申请失败"),
    NotPayed("1705", "订单尚未支付！"),
    OrderNotExists("1706", "订单不存在"),
    OrderPaymentNotActual("1707", "订单金额与支付金额不符"),
    BusinessTypeError("1708","业务类型错误"),
    NotChargeBackAudit("1709","该订单无提交退款审核"),
    NotChargeBacking("1710","订单状态非退款中"),
    PutAuthCode("1711","请输入验证码"),   //不允许修改此code，前端有用
    BankCardNumberIsNull("1712","储蓄卡号不允许为空"),
    BankCardNumberIsWrong("1713","请输入正确的储蓄卡号"),

    //审核模块
    PayAuditReject("1801","信审拒绝，当前订单不允许支付！"),
    RefundAuditReject("1802","信审拒绝，当前订单不允许退款！"),
    OrderAuditReject("1803","信审拒绝，该申请人不允许申请订单！"),

    //短信模块
    NoUsersToAlert("1901","不存在需要提前提醒的还款用户"),
    NoThisUser("1902","未找到符合该条件的用户"),
    NoOverdueUsers("1903","不存在逾期未还款用户"),
    NoOverdueUsersEligible("1904","不存在符合发送逾期短信条件的用户"),
    NoUsersToRemind("1905","不存在需要提醒的代扣代缴（不兜底）用户"),

    //风控模块
    FKError("1901","信审不通过！")
    ;


    fun isSuccess(): Boolean {
        return code == "0"
    }

    fun getCode(): String {
        return code
    }

    fun getMsg(): String {
        return msg
    }

    fun <T> parse(): WebResult<T> {
        return WebResult(code, msg)
    }

    fun <T> parse(data: T): WebResult<T> {
        return WebResult(code, msg, data)
    }

    fun <T> parseMsg(msg: String): WebResult<T> {
        return WebResult(code, msg)
    }

    fun <T> msg(msg: String): WebResult<T> {
        return WebResult(code, msg)
    }

    fun <T> msg(e: Throwable): WebResult<T> {
        var message = e.message
        if (e is UndeclaredThrowableException) {
            message = e.cause?.message
        }
        return WebResult(code, message)
    }


    companion object {
        private  val logger = LoggerFactory.getLogger(ResEnum::class.java)

        fun  <T>  success(data: T): WebResult<T> {
            return Success.parse(data)
        }

        fun  <T>  success(): WebResult<T> {
            return Success.parse()
        }

        fun  <T>  fail(msg: String): WebResult<T> {
            logger.warn("请求失败：{}",msg)
            return Fail.msg(msg)
        }

        fun  <T>  exception(e: Throwable): WebResult<T> {
            return Exception.msg(e)
        }

        fun <T> fail(code: String, msg: String): WebResult<T> {
            logger.warn("请求失败：{}-{}", code, msg)
            return WebResult(code, msg)
        }

        fun <T> fail(resEnum: ResEnum): WebResult<T> {
          logger.warn("请求失败：{}-{}", resEnum.code, resEnum.msg)
            return WebResult(resEnum.code, resEnum.msg)
        }
    }

}

/**
 *
 * 类名:com.dj.crbt.bean.ResultBean
 *
 * <pre>
 * 描述:
 * 基本思路:
 * 特别说明:
 * 编写者:李晓亮
 * 创建时间:2016年6月12日 下午2:34:22
 * 修改说明: 类的修改说明
</pre> *
 */
data class WebResult<T>(
        var code: String = "0",
        var msg: String? = "",
        var data: T? = null
) : Serializable {

    var isSuccess: Boolean = false
        @JsonIgnore
        get() = this.code == "0"

    companion object {
        private const val serialVersionUID = 4069665110575916039L
    }

}