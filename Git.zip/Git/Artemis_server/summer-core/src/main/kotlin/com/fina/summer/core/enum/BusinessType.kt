package com.fina.summer.core.enum

enum class BusinessType {
    CallChargeInstallment,      //话费分期（购机直降）
    FullInstallment,        //手机全额分期（话费贴息）
    FreePhoneInstallment    //安康零元购手机分期
}