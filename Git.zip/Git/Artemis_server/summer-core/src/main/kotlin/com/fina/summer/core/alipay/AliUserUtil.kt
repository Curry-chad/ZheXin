package com.fina.summer.core.alipay

import com.alipay.api.response.AlipayUserInfoShareResponse
import com.alipay.api.request.AlipayUserInfoShareRequest
import com.alipay.api.DefaultAlipayClient
import com.alipay.api.AlipayApiException
import com.alipay.api.AlipayConstants
import com.alipay.api.DefaultSigner
import com.alipay.api.response.AlipaySystemOauthTokenResponse
import com.alipay.api.request.AlipaySystemOauthTokenRequest
import com.fina.summer.core.alipay.AlipayServiceEnvConstants.ALIPAY_APP_ID
import com.fina.summer.core.alipay.AlipayServiceEnvConstants.ALIPAY_PUBLIC_KEY
import com.fina.summer.core.alipay.AlipayServiceEnvConstants.APP_ID
import com.fina.summer.core.alipay.AlipayServiceEnvConstants.CHARSET
import com.fina.summer.core.alipay.AlipayServiceEnvConstants.PARTNER
import com.fina.summer.core.alipay.AlipayServiceEnvConstants.PRIVATE_KEY
import com.fina.summer.core.alipay.AlipayServiceEnvConstants.TARGET_ID
import java.util.HashMap
import java.util.ArrayList
import java.io.UnsupportedEncodingException
import java.net.URLEncoder


object AliUserUtil{

    fun getOauthToken(authCode:String): AlipaySystemOauthTokenResponse? {
        val alipayClient = DefaultAlipayClient("https://openapi.alipay.com/gateway.do", APP_ID, PRIVATE_KEY, "json", CHARSET, ALIPAY_PUBLIC_KEY, "RSA2")
        val request = AlipaySystemOauthTokenRequest()
        request.code = authCode
        request.grantType = "authorization_code"
        try {
            return alipayClient.execute(request)
        } catch (e: AlipayApiException) {
            throw e
        }
    }


    fun getUserInfo(accessToken:String): AlipayUserInfoShareResponse? {
        val alipayClient = DefaultAlipayClient("https://openapi.alipay.com/gateway.do", APP_ID, PRIVATE_KEY, "json", CHARSET, ALIPAY_PUBLIC_KEY, "RSA2")
        val request = AlipayUserInfoShareRequest()
        return alipayClient.execute(request, accessToken)
    }

    fun getAlipayOauthToken(authCode:String): AlipaySystemOauthTokenResponse? {
        val alipayClient = DefaultAlipayClient("https://openapi.alipay.com/gateway.do", ALIPAY_APP_ID, PRIVATE_KEY, "json", CHARSET, ALIPAY_PUBLIC_KEY, "RSA2")
        val request = AlipaySystemOauthTokenRequest()
        request.code = authCode
        request.grantType = "authorization_code"
        try {
            return alipayClient.execute(request)
        } catch (e: AlipayApiException) {
            throw e
        }
    }

    fun getAlipayUserInfo(accessToken:String): AlipayUserInfoShareResponse? {
        val alipayClient = DefaultAlipayClient("https://openapi.alipay.com/gateway.do", ALIPAY_APP_ID, PRIVATE_KEY, "json", CHARSET, ALIPAY_PUBLIC_KEY, "RSA2")
        val request = AlipayUserInfoShareRequest()
        return alipayClient.execute(request, accessToken)
    }

    fun getAuthInfo(): String{
        val defaultSigner = DefaultSigner(PRIVATE_KEY)
        val content = getContent()
        return content + "&" +defaultSigner.sign(content,AlipayConstants.SIGN_TYPE_RSA2,"UTF-8")
    }

    fun getContent(): String{
        val keyValues = HashMap<String, String>()

        // 商户签约拿到的app_id，如：2013081700024223
        keyValues["app_id"] = APP_ID

        // 商户签约拿到的pid，如：2088102123816631
        keyValues["pid"] = PARTNER

        // 服务接口名称， 固定值
        keyValues["apiname"] = "com.alipay.account.auth"

        // 商户类型标识， 固定值
        keyValues["app_name"] = "mc"

        // 业务类型， 固定值
        keyValues["biz_type"] = "openservice"

        // 产品码， 固定值
        keyValues["product_id"] = "APP_FAST_LOGIN"

        // 授权范围， 固定值
        keyValues["scope"] = "kuaijie"

        // 商户唯一标识，如：kkkkk091125
        keyValues["target_id"] = TARGET_ID

        // 授权类型， 固定值
        keyValues["auth_type"] = "AUTHACCOUNT"

        // 签名类型
        keyValues["sign_type"] = AlipayConstants.SIGN_TYPE_RSA2

        //转换成string
        return buildContent(keyValues)
    }

    fun buildContent(map: Map<String, String>): String {
        val keys = ArrayList(map.keys)

        val sb = StringBuilder()
        for (i in 0 until keys.size - 1) {
            val key = keys[i]
            val value = map[key]!!
            sb.append(buildKeyValue(key, value, true))
            sb.append("&")
        }

        val tailKey = keys[keys.size - 1]
        val tailValue = map[tailKey]!!
        sb.append(buildKeyValue(tailKey, tailValue, true))

        return sb.toString()
    }

    /**
     * 拼接键值对
     *
     * @param key
     * @param value
     * @param isEncode
     * @return
     */
    private fun buildKeyValue(key: String, value: String, isEncode: Boolean): String {
        val sb = StringBuilder()
        sb.append(key)
        sb.append("=")
        if (isEncode) {
            try {
                sb.append(URLEncoder.encode(value, "UTF-8"))
            } catch (e: UnsupportedEncodingException) {
                sb.append(value)
            }

        } else {
            sb.append(value)
        }
        return sb.toString()
    }

}