package com.fina.summer.core.enum

enum class PaymentChannel {
    FyAntCheckLater,//蚂蚁花呗
    FyAlipayYEB,//支付宝余额宝预授权
    FyLbfCredit,//乐百分信用卡支付
    ZyxjDebit,//中原消金储蓄卡
    UnionPay,//银联支付
    ZxPay,//自有支付
}