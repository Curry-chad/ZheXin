package com.fina.summer.core.enum

enum class TradeType {

    Pay,    //支付
    Refund, //退款
    Cancel, //取消
    Receipt //垫付
}