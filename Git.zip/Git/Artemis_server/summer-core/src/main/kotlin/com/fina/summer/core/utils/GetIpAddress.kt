package com.fina.summer.core.utils

import org.slf4j.LoggerFactory
import java.io.*
import java.net.HttpURLConnection
import java.net.URL
import javax.servlet.http.HttpServletRequest

object GetIpAddress {
    private val logger = LoggerFactory.getLogger(GetIpAddress::class.java)

    @Throws(IOException::class)
    fun getInfo(srcUrl: String, timeoutMils: Int): String {

        val url = URL(srcUrl)
        val httpconn = url.openConnection() as HttpURLConnection
        httpconn.readTimeout = timeoutMils

        val inputReader = InputStreamReader(httpconn.inputStream)
        val bufReader = BufferedReader(inputReader)

        var tmpLine = bufReader.readLine()
        val contentBuffer = StringBuffer()

        while (tmpLine != null) {
            contentBuffer.append(tmpLine)
            tmpLine = bufReader.readLine()
        }

        bufReader.close()
        httpconn.disconnect()
        return contentBuffer.toString()
    }

    @Throws(IOException::class)
    fun getReader(srcUrl: String, timeoutMils: Int): BufferedReader {
        val url = URL(srcUrl)
        val httpconn = url.openConnection() as HttpURLConnection
        httpconn.readTimeout = timeoutMils

        val inputReader = InputStreamReader(httpconn.inputStream)
        return BufferedReader(inputReader)
    }

    // POST
    fun getInfoByPost(urlStr: String, xml: String, timeoutMils: Int, isXml: Boolean): String {
        var input: DataInputStream? = null
        val out = ByteArrayOutputStream()
        val xmlData = xml.toByteArray()
        try {
            val url = URL(urlStr)
            val urlCon = url.openConnection()
            urlCon.doOutput = true
            urlCon.doInput = true
            urlCon.useCaches = false
            urlCon.connectTimeout = timeoutMils
            urlCon.readTimeout = timeoutMils

            if (isXml) {
                urlCon.setRequestProperty("Content-Type", "text/xml")
            }
            urlCon.setRequestProperty("Content-length", xmlData.size.toString())
            val printout = DataOutputStream(urlCon.getOutputStream())
            printout.write(xmlData)
            printout.flush()
            printout.close()
            input = DataInputStream(urlCon.getInputStream())
            val bufferByte = ByteArray(256)

            var i = input.read(bufferByte)
            while (i > -1) {
                out.write(bufferByte, 0, i)
                out.flush()
                i = input.read(bufferByte)
            }
        } catch (e: Exception) {
            logger.error("连接错误：", e)
        }

        return out.toString()
    }

    // POST
    fun getInfoByPost2(urlStr: String, xml: String, timeoutMils: Int): String {
        var input: DataInputStream? = null
        val out = ByteArrayOutputStream()
        val xmlData = xml.toByteArray()
        try {
            val url = URL(urlStr)
            val urlCon = url.openConnection()
            urlCon.doOutput = true
            urlCon.doInput = true
            urlCon.useCaches = false
            urlCon.connectTimeout = timeoutMils
            urlCon.readTimeout = timeoutMils

            // urlCon.setRequestProperty("Content-Type", "text/xml");
            urlCon.setRequestProperty("Content-length", xmlData.size.toString())
            val printout = DataOutputStream(urlCon.getOutputStream())
            printout.write(xmlData)
            printout.flush()
            printout.close()
            input = DataInputStream(urlCon.getInputStream())
            val bufferByte = ByteArray(256)

            var i = input.read(bufferByte)
            while (i > -1) {
                out.write(bufferByte, 0, i)
                out.flush()
                i = input.read(bufferByte)
            }
        } catch (e: Exception) {
            logger.error("连接错误：", e)
        }

        return out.toString()
    }

    fun getClientIp(request: HttpServletRequest): String? {
        var ip: String? = request.getHeader("X-Client-Really-IP")
        if (ip == null || ip.length == 0 || "unknown".equals(ip, ignoreCase = true)) {
            ip = request.getHeader("Proxy-Client-IP")
        }
        if (ip == null || ip.length == 0 || "unknown".equals(ip, ignoreCase = true)) {
            ip = request.getHeader("WL-Proxy-Client-IP")
        }
        if (ip == null || ip.length == 0 || "unknown".equals(ip, ignoreCase = true)) {
            ip = request.getHeader("HTTP_CLIENT_IP")
        }
        if (ip == null || ip.length == 0 || "unknown".equals(ip, ignoreCase = true)) {
            ip = request.getHeader("HTTP_X_FORWARDED_FOR")
        }
        if (ip == null || ip.length == 0 || "unknown".equals(ip, ignoreCase = true)) {
            ip = request.remoteAddr
        }

        return ip
    }

}
