package com.fina.summer.core.enum

enum class GoodsType {

    Phone, //手机
    Household,   //家电
    Wearable,   //穿戴设备
    Pad   , //平板电脑
    Others//其他
}