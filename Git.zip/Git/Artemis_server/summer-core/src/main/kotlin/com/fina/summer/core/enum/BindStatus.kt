package com.fina.summer.core.enum

enum class BindStatus {

    Binding,//绑定中
    Success,//成功
    Fail    //失败
}