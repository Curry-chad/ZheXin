package com.fina.summer.core.utils


import com.fina.summer.core.enum.CompareStatus
import java.beans.PropertyDescriptor

class CompareObejct<T> {

    var status: CompareStatus? = null
        private set
    /**
     * 之前原始的值
     */
    var original: T? = null
    /**
     * 当前的值
     */
    var current: T? = null


    fun contrastObj(cls: Class<T>) {
        if (this.original == null) {
            this.status = CompareStatus.NEW
            return
        }
        if (this.status === CompareStatus.REMOVE) {
            return
        }
        var isEqual = true
        try {
            //Class clazz = this.original.getClass();
            val fields = cls.declaredFields
            for (field in fields) {
                val pd = PropertyDescriptor(field.name, cls)
                val getMethod = pd.readMethod
                val o1 = getMethod.invoke(this.original)
                val o2 = getMethod.invoke(this.current)
                val s1 = o1?.toString() ?: ""//避免空指针异常
                val s2 = o2?.toString() ?: ""//避免空指针异常
                //思考下面注释的这一行：会bug的，虽然被try catch了，程序没报错，但是结果不是我们想要的
                //if (!o1.toString().equals(o2.toString())) {
                if (s1.isNotEmpty() && s2.isNotEmpty() && s1 != s2) {
                    //textList.add("不一样的属性：" + field.getName() + " 属性值：[" + s1 + "," + s2 + "]");
                    isEqual = false
                    println("不一样的属性：" + field.name + " 属性值：[" + s1 + "," + s2 + "]")
                }
            }
        } catch (e: Exception) {
            println(e.message)
        }

        if (isEqual) {
            this.status = CompareStatus.NO_CHANGE
        } else {
            this.status = CompareStatus.CHANGE
        }
    }

}

