package com.fina.summer.core.config

import org.springframework.cache.annotation.EnableCaching
import org.springframework.web.servlet.config.annotation.EnableWebMvc
import org.springframework.web.servlet.config.annotation.ResourceHandlerRegistry
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer

@EnableWebMvc
@EnableCaching(proxyTargetClass = true)
open class SpringConfig : WebMvcConfigurer {

    override fun addResourceHandlers(registry: ResourceHandlerRegistry) {
        registry.addResourceHandler("swagger-ui.html")
                .addResourceLocations("classpath:/META-INF/resources/")

        registry.addResourceHandler("/webjars/**")
                .addResourceLocations("classpath:/META-INF/resources/webjars/")
    }


//    @Bean("redisTemplate")
//    open fun redisTemplate(redisConnectionFactory: RedisConnectionFactory): RedisTemplate<String, HttpReqLog> {
//        val redisTemplate = RedisTemplate<String,HttpReqLog>()
//        redisTemplate.setConnectionFactory(redisConnectionFactory)
//
//        // 使用Jackson2JsonRedisSerialize 替换默认序列化
//        val jackson2JsonRedisSerializer = Jackson2JsonRedisSerializer(HttpReqLog::class.java)
//
//        val objectMapper = jacksonObjectMapper()
//
//        jackson2JsonRedisSerializer.setObjectMapper(objectMapper)
//
//        // 设置value的序列化规则和 key的序列化规则
//        redisTemplate.keySerializer = StringRedisSerializer()
//        redisTemplate.valueSerializer = jackson2JsonRedisSerializer
//        return redisTemplate
//    }


}