package com.fina.summer.core.aliyun


import com.aliyuncs.DefaultAcsClient
import com.aliyuncs.exceptions.ClientException
import com.aliyuncs.http.MethodType
import com.aliyuncs.http.ProtocolType
import com.aliyuncs.profile.DefaultProfile
import com.aliyuncs.sts.model.v20150401.AssumeRoleRequest
import com.aliyuncs.sts.model.v20150401.AssumeRoleResponse
import org.slf4j.LoggerFactory
import java.util.*

object AliyunStsUtils {
    val LOGGER = LoggerFactory.getLogger(AliyunStsUtils::class.java)!!

    // 目前只有"cn-hangzhou"这个region可用, 不要使用填写其他region的值
    private const val REGION_CN_HANGZHOU = "cn-hangzhou"
    // 当前 STS API 版本
    val STS_API_VERSION = "2015-04-01"

    const val accessKeyId = "LTAIlWWISeEwbAR8"
    const val accessKeySecret = "1FH82ZMWuBpWR7dPboF0fbFgKEH7xv"
    // AssumeRole API 请求参数: RoleArn, RoleSessionName, Policy, and
    // DurationSeconds
    // RoleArn 需要在 RAM 控制台上获取
    val roleArn = "acs:ram::125969:role/rammilierresourcewrite"

    val roleSessionName = "zc-001"

    val policy = ("{\n" + "    \"Version\": \"1\", \n" + "    \"Statement\": [\n" + "        {\n"
            + "            \"Action\": [\n" + "                \"oss:GetBucket\", \n"
            + "                \"oss:GetObject\" \n" + "  ,\n \"oss:PutObject\"          ], \n" + "            \"Resource\": [\n"
            + "                \"acs:oss:*:*:*\"\n" + "            ], \n" + "            \"Effect\": \"Allow\"\n"
            + "        }\n" + "    ]\n" + "}")


    @Throws(Exception::class)
    fun stsToken(): Map<String, String> {
        val result = HashMap<String, String>()
        val protocolType = ProtocolType.HTTPS
        val response = assumeRole(accessKeyId, accessKeySecret, roleArn, roleSessionName,
                policy, protocolType)
        result["accessKeyId"] = response.credentials.accessKeyId
        result["accessKeySecret"] = response.credentials.accessKeySecret
        result["securityToken"] = response.credentials.securityToken
        result["bucketName"] = "zx-finance"
        return result
    }


    @Throws(ClientException::class)
    fun assumeRole(accessKeyId: String, accessKeySecret: String,
                   roleArn: String, roleSessionName: String, policy: String, protocolType: ProtocolType): AssumeRoleResponse {
        try {
            // 创建一个 Aliyun Acs Client, 用于发起 OpenAPI 请求
            val profile = DefaultProfile.getProfile(REGION_CN_HANGZHOU, accessKeyId, accessKeySecret)
            val client = DefaultAcsClient(profile)

            // 创建一个 AssumeRoleRequest 并设置请求参数
            val request = AssumeRoleRequest()
            request.version = STS_API_VERSION
            request.method = MethodType.POST
            request.protocol = protocolType
            request.roleArn = roleArn
            request.roleSessionName = roleSessionName
            request.policy = policy
            request.durationSeconds = 3600L
            // 发起请求，并得到response
            return client.getAcsResponse(request)
        } catch (e: ClientException) {
            throw e
        }

    }

}
