package com.fina.summer.core.utils

import org.apache.commons.lang.StringUtils
import org.slf4j.LoggerFactory
import java.io.File
import java.io.IOException
import java.util.*
import javax.mail.*
import javax.mail.internet.*

/**
 * 邮件发送工具类
 *
 * @author ThinkPad
 */

class EmailUtil {

    var host: String? = null

    var port: String? = null

    var from: String? = null

    var password: String? = null

    var to: List<String>? = null

    var cc: List<String>? = null

    var subject: String? = null

    var attchmentFileList: List<String>? = null

    var content: String? = null


    fun send() {
        send(host, port, from, password, to, cc, subject, attchmentFileList, content)
    }

    fun send(subject: String, content: String) {
        send(host, port, from, password, to, cc, subject, null, content)
    }

    @Throws(IOException::class, MessagingException::class)
    private fun send(host: String?, port: String?, from: String?, password: String?, to: List<String>?, cc: List<String>?, subject: String?, attchmentFileList: List<String>?, content: String?) {
        logger.debug("begin EmailUtil::send method, email param host [{}], port [{}], account [{}], " + "password [{}], to {}, cc {}, subject is [{}], attchmentFileList {}, content is [{}]",
                host, port, from, password, to, cc, subject, attchmentFileList, content)
        val props = Properties()
        props["mail.smtp.host"] = this.host!!
        props["mail.smtp.port"] = this.port!!
        props["mail.smtp.auth"] = "true"
        props["mail.smtp.socketFactory.fallback"] = "false"
        props["mail.debug"] = "true"

        val user = from
        val userPwd = password
        val session = Session.getInstance(props, object : Authenticator() {
            override fun getPasswordAuthentication(): PasswordAuthentication {
                return PasswordAuthentication(user, userPwd)
            }
        })

        val msg = MimeMessage(session)
        msg.setFrom(InternetAddress(from!!))
        if (null == to || to!!.isEmpty()) {
            logger.error("end EmailUtil::send method, from(email sender) is null...")
            return
        }

        for (toEmail in to!!) {
            msg.addRecipient(Message.RecipientType.TO, InternetAddress(toEmail))
        }

        if (cc != null) {
            for (ccEmail in cc!!) {
                msg.addRecipient(Message.RecipientType.CC, InternetAddress(ccEmail))
            }
        }

        msg.subject = subject
        msg.sentDate = Date()

        val mp = MimeMultipart()

        if (StringUtils.isNotEmpty(content)) {
            val htmlPart = MimeBodyPart()
            htmlPart.setContent(content, "text/html;charset=utf8")
            mp.addBodyPart(htmlPart)
        }

        if (attchmentFileList != null) {
            for (attach in this.attchmentFileList!!) {
                val file = File(attach)
                if (!file.exists()) {
                    logger.warn("attach [{}] file is not exist!", attach)
                    continue
                }

                val attachment = MimeBodyPart()
                attachment.attachFile(attach)
                var fileName = ""
                if (attach.lastIndexOf("/") > 0) {
                    fileName = attach.substring(attach.lastIndexOf("/") + 1)
                } else {
                    fileName = attach
                }
                logger.info("attach file name is [{}]", fileName)
                attachment.fileName = MimeUtility.encodeWord(fileName)
                mp.addBodyPart(attachment)
            }
        }
        msg.setContent(mp)
        Transport.send(msg)
    }

    companion object {
        private val logger = LoggerFactory.getLogger(EmailUtil::class.java)
    }

}
