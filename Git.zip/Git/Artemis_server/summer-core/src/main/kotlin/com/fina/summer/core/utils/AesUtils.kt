package com.fina.summer.core.utils

import org.apache.commons.codec.binary.Base64
import java.util.*
import javax.crypto.Cipher
import javax.crypto.spec.SecretKeySpec

/**
 * **Description** AES对称加密工具类 <BR></BR>
 *
 * @author shenhaiwen
 *
 * @since 2018年7月13日下午3:57:22
 */
object AesUtils {
    @Throws(Exception::class)
    fun encrypt(data: String, key: String): String {
        val bytesKey = Base64.decodeBase64(key)

        val secretKeySpec = SecretKeySpec(bytesKey, "AES")

        val cipher = Cipher.getInstance("AES")
        cipher.init(1, secretKeySpec)
        val bytes = cipher.doFinal(data.toByteArray(charset("utf-8")))
        return parseByte2HexStr(bytes)
    }

    @Throws(Exception::class)
    fun decrypt(data: String, key: String): String {
        val bytesKey = Base64.decodeBase64(key)
        println(Arrays.toString(bytesKey))

        val secretKeySpec = SecretKeySpec(bytesKey, "AES")

        val encryptBytes = parseHexStr2Byte(data)

        val cipher = Cipher.getInstance("AES")
        cipher.init(2, secretKeySpec)

        val decryptBytes = cipher.doFinal(encryptBytes!!)
        return String(decryptBytes, charset("UTF-8"))
    }

    fun parseByte2HexStr(buf: ByteArray): String {
        val sb = StringBuffer()
        for (i in buf.indices) {
            var hex = Integer.toHexString(buf[i].toInt() and 0xFF)
            if (hex.length == 1) {
                hex = "0$hex"
            }
            sb.append(hex.toUpperCase())
        }
        return sb.toString()
    }

    fun parseHexStr2Byte(hexStr: String): ByteArray? {
        if (hexStr.length < 1)
            return null
        val result = ByteArray(hexStr.length / 2)
        for (i in 0 until hexStr.length / 2) {
            val high = Integer.parseInt(hexStr.substring(i * 2, i * 2 + 1), 16)
            val low = Integer.parseInt(hexStr.substring(i * 2 + 1, i * 2 + 2),
                    16)
            result[i] = (high * 16 + low).toByte()
        }
        return result
    }
}