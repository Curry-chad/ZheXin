package com.fina.summer.core.enum

enum class SellerStatus {
    Sleeping,   //待激活
    Activated,   //已激活（审核通过）
    AuditRefused   //审核拒绝
}