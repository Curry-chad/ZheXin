package com.fina.summer.core.enum

enum class BindType {

    ALIPAY //支付宝
}