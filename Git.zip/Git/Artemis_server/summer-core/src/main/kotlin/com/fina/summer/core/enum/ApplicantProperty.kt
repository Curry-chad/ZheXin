package com.fina.summer.core.enum

enum class ApplicantProperty {
    OldCustomerEqualLevel,  //老客户平档办理
    OldCustomerUpLevel,  //老客户升档办理
    DifferentNetNewNetIn,   //异网新入网
    NewMobileCustomer   //新号 新客户办理
}