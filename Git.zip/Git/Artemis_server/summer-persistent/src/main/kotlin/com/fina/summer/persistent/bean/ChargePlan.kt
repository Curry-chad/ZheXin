package com.fina.summer.persistent.bean


class ChargePlan : StoreCodePlanGoods() {

    var id: String? = null

    var commonRebate: Int? = null

    var firstRebate: Int? = null

    var groupId: String? = null

    var name: String? = null

    var feePerMonth: Int? = null

    var needReceive: Int? = null
        get() = if (field != null){ if( field!! % 100 == 0){ field!! / 100 * 100 }else{ ( field!! / 100 + 1) * 100} }else null

    var needPayment: Int? = null

}