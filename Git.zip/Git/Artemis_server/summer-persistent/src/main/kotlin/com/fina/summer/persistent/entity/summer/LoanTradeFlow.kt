package com.fina.summer.persistent.entity.summer

import com.fina.summer.core.enum.InstitutionType
import com.fina.summer.core.enum.PaymentChannel
import com.fina.summer.core.enum.TradeType
import org.hibernate.annotations.DynamicInsert
import org.hibernate.annotations.DynamicUpdate
import org.hibernate.annotations.GenericGenerator
import org.hibernate.annotations.Parameter
import org.springframework.data.jpa.domain.support.AuditingEntityListener
import java.io.Serializable
import java.util.*
import javax.persistence.*

@Entity
@DynamicUpdate
@DynamicInsert
@EntityListeners(AuditingEntityListener::class)
data class LoanTradeFlow(
        @Id
        @GeneratedValue(generator = "idGenerator")
        @GenericGenerator(name = "idGenerator", strategy = "com.fina.summer.persistent.util.SnowGenerator"
                , parameters = [Parameter(name = "prefix", value = "TRF")])
        var id: String? = null,

        @Column(name = "trade_id")
        var tradeId: String? = null,

        @Column(name = "order_id")
        var orderId: String? = null,

        @Column(name = "trade_time")
        var tradeTime: Date? = null,

        @Column(name = "payer_loan_institution")
        @Enumerated(EnumType.STRING)
        var payerLoanInstitution: InstitutionType? = null,

        @Column(name = "payer_account_id")
        var payerAccountId: String? = null,

        @Column(name = "payer_logon_account")
        var payerLogonAccount: String? = null,

        @Column(name = "payment_channel")
        @Enumerated(EnumType.STRING)
        var paymentChannel: PaymentChannel? = null,

        @Column(name = "payer_actual_payment")
        var payerActualPayment: Int? = null,

        @Column(name = "loan_institution")
        @Enumerated(EnumType.STRING)
        var loanInstitution: InstitutionType? = null,

        @Column(name = "advance_account_id")
        var advanceAccountId: String? = null,

        @Column(name = "advance_logon_account")
        var advanceLogonAccount: String? = null,

        @Column(name = "advance_type")
        var advanceType: String? = null,

        @Column(name = "advance_actual_payment")
        var advanceActualPayment: Int? = null,

        @Column(name = "advance_receive_actual_payment")
        var advanceReceiveActualPayment: Int? = null,

        @Column(name = "advance_charges_payment")
        var advanceChargesPayment: Int? = null,

        @Column(name = "receive_loan_institution")
        @Enumerated(EnumType.STRING)
        var receiveLoanInstitution: InstitutionType? = null,

        @Column(name = "receive_account")
        var receiveAccount: String? = null,

        @Column(name = "receive_account_id")
        var receiveAccountId: String? = null,

        @Column(name = "receive_actual_payment")
        var receiveActualPayment: Int? = null,

        @Column(name = "third_trade_flow_no")
        var thirdTradeFlowNo: String? = null,

        @Column(name = "other_flow_no")
        var otherFlowNo: String? = null,

        @Column(name = "trade_type")
        @Enumerated(EnumType.STRING)
        var tradeType: TradeType? = null,

        @Column(name = "created_time")
        var createdTime: Date? = null,

        @Column(name = "updated_time")
        var updatedTime: Date? = null

) : Serializable
