package com.fina.summer.persistent.repo.user

import com.fina.summer.core.enum.UserStatus
import com.fina.summer.persistent.entity.summer.user.User
import org.springframework.data.jpa.repository.JpaRepository

interface UserRepo: JpaRepository<User,String> {

    fun findByMobile(mobile: String): User?

    fun findFirstByMobile(mobile: String): User?

    fun findFirstByMobileAndStatus(mobile: String, normal: UserStatus): User?
}