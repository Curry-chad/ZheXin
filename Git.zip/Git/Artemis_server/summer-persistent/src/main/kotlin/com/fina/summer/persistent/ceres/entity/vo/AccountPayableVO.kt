package com.fina.summer.persistent.ceres.entity.vo

import io.swagger.annotations.ApiModelProperty
import java.io.Serializable
import java.util.*

data class AccountPayableVO (
        @ApiModelProperty("打款表id")
        var outTaskId: String? = null,

        @ApiModelProperty("交易单号")
        var tradeId: String? = null,

        @ApiModelProperty("订单交易时间")
        var orderTradeTime: Date? = null,

        @ApiModelProperty("应转账金额（分）")
        var shouldAmount: String? = null,

        @ApiModelProperty("收款人名字")
        var payee: String? = null,

        @ApiModelProperty("收款账号")
        var payeeAccount: String? = null,

        @ApiModelProperty("收款银行")
        var payeeBank: String? = null,

        @ApiModelProperty("付款人名字")
        var payer: String? = null,

        @ApiModelProperty("付款人账号")
        var payAccount: String? = null,

        @ApiModelProperty("付款人银行")
        var payBank: String? = null,

        @ApiModelProperty("实收金额")
        var totalAmount: String? = null,

        @ApiModelProperty("转账状态")
        var status: String? = null,

        @ApiModelProperty("订单编号")
        var orderId: String? = null,

        @ApiModelProperty("资金方")
        var fundChannel: String? = null,

        @ApiModelProperty("计划执行时间")
        var planExecuteTime: Date? = null,

        @ApiModelProperty("订单完成时间")
        var finishTime: String? = null,

        @ApiModelProperty("经办人")
        var modifyBy: String? = null,

        @ApiModelProperty("备注")
        var message: String? = null,

        @ApiModelProperty("第三方流水号")
        var thirdOrderId: String? = null

) : Serializable