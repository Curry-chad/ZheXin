package com.fina.summer.persistent.ceres.entity.vo

import com.fina.summer.persistent.ceres.entity.constant.FundChannel
import com.fina.summer.persistent.ceres.entity.constant.TaskStatus
import java.io.Serializable
import java.util.*
import javax.persistence.EnumType
import javax.persistence.Enumerated

data class BillInVO(

        val bisTaskId: String? = null,

        var taskId: String? = null,

        var planExecuteTime: Date? = null,

        var payer: String? = null,

        var seqNo: Int? = null,

        var totalAmount: Int? = null,

        var overdueDays: Int? = 0,

        var penalty: Int? = 0,

        var merName: String? = null,

        @Enumerated(EnumType.STRING)
        var fundChannel: FundChannel? = FundChannel.None,

        var orderId: String? = null,

        @Enumerated(EnumType.STRING)
        var status: TaskStatus? = TaskStatus.None,

        var periodTimes: Int? = 12,

        var planTotalShouldAmount: Int? = 0,

        var leftPeriod: Int? = 0,

        var leftAmount: Int? = 0

): Serializable