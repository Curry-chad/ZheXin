package com.fina.summer.persistent.ceres.entity.vo

import io.swagger.annotations.ApiModelProperty
import java.io.Serializable

data class DeductVO(

        @ApiModelProperty("扣款订单")
        val ids: List<String>? = null,

        @ApiModelProperty("操作人")
        var modifyBy: String? = null

): Serializable