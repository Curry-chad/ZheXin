package com.fina.summer.persistent.ceres.repo

import com.fina.summer.persistent.ceres.entity.domain.BillOutTaskDO
import org.springframework.data.jpa.repository.JpaRepository

interface BillOutTaskRepo : JpaRepository<BillOutTaskDO, String>