package com.fina.summer.persistent.ceres.repo

import com.fina.summer.persistent.ceres.entity.domain.BillInFlowsPO
import org.springframework.data.jpa.repository.JpaRepository

interface BillInFlowsRepo : JpaRepository<BillInFlowsPO, String>