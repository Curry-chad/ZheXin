package com.fina.summer.persistent.bean



class Area {

    var provinceName: String? = null

    var cityName: String? = null
    //areaname
    var name: String? = null
}