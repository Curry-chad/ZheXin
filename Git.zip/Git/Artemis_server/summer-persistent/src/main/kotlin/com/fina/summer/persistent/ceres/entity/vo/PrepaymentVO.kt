package com.fina.summer.persistent.ceres.entity.vo

import com.fina.summer.persistent.ceres.entity.domain.BillInTasksPO
import java.io.Serializable

data class PrepaymentVO(

        var name: String? = null,

        var account: String? = null,

        var data : List<List<BillInTasksPO>> ? = null,

        var tasks: List<String>? = null,

        var amount: List<Int>? = null,

        var orderId: String? = null,

        var pageNo: Int? = null,

        var pageSize: Int? = null,

        var total: Int = 0,

        var modifyBy: String? = null
): Serializable