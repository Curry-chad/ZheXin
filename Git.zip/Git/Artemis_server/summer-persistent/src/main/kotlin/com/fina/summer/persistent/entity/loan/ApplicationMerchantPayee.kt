package com.fina.summer.persistent.entity.loan

import com.fina.summer.core.enum.AuditStatus
import com.fina.summer.core.enum.InstitutionType
import org.hibernate.annotations.*
import org.hibernate.annotations.Parameter
import org.springframework.data.annotation.CreatedDate
import org.springframework.data.annotation.LastModifiedDate
import org.springframework.data.jpa.domain.support.AuditingEntityListener
import java.io.Serializable
import java.util.*
import javax.persistence.*
import javax.persistence.Entity

@Entity
@DynamicInsert
@DynamicUpdate
@EntityListeners(AuditingEntityListener::class)
data class ApplicationMerchantPayee (

        @Id
        @GeneratedValue(generator = "idGenerator")
        @GenericGenerator(name = "idGenerator", strategy = "com.fina.summer.persistent.util.SnowGenerator"
                , parameters = [Parameter(name = "prefix", value = "AMP")])
        var id: String? = null,

        @Column(name = "payee_id",columnDefinition = "varchar(32) comment '收款账号ID'")
        var payeeId: String? = null,

        var appMerchantId: String? = null,

        @Column(name = "payee_institution")
        var payeeInstitution: String? = null,

        @Column(name = "payee_account_name")
        var payeeAccountName: String? = null,

        @Column(name = "payee_account_id")
        var payeeAccountId: String? = null,

        @Column(name = "payee_logon_account")
        var payeeLogonAccount: String? = null,

        @Column(columnDefinition = "varchar(255) comment '账户头像地址'")
        var payeeAccountAvatar: String? = null,

        @Column(name = "institution_type",columnDefinition = "varchar(32) comment '收款机构类型'")
        @Enumerated(EnumType.STRING)
        var institutionType: InstitutionType? = null,

        @Column(columnDefinition = "varchar(32) comment '分支机构名称'")
        var branchInstitution: String? = null,

        @Column(name = "created_time",columnDefinition = "datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间'")
        @CreatedDate
        var createdTime: Date? = null,

        @Column(name = "updated_time",columnDefinition = "datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间'")
        @LastModifiedDate
        var updatedTime: Date? = null
): Serializable