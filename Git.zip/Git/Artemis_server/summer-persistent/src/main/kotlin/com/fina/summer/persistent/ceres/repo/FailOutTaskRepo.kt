package com.fina.summer.persistent.ceres.repo

import com.fina.summer.persistent.ceres.entity.domain.FailOutTask
import org.springframework.data.jpa.repository.JpaRepository

interface FailOutTaskRepo : JpaRepository<FailOutTask, String>