package com.fina.summer.persistent.entity.loan

import com.fina.summer.core.enum.*
import com.google.gson.annotations.Expose
import org.hibernate.annotations.DynamicInsert
import org.hibernate.annotations.DynamicUpdate
import org.hibernate.annotations.GenericGenerator
import org.hibernate.annotations.Parameter
import org.springframework.data.annotation.CreatedDate
import org.springframework.data.annotation.LastModifiedDate
import org.springframework.data.jpa.domain.support.AuditingEntityListener
import java.io.Serializable
import java.util.*
import javax.persistence.*

@Entity
@DynamicInsert
@DynamicUpdate
@EntityListeners(AuditingEntityListener::class)
data class ApplicationLoanTrade(

        @Id
        @GeneratedValue(generator = "idGenerator")
        @GenericGenerator(name = "idGenerator", strategy = "com.fina.summer.persistent.util.SnowGenerator"
                , parameters = [Parameter(name = "prefix", value = "ALT")])
        var id: String? = null,

        var appLoanOrderId: String? = null,

        var tradeId: String? = null,

        @Column(columnDefinition = "varchar(32) comment '订单ID'")
        var orderId: String? = null,

        @Enumerated(EnumType.STRING)
        var tradeType: TradeType? = null,

        var principal: Int? = null,//本金

        var principalAndInterest: Int? = null,//本息合计

        @Column(columnDefinition = "varchar(32) COMMENT '商户类型'")
        var subject: String? = null,

        @Column(columnDefinition = "double COMMENT '利率，商户承担下应该以用户实际支付金额为本金计算利率'")
        var interestRate: Double? = null,

        var accountPeriod: Int? = null,//账期

        var repaymentMethod: String? = null,//还款方式：等额本息

        var monthlyRepaymentAmount: Int? = null,//每月还款金额

        @Enumerated(EnumType.STRING)
        var payerLoanInstitution: InstitutionType? = null,//付款人资金方机构：支付宝，银联

        var payerAccountId: String? = null,//付款人所属资金方机构账号ID

        var payerLogonAccount: String? = null,//付款人所属资金方机构登录账号

        var payerNeedPayment: Int? = null,//应付款金额

        @Column(columnDefinition = "varchar(64) comment '付款机构名称'")
        var payerInstitutionName: String? = null,

        @Column(columnDefinition = "varchar(32) comment '绑卡状态：待验证，成功，失败'")
        @Enumerated(EnumType.STRING)
        var payerAuthStatus: BindStatus? = null,//绑卡状态：待验证，成功，失败

        @Column(columnDefinition = "tinyint(1) default '0' comment '人脸识别结果'")
        var faceRecognitionResult: Boolean? = false,

        @Column(columnDefinition = "varchar(512) comment '人脸识别影像件'")
        var faceRecognitionImageUrl: String? = null,

        @Column(columnDefinition = "varchar(512) comment '人脸识别影像分析数据'")
        var faceRecognitionAnalyse: String? = null,

        @Enumerated(EnumType.STRING)
        var paymentChannel: PaymentChannel? = null,//支付渠道,蚂蚁花呗，余额宝、信用卡

        @Enumerated(EnumType.STRING)
        var receiveLoanInstitution: InstitutionType? = null,//收款人资金方机构：支付宝，银联

        @Column(columnDefinition = "varchar(64) comment '收款机构名称：支付宝/xx银行'")
        var receiveInstitutionName: String? = null,

        var receiveAccount: String? = null,//收款方账户

        var receiveAccountId: String? = null,

        var receiveNeedPayment: Int? = null,

        var auditNo: String? = null,

        var auditDescribe: String? = null,

        var auditPerson: String? = null,

        var auditTime: Date? = null,

        @Enumerated(EnumType.STRING)
        var auditStatus: AuditStatus? = null,

        @CreatedDate
        @Expose(deserialize = false)
        var createdTime: Date? = null,

        @LastModifiedDate
        @Expose(deserialize = false)
        var updatedTime: Date? = null,

        @Transient
        var refundFlowNo: String? = null,

        @Transient
        var validCode: String? = null

) : Serializable