package com.fina.summer.persistent.ceres.entity.domain

import com.fina.summer.persistent.ceres.entity.constant.BillType
import com.fina.summer.persistent.ceres.entity.constant.DeductChannel
import com.fina.summer.persistent.ceres.entity.constant.FundChannel
import com.fina.summer.persistent.ceres.entity.constant.Progress
import java.util.*
import javax.persistence.*

@Entity
@Table(name = "bill_out_plan", schema = "ceres", catalog = "")
class BillOutPlanPO(
        @Id
        @Column(name = "id")
        var id: String? = null,
        @Basic
        @Column(name = "order_id")
        var orderId: String? = null,
        @Basic
        @Column(name = "trade_id")
        var tradeId: String? = null,
        @Basic
        @Column(name = "account_open_bank")
        var accountOpenBank: String? = null,
        @Basic
        @Column(name = "debit_channel")
        @Enumerated(EnumType.STRING)
        var debitChannel: DeductChannel? = null,
        @Basic
        @Column(name = "fund_channel")
        @Enumerated(EnumType.STRING)
        var fundChannel: FundChannel? = null,
        @Basic
        @Column(name = "should_amount")
        var shouldAmount: Int? = null,
        @Basic
        @Column(name = "actual_amount")
        var actualAmount: Int? = null,
        @Basic
        @Column(name = "period_times")
        var periodTimes: Int? = null,
        @Basic
        @Column(name = "mer_id")
        var merId: String? = null,
        @Basic
        @Column(name = "order_trade_time")
        var orderTradeTime: Date? = null,
        @Basic
        @Column(name = "pay_date")
        var payDate: Date? = null,
        @Basic
        @Column(name = "payee_account")
        var payeeAccount: String? = null,
        @Basic
        @Column(name = "payee_bank")
        var payeeBank: String? = null,
        @Basic
        @Column(name = "payee_name")
        var payeeName: String? = null,
        @Basic
        @Column(name = "status")
        @Enumerated(EnumType.STRING)
        var status: Progress? = null,
        @Basic
        @Column(name = "create_by")
        var createBy: String? = null,
        @Basic
        @Column(name = "modify_by")
        var modifyBy: String? = null,
        @Basic
        @Column(name = "modify_time")
        var modifyTime: Date? = null,
        @Basic
        @Column(name = "created_time")
        var createdTime: Date? = null,
        @Basic
        @Column(name = "updated_time")
        var updatedTime: Date? = null,
        @Basic
        @Column(name = "loan_req_no")
        var loanReqNo: String? = null,
        @Basic
        @Column(name = "loan_no")
        var loanNo: String? = null,
        @Basic
        @Column(name = "cont_req_no")
        var contReqNo: String? = null,
        @Basic
        @Column(name = "cont_no")
        var contNo: String? = null,
        @Basic
        @Column(name = "type")
        @Enumerated(EnumType.STRING)
        var type: BillType? = null,
        @Basic
        @Column(name = "audit")
        var audit: Int? = null,
        @Basic
        @Column(name = "province_name")
        var provinceName: String? = null,
        @Basic
        @Column(name = "city_name")
        var cityName: String? = null

)
