package com.fina.summer.persistent.artemis.repo.user

import com.fina.summer.persistent.artemis.entity.domain.user.ManagerUserDO
import org.springframework.data.jpa.repository.JpaRepository

interface ManagerUserRepo : JpaRepository<ManagerUserDO, String> {

    fun findByLoginName(loginName: String): ManagerUserDO?

}