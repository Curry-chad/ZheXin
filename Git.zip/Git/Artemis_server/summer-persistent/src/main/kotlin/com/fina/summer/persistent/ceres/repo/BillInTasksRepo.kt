package com.fina.summer.persistent.ceres.repo

import com.fina.summer.persistent.ceres.entity.constant.BillType
import com.fina.summer.persistent.ceres.entity.domain.BillInTasksPO
import org.springframework.data.jpa.repository.JpaRepository
import org.springframework.data.jpa.repository.Lock
import org.springframework.data.jpa.repository.Modifying
import org.springframework.data.jpa.repository.Query
import org.springframework.data.repository.query.Param
import java.util.*
import javax.persistence.LockModeType

interface BillInTasksRepo : JpaRepository<BillInTasksPO, String> {

    @Lock(value = LockModeType.PESSIMISTIC_WRITE)
    @Query(value = "select t from BillInTasksPO t where t.id =?1 ")
    fun findByIdForUpdate(id: String): Optional<BillInTasksPO>

    fun findByBisTaskId(bisTaskId: String): List<BillInTasksPO>?

    fun findByRequestNo(requestNo: String): BillInTasksPO?

    fun findByTradeIdAndType(tradeId: String, type: BillType): List<BillInTasksPO>?

    fun findByOrderIdAndType(tradeId: String, type: BillType): List<BillInTasksPO>?

    fun findByOrderIdAndId(tradeId: String, id: String): BillInTasksPO?

    @Modifying
    @Query(value = "delete from bill_in_tasks where order_id =?1 and type =?2", nativeQuery = true)
    fun deleteData(orderId:String, type: String)

    @Modifying
    @Query(value = """
        update BillInTasksPO as b
        set
        b.lastExecuteTime = :#{#task.lastExecuteTime},
        b.thirdOrderId = :#{#task.thirdOrderId},
        b.modifyBy = :#{#task.modifyBy}
        where b.id = :#{#task.id}
    """)
    fun saveDefine(@Param("task") task: BillInTasksPO)
}