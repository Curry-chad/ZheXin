package com.fina.summer.persistent.entity.summer.user

import com.fina.summer.core.enum.SellerStatus
import com.google.gson.annotations.Expose
import org.hibernate.annotations.DynamicInsert
import org.hibernate.annotations.DynamicUpdate
import org.hibernate.annotations.GenericGenerator
import org.hibernate.annotations.Parameter
import org.springframework.data.annotation.CreatedDate
import org.springframework.data.annotation.LastModifiedDate
import org.springframework.data.jpa.domain.support.AuditingEntityListener
import java.io.Serializable
import java.util.*
import javax.persistence.*
import javax.validation.constraints.NotNull


@Entity
@DynamicInsert
@DynamicUpdate
@EntityListeners(AuditingEntityListener::class)
data class UserInfo (

        @Id
//        @GeneratedValue(generator = "idGenerator")
//        @GenericGenerator(name = "idGenerator", strategy = "com.fina.summer.persistent.util.SnowGenerator")
        var id: Long? = null,

        var userId: String? = null,

        var appUserId: String? = null,//用户进件ID

        var realname: String? = null,

        @NotNull
        var mobile: String? = null,

        var address: String? = null,

        var idno: String? = null,

        @Column(columnDefinition = "tinyint(1)  comment '人脸识别结果'")
        var faceRecognitionResult: Boolean? = null,

        @Column(columnDefinition = "varchar(255) comment '人脸识别影像件'")
        var faceRecognitionImageUrl: String? = null,

        @Column(columnDefinition = "varchar(512) comment '人脸识别影像分析数据'")
        var faceRecognitionAnalyse: String? = null,

        @Column(columnDefinition = "int(5) comment '人脸识别失败累计次数'")
        var faceRecognitionFailCnt: Int? = null,

        var certBackPicturePath: String? = null,

        var certFrontPicturePath: String? = null,

        var certHandLocalePicturePath: String? = null,//手持身份证照片

        var contactPersonName: String? = null,

        var contactPersonMobile: String? = null,

        var contactPersonRelationship: String? = null,

        @Column(columnDefinition = "varchar(64) comment '设备号'")
        var imei: String? = null,

        @Column(columnDefinition = "int(11) comment '通讯录个数'")
        var contactsNum: Int? = null,

        @Enumerated(EnumType.STRING)
        @Column(columnDefinition = "varchar(12) COMMENT '店员状态，Sleeping：未激活状态，Activated：已激活'")
        var status: SellerStatus? = null,

        @Column(columnDefinition = "varchar(255) COMMENT '信息描述'")
        var message: String? = null,

        @Column(name = "step" ,columnDefinition = "int(10) comment '信息填写步骤 100：完成'")
        var step: Int? = null,

        @Transient
        var operatorCode: String? = null,

        @Transient
        var storeName: String? = null,

        @CreatedDate
        @Expose(deserialize = false)
        var createdTime: Date? = null,

        @LastModifiedDate
        @Expose(deserialize = false)
        var updatedTime: Date? = null

): Serializable