package com.fina.summer.persistent.ceres.repo

import com.fina.summer.persistent.ceres.entity.domain.YeepayPayBillFlowsPO
import org.springframework.data.jpa.repository.JpaRepository

interface YeepayPayBillFlowsRepo : JpaRepository<YeepayPayBillFlowsPO, Long> {
    fun findByClientOrderNumAndYeepayFlowNum(clientOrderNum: String, yeepayFlowNum: String): YeepayPayBillFlowsPO?
}