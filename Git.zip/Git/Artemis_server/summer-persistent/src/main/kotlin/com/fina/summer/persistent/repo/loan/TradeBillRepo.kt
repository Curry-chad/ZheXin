package com.fina.summer.persistent.repo.loan

import com.fina.summer.persistent.entity.loan.TradeBill
import org.apache.ibatis.annotations.Select
import org.springframework.data.jpa.repository.JpaRepository

interface TradeBillRepo : JpaRepository<TradeBill, String> {

    fun findAllByTradeId(tradeId: String):List<TradeBill>
}