package com.fina.summer.persistent.entity.loan

import com.fina.summer.core.enum.AuditStatus
import org.hibernate.annotations.DynamicInsert
import org.hibernate.annotations.DynamicUpdate
import org.hibernate.annotations.GenericGenerator
import org.hibernate.annotations.Parameter
import org.springframework.data.annotation.CreatedDate
import org.springframework.data.annotation.LastModifiedDate
import org.springframework.data.jpa.domain.support.AuditingEntityListener
import java.io.Serializable
import java.sql.Timestamp
import java.util.*
import javax.persistence.*

@Entity
@Table(name = "application_store")
@DynamicInsert
@DynamicUpdate
@EntityListeners(AuditingEntityListener::class)
class ApplicationStore(
        @Id
        @GeneratedValue(generator = "idGenerator")
        @GenericGenerator(name = "idGenerator", strategy = "com.fina.summer.persistent.util.SnowGenerator"
                , parameters = [Parameter(name = "prefix", value = "AST")])
        var id: String? = null,

        @Column(name = "app_mer_id")
        var appMerId: String? = null,

        @Column(name = "store_id")
        var storeId: String? = null,

        @Column(name = "mer_id")
        var merId: String? = null,

        @Column(name = "organization_code")
        var organizationCode: String? = null,

        @Column(name = "organization_name")
        var organizationName: String? = null,

        @Column(name = "store_name")
        var storeName: String? = null,

        @Column(name = "grade")
        var grade: Int? = null,

        @Column(name = "address")
        var address: String? = null,

        @Column(name = "area_code")
        var areaCode: String? = null,

        @Column(name = "store_pic_path")
        var storePicPath: String? = null,

        @Column(columnDefinition = "varchar(32) comment '负责人姓名'")
        var managerName: String?=null,

        @Column(columnDefinition = "varchar(18) comment '负责人手机号'")
        var managerMobile: String?=null,

        @Column(name = "manager_address")
        var managerAddress: String? = null,

        @Column(name = "manager_cert_no")
        var managerCertNo: String? = null,

        @Column(name = "manager_cert_back_picture_path")
        var managerCertBackPicturePath: String? = null,

        @Column(name = "manager_cert_front_picture_path")
        var managerCertFrontPicturePath: String? = null,

        @Column(name = "contact_person_name")
        var contactPersonName: String? = null,

        @Column(name = "contact_person_mobile")
        var contactPersonMobile: String? = null,

        @Column(name = "contact_person_relationship")
        var contactPersonRelationship: String? = null,

        @Column(name = "audit_no")
        var auditNo: String? = null,

        @Column(name = "audit_describe")
        var auditDescribe: String? = null,

        @Column(name = "audit_person")
        var auditPerson: String? = null,

        @Column(name = "audit_time")
        var auditTime: Date? = null,

        @Enumerated(EnumType.STRING)
        var auditStatus: AuditStatus? = null,

        @Column(name = "created_time")
        @CreatedDate
        var createdTime: Date? = null,

        @Column(name = "updated_time")
        @LastModifiedDate
        var updatedTime: Date? = null
): Serializable