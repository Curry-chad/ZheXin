package com.fina.summer.persistent.artemis.repo.user

import com.fina.summer.persistent.artemis.entity.domain.user.ManagerUserInfoDO
import org.springframework.data.jpa.repository.JpaRepository

interface ManagerUserInfoRepo : JpaRepository<ManagerUserInfoDO, Long> {

    fun findByUserId(userId: String): ManagerUserInfoDO

}