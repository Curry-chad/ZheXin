package com.fina.summer.persistent.config

import org.springframework.beans.factory.annotation.Autowired
import org.springframework.beans.factory.annotation.Qualifier
import org.springframework.boot.autoconfigure.orm.jpa.HibernateSettings
import org.springframework.boot.autoconfigure.orm.jpa.JpaProperties
import org.springframework.boot.orm.jpa.EntityManagerFactoryBuilder
import org.springframework.context.annotation.Bean
import org.springframework.context.annotation.Configuration
import org.springframework.data.jpa.repository.config.EnableJpaRepositories
import org.springframework.orm.jpa.JpaTransactionManager
import org.springframework.orm.jpa.LocalContainerEntityManagerFactoryBean
import org.springframework.transaction.PlatformTransactionManager
import org.springframework.transaction.annotation.EnableTransactionManagement
import javax.annotation.Resource
import javax.persistence.EntityManager
import javax.persistence.EntityManagerFactory
import javax.sql.DataSource


@Configuration

@EnableTransactionManagement
@EnableJpaRepositories(
        entityManagerFactoryRef = "entityManagerFactoryArtemis",
        transactionManagerRef = "transactionManagerArtemis",
        basePackages = ["com.fina.summer.persistent.artemis.repo"])
class RepositoryArtemisConfig(
        @Autowired
        private val jpaProperties: JpaProperties,
        @Resource(name = "artemisDataSource")
        private val artemisDS: DataSource
) {

    @Bean(name = ["entityManagerArtemis"])
    fun entityArtemis(builder: EntityManagerFactoryBuilder): EntityManager {
        return entityManagerFactoryArtemis(builder).getObject()!!.createEntityManager()
    }


    @Bean(name = ["entityManagerFactoryArtemis"])
    fun entityManagerFactoryArtemis(builder: EntityManagerFactoryBuilder): LocalContainerEntityManagerFactoryBean {
        return builder
                .dataSource(artemisDS)
                .properties(getVendorProperties())
                .packages(
                        "com.fina.summer.persistent.artemis.entity.domain.user",
                        "com.fina.summer.persistent.artemis.entity.domain") //设置实体类所在位置
                .persistenceUnit("artemisPersistenceUnit")
                .build()
    }

    private fun getVendorProperties(): MutableMap<String, Any>? {
        return jpaProperties.getHibernateProperties(HibernateSettings())
    }

    @Bean(name = ["transactionManagerArtemis"])
    fun transactionManagerArtemis(@Qualifier("entityManagerFactoryArtemis") factory: EntityManagerFactory): PlatformTransactionManager {
        return JpaTransactionManager(factory)
    }
}