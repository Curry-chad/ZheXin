package com.fina.summer.persistent.ceres.entity.vo

import io.swagger.annotations.ApiModelProperty
import java.util.*

data class WithholdingSms (

        @ApiModelProperty("客户手机号")
        val mobile: String? = null,

        @ApiModelProperty("订单创建时间")
        var createdTime : Date?=null,

        @ApiModelProperty("门店名称")
        val storeName:String?=null,

        @ApiModelProperty("套餐名称")
        val name :String?=null,

        @ApiModelProperty("应收金额")
        val shouldAmount:Int?=0,

        @ApiModelProperty("银行卡尾号")
        val payAccount:String?=null,

        @ApiModelProperty("状态")
        var status: String? = null

        )