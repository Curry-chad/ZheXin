package com.fina.summer.persistent.entity.summer

import com.fina.summer.core.enum.AuditStatus
import com.google.gson.annotations.Expose
import org.hibernate.annotations.*
import org.hibernate.annotations.Parameter
import org.springframework.data.annotation.CreatedDate
import org.springframework.data.annotation.LastModifiedDate
import org.springframework.data.jpa.domain.support.AuditingEntityListener
import java.io.Serializable
import java.util.*
import javax.persistence.*
import javax.persistence.Entity

@Entity
@DynamicUpdate
@DynamicInsert
@EntityListeners(AuditingEntityListener::class)
@Where(clause = "delete_flag =false")
data class Store(

        @Id
        @GeneratedValue(generator = "idGenerator")
        @GenericGenerator(name = "idGenerator", strategy = "com.fina.summer.persistent.util.SnowGenerator"
                ,parameters = [Parameter(name = "prefix", value = "STO")])
        var id : String? = null,

        var merId: String? = null,

        @Enumerated(EnumType.STRING)
        var status: AuditStatus? = null,

        var message: String? = null,

        //--- 进件ID
        var appStoreId: String? = null,
        //--- 组织机构代码
        var organizationCode: String? = null,
        //--- 组织机构名称
        var organizationName: String? = null,

        //--- 门店信息
        var storeName: String? = null,
        var grade: Int? = null,
        var address: String?=null,
        var areaCode: String?=null,
        var storePicPath:String?=null,

        //--- 负责人信息
        var managerName: String?=null,
        var managerMobile: String?=null,
        var managerCertNo: String? = null,
        var managerAddress: String? = null,
        var managerCertFrontPicturePath: String? = null,
        var managerCertBackPicturePath: String? = null,

        //--- 其他
        var step: Int? = null,
        var auditCount: Int? = 0,

        @Column(nullable = false)
        var deleteFlag: Boolean = false,

        @CreatedDate
        var createdTime: Date? = null,

        @LastModifiedDate
        var updatedTime: Date? = null

) : Serializable