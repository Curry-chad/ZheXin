package com.fina.summer.persistent.ceres.repo

import com.fina.summer.persistent.ceres.entity.constant.BillType
import com.fina.summer.persistent.ceres.entity.domain.BillOutTasksPO
import org.springframework.data.jpa.repository.JpaRepository

interface BillOutTasksRepo : JpaRepository<BillOutTasksPO, String> {

    fun findByBisTaskId(bisTaskId: String): List<BillOutTasksPO>?

    fun findByOrderIdAndType(orderId: String, type: BillType): BillOutTasksPO?

    fun findByRequestNoAndThirdOrderId(requestNo: String, thirdOrderId: String): BillOutTasksPO?
}