package com.fina.summer.persistent.entity.summer

import java.io.Serializable
import java.util.*

data class StoreVO(

        var storeId: String? = null,

        var storeName: String? = null,

        var bossId: String? = null,

        var starLevel: Int? = 0,

        var address: String? = null,

        var areaName: String? = null,

        var status: String? = null,

        // 审核时间
        var auditTime: Date? = null,

        var createTime: Date? = null,

        var modifyTime: Date? = null

) : Serializable