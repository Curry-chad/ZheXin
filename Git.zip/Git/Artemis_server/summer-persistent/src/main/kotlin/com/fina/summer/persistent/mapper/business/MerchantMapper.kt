package com.fina.summer.persistent.mapper.business

import org.apache.ibatis.annotations.Mapper

@Mapper
interface MerchantMapper {
    fun untiePayee(payeeId: String): Int
}