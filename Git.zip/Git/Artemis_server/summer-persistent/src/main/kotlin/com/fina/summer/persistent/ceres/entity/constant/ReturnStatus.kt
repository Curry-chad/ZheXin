package com.fina.summer.persistent.ceres.entity.constant

enum class ReturnStatus {
    Undefined,
    Success,
    Faild
}