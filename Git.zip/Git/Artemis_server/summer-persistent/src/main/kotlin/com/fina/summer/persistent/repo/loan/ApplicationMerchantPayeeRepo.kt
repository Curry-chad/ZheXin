package com.fina.summer.persistent.repo.loan

import com.fina.summer.persistent.entity.loan.ApplicationMerchantPayee
import org.springframework.data.jpa.repository.JpaRepository

interface ApplicationMerchantPayeeRepo: JpaRepository<ApplicationMerchantPayee,String> {
}