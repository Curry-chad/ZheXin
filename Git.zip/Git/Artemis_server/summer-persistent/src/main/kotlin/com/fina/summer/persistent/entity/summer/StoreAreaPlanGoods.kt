package com.fina.summer.persistent.entity.summer

import org.hibernate.annotations.DynamicInsert
import org.hibernate.annotations.DynamicUpdate
import org.springframework.data.annotation.CreatedDate
import org.springframework.data.annotation.LastModifiedDate
import org.springframework.data.jpa.domain.support.AuditingEntityListener
import java.util.*
import javax.persistence.*

@Entity
@EntityListeners(AuditingEntityListener::class)
@DynamicInsert
@DynamicUpdate
data class StoreAreaPlanGoods (

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    var id: Long? = null,
    
    var storeId: String? = null,

    var adminCode: String? = null,

    var chargePlanGroupId: String? = null,

    var chargePlanId: String? = null,

    var brandId: String? = null,

    var goodsId: String? = null,

    @CreatedDate
    var createdTime: Date? = null,

    @LastModifiedDate
    var updatedTime: Date? = null
)