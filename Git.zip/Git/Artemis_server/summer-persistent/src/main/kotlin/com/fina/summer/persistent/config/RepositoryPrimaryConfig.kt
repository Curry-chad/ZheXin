package com.fina.summer.persistent.config

import org.springframework.beans.factory.annotation.Autowired
import org.springframework.boot.autoconfigure.orm.jpa.HibernateSettings
import org.springframework.boot.autoconfigure.orm.jpa.JpaProperties
import org.springframework.boot.orm.jpa.EntityManagerFactoryBuilder
import org.springframework.context.annotation.Bean
import org.springframework.context.annotation.Configuration
import org.springframework.context.annotation.Primary
import org.springframework.data.jpa.repository.config.EnableJpaRepositories
import org.springframework.orm.jpa.JpaTransactionManager
import org.springframework.orm.jpa.LocalContainerEntityManagerFactoryBean
import org.springframework.transaction.PlatformTransactionManager
import org.springframework.transaction.annotation.EnableTransactionManagement
import javax.annotation.Resource
import javax.persistence.EntityManager
import javax.sql.DataSource


@Configuration

@EnableTransactionManagement
@EnableJpaRepositories(
        entityManagerFactoryRef = "entityManagerFactoryPrimary",
        transactionManagerRef = "transactionManagerPrimary",
        basePackages = ["com.fina.summer.persistent.repo"])
open class RepositoryPrimaryConfig(
        @Autowired
        private val jpaProperties: JpaProperties,
        @Resource(name = "primaryDataSource")
        private val primaryDS: DataSource
) {

    @Bean(name = ["entityManagerPrimary"])
    @Primary
    open fun entityManager(builder: EntityManagerFactoryBuilder): EntityManager {
        return entityManagerFactoryPrimary(builder).getObject()!!.createEntityManager()
    }


    @Bean(name = ["entityManagerFactoryPrimary"])
    @Primary
    open fun entityManagerFactoryPrimary(builder: EntityManagerFactoryBuilder): LocalContainerEntityManagerFactoryBean {
        return builder
                .dataSource(primaryDS)
                .properties(getVendorProperties())
                .packages(
                        "com.fina.summer.persistent.entity.summer.business",
                        "com.fina.summer.persistent.entity.loan",
                        "com.fina.summer.persistent.entity.summer",
                        "com.fina.summer.persistent.entity.summer.user") //设置实体类所在位置
                .persistenceUnit("primaryPersistenceUnit")
                .build()
    }

    private fun getVendorProperties(): MutableMap<String, Any>? {
        return jpaProperties.getHibernateProperties(HibernateSettings())
    }

    @Bean(name = ["transactionManagerPrimary"])
    //@Primary
    open fun transactionManagerPrimary(builder: EntityManagerFactoryBuilder): PlatformTransactionManager {
        return JpaTransactionManager(entityManagerFactoryPrimary(builder).getObject()!!)
    }
}