package com.fina.summer.persistent.ceres.entity.constant

enum class BisTaskType(var type: String) {
    Undefined("undefined"),

    RepayPlan("repay_create"),
    MerRemit("remit_create"),

    RepayPlanCancel("repay_cancel"),
    MerRemitCancel("remit_cancel"),

    RemitInvalid("remit_invalid"),
    RepayInvalid("repay_invalid")
}