package com.fina.summer.persistent.ceres.entity.constant

enum class PayType(var msg: String) {
    Undefined(""),
    Debit("借记卡"),
    debit("借记卡"),
    WeiXin("微信"),
    PhoneBill("话费充值")
}