package com.fina.summer.persistent.ceres.entity.constant

enum class CheckStatus(var status: Int) {
    NoApplyCheck(0),
    ApplyCheck(1)
}