package com.fina.summer.persistent.bean

import com.fina.summer.core.enum.BrandType

class Brand : StoreCodePlanGoods() {

    var id: String? = null

    var name: String? = null

    var type: BrandType? = null

    var firstLetter: String? = null

}