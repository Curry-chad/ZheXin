package com.fina.summer.persistent.ceres.entity.constant

enum class AuditStatus(var status: Int){
    Normal(0),
    InRefundAudit(1),
    RefundSuccess(2),
    RefundFail(3)
}