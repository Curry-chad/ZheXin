package com.fina.summer.persistent.ceres.entity.constant

enum class ResultStatus(var msg:String) {
    Request("请求中"),
    Success("短信发送成功"),
    Failure("短信发送失败")
}