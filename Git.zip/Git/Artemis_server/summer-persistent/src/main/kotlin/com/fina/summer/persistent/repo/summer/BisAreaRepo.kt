package com.fina.summer.persistent.repo.summer

import com.fina.summer.persistent.entity.summer.BisArea
import org.springframework.data.jpa.repository.JpaRepository
import org.springframework.data.jpa.repository.Query

interface BisAreaRepo : JpaRepository<BisArea, Long> {

    @Query("""
        select b from BisArea b group by b.provinceCode
    """)
    fun findProvinces(): MutableList<BisArea>?

    @Query("""
        select b from BisArea b where b.provinceCode = ?1 group by b.cityCode
    """)
    fun findCitysByProvinceCode(provinceCode: String): MutableList<BisArea>?

    fun findAllByCityCode(cityCode: String): MutableList<BisArea>?

    fun findByCode(areaCode: String): BisArea?

    fun countByName(name: String): Long

    fun countByCityName(cityName: String): Long

    fun countByProvinceName(provinceName: String): Long

}