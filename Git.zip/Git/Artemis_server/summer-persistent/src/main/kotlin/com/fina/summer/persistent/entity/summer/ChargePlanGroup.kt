package com.fina.summer.persistent.entity.summer

import org.hibernate.annotations.DynamicInsert
import org.hibernate.annotations.DynamicUpdate
import org.hibernate.annotations.GenericGenerator
import org.hibernate.annotations.Parameter
import org.springframework.data.annotation.CreatedDate
import org.springframework.data.annotation.LastModifiedDate
import org.springframework.data.jpa.domain.support.AuditingEntityListener
import java.io.Serializable
import java.util.*
import javax.persistence.*

@Entity
@Table(name = "charge_plan_group")
@EntityListeners(AuditingEntityListener::class)
@DynamicInsert
@DynamicUpdate
data class ChargePlanGroup (
    @Id
    @Column(name = "id")
//    @GeneratedValue(generator = "idGenerator")
//    @GenericGenerator(name = "idGenerator", strategy = "com.fina.summer.persistent.util.SnowGenerator"
//            , parameters = [Parameter(name = "prefix", value = "CPG")])
    var id: String? = null,

    @Column(name = "name")
    var name: String? = null,

    @Column(name = "created_time")
    @CreatedDate
    var createdTime: Date? = null,

    @Column(name = "updated_time")
    @LastModifiedDate
    var updatedTime: Date? = null
): Serializable
