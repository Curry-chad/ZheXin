package com.fina.summer.persistent.ceres.repo

import com.fina.summer.persistent.ceres.entity.domain.ShortMessageFlowPO
import org.springframework.data.jpa.repository.JpaRepository

interface ShortMessageFlowRepo : JpaRepository<ShortMessageFlowPO, String>