package com.fina.summer.persistent.ceres.entity.constant

enum class YeePayStatus{
    PAY_SUCCESS
}