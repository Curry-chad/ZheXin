package com.fina.summer.persistent.ceres.entity

import java.io.Serializable

data class BillInQueryParam(

        var planExecuteTime: String? = null,

        var seqNo: Int? = null,

        var overdueDays: Int? = null,

        var payer: String? = null,

        var merName: String? = null

): Serializable