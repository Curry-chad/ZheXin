package com.fina.summer.persistent.artemis.mapper

import com.fina.summer.persistent.artemis.entity.domain.ManagerRoleDO
import org.apache.ibatis.annotations.Mapper

@Mapper
interface ManagerRoleMapper {

    fun listByUserId(userId: String): List<ManagerRoleDO>
}