package com.fina.summer.persistent.ceres.repo

import com.fina.summer.persistent.ceres.entity.domain.FailHandleFromKafkaPO
import org.springframework.data.jpa.repository.JpaRepository

interface FailHandleFromKafkaRepo : JpaRepository<FailHandleFromKafkaPO, String>