package com.fina.summer.persistent.ceres.entity.domain

import com.fina.summer.persistent.ceres.entity.constant.FlowStatus
import com.fina.summer.persistent.ceres.entity.constant.PayType
import org.hibernate.annotations.DynamicInsert
import org.hibernate.annotations.DynamicUpdate
import java.io.Serializable
import java.util.*
import javax.persistence.*

@Entity
@DynamicInsert
@DynamicUpdate
@Table(name = "bill_in_flow", schema = "ceres", catalog = "")
data class BillInFlowDO (
    @Id
    @Column(name = "id")
    var id: String? = null,
    @Basic
    @Column(name = "amount")
    var amount: Int? = null,
    @Basic
    @Column(name = "create_by")
    var createBy: String? = null,
    @Basic
    @Column(name = "create_time")
    var createTime: Date? = null,
    @Basic
    @Column(name = "execute_time")
    var executeTime: Date? = null,
    @Basic
    @Column(name = "message")
    var message: String? = null,
    @Basic
    @Column(name = "modify_by")
    var modifyBy: String? = null,
    @Basic
    @Column(name = "modify_time")
    var modifyTime: Date? = null,
    @Basic
    @Column(name = "pay_account")
    var payAccount: String? = null,
    @Basic
    @Column(name = "pay_type")
    @Enumerated(EnumType.STRING)
    var payType: PayType? = null,
    @Basic
    @Column(name = "payer")
    var payer: String? = null,
    @Basic
    @Column(name = "payer_idno")
    var payerIdno: String? = null,
    @Basic
    @Column(name = "penalty")
    var penalty: Int? = null,
    @Basic
    @Column(name = "request_no")
    var requestNo: String? = null,
    @Basic
    @Column(name = "status")
    @Enumerated(EnumType.STRING)
    var status: FlowStatus? = null,
    @Basic
    @Column(name = "task_id")
    var taskId: String? = null,
    @Basic
    @Column(name = "third_order_id")
    var thirdOrderId: String? = null,
    @Basic
    @Column(name = "trade_id")
    var tradeId: String? = null,
    @Basic
    @Column(name = "bis_task_id")
    var bisTaskId: String? = null
): Serializable
