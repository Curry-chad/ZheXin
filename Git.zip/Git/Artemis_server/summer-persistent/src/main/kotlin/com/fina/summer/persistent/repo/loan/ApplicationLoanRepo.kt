package com.fina.summer.persistent.repo.loan

import com.fina.summer.persistent.entity.loan.ApplicationLoan
import org.springframework.data.jpa.repository.JpaRepository

interface ApplicationLoanRepo : JpaRepository<ApplicationLoan, String> {

}