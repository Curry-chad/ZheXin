package com.fina.summer.persistent.ceres.entity.domain

import java.io.Serializable
import java.util.*
import javax.persistence.*

@Entity
@Table(name = "yeepay_pay_bill_flows", schema = "ceres", catalog = "")
class YeepayPayBillFlowsPO (
        @Id
    @Column(name = "id")
    var id: Long = 0,
        @Basic
    @Column(name = "merchant_code")
    var merchantCode: String? = null,
        @Basic
    @Column(name = "client_order_num")
    var clientOrderNum: String? = null,
        @Basic
    @Column(name = "yeepay_flow_num")
    var yeepayFlowNum: String? = null,
        @Basic
    @Column(name = "request_time")
    var requestTime: String? = null,
        @Basic
    @Column(name = "order_amount")
    var orderAmount: Int? = null,
        @Basic
    @Column(name = "service_charge")
    var serviceCharge: Int? = null,
        @Basic
    @Column(name = "auth_charge")
    var authCharge: Int? = null,
        @Basic
    @Column(name = "pay_charge")
    var payCharge: Int? = null,
        @Basic
    @Column(name = "clearing_time")
    var clearingTime: String? = null,
        @Basic
    @Column(name = "merchant_batch_num")
    var merchantBatchNum: String? = null,
        @Basic
    @Column(name = "yeepay_batch_num")
    var yeepayBatchNum: String? = null,
        @Basic
    @Column(name = "trade_time")
    var tradeTime: String? = null,
        @Basic
    @Column(name = "remark")
    var remark: String? = null,
        @Basic
    @Column(name = "pay_status")
    var payStatus: String? = null,
        @Basic
    @Column(name = "pay_method")
    var payMethod: String? = null,
        @Basic
    @Column(name = "terminal_num")
    var terminalNum: String? = null,
        @Basic
    @Column(name = "client_name")
    var clientName: String? = null,
        @Basic
    @Column(name = "card_num")
    var cardNum: String? = null,
        @Basic
    @Column(name = "flow_date")
    var flowDate: Date? = null,
        @Basic
    @Column(name = "created_time")
    var createdTime: Date? = null,
        @Basic
    @Column(name = "updated_time")
    var updatedTime: Date? = null
): Serializable
