package com.fina.summer.persistent.util

import com.fina.summer.core.utils.IdGenerator
import org.hibernate.engine.spi.SharedSessionContractImplementor
import org.hibernate.id.Configurable
import org.hibernate.id.IdentifierGenerator
import org.hibernate.service.ServiceRegistry
import org.hibernate.type.Type
import java.io.Serializable
import java.util.*

open class SnowGenerator : IdentifierGenerator,Configurable {

    open var prefix: String? = ""

    override fun configure(p0: Type?, p1: Properties?, p2: ServiceRegistry?){
        this.prefix = p1?.getProperty("prefix")
    }

    /**
     * Generate a new identifier.
     *
     * @param session The session from which the request originates
     * @param object the entity or collection (idbag) for which the id is being generated
     *
     * @return a new identifier
     *
     * @throws HibernateException Indicates trouble generating the identifier
     */
    override fun generate(session: SharedSessionContractImplementor?, any: Any?): Serializable {
        if(prefix == null || prefix == ""){
            return IdGenerator.nextId()
        }
        return prefix + IdGenerator.nextId()
    }
}