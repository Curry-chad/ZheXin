package com.fina.summer.persistent.config

import org.apache.ibatis.session.SqlSessionFactory
import org.mybatis.spring.SqlSessionFactoryBean
import org.mybatis.spring.annotation.MapperScan
import org.springframework.beans.factory.annotation.Qualifier
import org.springframework.boot.SpringBootConfiguration
import org.springframework.context.annotation.Bean
import org.springframework.core.io.support.PathMatchingResourcePatternResolver
import org.springframework.jdbc.datasource.DataSourceTransactionManager
import javax.sql.DataSource

@SpringBootConfiguration
@MapperScan(basePackages = ["com.fina.summer.persistent.ceres.mapper"], sqlSessionFactoryRef = "ceresSessionFactory")
open class CeresMybatisConfig {
    @Bean("ceresSessionFactory")
    open fun mysqlSessionFactory(@Qualifier("ceresDataSource") mysqlDataSource: DataSource): SqlSessionFactory {
        val bean = SqlSessionFactoryBean()
        val configuration = org.apache.ibatis.session.Configuration()
        configuration.isMapUnderscoreToCamelCase = true
        bean.setConfiguration(configuration)
        bean.setDataSource(mysqlDataSource)
        bean.setMapperLocations(PathMatchingResourcePatternResolver().getResources("classpath*:mapper/ceres/*.xml"))
        return bean.getObject()!!
    }


    @Bean("ceresTransactionManager")
    open fun clusterTransactionManager(@Qualifier("ceresDataSource") dataSource: DataSource): DataSourceTransactionManager {
        return DataSourceTransactionManager(dataSource)
    }


}