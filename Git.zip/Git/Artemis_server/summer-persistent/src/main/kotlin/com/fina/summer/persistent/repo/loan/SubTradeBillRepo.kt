package com.fina.summer.persistent.repo.loan

import com.fina.summer.core.enum.Progress
import com.fina.summer.persistent.entity.loan.SubTradeBill
import org.springframework.data.jpa.repository.JpaRepository
import java.util.*

interface SubTradeBillRepo : JpaRepository<SubTradeBill, String> {
    //    fun findAllByStatusAndPeriodDateLessThanEqual(doing: Progress, date: Date):List<SubTradeBill>
    fun findAllByStatusInAndPeriodDateLessThanEqual(list: List<Progress>, date: Date): List<SubTradeBill>

    fun findByRequestNo(s: String?): Optional<SubTradeBill>
    fun findAllByBillId(billId: String): List<SubTradeBill>
    fun findAllByTradeId(tradeId: String): List<SubTradeBill>

}