package com.fina.summer.persistent.ceres.entity.constant

enum class FlowStatus(var msg: String) {
    Success("成功"),
    Fail("失败")
}