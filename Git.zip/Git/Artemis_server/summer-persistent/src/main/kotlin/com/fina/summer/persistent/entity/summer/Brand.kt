package com.fina.summer.persistent.entity.summer

import com.fina.summer.core.enum.BrandType
import org.hibernate.annotations.DynamicInsert
import org.hibernate.annotations.DynamicUpdate
import org.hibernate.annotations.GenericGenerator
import org.hibernate.annotations.Parameter
import org.springframework.data.annotation.CreatedDate
import org.springframework.data.annotation.LastModifiedDate
import org.springframework.data.jpa.domain.support.AuditingEntityListener
import java.io.Serializable
import java.util.*
import javax.persistence.*

@Entity
@DynamicUpdate
@DynamicInsert
@EntityListeners(AuditingEntityListener::class)
data class Brand (
    @Id
    @GeneratedValue(generator = "idGenerator")
    @GenericGenerator(name = "idGenerator", strategy = "com.fina.summer.persistent.util.SnowGenerator"
            , parameters = [Parameter(name = "prefix", value = "BRA")])
    @Column(columnDefinition = "varchar(32) COMMENT '品牌编号'")
    var id: String? = null,
    @Column(columnDefinition = "varchar(32) COMMENT '品牌名称'")
    var name: String? = null,
    @Enumerated(EnumType.STRING)
    @Column(columnDefinition = "varchar(32) COMMENT '品牌类型 hot:热门机型，others:其它'")
    var type: BrandType? = null,
    @Column(columnDefinition = "varchar(8) COMMENT '品牌首字母'")
    var firstLetter: String? = null,

    @CreatedDate
    var createdTime: Date? = null,
    @LastModifiedDate
    var updatedTime: Date? = null

): Serializable