package com.fina.summer.persistent.ceres.entity.constant

enum class FundChannel(var fundChannelName: String) {
    None(""),
    Zx("哲信"),
    Zyxj("中原消金"),
    Zyxf("中原消金"),
    Undefine("未定义")
}