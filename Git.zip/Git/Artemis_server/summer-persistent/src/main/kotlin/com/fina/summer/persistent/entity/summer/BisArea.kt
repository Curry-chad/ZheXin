package com.fina.summer.persistent.entity.summer

import org.hibernate.annotations.DynamicInsert
import org.hibernate.annotations.DynamicUpdate
import org.springframework.data.annotation.CreatedDate
import org.springframework.data.annotation.LastModifiedDate
import org.springframework.data.jpa.domain.support.AuditingEntityListener
import java.io.Serializable
import java.util.*
import javax.persistence.*

@Entity
@DynamicUpdate
@DynamicInsert
@EntityListeners(AuditingEntityListener::class)
data class BisArea (
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    var id: Long = 0,

    @Column(name = "code")
    var code: String? = null,

    @Column(name = "name")
    var name: String? = null,

    @Column(name = "city_name")
    var cityName: String? = null,

    @Column(name = "city_code")
    var cityCode: String? = null,

    @Column(name = "province_name")
    var provinceName: String? = null,

    @Column(name = "province_code")
    var provinceCode: String? = null,

    @Column(name = "nation")
    var nation: String? = null,

    @Column(name = "name_en")
    var nameEn: String? = null,

    @Column(name = "short_name_en")
    var shortNameEn: String? = null,

    @Column(name = "admin_code")
    var adminCode: String? = null,

    @Column(columnDefinition = "bit(1) default b'1' comment '地区办单权限'")
    var permission: Boolean? = true,

    @Column(name = "created_time")
    @CreatedDate
    var createdTime: Date? = null,

    @Column(name = "updated_time")
    @LastModifiedDate
    var updatedTime: Date? = null

): Serializable
