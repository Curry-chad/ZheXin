package com.fina.summer.persistent.entity.loan

import com.fina.summer.core.enum.AuditStatus
import com.fina.summer.core.enum.BusinessType
import com.fina.summer.core.enum.GoodsType
import com.google.gson.annotations.Expose
import org.hibernate.annotations.DynamicInsert
import org.hibernate.annotations.DynamicUpdate
import org.hibernate.annotations.GenericGenerator
import org.hibernate.annotations.Parameter
import org.springframework.data.annotation.CreatedDate
import org.springframework.data.annotation.LastModifiedDate
import org.springframework.data.jpa.domain.support.AuditingEntityListener
import java.io.Serializable
import java.util.*
import javax.persistence.*


@Entity
@DynamicInsert
@DynamicUpdate
@EntityListeners(AuditingEntityListener::class)
data class ApplicationLoan(

        @Id
        @GeneratedValue(generator = "idGenerator")
        @GenericGenerator(name = "idGenerator", strategy = "com.fina.summer.persistent.util.SnowGenerator"
                , parameters = [Parameter(name = "prefix", value = "ALO")])
        var id: String? = null,

        var orderId: String? = null,

        var orderTime: Date? = null,

        @Enumerated(EnumType.STRING)
        var businessType: BusinessType? = null,//业务类型：购机直降、话费降息、

        var remark: String? = null,

        var sellerUserId: String? = null,//店员ID

        @Column(columnDefinition = "varchar(32) comment '店员ID'")
        var sellerId: String? = null,

        var storeId: String? = null,

        @Column(columnDefinition = "varchar(32) comment '用户进件ID'")
        var appUserId: String? = null,

        @Column(columnDefinition = "varchar(32) comment '门店进件ID'")
        var appStoreId: String? = null,

        @Column(columnDefinition = "varchar(32) comment '商户进件ID'")
        var appMerId: String? = null,

        var merId: String? = null,

        var areaCode: String? = null,//省市区统一编码

        var goodsCode: String? = null,//

        var goodsId: String? = null,

        var goodsPrice: Int? = null,

        var goodsName: String? = null,

        @Column(columnDefinition = "varchar(32) comment '商品类型'")
        @Enumerated(EnumType.STRING)
        var goodsType: GoodsType? = null,

        var applicantId: String? = null,

        var chargePlanGroupId: String? = null,

        var chargePlanId: String? = null,

        var telecomAgreementNo: String? = null,

        var telecomAgreementPic: String? = null,

        var telecomOrderNo: String? = null,

        var sellerClientPhoto: String? = null,

        @Column(columnDefinition = "int(11) COMMENT '商家应收金额'")
        var needReceive: Int? = null,//优惠价格

        @Column(columnDefinition = "int(11) COMMENT '用户应付金额'")
        var needPayment: Int? = null,

        @Column(columnDefinition = "int(11) COMMENT '分期数'")
        var installmentNum: Int? = 24,

        @Column(columnDefinition = "double COMMENT '利率，商户承担下应该以用户实际支付金额为本金计算利率'")
        var interestRate: Double? = null,

        @Column(columnDefinition = "int(11) COMMENT '每月还款金额'")
        var monthlyRepaymentAmount: Int? = null,

        @Column(columnDefinition = "varchar(32) comment '店员生成二维码的经度'")
        var longitude: String? = null,

        @Column(columnDefinition = "varchar(32) comment '店员生成二维码的纬度'")
        var latitude: String? = null,

        @Column(columnDefinition = "varchar(32) comment '店员生成二维码的IP'")
        var clientIp: String? = null,

        var auditNo: String? = null,

        var auditDescribe: String? = null,

        var auditPerson: String? = null,

        var auditTime: Date? = null,

        @Enumerated(EnumType.STRING)
        var auditStatus: AuditStatus? = null,

        @CreatedDate
        @Expose(deserialize = false)
        var createdTime: Date? = null,

        @LastModifiedDate
        @Expose(deserialize = false)
        var updatedTime: Date? = null,

        @Transient
        var appLoanApplicant: ApplicationLoanApplicant? = null


) : Serializable