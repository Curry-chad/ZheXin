package com.fina.summer.persistent.ceres.repo

import com.fina.summer.persistent.ceres.entity.constant.BillType
import com.fina.summer.persistent.ceres.entity.domain.BillRepayPlanPO
import org.apache.ibatis.annotations.Param
import org.springframework.data.jpa.repository.JpaRepository
import org.springframework.data.jpa.repository.Modifying
import org.springframework.data.jpa.repository.Query

interface BillRepayPlanRepo : JpaRepository<BillRepayPlanPO, String> {

    fun findByIdIn(ids: Set<String>): List<BillRepayPlanPO>

    fun findByTradeIdAndType(tradeId: String, type: BillType): BillRepayPlanPO?

    fun findByOrderIdAndType(orderId: String,type: BillType): BillRepayPlanPO?

    @Modifying
    @Query(value = "delete from bill_repay_plan where order_id =?1 and type =?2 ", nativeQuery = true)
    fun deleteData(orderId:String, type: String)
}