package com.fina.summer.persistent.ceres.entity.constant

enum class Progress {
    Ready,
    Cancel,
    Doing,
    Interrupt,
    Success,
    Fail,
    Error,
    Prepare
}

