package com.fina.summer.persistent.entity.summer

import org.hibernate.annotations.DynamicInsert
import org.hibernate.annotations.DynamicUpdate
import org.springframework.data.annotation.CreatedDate
import org.springframework.data.annotation.LastModifiedDate
import org.springframework.data.jpa.domain.support.AuditingEntityListener
import java.io.Serializable
import java.util.*
import javax.persistence.*

@Entity
@EntityListeners(AuditingEntityListener::class)
@DynamicInsert
@DynamicUpdate
data class EventTrack (

        @Id
        @GeneratedValue(strategy = GenerationType.IDENTITY)
        var id: Long? = null,

        @Column(columnDefinition = "datetime comment '事件时间'")
        var eventTime: Date? = null,

        @Column(columnDefinition = "varchar(32) comment '步骤'")
        var action: String? = null,

        @Column(columnDefinition = "varchar(64) comment '会话ID'")
        var sessionId: String? = null,

        @Column(columnDefinition = "varchar(64) comment '链路ID'")
        var trackId: String? = null,

        @Column(columnDefinition = "varchar(32) comment '店员的用户ID'")
        var userId: String? = null,

        @Column(columnDefinition = "varchar(32) comment '门店ID'")
        var storeId: String? = null,

        @Column(columnDefinition = "varchar(32) comment '客户身份证号'")
        var idno: String? = null,

        @Column(columnDefinition = "varchar(32) comment '订单号'")
        var orderId: String? = null,

        @Column(columnDefinition = "varchar(32) comment '交易单ID'")
        var tradeId: String? = null,

        @Column(columnDefinition = "varchar(255) comment '表单数据'")
        var formData: String? = null,

        @Column(columnDefinition = "varchar(1024) comment '图片信息'")
        var pictures: String? = null,

        @Column(columnDefinition = "varchar(255) comment '扩展参数'")
        var exparams: String? = null,

        @Column(name = "created_time",columnDefinition = "datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间'")
        @CreatedDate
        var createdTime: Date? = null,

        @Column(name = "updated_time",columnDefinition = "datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间'")
        @LastModifiedDate
        var updatedTime: Date? = null
): Serializable