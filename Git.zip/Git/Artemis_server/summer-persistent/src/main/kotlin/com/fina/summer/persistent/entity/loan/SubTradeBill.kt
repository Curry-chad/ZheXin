package com.fina.summer.persistent.entity.loan

import com.fina.summer.core.enum.Progress
import org.hibernate.annotations.DynamicInsert
import org.hibernate.annotations.DynamicUpdate
import org.hibernate.annotations.GenericGenerator
import org.hibernate.annotations.Parameter
import org.springframework.data.annotation.CreatedDate
import org.springframework.data.annotation.LastModifiedDate
import org.springframework.data.jpa.domain.support.AuditingEntityListener
import java.io.Serializable
import java.util.*
import javax.persistence.*

@Entity
@DynamicInsert
@DynamicUpdate
@EntityListeners(AuditingEntityListener::class)
class SubTradeBill(
        @Id
        @GeneratedValue(generator = "idGenerator")
        @GenericGenerator(name = "idGenerator", strategy = "com.fina.summer.persistent.util.SnowGenerator"
                , parameters = [Parameter(name = "prefix", value = "RB")])
        @Column(columnDefinition = "varchar(32) comment '子账单号'")
        var id: String? = null,

        @Column(columnDefinition = "varchar(32) comment '账单号'")
        var billId: String? = null,

        @Column(columnDefinition = "varchar(32) comment '支付请求号'", unique = true)
        var requestNo: String? = null,

        @Column(columnDefinition = "int comment '序列号'")
        var seqNo: Int? = null,

        @Column(columnDefinition = "varchar(32) comment '交易单号'")
        var tradeId: String? = null,

        @Column(columnDefinition = "date comment '帐期,年月日'")
        var periodDate: Date? = null,

        @Column(columnDefinition = "varchar(64) comment '客户身份证ID'")
        var idCardNo: String? = null,

        @Column(columnDefinition = "varchar(64) comment '银行卡号'")
        var bankCardNo: String? = null,

        @Column(columnDefinition = "int comment '金额（分）,支出为负数，收入为正数'")
        var shouldAmount: Int? = null,

        @Column(columnDefinition = "int comment '金额（分）,支出为负数，收入为正数'")
        var actualAmount: Int? = null,

        @Column(columnDefinition = "int comment '金额（分）,违约金'")
        var penalty: Int? = null,

        @Column(columnDefinition = "datetime comment '交易时间'")
        var tradeTime: Date? = null,

        @Enumerated(EnumType.STRING)
        @Column(columnDefinition = "varchar(64) comment '账单状态'")
        var status: Progress? = null,

        @Column(columnDefinition = "varchar(255) comment '描述'")
        var message: String? = null,

        @Column(columnDefinition = "varchar(64) comment ''")
        var thirdOrderId: String? = null,

        @Column(columnDefinition = "datetime comment '创建时间'")
        @CreatedDate
        var createdTime: Date? = null,

        @Column(columnDefinition = "datetime comment '修改时间'")
        @LastModifiedDate
        var updatedTime: Date? = null

) : Serializable