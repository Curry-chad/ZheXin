package com.fina.summer.persistent.config

import org.apache.ibatis.session.SqlSessionFactory
import org.mybatis.spring.SqlSessionFactoryBean
import org.mybatis.spring.annotation.MapperScan
import org.springframework.beans.factory.annotation.Qualifier
import org.springframework.boot.SpringBootConfiguration
import org.springframework.context.annotation.Bean
import org.springframework.core.io.support.PathMatchingResourcePatternResolver
import org.springframework.jdbc.datasource.DataSourceTransactionManager
import javax.sql.DataSource

@SpringBootConfiguration
@MapperScan(basePackages = ["com.fina.summer.persistent.artemis.mapper"], sqlSessionFactoryRef = "artemisSessionFactory")
open class ArtemisMybaitisConfig {
    @Bean("artemisSessionFactory")
    open fun mysqlSessionFactory(@Qualifier("artemisDataSource") mysqlDataSource: DataSource): SqlSessionFactory {
        val bean = SqlSessionFactoryBean()
        val configuration = org.apache.ibatis.session.Configuration()
        configuration.isMapUnderscoreToCamelCase = true
        bean.setConfiguration(configuration)
        bean.setDataSource(mysqlDataSource)
        bean.setMapperLocations(PathMatchingResourcePatternResolver().getResources("classpath*:mapper/artemis/*.xml"))
        return bean.getObject()!!
    }


    @Bean("artemisTransactionManager")
    open fun clusterTransactionManager(@Qualifier("artemisDataSource") dataSource: DataSource): DataSourceTransactionManager {
        return DataSourceTransactionManager(dataSource)
    }


}