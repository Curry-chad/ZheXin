package com.fina.summer.persistent.ceres.entity.vo

import com.fina.summer.persistent.ceres.entity.domain.BillOutTasksPO
import java.io.Serializable
import javax.print.attribute.standard.MediaSize

data class BatchAuditVO(

        var date: String?=null,

        var total: Int?=null,

        var payer: String?=null,

        var payAccount: String?=null,

        var payBank: String?=null,

        var modifyBy: String?=null,

        var repeate: List<String>? = null,

        var withoutOrder: List<String>? = null,

        var withoutAccount: List<String>? = null,

        var more: List<String>? = null,

        var wrongAmount: List<String>? = null,

        var wrongAmountNum: Int?=null,

        var success: List<BillSimpleVO>? = null,

        var other: List<BillSimpleVO>? = null

): Serializable