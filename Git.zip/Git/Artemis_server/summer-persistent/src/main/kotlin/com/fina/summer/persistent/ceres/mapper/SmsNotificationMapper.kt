package com.fina.summer.persistent.ceres.mapper

import com.fina.summer.persistent.ceres.entity.constant.ResultStatus
import com.fina.summer.persistent.ceres.entity.domain.ResultSendSms
import com.fina.summer.persistent.ceres.entity.vo.MultiSms
import com.fina.summer.persistent.ceres.entity.vo.SmsVO
import com.fina.summer.persistent.ceres.entity.vo.WithholdingSms
import org.apache.ibatis.annotations.Mapper
import org.apache.ibatis.annotations.Param
import org.springframework.stereotype.Component

@Mapper
@Component
interface SmsNotificationMapper {
    //#=========储蓄卡短信类===============
    //储蓄卡正常提醒
    fun findInfoAboutSendSms():List<SmsVO>
    //储蓄卡还款日
    fun findInfoSendSmsByTaskId(@Param("id") id: String): SmsVO?
    //储蓄卡逾期用户
    fun findInfoSendMultiphaseSms():List<MultiSms>

    //#=========打扣代缴短信类===============
    //代扣代缴（不兜底）
    fun findInfoSendWithholding():List<WithholdingSms>

    //短信记录save
    fun insertSendSms(list:List<ResultSendSms>)
    //根据mobile和批次号 修改状态status
    fun updateStatus(@Param("mobile")mobile: String,
                     @Param("outMsgId")outMsgId: String,
                     @Param("status")status: String)



}