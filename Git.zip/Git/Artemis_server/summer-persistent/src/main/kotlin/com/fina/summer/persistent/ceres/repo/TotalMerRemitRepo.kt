package com.fina.summer.persistent.ceres.repo

import com.fina.summer.persistent.ceres.entity.domain.TotalMerRemitDO
import org.springframework.data.jpa.repository.JpaRepository

interface TotalMerRemitRepo : JpaRepository<TotalMerRemitDO, String>