package com.fina.summer.persistent.entity.summer.user

import org.hibernate.annotations.DynamicInsert
import org.hibernate.annotations.DynamicUpdate
import org.springframework.data.annotation.CreatedDate
import org.springframework.data.annotation.LastModifiedDate
import org.springframework.data.jpa.domain.support.AuditingEntityListener
import java.io.Serializable
import java.util.*
import javax.persistence.*


@Entity
@DynamicInsert
@DynamicUpdate
@EntityListeners(AuditingEntityListener::class)
class UserContacts
(
        @Id
        @GeneratedValue(strategy = GenerationType.IDENTITY)
        var id: Long? = null,

        @Column(columnDefinition = "varchar(32) comment '用户ID'")
        var userId: String? = null,

        @Column(columnDefinition = "varchar(32) comment '联系人姓名'")
        var contactName: String? = null,

        @Column(columnDefinition = "text comment '联系人明细'")
        var contactDetail: String? = null,

        @CreatedDate
        var createdTime: Date? = null,

        @LastModifiedDate
        var updatedTime: Date? = null
): Serializable