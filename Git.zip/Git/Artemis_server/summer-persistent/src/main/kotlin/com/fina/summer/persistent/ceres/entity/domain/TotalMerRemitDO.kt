package com.fina.summer.persistent.ceres.entity.domain

import com.fina.summer.persistent.ceres.entity.constant.TotalMerStatus
import org.hibernate.annotations.DynamicInsert
import org.hibernate.annotations.DynamicUpdate
import java.io.Serializable
import java.util.*
import javax.persistence.*

@Entity
@DynamicInsert
@DynamicUpdate
@Table(name = "total_mer_remit", schema = "ceres", catalog = "")
class TotalMerRemitDO(
        @Id
        @Column(name = "id")
        var id: String? = null,
        @Basic
        @Column(name = "account_open_bank")
        var accountOpenBank: String? = null,
        @Basic
        @Column(name = "actual_amount")
        var actualAmount: Int? = null,
        @Basic
        @Column(name = "create_by")
        var createBy: String? = null,
        @Basic
        @Column(name = "create_time")
        var createTime: Date? = null,
        @Basic
        @Column(name = "debit_channel")
        var debitChannel: String? = null,
        @Basic
        @Column(name = "fund_channel")
        var fundChannel: String? = null,
        @Basic
        @Column(name = "left_period_times")
        var leftPeriodTimes: Int? = null,
        @Basic
        @Column(name = "mer_id")
        var merId: String? = null,
        @Basic
        @Column(name = "modify_by")
        var modifyBy: String? = null,
        @Basic
        @Column(name = "modify_time")
        var modifyTime: Date? = null,
        @Basic
        @Column(name = "order_id")
        var orderId: String? = null,
        @Basic
        @Column(name = "order_trade_time")
        var orderTradeTime: Date? = null,
        @Basic
        @Column(name = "pay_date")
        var payDate: Date? = null,
        @Basic
        @Column(name = "payee_account")
        var payeeAccount: String? = null,
        @Basic
        @Column(name = "payee_bank")
        var payeeBank: String? = null,
        @Basic
        @Column(name = "payee_name")
        var payeeName: String? = null,
        @Basic
        @Column(name = "period_times")
        var periodTimes: Int? = null,
        @Basic
        @Column(name = "should_amount")
        var shouldAmount: Int? = null,
        @Basic
        @Column(name = "status")
        @Enumerated(EnumType.STRING)
        var status: TotalMerStatus? = null,
        @Basic
        @Column(name = "trade_id")
        var tradeId: String? = null
) : Serializable
