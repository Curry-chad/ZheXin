package com.fina.summer.persistent.repo.summer

import com.fina.summer.persistent.entity.summer.ChargePlan
import org.springframework.data.jpa.repository.JpaRepository
import org.springframework.data.jpa.repository.Query

interface ChargePlanRepo: JpaRepository<ChargePlan,String> {
    fun findByName(name: String): ChargePlan?

    @Query("""
        select id
        from charge_plan
        order by id desc limit 1
    """, nativeQuery = true)
    fun getLastId(): String

    fun findAllByGroupId(id: String): List<ChargePlan>?
}