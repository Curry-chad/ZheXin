package com.fina.summer.persistent.entity.summer

import com.fina.summer.core.enum.ApplicantProperty
import org.hibernate.annotations.DynamicInsert
import org.hibernate.annotations.DynamicUpdate
import org.hibernate.annotations.GenericGenerator
import org.hibernate.annotations.Parameter
import org.springframework.data.annotation.CreatedDate
import org.springframework.data.annotation.LastModifiedDate
import org.springframework.data.jpa.domain.support.AuditingEntityListener
import java.io.Serializable
import java.util.*
import javax.persistence.*

@Entity
@DynamicInsert
@DynamicUpdate
@EntityListeners(AuditingEntityListener::class)
data class LoanOrderApplicant(

        @Id
        @GeneratedValue(generator = "idGenerator")
        @GenericGenerator(name = "idGenerator", strategy = "com.fina.summer.persistent.util.SnowGenerator"
                , parameters = [Parameter(name = "prefix", value = "ORA")])
        var id: String? = null,

        @Column(columnDefinition = "varchar(32) comment '申请人进件ID'")
        var appLoanApplicantId: String? = null,

        @Column(columnDefinition = "varchar(32) comment '订单ID'")
        var orderId: String? = null,

        @Column(columnDefinition = "varchar(32) comment '店员ID'")
        var sellerId: String? = null,

        @Column(columnDefinition = "varchar(32) comment '门店ID'")
        var storeId: String? = null,

        @Column(columnDefinition = "varchar(32) comment '真实姓名'")
        var realname: String? = null,

        @Column(columnDefinition = "varchar(32) comment '身份证号'")
        var idno: String? = null,

        @Column(columnDefinition = "varchar(16) comment '手机号'")
        var mobile: String? = null,

        @Column(name = "id_card_valid_long_time_flag", columnDefinition = "bit(1) default b'1' comment '身份证是否长期有效'")
//        @JsonProperty(value = "isIdCardValidLongTime")
        var idCardValidLongTimeFlag: Boolean? = true,

//        @JsonProperty(value = "isIdCardValid")
        @Column(name = "id_card_valid_flag", columnDefinition = "bit(1) default b'0' comment '身份证有效期是否到期'")
        var idCardValidFlag: Boolean? = false,

        @Column(columnDefinition = "datetime comment '身份证起始时间'")
        var idCardBeginTime: String? = null,

        @Column(columnDefinition = "datetime comment '身份证结束时间'")
        var idCardEndTime: String? = null,

        @Column(columnDefinition = "varchar(128) comment '身份证户籍地址'")
        var idCardAddress: String? = null,

        @Column(columnDefinition = "varchar(32) comment '身份证输入方式'")
        var idCardInputMethod: String? = null,

        @Column(columnDefinition = "varchar(32) comment '工作性质'")
        var wordNature: String? = null,

        @Column(columnDefinition = "varchar(32) comment '职务名称'")
        var jobTitle: String? = null,

        @Column(columnDefinition = "varchar(64) comment '所属行业'")
        var industry: String? = null,

        @Column(columnDefinition = "varchar(32) comment '职业名称'")
        var professionalName: String? = null,

        @Column(columnDefinition = "varchar(64) comment '单位名称'")
        var companyName: String? = null,

        @Column(columnDefinition = "varchar(32) comment '婚姻状况'")
        var maritalStatus: String? = null,

        @Column(columnDefinition = "varchar(32) comment '房产状况'")
        var housingSituation: String? = null,

        @Column(columnDefinition = "varchar(128) comment '居住地址'")
        var residentialAddress: String? = null,

        @Column(columnDefinition = "varchar(32) comment '居住所在省'")
        var residentialProvince: String? = null,

        @Column(columnDefinition = "varchar(32) comment '居住所在市'")
        var residentialCity: String? = null,

        @Column(columnDefinition = "varchar(32) comment '居住所在区'")
        var residentialArea: String? = null,

        @Column(columnDefinition = "varchar(32) comment '发卡行'")
        var bank: String? = null,

        @Column(columnDefinition = "varchar(64) comment '银行卡卡号'")
        var bankCardNumber: String? = null,

        @Column(columnDefinition = "varchar(255) comment '储蓄卡影像件反面'")
        var bankCardBackPicturePath: String? = null,

        @Column(columnDefinition = "varchar(255) comment '储蓄卡影像件反面'")
        var bankCardFrontPicturePath: String? = null,

        @Column(columnDefinition = "varchar(16) comment '银行预留手机号'")
        var bankReservedMobile: String? = null,

        @Column(columnDefinition = "varchar(32) comment '授信时的经度'")
        var longitude: String? = null,

        @Column(columnDefinition = "varchar(32) comment '授信时的纬度'")
        var latitude: String? = null,

        @Column(columnDefinition = "varchar(32) comment '授信申请时的IP地址'")
        var clientIp: String? = null,

        @Column(columnDefinition = "varchar(32) comment '店员与客户之间的距离（米）'")
        var distanceBetweenSeller: String? = null,

        @Column(columnDefinition = "int(11) comment '最大信用额度'")
        var creditLimit: Int? = null,//最大信用额度

        @Column(columnDefinition = "varchar(255) comment '身份证影像件反面'")
        var certBackPicturePath: String? = null,

        @Column(columnDefinition = "varchar(255) comment '身份证影像件正面'")
        var certFrontPicturePath: String? = null,

        @Column(columnDefinition = "varchar(255) comment '手持身份证照片'")
        var certHandLocalePicturePath: String? = null,//手持身份证照片

        @Column(columnDefinition = "varchar(32) comment '联系人姓名1'")
        var contactPersonName1: String? = null,

        @Column(columnDefinition = "varchar(16) comment '联系人电话1'")
        var contactPersonMobile1: String? = null,

        @Column(columnDefinition = "varchar(32) comment '联系人关系1'")
        var contactPersonRelationship1: String? = null,

        @Column(columnDefinition = "varchar(32) comment '联系人姓名2'")
        var contactPersonName2: String? = null,

        @Column(columnDefinition = "varchar(16) comment '联系人电话2'")
        var contactPersonMobile2: String? = null,

        @Column(columnDefinition = "varchar(32) comment '联系人关系2'")
        var contactPersonRelationship2: String? = null,

        @Column(columnDefinition = "varchar(32) comment '客户属性'")
        var applicantProperty: String? = null,

        @Column(columnDefinition = "varchar(255) comment '申请人签名地址'")
        var signatureUrl: String? = null,

        @CreatedDate
        var createdTime: Date? = null,

        @LastModifiedDate
        var updatedTime: Date? = null,

        @Transient
        var authCode: String? = null //绑定银行卡的授权码

) : Serializable