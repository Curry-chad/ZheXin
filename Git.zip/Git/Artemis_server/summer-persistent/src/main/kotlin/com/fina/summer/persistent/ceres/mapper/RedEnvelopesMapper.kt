package com.fina.summer.persistent.ceres.mapper

import com.fina.summer.persistent.ceres.entity.constant.Progress
import com.fina.summer.persistent.ceres.entity.constant.TaskStatus
import com.fina.summer.persistent.ceres.entity.vo.RedEnvelopesVO
import org.apache.ibatis.annotations.Mapper
import org.apache.ibatis.annotations.Param
import org.springframework.stereotype.Component

@Mapper
@Component
interface RedEnvelopesMapper {

    fun findByRed(@Param("query")redEnvelopesVO: RedEnvelopesVO): Int

    fun findByShouldAmount(@Param("query")redEnvelopesVO: RedEnvelopesVO): Int?

    fun findByRedNum(@Param("query")redEnvelopesVO: RedEnvelopesVO, @Param("type")type: Progress): Int

    fun findByRedShouldAmount(@Param("query")redEnvelopesVO: RedEnvelopesVO, @Param("type")type: Progress): Int?
}