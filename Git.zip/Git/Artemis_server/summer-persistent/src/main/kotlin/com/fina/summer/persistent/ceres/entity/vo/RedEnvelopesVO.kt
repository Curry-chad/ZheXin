package com.fina.summer.persistent.ceres.entity.vo

import io.swagger.annotations.ApiModelProperty
import java.io.Serializable

data class RedEnvelopesVO (

        @ApiModelProperty("订单ID")
        var id: String? = null,

        @ApiModelProperty("开始时间")
        var startTime: String? = null,

        @ApiModelProperty("结束时间")
        var endTime: String? = null,

        @ApiModelProperty("订单状态")
        var status: String? = null,

        @ApiModelProperty("店员名称/电话")
        var seller: String? = null,

        @ApiModelProperty("页码")
        var pageNo: Int? = null,

        @ApiModelProperty("每页显示条数")
        var pageSize: Int? = null
): Serializable