package com.fina.summer.persistent.ceres.entity.vo

import java.io.Serializable

data class AreaVO(

        var province: String? = null,

        var city: String? = null,

        var district: String? = null

): Serializable