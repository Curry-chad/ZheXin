package com.fina.summer.persistent.ceres.mapper

import com.fina.summer.persistent.ceres.entity.BillTasksQueryParam
import com.fina.summer.persistent.ceres.entity.domain.BillOutTasksPO
import com.fina.summer.persistent.ceres.entity.vo.*
import org.apache.ibatis.annotations.Mapper
import org.apache.ibatis.annotations.Param
import org.springframework.stereotype.Component
import java.util.*

@Mapper
@Component
interface BillOutTasksMapper {

    fun findByTopUpAll(@Param("query")topUpParamVO: TopupParamVO): List<TopupPlanVO>

    fun findByCount(@Param("query")topUpParamVO: TopupParamVO): Int

    fun findByRedEnvelopesAll(@Param("query")redEnvelopesVO: RedEnvelopesVO): List<RedEnvelopesPlanVO>

    fun findByByRedEnvelopesCount(@Param("query")redEnvelopesVO: RedEnvelopesVO): Int

    fun findByOpenId(@Param("id")id: String): BillOutTasksPO?

    fun findByMobile(@Param("id")id: String): BillOutTasksPO?

    fun findByTimeOrFundChannelOrStatusAndType(@Param("query")billTasksQueryParam: BillTasksQueryParam): List<AccountPayableVO>?

    fun getCount(@Param("query")billTasksQueryParam: BillTasksQueryParam): Int

    fun findInOrders(@Param("orderIds")orderIds: ArrayList<String>): List<BillOutTasksPO>?

    fun findByOrderIdAndType(orderId: String): BillOutTasksPO?

    fun findRecordByOrderIdAndSeqNoAndType(@Param("orderId")orderId: String,@Param("seqNo")seqNo: Int,@Param("type")type: String): BillOutTasksPO?
    /**
     *
     * @author zhengqiyang@zhexinit.com
     * @date 2019/5/7 14:59
     * @param no
     * @return FirstOverdueSeqnoVo
     * @description ��ѯ�������������ڴ���Ϣ
     */

    fun findFirstOverdueSeqnoList(): List<FirstOverdueSeqnoVo>?
/**
 *
 * @author zhengqiyang@zhexinit.com
 * @date 2019/5/7 15:24
 * @param [maxbisTaskId �˴η�ҳ������������ܱ�ID, pageSize ÿ�β�ѯ����������]
 * @return ��������б�
 * @description ��ѯ�����������������
 */

    fun findOverdueDataByPage(@Param("pageSize")pageSize: Int,@Param("maxOrderId")maxOrderId:String): List<BillOutTasksPO>?
    /**
     *
     * @author zhengqiyang@zhexinit.com
     * @date 2019/5/7 20:29
     * @param [updateBillOutTaskList ��Ҫ����ΥԼ��Ĵ�������б�]
     * @return Any
     * @description �������´�������ΥԼ���Ӧ�����
     */

    fun batchUpdateOverdueAmount(@Param("updateBillOutTaskList")updateBillOutTaskList:List<BillOutTasksPO>):Int
     fun findTopUpAreasBy(@Param("query")topUpParamVO: TopupParamVO): List<TopupAreaVO>


    fun updateStatusById(@Param("id")id: String,@Param("status")status: String)

    /**
     *
     * @author zhengqiyang@zhexinit.com
     * @date 2019/5/16 11:42
     * @param [startDate , endDate, type ]
     * @return Any
     * @description 查询当期�?要进行代缴的订单数据列表
     */

    fun findRechargeListByItem(@Param("startDate") startDate: Date, @Param("endDate") endDate: Date, @Param("type") type: String): List<BillOutTasksPO>?

    fun updateOverdueDays()


}