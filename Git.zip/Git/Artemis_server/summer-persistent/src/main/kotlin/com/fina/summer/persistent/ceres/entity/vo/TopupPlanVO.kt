package com.fina.summer.persistent.ceres.entity.vo

import io.swagger.annotations.ApiModelProperty
import java.io.Serializable
import java.util.*

data class TopupPlanVO (

        @ApiModelProperty("充值计划编号")
        var id: String? = null,

        @ApiModelProperty("用户姓名")
        var applicantName: String? = null,

        @ApiModelProperty("充值期数")
        var num: String? = null,

        @ApiModelProperty("充值金额")
        var amount: String? = null,

        @ApiModelProperty("支付方式")
        var tradeInstallmentType: String? = null,

        @ApiModelProperty("用户套餐金额")
        var feePerMonth: String? = null,

        @ApiModelProperty("实际充值时间")
        var finishTime: Date? = null,

        @ApiModelProperty("计划充值时间")
        var planExecuteTime: Date? = null,

        @ApiModelProperty("充值状态")
        var status: String? = null,

        @ApiModelProperty("订单编号")
        var orderId: String? = null,

        @ApiModelProperty("交易时间")
        var orderTradeTime: Date? = null,

        @ApiModelProperty("用户电话")
        var applicantMobile: String? = null,

        @ApiModelProperty("店员名称")
        var sellerName: String? = null,

        @ApiModelProperty("门店")
        var stoName: String? = null,

        @ApiModelProperty("套餐名称")
        var chargePlanName: String? = null,

        @ApiModelProperty("设备名称")
        var phoneName: String? = null,

        @ApiModelProperty("当前充值期数")
        var seqNo: Int? = null,

        @ApiModelProperty("当前充值金额")
        var shouldAmount: Int? = null,

        @ApiModelProperty("总充值期数")
        var periodTimes: Int? = null,

        @ApiModelProperty("总充值金额")
        var shouldAmountAll: Int? = null
) : Serializable