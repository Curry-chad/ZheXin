package com.fina.summer.persistent.mapper.business

import com.fina.summer.persistent.bean.OrderQuery
import com.fina.summer.persistent.entity.summer.LoanOrder
import org.apache.ibatis.annotations.Mapper


@Mapper
interface CommonMapper {

    fun findAllOrdersDynamic(orderQuery: OrderQuery): List<LoanOrder>?

    fun findDetalById(orderId: String): LoanOrder?

    fun createdJob()

    fun deleteData()

    fun userContacts()

    fun getNodeCode(organizationCode: String): String?
}