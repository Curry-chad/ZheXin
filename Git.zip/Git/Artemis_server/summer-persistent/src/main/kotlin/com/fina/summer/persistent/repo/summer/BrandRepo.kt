package com.fina.summer.persistent.repo.summer

import com.fina.summer.persistent.entity.summer.Brand
import org.springframework.data.jpa.repository.JpaRepository
import org.springframework.data.jpa.repository.Query

interface BrandRepo: JpaRepository<Brand,String> {
    fun findByName(name: String): Brand?

    @Query("""
        select *
        from brand
        where name = ?1
        order by id desc limit 1
    """, nativeQuery = true)
    fun findBrandByName(name: String): Brand?
}