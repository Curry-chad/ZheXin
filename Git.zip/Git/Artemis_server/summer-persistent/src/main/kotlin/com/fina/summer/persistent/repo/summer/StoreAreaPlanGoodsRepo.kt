package com.fina.summer.persistent.repo.summer

import com.fina.summer.persistent.entity.summer.StoreAreaPlanGoods
import org.springframework.data.jpa.repository.JpaRepository

interface StoreAreaPlanGoodsRepo: JpaRepository<StoreAreaPlanGoods,Long> {
    fun findByGoodsIdAndChargePlanIdAndChargePlanGroupId(goodsId: String, chargePlanId: String, chargePlanGroupId: String): StoreAreaPlanGoods?
}