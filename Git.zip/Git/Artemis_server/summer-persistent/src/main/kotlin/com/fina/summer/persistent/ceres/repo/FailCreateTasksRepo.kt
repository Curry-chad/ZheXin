package com.fina.summer.persistent.ceres.repo

import com.fina.summer.persistent.ceres.entity.domain.FailCreateTasksPO
import org.springframework.data.jpa.repository.JpaRepository

interface FailCreateTasksRepo : JpaRepository<FailCreateTasksPO, Int>