package com.fina.summer.persistent.bean

import java.io.Serializable
import java.util.*


open class StoreCodePlanGoods : Serializable {

    var storeId: String? = null

    var adminCode: String? = null

    var chargePlanGroupId: String? = null

    var chargePlanId: String? = null

    var brandId: String? = null

    var goodsId: String? = null

    var createdTime: Date? = null

    var updatedTime: Date? = null
}