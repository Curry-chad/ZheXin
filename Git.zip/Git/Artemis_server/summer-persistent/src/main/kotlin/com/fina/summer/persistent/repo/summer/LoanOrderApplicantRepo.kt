package com.fina.summer.persistent.repo.summer

import com.fina.summer.persistent.entity.summer.LoanOrderApplicant
import org.springframework.data.jpa.repository.JpaRepository

interface LoanOrderApplicantRepo : JpaRepository<LoanOrderApplicant, String> {
    fun findByOrderId(orderId: String): LoanOrderApplicant
}