package com.fina.summer.persistent.repo.user

import com.fina.summer.persistent.entity.summer.user.UserContacts
import org.springframework.data.jpa.repository.JpaRepository

interface UserContactsRepo: JpaRepository<UserContacts,Long> {

}