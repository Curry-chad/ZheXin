package com.fina.summer.persistent.entity.summer

import com.fina.summer.core.enum.GoodsType
import org.hibernate.annotations.DynamicInsert
import org.hibernate.annotations.DynamicUpdate
import org.hibernate.annotations.GenericGenerator
import org.hibernate.annotations.Parameter
import org.springframework.data.annotation.CreatedDate
import org.springframework.data.annotation.LastModifiedDate
import org.springframework.data.jpa.domain.support.AuditingEntityListener
import java.io.Serializable
import java.sql.Timestamp
import java.util.*
import javax.persistence.*

@Entity
@EntityListeners(AuditingEntityListener::class)
@DynamicInsert
@DynamicUpdate
data class Goods (
    @Id
    @GeneratedValue(generator = "idGenerator")
    @GenericGenerator(name = "idGenerator", strategy = "com.fina.summer.persistent.util.SnowGenerator"
            , parameters = [Parameter(name = "prefix", value = "GOD")])
    var id: String? = null,

    @Column(name = "name")
    var name: String? = null,

    @Column(name = "brand_id")
    var brandId: String? = null,

    @Column(name = "seq_no")
    var seqNo: Int? = null,

    @Column(name = "type")
    @Enumerated(EnumType.STRING)
    var type: GoodsType? = null,

    @Column(name = "picture")
    var picture: String? = null,

    @Column(name = "created_time")
    @CreatedDate
    var createdTime: Date? = null,

    @Column(name = "updated_time")
    @LastModifiedDate
    var updatedTime: Date? = null
): Serializable
