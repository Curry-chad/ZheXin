package com.fina.summer.persistent.ceres.entity.vo

import com.fina.summer.persistent.ceres.entity.constant.BillType
import java.io.Serializable

data class BingdingAndChangingCardVO(

        var orderId: String? = null,

        var payAccount: String? = null,

        var name: String? = null,

        var idno: String? = null,

        var payBank: String? = null,

        var billType: BillType? = null,

        var accountId: String? = null

): Serializable