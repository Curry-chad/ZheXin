package com.fina.summer.persistent.ceres.entity.constant

enum class OperateType {
    Undefined,              //未定义
    BindingAndChangingCard, //银行卡绑定更换
    Prepay,                 //还款
    FundChannel             //资金方修改
}
