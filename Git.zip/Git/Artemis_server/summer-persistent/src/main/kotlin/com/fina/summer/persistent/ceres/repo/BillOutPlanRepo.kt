package com.fina.summer.persistent.ceres.repo

import com.fina.summer.persistent.ceres.entity.constant.BillType
import com.fina.summer.persistent.ceres.entity.domain.BillOutPlanPO
import org.springframework.data.jpa.repository.JpaRepository

interface BillOutPlanRepo : JpaRepository<BillOutPlanPO, String> {
    fun findByTradeIdAndType(tradeId: String, type: BillType): BillOutPlanPO?

    fun findByIdAndOrderId(id: String, orderId: String): BillOutPlanPO?

    fun findByTradeIdAndTypeAndOrderId(tradeId: String, type: BillType, orderId: String): BillOutPlanPO?

    fun findByOrderIdAndType(orderId: String, type: BillType): BillOutPlanPO?

    fun findByOrderId(orderId: String): BillOutPlanPO
}