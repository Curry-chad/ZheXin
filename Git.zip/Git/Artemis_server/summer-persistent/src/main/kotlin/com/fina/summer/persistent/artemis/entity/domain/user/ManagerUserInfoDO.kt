package com.fina.summer.persistent.artemis.entity.domain.user

import com.google.gson.annotations.Expose
import org.hibernate.annotations.DynamicInsert
import org.hibernate.annotations.DynamicUpdate
import org.springframework.data.annotation.CreatedDate
import org.springframework.data.annotation.LastModifiedDate
import org.springframework.data.jpa.domain.support.AuditingEntityListener
import java.io.Serializable
import java.util.*
import javax.persistence.*


@Entity
@DynamicInsert
@DynamicUpdate
@EntityListeners(AuditingEntityListener::class)
@Table(name = "manager_user_info", schema = "artemis", catalog = "")
data class ManagerUserInfoDO (

        @Id
        @GeneratedValue(strategy = GenerationType.IDENTITY)
        var id: Long? = null,

        var userId: String? = null,

        var realName: String? = null,

        var mobile: String? = null,

        @CreatedDate
        @Expose(deserialize = false)
        var createdTime: Date? = null,

        @LastModifiedDate
        @Expose(deserialize = false)
        var updatedTime: Date? = null

): Serializable