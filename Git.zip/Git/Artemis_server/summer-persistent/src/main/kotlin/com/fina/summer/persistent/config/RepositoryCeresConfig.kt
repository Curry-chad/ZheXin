package com.fina.summer.persistent.config

import org.springframework.beans.factory.annotation.Autowired
import org.springframework.beans.factory.annotation.Qualifier
import org.springframework.boot.autoconfigure.orm.jpa.HibernateSettings
import org.springframework.boot.autoconfigure.orm.jpa.JpaProperties
import org.springframework.boot.orm.jpa.EntityManagerFactoryBuilder
import org.springframework.context.annotation.Bean
import org.springframework.context.annotation.Configuration
import org.springframework.context.annotation.Primary
import org.springframework.data.jpa.repository.config.EnableJpaRepositories
import org.springframework.orm.jpa.JpaTransactionManager
import org.springframework.orm.jpa.LocalContainerEntityManagerFactoryBean
import org.springframework.transaction.PlatformTransactionManager
import org.springframework.transaction.annotation.EnableTransactionManagement
import javax.annotation.Resource
import javax.persistence.EntityManager
import javax.persistence.EntityManagerFactory
import javax.sql.DataSource


@Configuration

@EnableTransactionManagement
@EnableJpaRepositories(
        entityManagerFactoryRef = "entityManagerFactoryCeres",
        transactionManagerRef = "transactionManagerCeres",
        basePackages = ["com.fina.summer.persistent.ceres.repo"])
class RepositoryCeresConfig(
        @Autowired
        private val jpaProperties: JpaProperties,
        @Resource(name = "ceresDataSource")
        private val ceresDS: DataSource
) {

    @Bean(name = ["entityManagerCeres"])
    fun entityManagerCeres(builder: EntityManagerFactoryBuilder): EntityManager {
        return entityManagerFactoryCeres(builder).getObject()!!.createEntityManager()
    }


    @Bean(name = ["entityManagerFactoryCeres"])
    fun entityManagerFactoryCeres(builder: EntityManagerFactoryBuilder): LocalContainerEntityManagerFactoryBean {
        return builder
                .dataSource(ceresDS)
                .properties(getVendorProperties())
                .packages("com.fina.summer.persistent.ceres.entity.domain") //设置实体类所在位置
                .persistenceUnit("ceresPersistenceUnit")
                .build()
    }

    private fun getVendorProperties(): MutableMap<String, Any>? {
        return jpaProperties.getHibernateProperties(HibernateSettings())
    }

    @Primary
    @Bean(name = ["transactionManagerCeres"])
    fun transactionManagerCeres(@Qualifier("entityManagerFactoryCeres") factory: EntityManagerFactory): PlatformTransactionManager {
        return JpaTransactionManager(factory)
    }
}