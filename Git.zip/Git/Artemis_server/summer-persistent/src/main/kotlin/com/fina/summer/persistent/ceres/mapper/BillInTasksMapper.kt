package com.fina.summer.persistent.ceres.mapper

import com.fina.summer.persistent.bean.loan.ChargeBack
import com.fina.summer.persistent.ceres.entity.ReceivableParam
import com.fina.summer.persistent.ceres.entity.constant.BillType
import com.fina.summer.persistent.ceres.entity.domain.BillInTasksPO
import com.fina.summer.persistent.ceres.entity.vo.ReceivableVO
import org.apache.ibatis.annotations.Mapper
import org.apache.ibatis.annotations.Param
import org.springframework.stereotype.Component
import java.util.*

@Mapper
@Component
interface BillInTasksMapper {

    fun findBy(@Param("query")receivableParam: ReceivableParam): List<ReceivableVO>

    fun findAreasBy(@Param("query")receivableParam: ReceivableParam, @Param("type")type: BillType): List<ReceivableVO>

    fun refundReviewSearch(@Param("orderId") orderId: String,@Param("type") type: String): List<ChargeBack>

    /**
     *
     * @author zhengqiyang@zhexinit.com
     * @date 2019/5/15 16:57
     * @param [startDate 本月第一天0点0分0秒, endDate 本月最后一天23点59分59秒, type 任务类型]
     * @return 收款任务ID列表
     * @description 查询当期需要进行代扣的话费订单数据
     */

    fun findReductListByItem(@Param("startDate") startDate: Date,@Param("endDate") endDate: Date,@Param("type") type: String):List<BillInTasksPO>?

    /**
     *
     * @author zhengqiyang@zhexinit.com
     * @date 2019/5/22 16:42
     * @param [tradeId, startDate, endDate]
     * @return 还款记录
     * @description 查询某个订单在某段时间内的所有还款记录
     */

    fun findReceivedByBetweenTime(@Param("tradeId") tradeId: String, @Param("startDate") startDate: Date, @Param("endDate") endDate: Date): List<BillInTasksPO>
}