package com.fina.summer.persistent.ceres.entity.vo

import io.swagger.annotations.ApiModelProperty
import java.io.Serializable
import java.util.*

data class TopupPlanAllVO (

        @ApiModelProperty("充值任务总表id")
        var id: String? = null,

        @ApiModelProperty("订单编号")
        var orderId: String? = null,

        @ApiModelProperty("交易单号")
        var tradeId: String? = null,

        @ApiModelProperty("开户行")
        var accountOpenBank: String? = null,

        @ApiModelProperty("代扣渠道")
        var debitChannel: String? = null,

        @ApiModelProperty("资金方")
        var fundChannel: String? = null,

        @ApiModelProperty("应转账金额（分）")
        var shouldAmount: Int? = null,

        @ApiModelProperty("实际转账金额（分）数")
        var actualAmount: Int? = null,

        @ApiModelProperty("分期次数")
        var periodTimes: Int? = null,

        @ApiModelProperty("商户id")
        var merId: String? = null,

        @ApiModelProperty("订单交易时间")
        var orderTradeTime: Date? = null,

        @ApiModelProperty("计划打款日")
        var payDate: Date? = null,

        @ApiModelProperty("收款账号")
        var payeeAccount: String? = null,

        @ApiModelProperty("收款银行")
        var payeeBank: String? = null,

        @ApiModelProperty("收款人名字")
        var payeeName: String? = null,

        @ApiModelProperty("转账状态")
        var status: String? = null,

        @ApiModelProperty("创建人")
        var createBy: String? = null,

        @ApiModelProperty("修改人")
        var modifyBy: String? = null,

        @ApiModelProperty("修改时间")
        var modifyTime: Date? = null,

        @ApiModelProperty("创建时间")
        var createdTime: Date? = null,

        @ApiModelProperty("更新时间")
        var updatedTime: Date? = null,

        @ApiModelProperty("请款申请流水号")
        var loanReqNo: String? = null,

        @ApiModelProperty("请款成功借据编号")
        var loanNo: String? = null,

        @ApiModelProperty("贷款申请流水号")
        var contReqNo: String? = null,

        @ApiModelProperty("申请成功合同编号")
        var contNo: String? = null,

        @ApiModelProperty("应收款类型")
        var type: String? = null,

        @ApiModelProperty("审查状态")
        var audit: String? = null
) : Serializable