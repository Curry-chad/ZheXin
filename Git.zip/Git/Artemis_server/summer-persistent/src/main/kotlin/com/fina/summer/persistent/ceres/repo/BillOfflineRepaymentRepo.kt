package com.fina.summer.persistent.ceres.repo

import com.fina.summer.persistent.ceres.entity.domain.BillOfflineRepaymentPO
import org.springframework.data.jpa.repository.JpaRepository
import org.springframework.data.jpa.repository.Query

interface BillOfflineRepaymentRepo : JpaRepository<BillOfflineRepaymentPO, String> {

    @Query(value = "SELECT * FROM bill_offline_repayment_tasks WHERE id =?1", nativeQuery = true)
    fun findByTaskId(id: String): BillOfflineRepaymentPO?

}