package com.fina.summer.persistent.repo.loan

import com.fina.summer.persistent.entity.loan.ApplicationUser
import org.springframework.data.jpa.repository.JpaRepository

interface ApplicationUserRepo: JpaRepository<ApplicationUser,String> {
}