package com.fina.summer.persistent.entity.summer

import com.fina.summer.core.enum.InstitutionType
import org.hibernate.annotations.*
import org.hibernate.annotations.Parameter
import org.springframework.data.annotation.CreatedDate
import org.springframework.data.annotation.LastModifiedDate
import org.springframework.data.jpa.domain.support.AuditingEntityListener
import java.util.*
import javax.persistence.*
import javax.persistence.Entity

@Entity
@DynamicUpdate
@DynamicInsert
@EntityListeners(AuditingEntityListener::class)
@Where(clause = "delete_flag =false")
data class Payee (
    @Id
    @GeneratedValue(generator = "idGenerator")
    @GenericGenerator(name = "idGenerator", strategy = "com.fina.summer.persistent.util.SnowGenerator"
            , parameters = [Parameter(name = "prefix", value = "PAY")])
    var id: String? = null,

    @Column(name = "mer_id")
    var merId: String? = null,

    @Column(name = "status")
    var status: String? = null,

    @Column(name = "payee_institution")
    var payeeInstitution: String? = null,

    @Column(name = "payee_account_name")
    var payeeAccountName: String? = null,

    @Column(name = "payee_account_id")
    var payeeAccountId: String? = null,

    @Column(name = "payee_logon_account")
    var payeeLogonAccount: String? = null,

    @Column(columnDefinition = "varchar(255) comment '账户头像地址'")
    var payeeAccountAvatar: String? = null,

    @Column(name = "institution_type")
    @Enumerated(EnumType.STRING)
    var institutionType: InstitutionType? = null,

    @Column(columnDefinition = "varchar(32) comment '分支机构名称'")
    var branchInstitution: String? = null,

    @Column(name = "delete_flag")
    var deleteFlag: Boolean = false,

    @Column(name = "created_time")
    @CreatedDate
    var createdTime: Date? = null,

    @Column(name = "updated_time")
    @LastModifiedDate
    var updatedTime: Date? = null
)
