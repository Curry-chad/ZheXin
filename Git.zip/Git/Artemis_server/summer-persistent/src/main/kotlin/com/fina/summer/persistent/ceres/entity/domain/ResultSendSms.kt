package com.fina.summer.persistent.ceres.entity.domain

import com.fina.summer.persistent.ceres.entity.constant.FundChannel
import com.fina.summer.persistent.ceres.entity.constant.ResultStatus
import com.google.gson.annotations.Expose
import org.hibernate.annotations.DynamicInsert
import org.hibernate.annotations.DynamicUpdate
import org.hibernate.annotations.GenericGenerator
import org.hibernate.annotations.Parameter
import org.springframework.data.annotation.CreatedDate
import org.springframework.data.jpa.domain.support.AuditingEntityListener
import java.io.Serializable
import java.util.*
import javax.persistence.*


@Entity
@DynamicInsert
@DynamicUpdate
@EntityListeners(AuditingEntityListener::class)
@Table(name = "result_send_sms", schema = "ceres", catalog = "")
class ResultSendSms (

    @Id
    @Column(name = "id")
    var id: String? = null,

    @Column(name = "mobile")
    var mobile: String? = null,

    //批次号
    @Basic
    @Column(name = "out_msg_id")
    var outMsgId: String? = null,

    //短信发送结果
    @Enumerated(EnumType.STRING)
    var status: ResultStatus? = ResultStatus.Request,

    //短信内容
    @Basic
    @Column(name = "msg")
    var msg: String? = null,

    @Basic
    @Column(name = "created_time")
    var createdTime: Date? = null

): Serializable