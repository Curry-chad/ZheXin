package com.fina.summer.persistent.artemis.repo.user

import com.fina.summer.persistent.artemis.entity.domain.user.ManagerUserLoginLogDO
import org.springframework.data.jpa.repository.JpaRepository

interface ManagerUserLoginLogRepo: JpaRepository<ManagerUserLoginLogDO,Long> {
}