package com.fina.summer.persistent.bean

class Goods : StoreCodePlanGoods() {

    var id: String? = null

    var name: String? = null

    var seqNo: Int? = null

    var type: String? = null

    var picture: String? = null

}
