package com.fina.summer.persistent.entity.summer

import java.io.Serializable
import java.util.*

data class SellerVO(

        var id: String? = null,

        var name: String? = null,

        var mobile: String? = null,

        var bossId: String? = null,

        var certNo: String? = null,

        var storeName: String? = null,

        var createTime: Date? = null,

        var modifyTime: Date? = null

) : Serializable