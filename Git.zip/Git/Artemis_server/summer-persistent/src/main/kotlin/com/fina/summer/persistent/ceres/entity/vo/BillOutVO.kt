package com.fina.summer.persistent.ceres.entity.vo

import com.fina.summer.persistent.ceres.entity.constant.FundChannel
import com.fina.summer.persistent.ceres.entity.constant.TaskStatus
import java.io.Serializable
import java.util.*
import javax.persistence.EnumType
import javax.persistence.Enumerated

data class BillOutVO(
        var id: String? = null,

        var orderTradeTime: Date? = null,

        var payeeName: String? = null,

        var payeeAccount: String? = null,

        var payeeBank: String? = null,

        var shouldAmount: Int? = null,

        var totalAmount: Int? = null,

        var merName: String? = null,

        var payer: String? = null,

        var payAccount: String? = null,

        var payBank: String? = null,

        @Enumerated(EnumType.STRING)
        var status: TaskStatus? = TaskStatus.None, // 若数据库数据异常，则返回空字符串

        var paymentVoucher: String? = null,

        var orderId: String? = null,

        @Enumerated(EnumType.STRING)
        var fundChannel: FundChannel? = FundChannel.None, // 若数据库数据异常，则返回空字符串

        var accountOpenBank: String? = null,

        var monthlyRepaymentAmount: Int? = null,//每月还款金额

        var ordInstallmentNum: Int? = null,//分期数

        var applicantName: String? = null,//借款人姓名

        var tradeId: String? = null,//交易流水号

        var stoProvinceName: String? = null,//省

        var stoCityName: String? = null//市
): Serializable