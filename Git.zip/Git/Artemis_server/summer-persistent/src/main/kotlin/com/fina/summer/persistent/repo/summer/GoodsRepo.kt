package com.fina.summer.persistent.repo.summer

import com.fina.summer.persistent.entity.summer.Goods
import org.springframework.data.jpa.repository.JpaRepository
import org.springframework.data.jpa.repository.Query

interface GoodsRepo: JpaRepository<Goods,String> {
    fun findByName(name: String): Goods?

    @Query("""
        select *
        from goods
        where name = ?1
        order by id desc limit 1
    """, nativeQuery = true)
    fun findGoodsByName(name: String): Goods?
}