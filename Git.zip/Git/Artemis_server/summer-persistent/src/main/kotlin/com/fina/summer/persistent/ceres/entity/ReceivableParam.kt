package com.fina.summer.persistent.ceres.entity

import com.fina.summer.persistent.ceres.entity.constant.BillType
import io.swagger.annotations.ApiModelProperty
import java.io.Serializable

data class ReceivableParam (

        @ApiModelProperty("还款时间：起始")
        var startTime: String? = null,

        @ApiModelProperty("还款时间：截止")
        var endTime: String? = null,

        @ApiModelProperty("还款状态")
        var status: String? = null,

        @ApiModelProperty("省")
        var province: String? = null,

        @ApiModelProperty("市")
        var city: String? = null,

        @ApiModelProperty("areaCode")
        var areaCode: String? = null,

        @ApiModelProperty("县/区")
        var district: String? = null,

        @ApiModelProperty("门店名称/id")
        var store: String? = null,

        @ApiModelProperty("店员名称/电话")
        var seller: String? = null,

        @ApiModelProperty("还款人姓名/电话/身份证")
        var payer: String? = null,

        @ApiModelProperty("类型")
        var type: BillType? = null
): Serializable