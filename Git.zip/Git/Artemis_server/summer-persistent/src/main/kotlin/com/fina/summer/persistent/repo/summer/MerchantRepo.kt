package com.fina.summer.persistent.repo.summer

import com.fina.summer.persistent.entity.summer.Merchant
import org.springframework.data.jpa.repository.JpaRepository

interface MerchantRepo : JpaRepository<Merchant, String> {

    fun findByUserId(userId: String): Merchant?

    fun findByCertNo(certNo: String): Merchant?

    fun findAllByCertNo(certNo: String): List<Merchant>?
}