package com.fina.summer.persistent.repo.summer

import com.fina.summer.persistent.entity.summer.ChargePlanGroup
import org.springframework.data.jpa.repository.JpaRepository
import org.springframework.data.jpa.repository.Query

interface ChargePlanGroupRepo: JpaRepository<ChargePlanGroup,String> {
    fun findByName(name: String): ChargePlanGroup?

    @Query("""
        select id
        from charge_plan_group
        order by id desc limit 1
    """, nativeQuery = true)
    fun getLastId(): String
}