package com.fina.summer.persistent.ceres.entity.vo

import io.swagger.annotations.ApiModelProperty
import java.io.Serializable

data class RedEnvelopesPlanVO (

        @ApiModelProperty("任务编号ID")
        var id: String? = null,

        @ApiModelProperty("省")
        var stoProvinceName: String? = null,

        @ApiModelProperty("市")
        var stoCityName: String? = null,

        @ApiModelProperty("商户")
        var merName: String? = null,

        @ApiModelProperty("门店")
        var stoName: String? = null,

        @ApiModelProperty("店员")
        var sellerName: String? = null,

        @ApiModelProperty("订单ID")
        var orderId: String? = null,

        @ApiModelProperty("红包个数")
        var ordInstallmentNum: Int? = null,

        @ApiModelProperty("红包金额")
        var shouldAmount: String? = null,

        @ApiModelProperty("发放状态")
        var status: String? = null,

        @ApiModelProperty("微信openId")
        var openId: String? = null
): Serializable