package com.fina.summer.persistent.artemis.repo.user

import com.fina.summer.persistent.artemis.entity.domain.ManagerMenuDO
import org.springframework.data.jpa.repository.JpaRepository

interface ManagerMenuRepo : JpaRepository<ManagerMenuDO, Long>