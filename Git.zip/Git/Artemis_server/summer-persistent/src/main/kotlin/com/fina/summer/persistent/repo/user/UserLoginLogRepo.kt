package com.fina.summer.persistent.repo.user

import com.fina.summer.persistent.entity.summer.user.UserLoginLog
import org.springframework.data.jpa.repository.JpaRepository

interface UserLoginLogRepo: JpaRepository<UserLoginLog,Long> {
}