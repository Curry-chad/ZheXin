package com.fina.summer.persistent.repo.summer

import com.fina.summer.core.enum.InstitutionType
import com.fina.summer.persistent.entity.summer.Payee
import org.springframework.data.jpa.repository.JpaRepository

interface PayeeRepo: JpaRepository<Payee,String> {

    fun findByInstitutionTypeAndMerId(payerLoanInstitution: InstitutionType, merId: String): Payee?

    fun findAllByMerId(merId: String): List<Payee>?

    fun findByPayeeAccountId(alipayId: String?): Payee?
}