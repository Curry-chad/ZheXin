package com.fina.summer.persistent.ceres.entity.vo

import java.io.Serializable

data class OutBackQueryParam(

        var outTaskId: String? = null,

        var msg: String? = null,

        var modifyBy: String? = null

): Serializable