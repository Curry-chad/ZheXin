package com.fina.summer.persistent.entity.loan

import com.fina.summer.core.enum.AuditStatus
import org.hibernate.annotations.DynamicInsert
import org.hibernate.annotations.DynamicUpdate
import org.hibernate.annotations.GenericGenerator
import org.hibernate.annotations.Parameter
import org.springframework.data.annotation.CreatedDate
import org.springframework.data.annotation.LastModifiedDate
import org.springframework.data.jpa.domain.support.AuditingEntityListener
import java.io.Serializable
import java.sql.Timestamp
import java.util.*
import javax.persistence.*

@Entity
@Table(name = "application_user")
@DynamicInsert
@DynamicUpdate
@EntityListeners(AuditingEntityListener::class)
class ApplicationUser(
        @Id
        @GeneratedValue(generator = "idGenerator")
        @GenericGenerator(name = "idGenerator", strategy = "com.fina.summer.persistent.util.SnowGenerator"
                , parameters = [Parameter(name = "prefix", value = "AUS")])
        var id: String? = null,

        @Column(name = "user_id")
        var userId: String? = null,

        @Column(name = "store_id")
        var storeId: String? = null,

        @Column(name = "operate_code")
        var operateCode: String? = null,

        @Column(name = "mobile")
        var mobile: String? = null,

        @Column(name = "realname" ,columnDefinition = "varchar(32) comment '真实姓名'")
        var realname: String? = null,

        @Column(name = "address")
        var address: String? = null,

        @Column(name = "idno")
        var idno: String? = null,

        @Column(columnDefinition = "tinyint(1)  comment '人脸识别结果'")
        var faceRecognitionResult: Boolean? = null,

        @Column(columnDefinition = "varchar(255) comment '人脸识别影像件'")
        var faceRecognitionImageUrl: String? = null,

        @Column(columnDefinition = "int(5) comment '人脸识别失败累计次数'")
        var faceRecognitionFailCnt: Int? = null,

        @Column(name = "cert_front_picture_path")
        var certFrontPicturePath: String? = null,

        var certBackPicturePath: String? = null,

        @Column(name = "contact_person_mobile")
        var contactPersonMobile: String? = null,

        @Column(name = "contact_person_name")
        var contactPersonName: String? = null,

        @Column(name = "contact_person_relationship")
        var contactPersonRelationship: String? = null,

        @Column(name = "payee_institution")
        var payeeInstitution: String? = null,

        @Column(name = "payee_account_name")
        var payeeAccountName: String? = null,

        @Column(name = "payee_account_id")
        var payeeAccountId: String? = null,

        @Column(name = "payee_logon_account")
        var payeeLogonAccount: String? = null,

        @Column(columnDefinition = "varchar(64) comment '设备号'")
        var imei: String? = null,

        @Column(columnDefinition = "int(11) comment '通讯录个数'")
        var contactsNum: Int? = null,

        @Column(name = "audit_no")
        var auditNo: String? = null,

        @Column(name = "audit_describe")
        var auditDescribe: String? = null,

        @Column(name = "audit_person")
        var auditPerson: String? = null,

        @Column(name = "audit_time")
        var auditTime: Date? = null,

        @Enumerated(EnumType.STRING)
        var auditStatus: AuditStatus? = null,

        @Column(name = "created_time")
        @CreatedDate
        var createdTime: Date? = null,

        @Column(name = "updated_time")
        @LastModifiedDate
        var updatedTime: Date? = null

): Serializable