package com.fina.summer.persistent.ceres.entity.domain

import com.fina.summer.persistent.ceres.entity.constant.PayType
import com.fina.summer.persistent.ceres.entity.constant.TaskStatus
import org.hibernate.annotations.DynamicInsert
import org.hibernate.annotations.DynamicUpdate
import java.io.Serializable
import java.util.*
import javax.persistence.*

@Entity
@DynamicInsert
@DynamicUpdate
@Table(name = "bill_in_task", schema = "ceres", catalog = "")
class BillInTaskDO (
    @Id
    @Column(name = "id")
    var id: String? = null,
    @Basic
    @Column(name = "bis_task_id")
    var bisTaskId: String? = null,
    @Basic
    @Column(name = "create_by")
    var createBy: String? = null,
    @Basic
    @Column(name = "create_time")
    var createTime: Date? = null,
    @Basic
    @Column(name = "finish_time")
    var finishTime: Date? = null,
    @Basic
    @Column(name = "last_execute_time")
    var lastExecuteTime: Date? = null,
    @Basic
    @Column(name = "message")
    var message: String? = null,
    @Basic
    @Column(name = "modify_by")
    var modifyBy: String? = null,
    @Basic
    @Column(name = "modify_time")
    var modifyTime: Date? = null,
    @Basic
    @Column(name = "next_execute_time")
    var nextExecuteTime: Date? = null,
    @Basic
    @Column(name = "overdue_days")
    var overdueDays: Int? = null,
    @Basic
    @Column(name = "pay_type")
    @Enumerated(EnumType.STRING)
    var payType: PayType? = null,
    @Basic
    @Column(name = "payer")
    var payer: String? = null,
    @Basic
    @Column(name = "payer_idno")
    var payerIdno: String? = null,
    @Basic
    @Column(name = "penalty")
    var penalty: Int? = null,
    @Basic
    @Column(name = "plan_execute_time")
    var planExecuteTime: Date? = null,
    @Basic
    @Column(name = "request_no")
    var requestNo: String? = null,
    @Basic
    @Column(name = "seq_no")
    var seqNo: Int? = null,
    @Basic
    @Column(name = "should_amount")
    var shouldAmount: Int? = null,
    @Basic
    @Column(name = "status")
    @Enumerated(EnumType.STRING)
    var status: TaskStatus? = null,
    @Basic
    @Column(name = "task_type")
    var taskType: String? = null,
    @Basic
    @Column(name = "third_order_id")
    var thirdOrderId: String? = null,
    @Basic
    @Column(name = "total_amount")
    var totalAmount: Int? = null,
    @Basic
    @Column(name = "trade_id")
    var tradeId: String? = null
): Serializable
