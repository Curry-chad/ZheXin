package com.fina.summer.persistent.summer.mapper


import com.fina.summer.persistent.summer.entity.vo.SumAllVo
import com.fina.summer.persistent.summer.entity.vo.SumAreasVO
import org.apache.ibatis.annotations.Mapper

@Mapper
interface BusinessStatisticsMapper {
    fun findByAll(): SumAllVo
    fun findGroupByArea(): List<SumAreasVO>
}