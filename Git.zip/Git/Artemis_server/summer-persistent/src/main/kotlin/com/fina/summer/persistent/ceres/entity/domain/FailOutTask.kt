package com.fina.summer.persistent.ceres.entity.domain

import java.io.Serializable
import java.util.*
import javax.persistence.*

@Entity
@Table(name = "fail_out_task", schema = "ceres", catalog = "")
class FailOutTask (
        @Id
        @GeneratedValue(strategy = GenerationType.IDENTITY)
        @Column(name = "id")
        var id: Int = 0,
        @Basic
        @Column(name = "bis_task_id")
        var bisTaskId: String? = null,
        @Basic
        @Column(name = "task_id")
        var taskId: String? = null,
        @Basic
        @Column(name = "type")
        var type: String? = null,
        @Basic
        @Column(name = "message")
        var message: String? = null,
        @Basic
        @Column(name = "amount")
        var amount: Int? = null,
        @Basic
        @Column(name = "created_time")
        var createdTime: Date? = null,
        @Basic
        @Column(name = "updated_time")
        var updatedTime: Date? = null
): Serializable