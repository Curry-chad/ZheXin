package com.fina.summer.persistent.ceres.entity.vo

import io.swagger.annotations.ApiModelProperty
import java.io.Serializable

data class TopupAreaVO(

        @ApiModelProperty("名称")
        var name: String? = null,

        @ApiModelProperty("编码")
        var code: String? = null,

        @ApiModelProperty("符合条件的订单数")
        var count: Int? = 0

) : Serializable