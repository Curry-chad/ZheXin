package com.fina.summer.persistent.ceres.entity.domain

import org.hibernate.annotations.DynamicInsert
import org.hibernate.annotations.DynamicUpdate
import java.io.Serializable
import java.util.*
import javax.persistence.*

@Entity
@DynamicInsert
@DynamicUpdate
@Table(name = "short_message", schema = "ceres", catalog = "")
class ShortMessagePO(
        @Id
        @GeneratedValue(strategy = GenerationType.IDENTITY)
        @Column(name = "id")
        var id: Long = 0,
        @Basic
        @Column(name = "short_message_type")
        var shortMessageType: Byte? = null,
        @Basic
        @Column(name = "title")
        var title: String? = null,
        @Basic
        @Column(name = "message")
        var message: String? = null,
        @Basic
        @Column(name = "created_time")
        var createdTime: Date? = null,
        @Basic
        @Column(name = "updated_time")
        var updatedTime: Date? = null
) : Serializable
