package com.fina.summer.persistent.ceres.entity.domain

import com.fina.summer.persistent.ceres.entity.constant.ReturnStatus
import org.hibernate.annotations.DynamicInsert
import org.hibernate.annotations.DynamicUpdate
import org.springframework.data.annotation.CreatedDate
import org.springframework.data.annotation.LastModifiedDate
import java.io.Serializable
import java.util.*
import javax.persistence.*

@Entity
@DynamicInsert
@DynamicUpdate
@Table(name = "short_message_flow", schema = "ceres", catalog = "")
class ShortMessageFlowPO(
        @Id
        @GeneratedValue(strategy = GenerationType.IDENTITY)
        @Column(name = "id")
        var id: Long = 0,
        @Basic
        @Column(name = "bis_task_id")
        var bisTaskId: String? = null,
        @Basic
        @Column(name = "task_id")
        var taskId: String? = null,
        @Basic
        @Column(name = "short_message_id")
        var shortMessageId: Long? = null,
        @Basic
        @Column(name = "sms_id")
        var smsId: String? = null,
        @Basic
        @Column(name = "status")
        @Enumerated(EnumType.STRING)
        var status: ReturnStatus? = null,
        @Basic
        @Column(name = "message")
        var message: String? = null,
        @Basic
        @Column(name = "result_msg")
        var resultMsg: String? = null,
        @Basic
        @Column(name = "created_time")
        @CreatedDate
        var createdTime: Date? = null,
        @Basic
        @Column(name = "updated_time")
        @LastModifiedDate
        var updatedTime: Date? = null
): Serializable
