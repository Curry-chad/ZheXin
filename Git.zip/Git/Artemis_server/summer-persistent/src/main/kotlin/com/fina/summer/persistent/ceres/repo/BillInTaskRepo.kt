package com.fina.summer.persistent.ceres.repo

import com.fina.summer.persistent.ceres.entity.domain.BillInTaskDO
import org.springframework.data.jpa.repository.JpaRepository

interface BillInTaskRepo : JpaRepository<BillInTaskDO, String> {

    fun findByBisTaskIdAndSeqNo(bisTaskId: String, seqNo: Int): BillInTaskDO?
}