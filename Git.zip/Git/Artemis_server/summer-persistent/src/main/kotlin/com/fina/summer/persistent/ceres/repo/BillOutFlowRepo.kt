package com.fina.summer.persistent.ceres.repo

import com.fina.summer.persistent.ceres.entity.domain.BillOutFlowDO
import org.springframework.data.jpa.repository.JpaRepository

interface BillOutFlowRepo : JpaRepository<BillOutFlowDO, String> {
    fun findByTaskId(taskId: String): List<BillOutFlowDO>
}