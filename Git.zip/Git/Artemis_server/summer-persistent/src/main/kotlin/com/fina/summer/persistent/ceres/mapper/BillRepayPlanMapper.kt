package com.fina.summer.persistent.ceres.mapper

import com.fina.summer.persistent.ceres.entity.constant.BillType
import com.fina.summer.persistent.ceres.entity.domain.BillRepayPlanPO
import com.fina.summer.persistent.ceres.entity.vo.PrepaymentVO
import org.apache.ibatis.annotations.Mapper
import org.apache.ibatis.annotations.Param
import org.springframework.stereotype.Component

@Mapper
@Component
interface BillRepayPlanMapper {
    fun findByPayerAndPayAccountAndType(@Param("query") prepayment: PrepaymentVO): List<String>

    /**
     *
     * @author zhengqiyang@zhexinit.com
     * @date 2019/5/16 14:56
     * @param [orderId, typeList]
     * @return Any
     * @description 根据订单id和类型列表查询唯一的一条记录
     */

    fun findByOrderIdAndTypeList(@Param("orderId")orderId:String,@Param("typeList")typeList:List<BillType>) : BillRepayPlanPO?

}