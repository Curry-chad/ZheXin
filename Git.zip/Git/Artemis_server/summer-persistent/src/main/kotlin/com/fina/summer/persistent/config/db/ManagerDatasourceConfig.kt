package com.fina.summer.persistent.config.db

import com.alibaba.druid.pool.DruidDataSource
import com.fina.summer.persistent.bean.DBConfig
import com.fina.summer.persistent.config.DatasourceConfig
import org.apache.ibatis.session.SqlSessionFactory
import org.mybatis.spring.SqlSessionFactoryBean
import org.mybatis.spring.SqlSessionTemplate
import org.mybatis.spring.annotation.MapperScan
import org.slf4j.LoggerFactory
import org.springframework.beans.factory.annotation.Qualifier
import org.springframework.boot.context.properties.ConfigurationProperties
import org.springframework.context.annotation.AdviceMode
import org.springframework.context.annotation.Bean
import org.springframework.context.annotation.Configuration
import org.springframework.core.io.support.PathMatchingResourcePatternResolver
import org.springframework.jdbc.datasource.DataSourceTransactionManager
import org.springframework.transaction.annotation.EnableTransactionManagement
import java.sql.SQLException
import javax.sql.DataSource

/**
 * Created by keets on 2016/12/5.
 */
/*@Configuration
@EnableTransactionManagement(mode = AdviceMode.ASPECTJ)
@MapperScan(basePackages = ["com.fina.summer.persistent.manager.mapper"], sqlSessionTemplateRef = "managerSqlSessionTemplate")*/
class ManagerDatasourceConfig {

    private val logger = LoggerFactory.getLogger(DatasourceConfig::class.java)

    private val mapperPath = "classpath*:mapper/manager/*.xml"

    @Bean("managerDBConfig")
    @ConfigurationProperties("spring.manager.datasource")
    open fun managerDBConfig(): DBConfig {
        return DBConfig()
    }

    @Bean(name = ["managerDataSource"])
    fun testDataSource(@Qualifier("managerDBConfig") dbConfig: DBConfig): DataSource {
        val datasource = DruidDataSource()

        datasource.url = dbConfig.jdbcUrl
        datasource.username = dbConfig.username
        datasource.password = dbConfig.password
        datasource.driverClassName = dbConfig.driverClassName

        // configuration
        datasource.initialSize = dbConfig.initialSize
        datasource.minIdle = dbConfig.minIdle
        datasource.maxActive = dbConfig.maxActive
        datasource.maxWait = dbConfig.maxWait.toLong()
        datasource.timeBetweenEvictionRunsMillis = dbConfig.timeBetweenEvictionRunsMillis.toLong()
        datasource.minEvictableIdleTimeMillis = dbConfig.minEvictableIdleTimeMillis.toLong()
        datasource.validationQuery = dbConfig.validationQuery
        datasource.isTestWhileIdle = dbConfig.testWhileIdle
        datasource.isTestOnBorrow = dbConfig.testOnBorrow
        datasource.isTestOnReturn = dbConfig.testOnReturn
        datasource.isPoolPreparedStatements = dbConfig.poolPreparedStatements
        datasource.maxPoolPreparedStatementPerConnectionSize = dbConfig.maxPoolPreparedStatementPerConnectionSize
        try {
            datasource.setFilters(dbConfig.filters)
        } catch (e: SQLException) {
            logger.error("druid configuration initialization filter", e)
        }

        datasource.setConnectionProperties(dbConfig.connectionProperties)

        return datasource
    }

    @Bean(name = ["managerSqlSessionFactory"])
    @Throws(Exception::class)
    fun testSqlSessionFactory(@Qualifier("managerDataSource") dataSource: DataSource): SqlSessionFactory? {
        val bean = SqlSessionFactoryBean()
        bean.setDataSource(dataSource)
        bean.setMapperLocations(PathMatchingResourcePatternResolver().getResources(mapperPath))
        bean.getObject()!!.configuration.isMapUnderscoreToCamelCase = true
        return bean.getObject()
    }

    @Bean(name = ["managerTransactionManager"])
    fun testTransactionManager(@Qualifier("managerDataSource") dataSource: DataSource): DataSourceTransactionManager {
        return DataSourceTransactionManager(dataSource)
    }

    @Bean(name = ["managerSqlSessionTemplate"])
    @Throws(Exception::class)
    fun testSqlSessionTemplate(
            @Qualifier("managerSqlSessionFactory") sqlSessionFactory: SqlSessionFactory): SqlSessionTemplate {
        return SqlSessionTemplate(sqlSessionFactory)
    }

}
