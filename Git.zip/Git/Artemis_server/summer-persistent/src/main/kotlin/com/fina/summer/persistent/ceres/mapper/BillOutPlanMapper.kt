package com.fina.summer.persistent.ceres.mapper

import com.fina.summer.persistent.ceres.entity.constant.BillType
import com.fina.summer.persistent.ceres.entity.domain.BillOutPlanPO
import com.fina.summer.persistent.ceres.entity.vo.TopupPlanAllVO
import org.apache.ibatis.annotations.Mapper
import org.apache.ibatis.annotations.Param
import org.springframework.stereotype.Component

@Mapper
@Component
interface BillOutPlanMapper {

    fun findByIdAndType(@Param("orderIds")orderIds: List<String>, type: BillType) : List<TopupPlanAllVO>
    fun findById()
    /**
     *
     * @author zhengqiyang@zhexinit.com
     * @date 2019/5/16 14:45
     * @param [orderId, typeList]
     * @return Any
     * @description 查询不同类型的订单(一笔订单只有一个类型)
     */

    fun findByOrderIdAndTypeList(@Param("orderId")orderId: String,@Param("typeList")typeList:List<BillType>) : BillOutPlanPO?

}