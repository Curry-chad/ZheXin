package com.fina.summer.persistent.repo.loan

import com.fina.summer.persistent.entity.loan.ApplicationLoanApplicant
import org.springframework.data.jpa.repository.JpaRepository

interface ApplicationLoanApplicantRepo : JpaRepository<ApplicationLoanApplicant, String> {
    fun findByAppLoanOrderId(applicationId: String): ApplicationLoanApplicant
}