package com.fina.summer.persistent.entity.summer

import com.fina.summer.core.enum.BusinessType
import com.fina.summer.core.enum.GoodsType
import com.fina.summer.core.enum.OrderStatus
import com.google.gson.annotations.Expose
import org.hibernate.annotations.DynamicInsert
import org.hibernate.annotations.DynamicUpdate
import org.hibernate.annotations.GenericGenerator
import org.hibernate.annotations.Parameter
import org.springframework.data.annotation.CreatedDate
import org.springframework.data.annotation.LastModifiedDate
import org.springframework.data.jpa.domain.support.AuditingEntityListener
import java.io.Serializable
import java.util.*
import javax.persistence.*

@Entity
@EntityListeners(AuditingEntityListener::class)
@DynamicInsert
@DynamicUpdate
data class LoanOrder(

        @Id
        @GeneratedValue(generator = "idGenerator")
        @GenericGenerator(name = "idGenerator", strategy = "com.fina.summer.persistent.util.SnowGenerator"
                , parameters = [Parameter(name = "prefix", value = "ORD")])
        var id: String? = null,

        var orderTime: Date? = null,

        @Enumerated(EnumType.STRING)
        var businessType: BusinessType? = null,

        @Column(columnDefinition = "varchar(255) COMMENT '备注'")
        var remark: String? = null,

        @Enumerated(EnumType.STRING)
        var status: OrderStatus? = null,

        @Column(columnDefinition = "varchar(32) COMMENT '办单的用户ID'")
        var sellerUserId: String? = null,

        @Column(columnDefinition = "varchar(32) COMMENT '店员信息ID：user_info表的ID，用作数据兼容'")
        var sellerId: String? = null,

        var storeId: String? = null,
        var merId: String? = null,

        var appLoanOrderId: String? = null,

        @Column(columnDefinition = "varchar(32) comment '地区编码'")
        var areaCode: String? = null,//省市区统一编码

//        --- 商品信息
        var goodsCode: String? = null,
        var goodsId: String? = null,
        var goodsPrice: Int? = null,
        var goodsName: String? = null,

        @Column(columnDefinition = "varchar(32) comment '商品类型'")
        @Enumerated(EnumType.STRING)
        var goodsType: GoodsType? = null,

//        --- 订单金额 应该是交易单列表（除了已取消的）的总和
        @Column(columnDefinition = "int(11) COMMENT '分期数'")
        var installmentNum: Int? = 24,

        @Column(columnDefinition = "double COMMENT '利率，商户承担下应该以用户实际支付金额为本金计算利率'")
        var interestRate: Double? = null,

        @Column(columnDefinition = "int(11) COMMENT '用户应付金额'")
        var needPayment: Int? = null,

        @Column(columnDefinition = "int(11) COMMENT '实付金额'")
        var actualPayment: Int? = null,

        @Column(columnDefinition = "int(11) COMMENT '每月还款金额'")
        var monthlyRepaymentAmount: Int? = null,

        @Column(columnDefinition = "int(11) COMMENT '商家应收金额'")
        var needReceive: Int? = null,//优惠价格

//        --- 申请人信息
        @Column(columnDefinition = "varchar(32) comment '订单申请人ID'")
        var orderApplicantId: String? = null,

//        --- 订单业务信息
        var chargePlanGroupId: String? = null,
        var chargePlanId: String? = null,
        var telecomAgreementNo: String? = null,
        var telecomAgreementPic: String? = null,
        var telecomOrderNo: String? = null,

        @Column(columnDefinition = " bit(1) COMMENT '运营商合约信息是否有效'")
        var telecomAgreementValidity: Boolean? = null,

        var sellerClientPhoto: String? = null,
        var message: String? = null,

        @Column(columnDefinition = "varchar(32) comment '店员生成二维码的经度'")
        var longitude: String? = null,

        @Column(columnDefinition = "varchar(32) comment '店员生成二维码的纬度'")
        var latitude: String? = null,

        @Column(columnDefinition = "varchar(32) comment '店员生成二维码的IP'")
        var clientIp: String? = null,

        @Column(columnDefinition = " bit(1) NOT NULL DEFAULT false COMMENT '订单信息是否完善'")
        var completeFlag: Boolean? = false,

        @Column(columnDefinition = "varchar(32) comment '客户端来源：Android Alipay'")
        var clientSource: String? = null,

        @Column(columnDefinition = "varchar(32) comment '客户端版本号'")
        var clientVersion: String? = null,

        @CreatedDate
        var createdTime: Date? = null,

        @LastModifiedDate
        var updatedTime: Date? = null,

        @Transient
        var storeName: String? = null,
        @Transient
        var sellerName: String? = null,
        @Transient
        var sellerMobile: String? = null,
        @Transient
        var chargePlanName: String? = null,
        @Transient
        var chargePlanGroupName: String? = null,
        @Transient
        var sellerOperatorCode: String? = null,

        @Transient
        var tradeList: List<LoanTrade>? = null,

        @Transient
        var appUserId: String? = null,

        @Transient
        var appStoreId: String? = null,

        @Transient
        var appMerId: String? = null,

        @Transient
        var feePerMonth: Int? = 0,

        @Transient
        var chargeNeedPayment: Int? = 0,

        @Transient
        var orderApplicant: LoanOrderApplicant? = null

) : Serializable