package com.fina.summer.persistent.config

import com.fina.summer.persistent.bean.DBConfig
import com.zaxxer.hikari.HikariDataSource
import org.springframework.beans.factory.annotation.Qualifier
import org.springframework.boot.context.properties.ConfigurationProperties
import org.springframework.boot.jdbc.DataSourceBuilder
import org.springframework.context.annotation.Bean
import org.springframework.context.annotation.Configuration
import org.springframework.context.annotation.Primary
import javax.sql.DataSource


@Configuration
class DatasourceConfig {
    @Bean(name = ["primaryDataSource"])
    @Primary
    @Qualifier("primaryDataSource")
    fun primaryDatasource(@Qualifier("primaryDBConfig") dbConfig: DBConfig): DataSource {
        val dataSource = DataSourceBuilder.create()
                .type(HikariDataSource::class.java)
                .password(dbConfig.password)
                .url(dbConfig.jdbcUrl)
                .username(dbConfig.username)
                .driverClassName(dbConfig.driverClassName)
                .build()

        return dataSource
    }

    @Bean("primaryDBConfig")
    @Primary
    @ConfigurationProperties("spring.primary.datasource")
    fun primaryDBConfig(): DBConfig {
        return DBConfig()
    }

    @Bean(name = ["artemisDataSource"])
    @Qualifier("artemisDataSource")
    fun managerDatasource(@Qualifier("artemisDBConfig") dbConfig: DBConfig): DataSource {
        val dataSource = DataSourceBuilder.create()
                .type(HikariDataSource::class.java)
                .password(dbConfig.password)
                .url(dbConfig.jdbcUrl)
                .username(dbConfig.username)
                .driverClassName(dbConfig.driverClassName)
                .build()
        return dataSource
    }

    @Bean("artemisDBConfig")
    @ConfigurationProperties("spring.artemis.datasource")
    fun managerDBConfig(): DBConfig {
        return DBConfig()
    }


    @Bean(name = ["ceresDataSource"])
    @Qualifier("ceresDataSource")
    fun ceresDatasource(@Qualifier("ceresDBConfig") dbConfig: DBConfig): DataSource {
        val dataSource = DataSourceBuilder.create()
                .type(HikariDataSource::class.java)
                .password(dbConfig.password)
                .url(dbConfig.jdbcUrl)
                .username(dbConfig.username)
                .driverClassName(dbConfig.driverClassName)
                .build()
        return dataSource
    }

    @Bean("ceresDBConfig")
    @ConfigurationProperties("spring.ceres.datasource")
    fun ceresDBConfig(): DBConfig {
        return DBConfig()
    }
}