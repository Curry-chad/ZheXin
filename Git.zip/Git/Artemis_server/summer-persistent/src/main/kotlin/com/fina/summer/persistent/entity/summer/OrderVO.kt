package com.fina.summer.persistent.entity.summer

import java.io.Serializable
import java.util.*

data class OrderVO(

        var id: String? = null,

        var agreementNo: String? = null,

        var chargePlanGroupName: String? = null,

        var phoneName: String? = null,

        var imei: String? = null,

        var clientName: String? = null,

        var clientCertNo: String? = null,

        var chargePlanName: String? = null,

        var clientMobile: String? = null,

        var actualReduction: String? = null,

        var actualPayment: String? = null,

        var status: String? = null,

        var tradeTime: Date? = null,

        var sellerName: String? = null,

        var storeName: String? = null,

        var createTime: Date? = null

        ): Serializable