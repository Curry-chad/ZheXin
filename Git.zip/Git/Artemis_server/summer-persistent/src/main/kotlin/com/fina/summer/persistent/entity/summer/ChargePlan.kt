package com.fina.summer.persistent.entity.summer

import org.hibernate.annotations.DynamicInsert
import org.hibernate.annotations.DynamicUpdate
import org.hibernate.annotations.GenericGenerator
import org.hibernate.annotations.Parameter
import org.springframework.data.annotation.CreatedDate
import org.springframework.data.annotation.LastModifiedDate
import org.springframework.data.jpa.domain.support.AuditingEntityListener
import java.io.Serializable
import java.sql.Timestamp
import java.util.*
import javax.persistence.*

@Entity
@Table(name = "charge_plan")
@EntityListeners(AuditingEntityListener::class)
@DynamicInsert
@DynamicUpdate
data class ChargePlan (
    @Id
    @Column(name = "id")
//    @GeneratedValue(generator = "idGenerator")
//    @GenericGenerator(name = "idGenerator", strategy = "com.fina.summer.persistent.util.SnowGenerator"
//            , parameters = [Parameter(name = "prefix", value = "CPL")])
    var id: String? = null,

    @Column(name = "common_rebate")
    var commonRebate: Int? = null,

    @Column(name = "first_rebate")
    var firstRebate: Int? = null,

    @Column(name = "group_id")
    var groupId: String? = null,

    @Column(name = "name")
    var name: String? = null,

    @Column(name = "fee_per_month")
    var feePerMonth: Int? = null,

    @Column(name = "need_receive")
    var needReceive: Int? = null,

    @Column(name = "need_payment")
    var needPayment: Int? = null,

    @Column(name = "installment_num")
    var installmentNum: Int? = null,

    @Column(name = "created_time")
    @CreatedDate
    var createdTime: Date? = null,

    @Column(name = "updated_time")
    @LastModifiedDate
    var updatedTime: Date? = null
): Serializable
