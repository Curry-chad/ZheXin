package com.fina.summer.persistent.ceres.entity

import com.fina.summer.persistent.ceres.entity.constant.TaskStatus
import java.io.Serializable
import java.util.*
import javax.persistence.EnumType
import javax.persistence.Enumerated

data class BillOutTaskUpdateParam(
        var id: String? = null,

        var payerName: String? = null,

        var payerAccount: String? = null,

        var payerBank: String? = null,

        @Enumerated(EnumType.STRING)
        var status: TaskStatus? = null,

        var finishTime: Date? = null,

        var modifyBy: String? = null,

        var modifyTime: Date? = null

) : Serializable