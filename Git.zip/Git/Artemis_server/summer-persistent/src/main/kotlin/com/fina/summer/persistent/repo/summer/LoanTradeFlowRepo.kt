package com.fina.summer.persistent.repo.summer

import com.fina.summer.persistent.entity.summer.LoanTradeFlow
import org.springframework.data.jpa.repository.JpaRepository

interface LoanTradeFlowRepo : JpaRepository<LoanTradeFlow, String> {
}