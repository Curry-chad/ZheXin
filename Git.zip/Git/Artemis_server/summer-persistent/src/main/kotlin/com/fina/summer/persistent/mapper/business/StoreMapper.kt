package com.fina.summer.persistent.mapper.business

import com.fina.summer.persistent.entity.summer.StoreVO
import org.apache.ibatis.annotations.Mapper

@Mapper
interface StoreMapper {

    fun list(): List<StoreVO>

}