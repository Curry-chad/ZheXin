package com.fina.summer.persistent.ceres.entity.constant

enum class TaskStatus(var msg: String) {
    None(""),
    Ready("待处理"),
    Doing("处理中"),
    Cancel("取消"),
    Success("成功"),
    Fail("失败")
}