package com.fina.summer.persistent.repo.user

import com.fina.summer.core.enum.BindType
import com.fina.summer.persistent.entity.summer.user.UserBind
import org.springframework.data.jpa.repository.JpaRepository

interface UserBindRepo: JpaRepository<UserBind,Long> {

    fun findByUserIdAndBindType(userId: String, bindType: BindType): UserBind?
    fun findByBindId(bindId: String): UserBind?
}