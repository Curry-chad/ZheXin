package com.fina.summer.persistent.mapper.business

import com.fina.summer.persistent.entity.summer.user.User
import com.fina.summer.persistent.entity.summer.user.UserInfo
import org.apache.ibatis.annotations.Mapper
import java.util.HashMap

@Mapper
interface UserMapper {

    fun findByMobileAndRole(map: HashMap<String, String>): User?

    fun findUserInfoByStoreId(map: HashMap<String, String>): List<UserInfo>?
}
