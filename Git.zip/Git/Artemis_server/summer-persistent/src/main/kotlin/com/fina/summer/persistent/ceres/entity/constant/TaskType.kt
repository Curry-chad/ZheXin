package com.fina.summer.persistent.ceres.entity.constant

enum class TaskType(var msg: String) {
    Repay("还款"),
    Advance("垫付本金")
}