package com.fina.summer.persistent.entity.summer

import com.fina.summer.core.enum.AuditStatus
import org.hibernate.annotations.*
import org.hibernate.annotations.Parameter
import org.springframework.data.annotation.CreatedDate
import org.springframework.data.annotation.LastModifiedDate
import org.springframework.data.jpa.domain.support.AuditingEntityListener
import java.io.Serializable
import java.util.*
import javax.persistence.*
import javax.persistence.Entity

@Entity
@DynamicUpdate
@DynamicInsert
@EntityListeners(AuditingEntityListener::class)
@Where(clause = "delete_flag =false")
data class Merchant(

        @Id
        @GeneratedValue(generator = "idGenerator")
        @GenericGenerator(name = "idGenerator", strategy = "com.fina.summer.persistent.util.SnowGenerator"
                , parameters = [Parameter(name = "prefix", value = "MER")])
        var id: String? = null,

        @Enumerated(EnumType.STRING)
        var status: AuditStatus? = null,

        var merName: String? = null,

        var merType: String? = null,

        @Column(name = "app_mer_id")
        var appMerId: String? = null,

        @Column(name = "cert_no")
        var certNo: String? = null,

        @Column(name = "cert_picture_path")
        var certPicturePath: String? = null,

        @Column(name = "cert_type")
        var certType: String? = null,

        @Column(name = "cert_name")
        var certName: String? = null,

        @Column(name = "mobile")
        var mobile: String? = null,

        @Column(name = "address")
        var address: String? = null,

        @Column(name = "area_code")
        var areaCode: String? = null,

        @Column(name = "legal_person_name")
        var legalPersonName: String? = null,

        @Column(name = "legal_person_cert_no")
        var legalPersonCertNo: String? = null,

        @Column(name = "legal_person_cert_back_picture_path")
        var legalPersonCertBackPicturePath: String? = null,

        @Column(name = "legal_person_cert_front_picture_path")
        var legalPersonCertFrontPicturePath: String? = null,

        @Column(name = "certification_flag")
        var isCertificationFlag: Boolean = false,

        @Column(name = "contact_person_mobile")
        var contactPersonMobile: String? = null,

        @Column(name = "contact_person_name")
        var contactPersonName: String? = null,

        @Column(name = "contact_person_relationship")
        var contactPersonRelationship: String? = null,

        @Column(name = "delete_flag")
        var deleteFlag: Boolean = false,

        @Column(name = "step")
        var step: Int? = null,

        @Column(name = "audit_count")
        var auditCount: Int? = 0,

        @Column(name = "created_time")
        @CreatedDate
        var createdTime: Date? = null,

        @Column(name = "updated_time")
        @LastModifiedDate
        var updatedTime: Date? = null,

        @Column(name = "user_id")
        var userId: String? = null,

        var message: String? = null,

        @Column(columnDefinition = "varchar(255) COMMENT '商户合约签名'")
        var signature: String? = null,

        @Transient
        var payeeList: List<Payee>? = null

) : Serializable
