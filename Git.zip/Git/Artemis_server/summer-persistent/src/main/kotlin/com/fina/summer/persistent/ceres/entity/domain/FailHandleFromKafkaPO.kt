package com.fina.summer.persistent.ceres.entity.domain

import java.io.Serializable
import java.util.*
import javax.persistence.*

@Entity
@Table(name = "fail_handle_from_kafka", schema = "ceres", catalog = "")
class FailHandleFromKafkaPO(
        @Id
        @GeneratedValue(strategy = GenerationType.IDENTITY)
        @Column(name = "id")
        var id: Int = 0,
        @Basic
        @Column(name = "topic")
        var topic: String? = null,
        @Basic
        @Column(name = "kafka_key")
        var kafkaKey: String? = null,
        @Basic
        @Column(name = "kafka_value")
        var kafkaValue: String? = null,
        @Basic
        @Column(name = "created_time")
        var createdTime: Date? = null,
        @Basic
        @Column(name = "updated_time")
        var updatedTime: Date? = null
) : Serializable
