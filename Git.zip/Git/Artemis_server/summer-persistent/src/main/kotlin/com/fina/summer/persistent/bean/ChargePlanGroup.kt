package com.fina.summer.persistent.bean


class ChargePlanGroup : StoreCodePlanGoods() {

    var id: String? = null

    var name: String? = null
}
