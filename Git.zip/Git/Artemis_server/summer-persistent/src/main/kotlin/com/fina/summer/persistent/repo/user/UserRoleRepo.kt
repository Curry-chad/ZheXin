package com.fina.summer.persistent.repo.user

import com.fina.summer.core.enum.RoleType
import com.fina.summer.persistent.entity.summer.user.Role
import com.fina.summer.persistent.entity.summer.user.UserRole
import org.springframework.data.jpa.repository.JpaRepository
import org.springframework.data.jpa.repository.Query

interface UserRoleRepo: JpaRepository<UserRole,Long> {

    @Query("""
        select r
        from Role r,UserRole ur
        where ur.userId = ?1
        and r.id = ur.roleId
    """ )
    fun findRoleByUserId(userId: String): List<Role>?

    fun findByUserIdAndRoleId(userId: String, roleId: String): UserRole?
}