package com.fina.summer.persistent.mapper.business

import com.fina.summer.persistent.bean.Brand
import com.fina.summer.persistent.bean.ChargePlan
import com.fina.summer.persistent.bean.ChargePlanGroup
import com.fina.summer.persistent.bean.Goods
import org.apache.ibatis.annotations.Mapper


@Mapper
interface ChargePlanMapper {

    fun getChargePlanGroupByStoreAndCode(map: HashMap<String, String>): List<ChargePlanGroup>?

    fun getChargePlanByStoreIdAndCodeAndGroup(map: HashMap<String, String>): List<ChargePlan>?

    fun getBrandByStoreAndCodeAndPlan(map: HashMap<String, String>): List<Brand>?

    fun getGoodsByStoreAndCodeAndPlanAndBrand(map: HashMap<String, String>): List<Goods>?
}