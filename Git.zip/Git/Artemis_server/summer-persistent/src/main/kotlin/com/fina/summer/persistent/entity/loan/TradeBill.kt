package com.fina.summer.persistent.entity.loan

import com.fina.summer.core.enum.Progress
import org.hibernate.annotations.DynamicInsert
import org.hibernate.annotations.DynamicUpdate
import org.hibernate.annotations.GenericGenerator
import org.hibernate.annotations.Parameter
import org.springframework.data.annotation.CreatedDate
import org.springframework.data.annotation.LastModifiedDate
import org.springframework.data.jpa.domain.support.AuditingEntityListener
import java.io.Serializable
import java.util.*
import javax.persistence.*

@Entity
@DynamicInsert
@DynamicUpdate
@EntityListeners(AuditingEntityListener::class)
data class TradeBill(
        @Id
        @GeneratedValue(generator = "idGenerator")
        @GenericGenerator(name = "idGenerator", strategy = "com.fina.summer.persistent.util.SnowGenerator"
                , parameters = [Parameter(name = "prefix", value = "B")])
        @Column(columnDefinition = "varchar(32) comment '账单号'")
        var id: String? = null,

        @Column(columnDefinition = "varchar(32) comment '交易单号'")
        var tradeId: String? = null,


        @Column(columnDefinition = "varchar(64) comment '客户身份证ID'")
        var idCardNo: String? = null,

        @Column(columnDefinition = "varchar(64) comment '银行卡号'")
        var bankCardNo: String? = null,

        @Column(columnDefinition = "int comment '分期次数'")
        var periodTimes: Int? = null,

        @Column(columnDefinition = "int comment '金额（分）,支出为负数，收入为正数'")
        var shouldAmount: Int? = null,

        @Column(columnDefinition = "int comment '金额（分）,支出为负数，收入为正数'")
        var actualAmount: Int? = null,

        @Column(columnDefinition = "datetime comment '交易时间'")
        var tradeTime: Date? = null,

        @Enumerated(EnumType.STRING)
        @Column(columnDefinition = "varchar(64) comment '账单状态'")
        var status: Progress? = null,

        @Column(columnDefinition = "datetime comment '创建时间'")
        @CreatedDate
        var createdTime: Date? = null,

        @Column(columnDefinition = "datetime comment '修改时间'")
        @LastModifiedDate
        var updatedTime: Date? = null

) : Serializable