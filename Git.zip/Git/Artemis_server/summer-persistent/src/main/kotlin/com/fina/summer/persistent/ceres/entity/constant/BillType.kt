package com.fina.summer.persistent.ceres.entity.constant

enum class BillType(var msg: String){
    User("客户"),
    Zyxf("中原"),
    Merchant("商户"),
    Cz("充值"),
    Reward("红包"),
    ServiceCharge("手续费"),
    PhoneBill("话费"),
    PhoneBillNoAmount("话费不兜底")
}