package com.fina.summer.persistent.repo.user

import com.fina.summer.core.enum.JobStatus
import com.fina.summer.persistent.entity.summer.user.UserJob
import org.springframework.data.jpa.repository.JpaRepository

interface UserJobRepo: JpaRepository<UserJob,Long>{

    fun findByUserIdAndJobStatus(userId: String, active: JobStatus): UserJob?

}