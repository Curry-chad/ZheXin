package com.fina.summer.persistent.ceres.entity

import java.io.Serializable
import java.util.*


data class BillTasksQueryParam(

        var startTime: String? = null,

        var endTime: String? = null,

        var fundChannel: String? = null,

        var status: String? = null,

        var page: Int? = null,

        var rows: Int? = null

        ): Serializable