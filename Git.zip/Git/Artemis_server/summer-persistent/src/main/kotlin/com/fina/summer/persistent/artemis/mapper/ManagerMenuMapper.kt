package com.fina.summer.persistent.artemis.mapper

import com.fina.summer.persistent.artemis.entity.vo.ManagerMenuVO
import org.apache.ibatis.annotations.Mapper

@Mapper
interface ManagerMenuMapper {

    fun getUrlsByUserId(userId: String): List<String>

    fun getFirstLvMenusByUserId(userId: String): List<ManagerMenuVO>

    fun listByParentUrlAndUserId(userId: String, parentUrl: String): List<ManagerMenuVO>

}