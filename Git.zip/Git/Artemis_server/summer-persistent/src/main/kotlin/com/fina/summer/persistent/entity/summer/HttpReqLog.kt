package com.fina.summer.persistent.entity.summer

import org.hibernate.annotations.DynamicInsert
import org.hibernate.annotations.DynamicUpdate
import org.springframework.data.annotation.CreatedDate
import org.springframework.data.jpa.domain.support.AuditingEntityListener
import org.springframework.web.bind.annotation.RequestMethod
import java.util.*
import javax.persistence.*

@Entity
@DynamicInsert
@DynamicUpdate
@EntityListeners(AuditingEntityListener::class)
data class HttpReqLog(
        @Id
        @Column(columnDefinition = "varchar(32) COMMENT '流水号'")
        var id: String? = null,
        @Enumerated(EnumType.STRING)
        @Column(columnDefinition = "varchar(32) COMMENT '请求方法'")
        var method: RequestMethod? = null,
        @Column(columnDefinition = "varchar(64)")
        var contentType: String? = null,
        @Column(columnDefinition = "varchar(255) COMMENT '请求链接'")
        var url: String? = null,
        @Column(columnDefinition = "varchar(32) COMMENT '响应CODE'")
        var httpCode: Int? = null,
        @Column(columnDefinition = "text COMMENT '请求体'")
        var requestBody: String? = null,
        @Column(columnDefinition = "text COMMENT '响应体'")
        var responseBody: String? = null,
        @Column(columnDefinition = "bigint(20) COMMENT '耗时'")
        var cost: Long? = null,
        @CreatedDate
        var createTime: Date? = null,
//        @CreatedBy
        @Column(columnDefinition = "varchar(32) COMMENT '创建人'")
        var createBy: String? = null
)