package com.fina.summer.persistent.bean

import com.fasterxml.jackson.annotation.JsonIgnore
import com.fina.summer.core.bean.Pageable
import java.util.*

class OrderQuery(
//        @field:NotNull(message = "起始时间不能为空！")
        var startTime: Date? = null,
//        @field:NotNull(message = "结束时间不能为空！")
        var endTime: Date? = null,

        var mobile: String? = null,

        var name: String? = null,

        var orderId: String? = null,

        var query: String? = null,

        @JsonIgnore
        var sellerId: Long? = null,

        var merId: String? = null,

        @JsonIgnore
        var sellerUserId: String? = null

) : Pageable()