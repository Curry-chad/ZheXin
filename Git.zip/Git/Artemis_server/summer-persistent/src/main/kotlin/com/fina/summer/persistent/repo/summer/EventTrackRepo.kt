package com.fina.summer.persistent.repo.summer

import com.fina.summer.persistent.entity.summer.EventTrack
import org.springframework.data.jpa.repository.JpaRepository

interface EventTrackRepo: JpaRepository<EventTrack,Long> {
}