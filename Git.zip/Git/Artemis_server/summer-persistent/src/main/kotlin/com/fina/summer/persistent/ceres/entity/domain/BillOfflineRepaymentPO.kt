package com.fina.summer.persistent.ceres.entity.domain

import com.fina.summer.persistent.ceres.entity.constant.Progress
import java.util.*
import javax.persistence.*

@Entity
@Table(name = "bill_offline_repayment_tasks", schema = "ceres", catalog = "")
class BillOfflineRepaymentPO (
        @Id
        @Column(name = "id")
        var id: String? = null,
        @Basic
        @Column(name = "order_id")
        var orderId: String? = null,
        @Basic
        @Column(name = "should_amount_num")
        var shouldAmountNum: Int? = null,
        @Basic
        @Column(name = "plan_execute_time")
        var planExecuteTime: Date? = null,
        @Basic
        @Column(name = "should_amount")
        var shouldAmount: Int? = null,
        @Basic
        @Column(name = "payer")
        var payer: String? = null,
        @Basic
        @Column(name = "pay_bank")
        var payBank: String? = null,
        @Basic
        @Column(name = "message")
        var message: String? = null,
        @Basic
        @Column(name = "overdue_num")
        var overdueNum: Int? = null,
        @Basic
        @Column(name = "payer_idno")
        var payerIdno: String? = null,
        @Basic
        @Column(name = "create_by")
        var createBy: String? = null,
        @Basic
        @Column(name = "modify_by")
        var modifyBy: String? = null,
        @Basic
        @Column(name = "created_time")
        var createdTime: Date? = null,
        @Basic
        @Column(name = "updated_time")
        var updatedTime: Date? = null,
        @Basic
        @Column(name = "status")
        @Enumerated(EnumType.STRING)
        var status: Progress? = null,
        @Basic
        @Column(name = "total_amount")
        var totalAmount: Int? = null,
        @Basic
        @Column(name = "transfer_method")
        var transferMethod: String? = null,
        @Basic
        @Column(name = "collection_account")
        var collectionAccount: String? = null,
        @Basic
        @Column(name = "finish_time")
        var finishTime: Date? = null,
        @Basic
        @Column(name = "pay_account")
        var payAccount: String? = null
)