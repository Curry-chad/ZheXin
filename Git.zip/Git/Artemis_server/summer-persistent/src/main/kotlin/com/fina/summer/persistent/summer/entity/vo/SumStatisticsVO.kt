package com.fina.summer.persistent.summer.entity.vo

import java.io.Serializable
import java.math.BigDecimal


data class SumAllVo(

        var sumOrderNum: Long? = 0,
        var sumOrderAmount: BigDecimal? = BigDecimal(0),
        var areaList: List<SumAreasVO>? = ArrayList()


) : Serializable

data class SumAreasVO(
        var areaName: String? = null,

        var areaCode: String? = null,

        var sumOrderNum: Long? = 0,
        var sumOrderAmount: BigDecimal? = BigDecimal(0)
) : Serializable