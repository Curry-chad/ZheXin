package com.fina.summer.persistent.ceres.repo

import com.fina.summer.persistent.ceres.entity.domain.ShortMessagePO
import org.springframework.data.jpa.repository.JpaRepository

interface ShortMessageRepo: JpaRepository<ShortMessagePO, Long> {
}