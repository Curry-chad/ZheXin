package com.fina.summer.persistent.ceres.entity.vo

import io.swagger.annotations.ApiModelProperty
import java.io.Serializable

data class RedEnvelopesNumVo (

        @ApiModelProperty("全部红包")
        var allRed: Int? = null,

        @ApiModelProperty("全部红包金额")
        var amountMoney: String? = null,

        @ApiModelProperty("已发放红包")
        var grantRed: Int? = null,

        @ApiModelProperty("已发放红包金额")
        var grantAmountMoney: String? = null,

        @ApiModelProperty("待发放红包")
        var unissuedRed: Int? = null,

        @ApiModelProperty("代发放红包金额")
        var unissuedAmountMoney: String? = null,

        @ApiModelProperty("发送失败红包")
        var failRed: Int? = null,

        @ApiModelProperty("发送失败红包金额")
        var failAmountMoney: String? = null
): Serializable