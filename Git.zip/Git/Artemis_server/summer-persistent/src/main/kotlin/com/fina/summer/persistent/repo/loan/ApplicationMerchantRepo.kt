package com.fina.summer.persistent.repo.loan

import com.fina.summer.persistent.entity.loan.ApplicationMertchant
import org.springframework.data.jpa.repository.JpaRepository

interface ApplicationMerchantRepo: JpaRepository<ApplicationMertchant,String> {
}