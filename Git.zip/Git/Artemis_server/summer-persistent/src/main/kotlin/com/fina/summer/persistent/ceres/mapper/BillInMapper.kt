package com.fina.summer.persistent.ceres.mapper

import com.fina.summer.persistent.ceres.entity.BillInQueryParam
import com.fina.summer.persistent.ceres.entity.domain.BillInFlowDO
import com.fina.summer.persistent.ceres.entity.domain.BillInTasksPO
import com.fina.summer.persistent.ceres.entity.vo.BillInVO
import com.fina.summer.persistent.ceres.entity.vo.PrepaymentVO
import org.apache.ibatis.annotations.Mapper
import org.apache.ibatis.annotations.Param
import org.springframework.stereotype.Component

@Mapper
@Component
interface BillInMapper {

    fun findAllBy(@Param("query") query: BillInQueryParam): List<BillInVO>

    fun findAllFlowByBisTaskIdAndSeqNo(@Param("bisTaskId") bisTaskId: String, @Param("seqNo") seqNo: Int): BillInFlowDO?

    fun findLatelyFLow(bisTaskId: String): BillInFlowDO?

    fun findByBisTaskId(@Param("query") prepayment: PrepaymentVO): List<BillInTasksPO>

    fun findByCount(@Param("query") prepayment: PrepaymentVO): Int
}