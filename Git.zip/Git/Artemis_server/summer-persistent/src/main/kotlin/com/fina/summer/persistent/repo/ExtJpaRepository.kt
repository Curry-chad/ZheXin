package com.fina.summer.persistent.repo

import org.springframework.data.jpa.repository.JpaRepository
import java.io.Serializable
import org.springframework.data.repository.NoRepositoryBean


@NoRepositoryBean
interface ExtJpaRepository<T, ID : Serializable> : JpaRepository<T, ID> {
    /**
     * insert or dynamic update entity (will findOne first)
     * @param id entity id
     * @param entity entity
     * @return entity
     */
    fun dynamicSave(id: ID, entity: T): T
}