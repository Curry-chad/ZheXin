package com.fina.summer.persistent.ceres.repo

import com.fina.summer.persistent.ceres.entity.domain.BillOutFlowsPO
import org.apache.ibatis.annotations.Param
import org.springframework.data.jpa.repository.JpaRepository
import org.springframework.data.jpa.repository.Query

interface BillOutFlowsRepo : JpaRepository<BillOutFlowsPO, String> {
    @Query(value = "SELECT * from bill_out_flows where task_id =?1 and status!=\"Success\" ORDER BY updated_time desc LIMIT 1\n", nativeQuery = true)
     fun findByTaskIdDesc(outTaskId: String): BillOutFlowsPO
}