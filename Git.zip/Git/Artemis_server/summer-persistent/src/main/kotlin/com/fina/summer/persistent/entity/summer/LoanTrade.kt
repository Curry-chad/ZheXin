package com.fina.summer.persistent.entity.summer

import com.fina.summer.core.enum.BindStatus
import com.fina.summer.core.enum.InstitutionType
import com.fina.summer.core.enum.OrderStatus
import com.fina.summer.core.enum.PaymentChannel
import org.hibernate.annotations.DynamicInsert
import org.hibernate.annotations.DynamicUpdate
import org.hibernate.annotations.GenericGenerator
import org.hibernate.annotations.Parameter
import org.springframework.data.annotation.CreatedDate
import org.springframework.data.annotation.LastModifiedDate
import org.springframework.data.jpa.domain.support.AuditingEntityListener
import java.io.Serializable
import java.util.*
import javax.persistence.*

@Entity
@EntityListeners(AuditingEntityListener::class)
@DynamicInsert
@DynamicUpdate
data class LoanTrade(

        @Id
        @GeneratedValue(generator = "idGenerator")
        @GenericGenerator(name = "idGenerator", strategy = "com.fina.summer.persistent.util.SnowGenerator"
                , parameters = [Parameter(name = "prefix", value = "TRA")])
        var id: String? = null,

//        @Column(columnDefinition = "varchar(32) NOT NULL COMMENT '订单ID'")
        var orderId: String? = null,

        @Enumerated(EnumType.STRING)
//        @Column(columnDefinition = "varchar(32) COMMENT '订单状态，NO_APPLY:订单创建未申请支付，PAYING:等待支付，FAIL_APPLY:支付申请失败，PAYED:支付成功'")
        var status: OrderStatus? = null,

        @Column(columnDefinition = "varchar(32) COMMENT '交易标题'")
        var subject: String? = null,

//        --- 进件ID
        var appLoanTradeId: String? = null,

        @Column(name = "trade_time")
        var tradeTime: Date? = null,

        @Column(columnDefinition = "datetime comment '到账时间'")
        var receiptTime: Date? = null,

        //        --- 订单金额
        var principal: Int? = null,
//        @Column(columnDefinition = "int(11) COMMENT '本息合计'")
        var principalAndInterest: Int? = null,

        @Column(columnDefinition = "double COMMENT '利率，商户承担下应该以用户实际支付金额为本金计算利率'")
        var interestRate: Double? = null,

//        @Column(columnDefinition = "int(11) DEFAULT NULL COMMENT '帐期'")
        var accountPeriod: Int? = null,
//        @Column(columnDefinition = "varchar(32) COMMENT '还款方式：等额本息'")
        var repaymentMethod: String? = null,
//        @Column(columnDefinition = "int(11) DEFAULT NULL COMMENT '每月还款金额'")
        var monthlyRepaymentAmount: Int? = null,

//--- 付款人
//        @Column(columnDefinition = "varchar(32) COMMENT '付款人资金方机构：支付宝，银联'")
        @Enumerated(EnumType.STRING)
        var payerLoanInstitution: InstitutionType? = null,
//        @Column(columnDefinition = "varchar(64) DEFAULT NULL COMMENT '付款人所属资金方机构账号ID'")
        var payerAccountId: String? = null,
//        @Column(columnDefinition = "varchar(64) DEFAULT NULL COMMENT '付款人所属资金方机构登录账号'")
        var payerLogonAccount: String? = null,

        @Column(columnDefinition = "varchar(64) comment '付款机构名称'")
        var payerInstitutionName: String? = null,
//        @Column(columnDefinition = "varchar(64) DEFAULT NULL COMMENT '支付渠道,ant_check_later:蚂蚁花呗，信用卡'")

        @Enumerated(EnumType.STRING)
        var paymentChannel: PaymentChannel? = null,
//        @Column(columnDefinition = "int(11) DEFAULT NULL COMMENT '应付款金额'")
        var payerNeedPayment: Int? = null,

        @Column(columnDefinition = "varchar(32) comment '绑卡状态：待验证，成功，失败'")
        @Enumerated(EnumType.STRING)
        var payerAuthStatus: BindStatus? = null,//绑卡状态：待验证，成功，失败

        @Column(columnDefinition = "tinyint(1) default '0' comment '人脸识别结果'")
        var faceRecognitionResult: Boolean? = false,

        @Column(columnDefinition = "varchar(255) comment '人脸识别影像件'")
        var faceRecognitionImageUrl: String? = null,

        @Column(columnDefinition = "varchar(512) comment '人脸识别影像分析数据'")
        var faceRecognitionAnalyse: String? = null,

//--- 收款人

//        @Column(columnDefinition = "varchar(32) COMMENT '收款人资金方机构：支付宝，银联'")
        @Enumerated(EnumType.STRING)
        var receiveLoanInstitution: InstitutionType? = null,
//        @Column(columnDefinition = "varchar(64) DEFAULT NULL COMMENT '收款方账户'")
        var receiveAccount: String? = null,
//        @Column(columnDefinition = "varchar(64) DEFAULT NULL COMMENT '收款方账户ID'")
        var receiveAccountId: String? = null,
//        @Column(columnDefinition = "int(11) DEFAULT NULL COMMENT '应收款金额'")
        var receiveNeedPayment: Int? = null,

        @Column(columnDefinition = "varchar(64) comment '收款机构名称：支付宝/xx银行'")
        var receiveInstitutionName: String? = null,

        @Column(columnDefinition = "int(11) COMMENT '用户实付款金额'")
        var payerActualPayment: Int? = null,

        @Column(columnDefinition = "int(11) COMMENT '商家实收款金额'")
        var receiveActualPayment: Int? = null,

//--- 资金方交易编号

        @Column(columnDefinition = "varchar(64) DEFAULT NULL COMMENT '外部平台订单号，如支付宝'")
        var thirdTradeFlowNo: String? = null,
        @Column(columnDefinition = "varchar(255) DEFAULT NULL COMMENT '支付二维码链接'")
        var qrCode: String? = null,

        @Column(columnDefinition = "varchar(255) DEFAULT NULL COMMENT '交易信息'")
        var message: String? = null,

        @CreatedDate
        var createdTime: Date? = null,

        @LastModifiedDate
        var updatedTime: Date? = null,

        @Transient
        var appLoanOrderId: String? = null,

        @Transient
        var riskCode: String? = null


) : Serializable