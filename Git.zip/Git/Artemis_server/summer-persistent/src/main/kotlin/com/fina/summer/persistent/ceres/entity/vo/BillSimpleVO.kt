package com.fina.summer.persistent.ceres.entity.vo

import java.io.Serializable

data class BillSimpleVO(

        var thirdOrderId: String? = null,

        var payeeAccount: String? = null,

        var payee: String? = null,

        var orderId:String?=null,

        var totalAmount:String?=null,

        var msg:String?=null


        ): Serializable