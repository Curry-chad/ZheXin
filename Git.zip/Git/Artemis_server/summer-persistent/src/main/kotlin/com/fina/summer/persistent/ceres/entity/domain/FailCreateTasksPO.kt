package com.fina.summer.persistent.ceres.entity.domain

import java.io.Serializable
import java.util.*
import javax.persistence.*

@Entity
@Table(name = "fail_create_tasks", schema = "ceres", catalog = "")
class FailCreateTasksPO (
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    var id: Int = 0,
    @Basic
    @Column(name = "bis_task_id")
    var bisTaskId: String? = null,
    @Basic
    @Column(name = "bis_task_type")
    var bisTaskType: String? = null,
    @Basic
    @Column(name = "created_time")
    var createdTime: Date? = null,
    @Basic
    @Column(name = "updated_time")
    var updatedTime: Date? = null
): Serializable
