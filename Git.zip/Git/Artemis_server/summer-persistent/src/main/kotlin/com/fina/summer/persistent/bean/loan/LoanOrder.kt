package com.fina.summer.persistent.bean.loan

import io.swagger.annotations.ApiModelProperty
import java.io.Serializable
import java.util.*

data class LoanOrder (

        @ApiModelProperty("订单编号")
        var orderId: String? = null,

        @ApiModelProperty("订单所在省")
        var provinceName: String? = null,

        @ApiModelProperty("订单所在市")
        var cityName: String? = null,

        @ApiModelProperty("订单所在区")
        var areaName: String? = null,

        @ApiModelProperty("商户名")
        var merName: String? = null,

        @ApiModelProperty("门店名")
        var storeName: String? = null,

        @ApiModelProperty("店员")
        var sellName: String? = null,

        @ApiModelProperty("店员手机")
        var sellMobile: String? = null,

        @ApiModelProperty("实付金额")
        var actualPayment: Int? = null,

        @ApiModelProperty("商品名称")
        var goodsName: String? = null,
        @ApiModelProperty("客户")
        var realname: String? = null,

        @ApiModelProperty("状态")
        var status: String? = null,

        @ApiModelProperty("创建时间")
        var orderCreatedTime: Date? = null,

//详情
        @ApiModelProperty("套餐名称")
        var planName: String? = null,
        @ApiModelProperty("门店id")
        var storeId: String? = null,
        @ApiModelProperty("门店地址")
        var storeAddress: String? = null,
        @ApiModelProperty("支付方式")
        var paymentChannel: String? = null,
        @ApiModelProperty("支付账号")
        var payerLogonAccount: String? = null,
        @ApiModelProperty("用户手机")
        var applicantMobile: String? = null,
        @ApiModelProperty("身份证id")
        var idNo: String? = null,
        @ApiModelProperty("门店bossid")
        var organizationCode: String? = null,
        @ApiModelProperty("交易单号")
        var tradeId: String? = null,
        @ApiModelProperty("合约信息是否有效")
        var telecomAgreementValidity: String? = null,
        @ApiModelProperty("合约号")
        var telecomAgreementNo: String? = null,
        @ApiModelProperty("合约状态")
        var telecomAgreementStatus: String? = null,
        @ApiModelProperty("交易状态")
        var tradeStatus: String? = null,
        @ApiModelProperty("交易单创建时间")
        var tradeCreatedTime: Date? = null

): Serializable