package com.fina.summer.persistent.mapper.business

import com.fina.summer.persistent.entity.summer.SellerVO
import org.apache.ibatis.annotations.Mapper

@Mapper
interface SellerMapper {

    fun list(): List<SellerVO>

}