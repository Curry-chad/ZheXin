package com.fina.summer.persistent.config

import org.apache.ibatis.session.SqlSessionFactory
import org.mybatis.spring.SqlSessionFactoryBean
import org.mybatis.spring.annotation.MapperScan
import org.springframework.beans.factory.annotation.Qualifier
import org.springframework.boot.SpringBootConfiguration
import org.springframework.context.annotation.Bean
import org.springframework.context.annotation.Primary
import org.springframework.core.io.support.PathMatchingResourcePatternResolver
import org.springframework.jdbc.datasource.DataSourceTransactionManager
import javax.sql.DataSource

@SpringBootConfiguration
@MapperScan(basePackages = ["com.fina.summer.persistent.mapper","com.fina.summer.persistent.summer.mapper"], sqlSessionFactoryRef = "primarySessionFactory")
open class PrimaryMybatisConfig {
    @Bean("primarySessionFactory")
    @Primary
    open fun mysqlSessionFactory(@Qualifier("primaryDataSource") mysqlDataSource: DataSource): SqlSessionFactory {
        val bean = SqlSessionFactoryBean()
        val configuration = org.apache.ibatis.session.Configuration()
        configuration.isMapUnderscoreToCamelCase = true
        bean.setConfiguration(configuration)
        bean.setDataSource(mysqlDataSource)
        bean.setMapperLocations(PathMatchingResourcePatternResolver().getResources("classpath*:mapper/**/*.xml"))
        return bean.getObject()!!
    }


    //@Primary
    @Bean("primaryTransactionManager")
    open fun clusterTransactionManager(@Qualifier("primaryDataSource") dataSource: DataSource): DataSourceTransactionManager {
        return DataSourceTransactionManager(dataSource)
    }


}