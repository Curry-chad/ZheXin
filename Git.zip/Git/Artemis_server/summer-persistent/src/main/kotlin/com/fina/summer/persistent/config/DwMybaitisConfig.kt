package com.fina.summer.persistent.config

import org.apache.ibatis.session.SqlSessionFactory
import org.mybatis.spring.SqlSessionFactoryBean
import org.mybatis.spring.annotation.MapperScan
import org.springframework.beans.factory.annotation.Qualifier
import org.springframework.boot.SpringBootConfiguration
import org.springframework.context.annotation.Bean
import org.springframework.core.io.support.PathMatchingResourcePatternResolver
import org.springframework.jdbc.datasource.DataSourceTransactionManager
import javax.sql.DataSource

//@SpringBootConfiguration
//@MapperScan(basePackages = ["com.fina.summer.persistent.summer.mapper"], sqlSessionFactoryRef = "primarySessionFactory")
open class DwMybatisConfig {
    @Bean("summerSessionFactory")
    open fun mysqlSessionFactory(@Qualifier("summerDataSource") mysqlDataSource: DataSource): SqlSessionFactory {
        val bean = SqlSessionFactoryBean()
        val configuration = org.apache.ibatis.session.Configuration()
        configuration.isMapUnderscoreToCamelCase = true
        bean.setConfiguration(configuration)
        bean.setDataSource(mysqlDataSource)
        bean.setMapperLocations(PathMatchingResourcePatternResolver().getResources("classpath*:mapper/summer/*.xml"))
        return bean.getObject()!!
    }


    @Bean("mybatisTransactionManager")
    open fun clusterTransactionManager(@Qualifier("summerDataSource") dataSource: DataSource): DataSourceTransactionManager {
        return DataSourceTransactionManager(dataSource)
    }


}