package com.fina.summer.persistent.ceres.entity.domain

import com.fina.summer.persistent.ceres.entity.constant.FlowStatus
import com.fina.summer.persistent.ceres.entity.constant.PayType
import org.hibernate.annotations.DynamicInsert
import org.hibernate.annotations.DynamicUpdate
import org.hibernate.annotations.GenericGenerator
import org.hibernate.annotations.Parameter
import java.io.Serializable
import java.util.*
import javax.persistence.*

@Entity
@DynamicInsert
@DynamicUpdate
@Table(name = "bill_out_flow", schema = "ceres", catalog = "")
class BillOutFlowDO(
        @Id
        @GeneratedValue(generator = "idGenerator")
        @GenericGenerator(name = "idGenerator", strategy = "com.fina.summer.persistent.util.SnowGenerator"
                , parameters = [(Parameter(name = "prefix", value = "BOF"))])
        @Column(name = "id")
        var id: String? = null,
        @Basic
        @Column(name = "amount")
        var amount: Int? = null,
        @Basic
        @Column(name = "create_by")
        var createBy: String? = null,
        @Basic
        @Column(name = "create_time")
        var createTime: Date? = null,
        @Basic
        @Column(name = "execute_time")
        var executeTime: Date? = null,
        @Basic
        @Column(name = "message")
        var message: String? = null,
        @Basic
        @Column(name = "modify_by")
        var modifyBy: String? = null,
        @Basic
        @Column(name = "modify_time")
        var modifyTime: Date? = null,
        @Basic
        @Column(name = "pay_account")
        var payAccount: String? = null,
        @Basic
        @Column(name = "pay_bank")
        var payBank: String? = null,
        @Basic
        @Column(name = "pay_type")
        @Enumerated(EnumType.STRING)
        var payType: PayType? = null,
        @Basic
        @Column(name = "payee")
        var payee: String? = null,
        @Basic
        @Column(name = "payee_account")
        var payeeAccount: String? = null,
        @Basic
        @Column(name = "payee_open_institution")
        var payeeOpenInstitution: String? = null,
        @Basic
        @Column(name = "payer")
        var payer: String? = null,
        @Basic
        @Column(name = "payment_voucher")
        var paymentVoucher: String? = null,
        @Basic
        @Column(name = "penalty")
        var penalty: Int? = null,
        @Basic
        @Column(name = "request_no")
        var requestNo: String? = null,
        @Basic
        @Column(name = "status")
        @Enumerated(EnumType.STRING)
        var status: FlowStatus? = null,
        @Basic
        @Column(name = "task_id")
        var taskId: String? = null,
        @Basic
        @Column(name = "third_order_id")
        var thirdOrderId: String? = null,
        @Basic
        @Column(name = "trade_id")
        var tradeId: String? = null
) : Serializable
