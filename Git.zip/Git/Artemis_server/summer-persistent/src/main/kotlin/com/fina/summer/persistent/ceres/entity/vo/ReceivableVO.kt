package com.fina.summer.persistent.ceres.entity.vo

import com.fina.summer.persistent.ceres.entity.constant.Progress
import io.swagger.annotations.ApiModelProperty
import java.io.Serializable
import java.util.*
import javax.persistence.EnumType
import javax.persistence.Enumerated

data class ReceivableVO(
        @ApiModelProperty("还款计划编号")
        var id: String? = null,

        @ApiModelProperty("还款计划总表编号")
        var bisTaskId: String? = null,

        @ApiModelProperty("还款人")
        var payer: String? = null,

        @ApiModelProperty("扣款期数")
        var seqNo: Int? = null,

        @ApiModelProperty("分期次数")
        var periodTimes: Int? = null,

        @ApiModelProperty("扣款本金")
        var shouldAmount: Int? = null,

        @ApiModelProperty("总期数扣款本金（所有期数本金）")
        var totalShouldAmount: Int? = null,

        @ApiModelProperty("总扣款本金（本金+违约金）")
        var totalAmount: Int? = null,

        @ApiModelProperty("逾期天数")
        var overdueDays: Int? = null,

        @ApiModelProperty("扣款时间")
        var planExecuteTime: Date? = null,

        @ApiModelProperty("上一次扣款时间")
        var lastExecuteTime: Date? = null,

        @ApiModelProperty("实际完成时间")
        var finishTime: Date? = null,

        @ApiModelProperty("扣款状态")
        @Enumerated(EnumType.STRING)
        var status: Progress? = null,

        @ApiModelProperty("订单编号")
        var orderId: String? = null,

        @ApiModelProperty("交易时间")
        var orderTradeTime: Date? = null,

        @ApiModelProperty("门店名称")
        var storeName: String? = null, //*

        @ApiModelProperty("店员名称")
        var sellerName: String? = null, //*

        @ApiModelProperty("店员名称")
        var checkStatus: Int? = null, //*

        @ApiModelProperty("详情：还款人电话")
        var payerMobile: String? = null,

        @ApiModelProperty("详情：还款人身份证号码")
        var payerIdno: String? = null,

        @ApiModelProperty("详情：还款人储蓄卡卡号")
        var payAccount: String? = null,

        @ApiModelProperty("详情：套餐名称")
        var chargePlanName: String? = null,

        @ApiModelProperty("详情：设备型号")
        var deviceModel: String? = null,

        @ApiModelProperty("详情：店员电话")
        var sellerMobile: String? = null,

        @ApiModelProperty("详情：商户电话")
        var merMobile: String? = null,

        @ApiModelProperty("详情：联系人1姓名")
        var linkmanOneName: String? = null,

        @ApiModelProperty("详情：联系人1电话")
        var linkmanOneMobile: String? = null,

        @ApiModelProperty("详情：联系人1与还款人关系")
        var linkmanOneRelation: String? = null,

        @ApiModelProperty("详情：联系人2姓名")
        var linkmanTwoName: String? = null,

        @ApiModelProperty("详情：联系人2手机号")
        var linkmanTwoMobile: String? = null,

        @ApiModelProperty("详情：联系人2余还款人关系")
        var linkmanTwoRelation: String? = null,

        var province: String? = null,

        var city: String? = null,

        var district: String? = null
): Serializable