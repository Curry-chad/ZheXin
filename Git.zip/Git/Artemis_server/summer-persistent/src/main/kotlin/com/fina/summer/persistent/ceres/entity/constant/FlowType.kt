package com.fina.summer.persistent.ceres.entity.constant

enum class FlowType(var msg: String) {
    Undefined(""),
    BindingAndChangingCard("储蓄卡绑定与更换")
}