package com.fina.summer.persistent.entity.summer.user

import com.fina.summer.core.enum.JobStatus
import org.hibernate.annotations.DynamicInsert
import org.hibernate.annotations.DynamicUpdate
import org.springframework.data.annotation.CreatedDate
import org.springframework.data.annotation.LastModifiedDate
import org.springframework.data.jpa.domain.support.AuditingEntityListener
import java.io.Serializable
import java.util.*
import javax.persistence.*


@Entity
@DynamicInsert
@DynamicUpdate
@EntityListeners(AuditingEntityListener::class)
data class UserJob (

        @Id
        @GeneratedValue(strategy = GenerationType.IDENTITY)
        var id: Long? = null,

        @Column(columnDefinition = "varchar(32) comment '用户ID'")
        var userId: String? = null,

        @Column(columnDefinition = "varchar(32) comment '商户ID'")
        var merId: String? = null,

        @Column(columnDefinition = "varchar(32) comment '门店ID'")
        var storeId: String? = null,

        @Column(columnDefinition = "varchar(32) comment '门店名称'")
        var storeName: String? = null,

        @Column(columnDefinition = "varchar(32) comment '操作员编号'")
        var operatorCode: String? = null,

        @Column(columnDefinition = "varchar(32) comment '工作状态： 在职-Active，离职-Leave'")
        @Enumerated(EnumType.STRING)
        var jobStatus: JobStatus? = null,

        @CreatedDate
        var createdTime: Date? = null,

        @LastModifiedDate
        var updatedTime: Date? = null
): Serializable