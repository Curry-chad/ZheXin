package com.fina.summer.persistent.bean.loan

import com.fina.summer.persistent.ceres.entity.constant.PayType
import io.swagger.annotations.ApiModelProperty
import java.io.Serializable
import java.util.*
import javax.persistence.EnumType
import javax.persistence.Enumerated

data class ChargeBack (

        @ApiModelProperty("交易单id")
        var id: String? = null,

        @ApiModelProperty("支付账号")
        var payAccount: String? = null,

        @ApiModelProperty("支付方式")
        @Enumerated(EnumType.STRING)
        var payType: PayType? = null,

        @ApiModelProperty("更新时间")
        var updatedTime: Date? = null,

        @ApiModelProperty("应付金额")
        var amount: String? = null,

        @ApiModelProperty("收款方式")
        var payeeType: PayType? = null,

        @ApiModelProperty("收方账号")
        var payeeAccount: String? = null,

        @ApiModelProperty("备注")
        var notes: String? = null,

        @ApiModelProperty("文件")
        var file: String? = null

        ): Serializable