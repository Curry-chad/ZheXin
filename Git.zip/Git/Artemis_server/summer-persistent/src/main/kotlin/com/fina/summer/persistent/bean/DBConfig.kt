package com.fina.summer.persistent.bean

import com.fina.summer.core.utils.ConfigTools


class DBConfig {

    var username: String? = null

    var jdbcUrl: String? = null

    var driverClassName: String? = null

    var decrypt: Boolean = false

    var decryptKey: String? = null

    var password: String? = null
        get() = if (field != null && decrypt) ConfigTools.decrypt(decryptKey, field!!) else field

    var initialSize: Int = 0

    var minIdle: Int = 0

    var maxActive: Int = 0

    var maxWait: Int = 0

    var timeBetweenEvictionRunsMillis: Int = 0

    var minEvictableIdleTimeMillis: Int = 0

    var validationQuery: String? = null

    var testWhileIdle: Boolean = false

    var testOnBorrow: Boolean = false

    var testOnReturn: Boolean = false

    var poolPreparedStatements: Boolean = false

    var maxPoolPreparedStatementPerConnectionSize: Int = 0

    var filters: String? = null

    var connectionProperties: String? = null
}