package com.fina.summer.persistent.ceres.repo

import com.fina.summer.persistent.ceres.entity.domain.BillInFlowDO
import org.springframework.data.jpa.repository.JpaRepository

interface BillInFlowRepo : JpaRepository<BillInFlowDO, String> {

    fun findByTaskId(taskId: String): BillInFlowDO?
}