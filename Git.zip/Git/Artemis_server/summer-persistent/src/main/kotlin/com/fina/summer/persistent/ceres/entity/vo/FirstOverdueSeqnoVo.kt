package com.fina.summer.persistent.ceres.entity.vo

import io.swagger.annotations.ApiModelProperty
import java.io.Serializable

/**
 * @author zhengqiyang@zhexinit.com
 * @version V1.0
 * @since 1.0 2019/5/7 14:55
 * @description 订单首期逾期期次对象
 */
data class FirstOverdueSeqnoVo (
        @ApiModelProperty("打款任务总表ID")
        var bisTaskId: String? = null,

        @ApiModelProperty("期次号")
        var seqNo: Int? = null
):Serializable