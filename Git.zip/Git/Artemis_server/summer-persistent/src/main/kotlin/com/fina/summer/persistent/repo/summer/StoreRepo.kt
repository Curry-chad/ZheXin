package com.fina.summer.persistent.repo.summer

import com.fina.summer.core.enum.AuditStatus
import com.fina.summer.persistent.entity.summer.Store
import org.springframework.data.jpa.repository.JpaRepository

interface StoreRepo: JpaRepository<Store, String> {

    fun findAllByMerId(merId: String): List<Store>?
    fun findByOrganizationCode(organizationCode: String): Store?
    fun findAllByMerIdAndStatus(merId: String, auditPass: AuditStatus): List<Store>?
}