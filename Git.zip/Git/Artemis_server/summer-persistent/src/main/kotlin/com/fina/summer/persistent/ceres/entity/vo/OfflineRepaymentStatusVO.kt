package com.fina.summer.persistent.ceres.entity.vo

import com.fina.summer.persistent.ceres.entity.constant.Progress
import io.swagger.annotations.ApiModelProperty
import java.io.Serializable

data class OfflineRepaymentStatusVO (

        @ApiModelProperty("还款计划Id")
        var id: String? = null,

        @ApiModelProperty("订单编号")
        var orderId: String? = null,

        @ApiModelProperty("支付方姓名")
        var payer: String? = null,

        @ApiModelProperty("转账方式")
        var transferMethod: String? = null,

        @ApiModelProperty("我方收款账户")
        var collectionAccount: String? = null,

        @ApiModelProperty("支付方银行名称")
        var payBank: String? = null,

        @ApiModelProperty("应还款时间")
        var planExecuteTime: String? = null,

        @ApiModelProperty("应还款金额（分 包含逾期金额）")
        var shouldAmountNum: Int? = null,

        @ApiModelProperty("实际还款金额")
        var totalAmount: Int? = null,

        @ApiModelProperty("实际还款时间")
        var finishTime: String? = null,

        @ApiModelProperty("当前逾期期数")
        var overdueNum: Int? = null,

        @ApiModelProperty("修改人")
        var modifyBy: String? = "collection",

        @ApiModelProperty("催收状态")
        var status: Progress? = null

): Serializable