package com.fina.summer.persistent.mapper.business

import com.fina.summer.persistent.entity.summer.OrderVO
import org.apache.ibatis.annotations.Mapper

@Mapper
interface OrderMapper {

    fun list(): List<OrderVO>

}