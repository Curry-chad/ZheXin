package com.fina.summer.persistent.artemis.entity.vo

import java.io.Serializable

data class ManagerMenuVO(

        var id: Long? = null,

        var name: String? = null,

        var url: String? = null,

        var typeName: String? = null,

        var delimiter: String? = null

) : Serializable