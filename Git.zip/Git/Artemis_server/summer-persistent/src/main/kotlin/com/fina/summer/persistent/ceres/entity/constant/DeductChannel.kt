package com.fina.summer.persistent.ceres.entity.constant

enum class DeductChannel {
    YeePayHdr,//易宝-翰达睿
    YeePayZx,//易宝-哲信
    AllinPay, // 通联
    BaofooPay//宝付
}