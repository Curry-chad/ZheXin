package com.fina.summer.persistent.ceres.entity.vo

import com.fina.summer.persistent.ceres.entity.constant.FundChannel
import com.fina.summer.persistent.ceres.entity.domain.BillInTasksPO
import java.io.Serializable

data class FundChannelVO(

        var tradeId: String?,

        var fundChannel: FundChannel?

): Serializable