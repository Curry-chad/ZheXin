package com.fina.summer.persistent.repo.summer

import com.fina.summer.core.enum.OrderStatus
import com.fina.summer.persistent.entity.summer.LoanTrade
import org.springframework.data.jpa.repository.JpaRepository
import org.springframework.data.jpa.repository.Query

interface LoanTradeRepo : JpaRepository<LoanTrade, String> {

    fun findAllByOrderId(id: String): List<LoanTrade>?

    fun findAllByOrderIdAndStatusNot(id: String, cancel: OrderStatus): List<LoanTrade>?

    @Query("""
        select tr.*
        from loan_trade tr
        where tr.order_id = ?1
        and (tr.status = 'Payed' or tr.status = 'PayedWithoutAdvance')
    """, nativeQuery = true)
    fun findPayedTrades(orderId: String): List<LoanTrade>?
}