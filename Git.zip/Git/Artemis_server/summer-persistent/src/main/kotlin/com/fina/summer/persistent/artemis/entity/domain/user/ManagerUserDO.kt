package com.fina.summer.persistent.artemis.entity.domain.user

import com.fina.summer.core.utils.Md5Util
import com.fina.summer.persistent.artemis.entity.domain.ManagerRoleDO
import com.google.gson.annotations.Expose
import org.hibernate.annotations.DynamicInsert
import org.hibernate.annotations.DynamicUpdate
import org.hibernate.annotations.GenericGenerator
import org.hibernate.annotations.Parameter
import org.springframework.data.annotation.CreatedDate
import org.springframework.data.annotation.LastModifiedDate
import org.springframework.data.jpa.domain.support.AuditingEntityListener
import java.io.Serializable
import java.util.*
import javax.persistence.*

@Entity
@DynamicInsert
@DynamicUpdate
@EntityListeners(AuditingEntityListener::class)
@Table(name = "manager_user", schema = "artemis", catalog = "")
data class ManagerUserDO(

        @Id
        @GeneratedValue(generator = "idGenerator")
        @GenericGenerator(name = "idGenerator", strategy = "com.fina.summer.persistent.util.SnowGenerator"
                , parameters = [(Parameter(name = "prefix", value = "USR"))])
        var id: String? = null,

        var loginName: String? = null,

        var password: String? = Md5Util.md5("Zx12345"),

        var loginTime: Date? = null,

        var logoutTime: Date? = null,

        //用户状态,Waiting:创建未认证（比如没有激活，没有输入验证码等等）--等待验证的用户 , Normal:正常状态,Lock：用户被锁定.
        @Enumerated(EnumType.STRING)
        var status: UserStatus? = UserStatus.Normal,

        @Expose(deserialize = false)
        @Column(nullable = false)
        var deleteFlag: Boolean? = false,

        @CreatedDate
        @Expose(deserialize = false)
        var createdTime: Date? = null,

        @LastModifiedDate
        @Expose(deserialize = false)
        var updatedTime: Date? = null,

        @Transient
        var roleDOList: List<ManagerRoleDO>? = null

) : Serializable

enum class UserStatus {
    Waiting,
    Normal,
    Lock
}