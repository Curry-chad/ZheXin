package com.fina.summer.persistent.entity.loan

import com.fina.summer.core.enum.AuditStatus
import org.hibernate.annotations.DynamicInsert
import org.hibernate.annotations.DynamicUpdate
import org.hibernate.annotations.GenericGenerator
import org.hibernate.annotations.Parameter
import org.springframework.data.annotation.CreatedDate
import org.springframework.data.annotation.LastModifiedDate
import org.springframework.data.jpa.domain.support.AuditingEntityListener
import java.sql.Timestamp
import java.util.*
import javax.persistence.*

@Entity
@Table(name = "application_merchant")
@DynamicInsert
@DynamicUpdate
@EntityListeners(AuditingEntityListener::class)
data class ApplicationMertchant(
        @Id
        @GeneratedValue(generator = "idGenerator")
        @GenericGenerator(name = "idGenerator", strategy = "com.fina.summer.persistent.util.SnowGenerator"
                , parameters = [Parameter(name = "prefix", value = "AME")])
        var id: String? = null,

        @Column(name = "mer_id")
        var merId: String? = null,

        @Column(columnDefinition = "varchar(32) comment '商户名称'")
        var merName: String? = null,

        @Column(columnDefinition = "varchar(32) comment '商户类型'")
        var merType: String? = null,

        @Column(name = "cert_no")
        var certNo: String? = null,

        @Column(name = "cert_picture_path")
        var certPicturePath: String? = null,

        @Column(name = "cert_type")
        var certType: String? = null,

        @Column(name = "cert_name")
        var certName: String? = null,

        @Column(name = "mobile")
        var mobile: String? = null,

        @Column(name = "address")
        var address: String? = null,

        @Column(name = "area_code")
        var areaCode: String? = null,

        @Column(name = "legal_person_name")
        var legalPersonName: String? = null,

        @Column(name = "legal_person_cert_no")
        var legalPersonCertNo: String? = null,

        @Column(name = "legal_person_cert_back_picture_path")
        var legalPersonCertBackPicturePath: String? = null,

        @Column(name = "legal_person_cert_front_picture_path")
        var legalPersonCertFrontPicturePath: String? = null,

        @Column(name = "certification_flag")
        var isCertificationFlag: Boolean = false,

        @Column(name = "contact_person_mobile")
        var contactPersonMobile: String? = null,

        @Column(name = "contact_person_name")
        var contactPersonName: String? = null,

        @Column(name = "contact_person_relationship")
        var contactPersonRelationship: String? = null,

        @Column(columnDefinition = "varchar(255) COMMENT '商户合约签名'")
        var signature: String? = null,

        @Column(name = "audit_no",columnDefinition = "varchar(32) comment '审核单号'")
        var auditNo: String? = null,

        @Column(name = "audit_describe",columnDefinition = "varchar(32) comment '审核描述'")
        var auditDescribe: String? = null,

        @Column(name = "audit_person",columnDefinition = "varchar(32) comment '审核人'")
        var auditPerson: String? = null,

        @Column(name = "audit_time",columnDefinition = "varchar(32) comment '审核时间'")
        var auditTime: Date? = null,

        @Enumerated(EnumType.STRING)
        @Column(name = "audit_status",columnDefinition = "varchar(32) comment '审核状态'")
        var auditStatus: AuditStatus? = null,

        @Column(name = "created_time")
        @CreatedDate
        var createdTime: Date? = null,

        @Column(name = "updated_time")
        @LastModifiedDate
        var updatedTime: Date? = null
)
