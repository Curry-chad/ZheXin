package com.fina.summer.persistent.config.db

import com.alibaba.druid.pool.DruidDataSource
import com.fina.summer.persistent.bean.DBConfig
import com.fina.summer.persistent.config.DatasourceConfig
import org.apache.ibatis.session.SqlSessionFactory
import org.mybatis.spring.SqlSessionFactoryBean
import org.mybatis.spring.SqlSessionTemplate
import org.slf4j.LoggerFactory
import org.springframework.beans.factory.annotation.Qualifier
import org.springframework.boot.context.properties.ConfigurationProperties
import org.springframework.context.annotation.Bean
import org.springframework.core.io.support.PathMatchingResourcePatternResolver
import org.springframework.jdbc.datasource.DataSourceTransactionManager
import java.sql.SQLException
import javax.sql.DataSource

/**
 * Created by keets on 2016/12/5.
 */
/*@Configuration
@EnableTransactionManagement(mode = AdviceMode.ASPECTJ)
@MapperScan(basePackages = ["com.fina.summer.persistent.dmphone.mapper"], sqlSessionTemplateRef = "dmphoneSqlSessionTemplate")*/
class DmphoneDatasourceConfig {

    private val logger = LoggerFactory.getLogger(DatasourceConfig::class.java)

    private val mapperPath = "classpath*:mapper/dmphone/*.xml"

    @Bean("dmphoneDBConfig")
    @ConfigurationProperties("spring.dmphone.datasource")
    open fun dmphoneDBConfig(): DBConfig {
        return DBConfig()
    }

    @Bean(name = ["dmphoneDataSource"])
    fun testDataSource(@Qualifier("dmphoneDBConfig") dbConfig: DBConfig): DataSource {
        val datasource = DruidDataSource()

        datasource.url = dbConfig.jdbcUrl
        datasource.username = dbConfig.username
        datasource.password = dbConfig.password
        datasource.driverClassName = dbConfig.driverClassName

        // configuration
        datasource.initialSize = dbConfig.initialSize
        datasource.minIdle = dbConfig.minIdle
        datasource.maxActive = dbConfig.maxActive
        datasource.maxWait = dbConfig.maxWait.toLong()
        datasource.timeBetweenEvictionRunsMillis = dbConfig.timeBetweenEvictionRunsMillis.toLong()
        datasource.minEvictableIdleTimeMillis = dbConfig.minEvictableIdleTimeMillis.toLong()
        datasource.validationQuery = dbConfig.validationQuery
        datasource.isTestWhileIdle = dbConfig.testWhileIdle
        datasource.isTestOnBorrow = dbConfig.testOnBorrow
        datasource.isTestOnReturn = dbConfig.testOnReturn
        datasource.isPoolPreparedStatements = dbConfig.poolPreparedStatements
        datasource.maxPoolPreparedStatementPerConnectionSize = dbConfig.maxPoolPreparedStatementPerConnectionSize
        try {
            datasource.setFilters(dbConfig.filters)
        } catch (e: SQLException) {
            logger.error("druid configuration initialization filter", e)
        }

        datasource.setConnectionProperties(dbConfig.connectionProperties)

        return datasource
    }

    @Bean(name = ["dmphoneSqlSessionFactory"])
    @Throws(Exception::class)
    fun testSqlSessionFactory(@Qualifier("dmphoneDataSource") dataSource: DataSource): SqlSessionFactory? {
        val bean = SqlSessionFactoryBean()
        bean.setDataSource(dataSource)
        bean.setMapperLocations(PathMatchingResourcePatternResolver().getResources(mapperPath))
        bean.getObject()!!.configuration.isMapUnderscoreToCamelCase = true
        return bean.getObject()
    }

    @Bean(name = ["dmphoneTransactiondmphone"])
    fun testTransactiondmphone(@Qualifier("dmphoneDataSource") dataSource: DataSource): DataSourceTransactionManager {
        return DataSourceTransactionManager(dataSource)
    }

    @Bean(name = ["dmphoneSqlSessionTemplate"])
    @Throws(Exception::class)
    fun testSqlSessionTemplate(
            @Qualifier("dmphoneSqlSessionFactory") sqlSessionFactory: SqlSessionFactory): SqlSessionTemplate {
        return SqlSessionTemplate(sqlSessionFactory)
    }

}
