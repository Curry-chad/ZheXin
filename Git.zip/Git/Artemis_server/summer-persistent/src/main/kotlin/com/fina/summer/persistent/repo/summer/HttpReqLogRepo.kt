package com.fina.summer.persistent.repo.summer

import com.fina.summer.persistent.entity.summer.HttpReqLog
import org.springframework.data.jpa.repository.JpaRepository

interface HttpReqLogRepo : JpaRepository<HttpReqLog, String> {
}