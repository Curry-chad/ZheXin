package com.fina.summer.persistent.repo.user

import com.fina.summer.persistent.entity.summer.user.UserInfo
import org.springframework.data.jpa.repository.JpaRepository

interface UserInfoRepo: JpaRepository<UserInfo,Long> {

    fun findByUserId(userId: String): UserInfo?
}