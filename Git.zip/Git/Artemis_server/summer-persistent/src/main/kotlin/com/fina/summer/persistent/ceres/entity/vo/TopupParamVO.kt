package com.fina.summer.persistent.ceres.entity.vo

import io.swagger.annotations.ApiModelProperty
import java.io.Serializable

data class TopupParamVO (

        @ApiModelProperty("充值时间：起始")
        var startTime: String? = null,

        @ApiModelProperty("充值时间：截止")
        var endTime: String? = null,

        @ApiModelProperty("充值状态")
        var status: String? = null,

        @ApiModelProperty("省")
        var province: String? = null,

        @ApiModelProperty("areaCode")
        var areaCode: String? = null,


        @ApiModelProperty("市")
        var city: String? = null,

        @ApiModelProperty("县/区")
        var district: String? = null,

        @ApiModelProperty("门店名称/id")
        var store: String? = null,

        @ApiModelProperty("店员名称/电话")
        var seller: String? = null,

        @ApiModelProperty("还款人姓名/电话/身份证")
        var payer: String? = null,

        @ApiModelProperty("页码")
        var pageNo: Int? = null,

        @ApiModelProperty("每页显示条数")
        var pageSize: Int? = null
) : Serializable