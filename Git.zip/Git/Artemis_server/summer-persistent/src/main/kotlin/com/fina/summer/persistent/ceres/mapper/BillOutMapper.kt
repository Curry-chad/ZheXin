package com.fina.summer.persistent.ceres.mapper

import com.fina.summer.persistent.ceres.entity.domain.BillOutFlowsPO
import com.fina.summer.persistent.ceres.entity.vo.BillOutVO
import org.apache.ibatis.annotations.Mapper
import org.apache.ibatis.annotations.Param
import org.springframework.stereotype.Component

@Mapper
@Component
interface BillOutMapper {



    fun findByTaskIdDesc(@Param("outTaskId")outTaskId: String): BillOutFlowsPO?


}