package com.fina.summer.persistent.ceres.entity.vo

import io.swagger.annotations.ApiModelProperty
import java.io.Serializable

data class    SmsResult (

        @ApiModelProperty("正常扣款结果")
        var result : String?=null,

        @ApiModelProperty("客户手机号")
        val mobile: String? = null,

        @ApiModelProperty("批次号")
        val outMsgId: String? = null

  ): Serializable