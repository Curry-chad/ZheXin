package com.fina.summer.persistent.repo.summer

import com.fina.summer.persistent.entity.summer.LoanOrder
import org.springframework.data.jpa.repository.JpaRepository
import org.springframework.data.jpa.repository.Query

interface LoanOrderRepo : JpaRepository<LoanOrder, String> {

    fun findAllBySellerUserId(id: String): List<LoanOrder>

    @Query("""
        SELECT
            p.`NAME` AS goods_name,
            s.`realname` AS seller_name,
            s.operator_code as seller_operator_code,
            st.store_name AS store_name,
            o.*,
            c.common_rebate,
            c.first_rebate,
            c.fee_per_month,
            c.NAME AS charge_plan_name,
            cg.NAME AS charge_plan_group_name
        FROM
            loan_order AS o
            LEFT JOIN goods AS p ON p.id = o.goods_id
            LEFT JOIN user_info AS s ON s.id = o.seller_id
            LEFT JOIN store AS st ON st.id = o.store_id
            LEFT JOIN charge_plan AS c ON c.id = o.charge_plan_id
            LEFT JOIN charge_plan_group AS cg ON cg.id = c.group_id
        WHERE
            o.id =  ?1
    """, nativeQuery = true)
    fun findDetalById(orderId: String): LoanOrder?
}