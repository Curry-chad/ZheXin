package com.fina.summer.persistent.ceres.entity.domain

import com.fina.summer.persistent.ceres.entity.constant.FundChannel
import com.fina.summer.persistent.ceres.entity.constant.TotalRepayPlanStatus
import org.hibernate.annotations.DynamicInsert
import org.hibernate.annotations.DynamicUpdate
import java.io.Serializable
import java.util.*
import javax.persistence.*

@Entity
@DynamicInsert
@DynamicUpdate
@Table(name = "total_repay_plan", schema = "ceres", catalog = "")
class TotalRepayPlanDO(
        @Id
        @Column(name = "id")
        var id: String? = null,
        @Basic
        @Column(name = "create_by")
        var createBy: String? = null,
        @Basic
        @Column(name = "create_time")
        var createTime: Date? = null,
        @Basic
        @Column(name = "debit_channel")
        var debitChannel: String? = null,
        @Basic
        @Column(name = "fund_channel")
        @Enumerated(EnumType.STRING)
        var fundChannel: FundChannel? = null,
        @Basic
        @Column(name = "left_amount")
        var leftAmount: Int? = null,
        @Basic
        @Column(name = "left_period")
        var leftPeriod: Int? = null,
        @Basic
        @Column(name = "modify_by")
        var modifyBy: String? = null,
        @Basic
        @Column(name = "modify_time")
        var modifyTime: Date? = null,
        @Basic
        @Column(name = "order_id")
        var orderId: String? = null,
        @Basic
        @Column(name = "order_trade_time")
        var orderTradeTime: Date? = null,
        @Basic
        @Column(name = "pay_account")
        var payAccount: String? = null,
        @Basic
        @Column(name = "pay_bank")
        var payBank: String? = null,
        @Basic
        @Column(name = "payer")
        var payer: String? = null,
        @Basic
        @Column(name = "payer_idno")
        var payerIdno: String? = null,
        @Basic
        @Column(name = "period_times")
        var periodTimes: Int? = null,
        @Basic
        @Column(name = "repay_date")
        var repayDate: Date? = null,
        @Basic
        @Column(name = "should_amount")
        var shouldAmount: Int? = null,
        @Basic
        @Column(name = "status")
        @Enumerated(EnumType.STRING)
        var status: TotalRepayPlanStatus? = null,
        @Basic
        @Column(name = "trade_id")
        var tradeId: String? = null
) : Serializable
