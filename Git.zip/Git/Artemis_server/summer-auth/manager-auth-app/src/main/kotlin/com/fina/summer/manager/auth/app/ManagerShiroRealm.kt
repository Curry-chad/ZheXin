package com.fina.summer.manager.auth.app

import com.fina.summer.auth.core.shiro.SessionUtils
import com.fina.summer.core.respone.ResEnum
import com.fina.summer.persistent.artemis.entity.domain.ManagerRoleDO
import com.fina.summer.persistent.artemis.entity.domain.user.ManagerUserDO
import com.fina.summer.persistent.artemis.entity.domain.user.UserStatus
import com.fina.summer.persistent.artemis.mapper.ManagerMenuMapper
import com.fina.summer.persistent.artemis.mapper.ManagerRoleMapper
import com.fina.summer.persistent.artemis.repo.user.ManagerUserRepo
import org.apache.commons.lang.ArrayUtils
import org.apache.shiro.SecurityUtils
import org.apache.shiro.authc.*
import org.apache.shiro.authz.AuthorizationInfo
import org.apache.shiro.authz.SimpleAuthorizationInfo
import org.apache.shiro.crypto.hash.SimpleHash
import org.apache.shiro.realm.AuthorizingRealm
import org.apache.shiro.subject.PrincipalCollection
import org.apache.shiro.subject.SimplePrincipalCollection
import org.apache.shiro.subject.support.DefaultSubjectContext
import org.apache.shiro.web.mgt.DefaultWebSecurityManager
import org.apache.shiro.web.session.mgt.DefaultWebSessionManager
import org.slf4j.LoggerFactory
import org.springframework.stereotype.Component
import java.util.*


@Component
class ManagerShiroRealm(
        private val managerUserRepo: ManagerUserRepo,
        private val managerRoleMapper: ManagerRoleMapper,
        private val managerMenuMapper: ManagerMenuMapper
) : AuthorizingRealm() {

    /**
     * 授权查询回调函数, 进行鉴权但缓存中无用户的授权信息时调用.
     */
    override fun doGetAuthorizationInfo(principals: PrincipalCollection): AuthorizationInfo {
        val suberId = principals.primaryPrincipal as String
        val authorizationInfo = SimpleAuthorizationInfo()
        try {
            val permissions = HashSet<String>()
            val roleDOList: List<ManagerRoleDO> = managerRoleMapper.listByUserId(suberId)
            val menuUrlList: List<String> = managerMenuMapper.getUrlsByUserId(suberId)
            var isSuperAdmin = false
            roleDOList.forEach {
                if (RoleConstant.ROLE_ADMIN == it.name) {
                    permissions.add("*")
                    isSuperAdmin = true
                    return@forEach
                }
            }
            if (!isSuperAdmin) {
                permissions.addAll(menuUrlList)
            }

            authorizationInfo.stringPermissions = permissions
        } catch (e: Exception) {
            e.printStackTrace()
        }

        return authorizationInfo
    }


    /**
     * 认证回调函数,登录时调用
     */
    @Throws(AuthenticationException::class)
    override fun doGetAuthenticationInfo(authcToken: AuthenticationToken): AuthenticationInfo {
        val token = authcToken as UsernamePasswordToken
        val userId = token.username
        val password = authcToken.password

        val optional = managerUserRepo.findById(userId)
        val userDO: ManagerUserDO = if (optional.isPresent) optional.get() else throw UnknownAccountException(ResEnum.UserNotExist.getMsg())

        if (userDO.status == UserStatus.Lock) {
            throw LockedAccountException(ResEnum.UserLock.getMsg())
        }
        if (ArrayUtils.isEmpty(password)) {
            kickOutUserOnCurrent(userDO.id!!)
            return SimpleAuthenticationInfo(userDO.id, "", name)
        }
        val passwordOrigin = String(password)
        val passwordMd5 = SimpleHash("MD5", passwordOrigin, userDO.id, 1).toString()
        if (passwordMd5 != userDO.password) {
            throw IncorrectCredentialsException(ResEnum.IncorrectCredentials.getMsg())
        }
        kickOutUserOnCurrent(userDO.id!!)
        return SimpleAuthenticationInfo(userDO.id, passwordOrigin, name)
    }

    /**
     * 更新用户授权信息缓存
     *
     * @param principal
     */
    fun clearCachedAuthorizationInfo(principal: String) {
        val principals = SimplePrincipalCollection(principal, name)
        clearCachedAuthorizationInfo(principals)
    }

    /**
     * 更新当前用户授权信息缓存
     */
    fun clearCachedAuthorizationInfo() {
        if (SecurityUtils.getSubject().isAuthenticated) {
            clearCachedAuthorizationInfo(SessionUtils.currentUserId().toString())
        }
    }

    /**
     * 清除所有用户授权信息缓存.
     */
    fun clearAllCachedAuthorizationInfo() {
        val cache = authorizationCache
        if (cache != null) {
            for (key in cache.keys()) {
                cache.remove(key)
            }
        }
    }

    /**
     * 判断当前登录用户是否为上次登录用户
     */
    private fun kickOutUserOnCurrent(userId: String) {
        // 判断本次登录用户是否为上次登录用户，是：绕过shiro挤退操作；否：进入shiro挤退操作
        val sUserId = SessionUtils.session.getAttribute(DefaultSubjectContext.PRINCIPALS_SESSION_KEY)
        if (sUserId == null || userId != sUserId.toString()) { // true: 不是上次登录用户
            kickOutUser(userId)
        }
    }

    /**
     * 挤掉当前用户其他登录session，保证当前登录操作产生的session唯一
     */
    private fun kickOutUser(userId: String) {
        //处理session
        val securityManager = SecurityUtils.getSecurityManager() as DefaultWebSecurityManager
        val sessionManager = securityManager.sessionManager as DefaultWebSessionManager
        val sessions = sessionManager.sessionDAO.activeSessions//获取当前已登录的用户session列表
        for (session in sessions) {
            //清除该用户以前登录时保存的session
            val sUserId = session.getAttribute(DefaultSubjectContext.PRINCIPALS_SESSION_KEY)
            if (sUserId != null && userId == sUserId.toString()) {
                sessionManager.sessionDAO.delete(session)
            }
        }
    }

    companion object {

        private val logger = LoggerFactory.getLogger(ManagerShiroRealm::class.java)
    }

}
