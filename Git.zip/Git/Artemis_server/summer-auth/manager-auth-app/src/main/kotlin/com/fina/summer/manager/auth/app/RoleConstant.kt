package com.fina.summer.manager.auth.app

class RoleConstant {
    companion object {
        const val ROLE_ADMIN = "超级管理员"
    }
}