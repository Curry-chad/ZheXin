package com.fina.summer.manager.auth.app

import com.fina.summer.auth.core.shiro.RedisSessionDAO
import org.apache.shiro.cache.CacheManager
import org.apache.shiro.realm.Realm
import org.apache.shiro.session.mgt.SessionManager
import org.apache.shiro.spring.web.ShiroFilterFactoryBean
import org.apache.shiro.web.mgt.DefaultWebSecurityManager
import org.apache.shiro.web.servlet.SimpleCookie
import org.apache.shiro.web.session.mgt.DefaultWebSessionManager
import org.springframework.beans.factory.annotation.Qualifier
import org.springframework.context.annotation.Bean
import org.springframework.context.annotation.Configuration


@Configuration
open class ManagerAuthConfig {

    @Bean("shiroFilter")
    open fun shiroFilterFactoryBean(securityManager: DefaultWebSecurityManager): ShiroFilterFactoryBean {
        val factoryBean = ShiroFilterFactoryBean()
        factoryBean.setFilterChainDefinitions("")
        factoryBean.securityManager = securityManager
        return factoryBean
    }

    @Bean
    open fun securityManager(managerShiroRealm: Realm,
                             @Qualifier("sessionManager")
                             sessionManager: SessionManager,
                             cacheManager: CacheManager): DefaultWebSecurityManager {

        val securityManager = DefaultWebSecurityManager()
        securityManager.sessionManager = sessionManager
        securityManager.cacheManager = cacheManager
        securityManager.setRealm(managerShiroRealm)
        return securityManager
    }

    @Bean("sessionManager")
    open fun getSessionManager(redisSessionDao: RedisSessionDAO): DefaultWebSessionManager {

        val sessionManager = DefaultWebSessionManager()
        sessionManager.sessionDAO = redisSessionDao
        sessionManager.globalSessionTimeout = 30 * 24 * 3600 * 1000L//ms
        sessionManager.isDeleteInvalidSessions = true
        sessionManager.isSessionValidationSchedulerEnabled = true

        val cookie = SimpleCookie("MANAGER_SESSION_ID")
        cookie.path = "/"
        cookie.maxAge = 30 * 24 * 3600//s

        sessionManager.sessionIdCookie = cookie
        sessionManager.isSessionIdCookieEnabled = true

        return sessionManager

    }

}