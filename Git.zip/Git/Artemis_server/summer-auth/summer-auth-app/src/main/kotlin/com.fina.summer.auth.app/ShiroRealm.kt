package com.fina.summer.auth.app

import com.fina.summer.auth.core.shiro.SessionUtils
import org.apache.shiro.SecurityUtils
import org.apache.shiro.authc.*
import org.apache.shiro.authz.AuthorizationInfo
import org.apache.shiro.authz.SimpleAuthorizationInfo
import org.apache.shiro.realm.AuthorizingRealm
import org.apache.shiro.subject.PrincipalCollection
import org.apache.shiro.subject.SimplePrincipalCollection
import org.slf4j.LoggerFactory
import org.springframework.stereotype.Component
import java.util.*

@Component("AppShiroRealm")
class ShiroRealm : AuthorizingRealm() {

    /**
     * 授权查询回调函数, 进行鉴权但缓存中无用户的授权信息时调用.
     */
    override fun doGetAuthorizationInfo(principals: PrincipalCollection): AuthorizationInfo {
        val suberId = principals.primaryPrincipal as String
        val authorizationInfo = SimpleAuthorizationInfo()
        try {
            val permissions = HashSet<String>()
            //            if ("off".equals(UserConfig.getPermissionSwitch())) {
            permissions.add("*")
            //            } else {
            //                permissions = permissionMapper.selectSmcPermissions(suberId);
            //            }
            authorizationInfo.stringPermissions = permissions
        } catch (e: Exception) {
            e.printStackTrace()
        }

        return authorizationInfo
    }


    /**
     * 认证回调函数,登录时调用
     */
    @Throws(AuthenticationException::class)
    override fun doGetAuthenticationInfo(authcToken: AuthenticationToken): AuthenticationInfo {
        val token = authcToken as UsernamePasswordToken
        //        ZSuberVip currentUser = new ZSuberVip();
        //        try {
        //            currentUser = suberService.getAuthSuber(token.getUsername());
        //        } catch (Exception e) {
        //            logger.error(e.getMessage(), e);
        //            throw new AuthenticationException();
        //        }
        val password = authcToken.password

        return SimpleAuthenticationInfo(token.username, password, name)
    }

    /**
     * 更新用户授权信息缓存
     *
     * @param principal
     */
    fun clearCachedAuthorizationInfo(principal: String) {
        val principals = SimplePrincipalCollection(principal, name)
        clearCachedAuthorizationInfo(principals)
    }

    /**
     * 更新当前用户授权信息缓存
     */
    fun clearCachedAuthorizationInfo() {
        if (SecurityUtils.getSubject().isAuthenticated) {
            clearCachedAuthorizationInfo(SessionUtils.currentUserId().toString())
        }
    }

    /**
     * 清除所有用户授权信息缓存.
     */
    fun clearAllCachedAuthorizationInfo() {
        val cache = authorizationCache
        if (cache != null) {
            for (key in cache.keys()) {
                cache.remove(key)
            }
        }
    }

    companion object {

        private val logger = LoggerFactory.getLogger(ShiroRealm::class.java)
    }

}
