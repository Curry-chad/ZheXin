package com.fina.summer.auth.app

import com.fina.summer.auth.core.shiro.RedisSessionDAO
import org.apache.shiro.cache.CacheManager
import org.apache.shiro.realm.Realm
import org.apache.shiro.session.mgt.SessionManager
import org.apache.shiro.spring.web.ShiroFilterFactoryBean
import org.apache.shiro.web.mgt.DefaultWebSecurityManager
import org.apache.shiro.web.servlet.SimpleCookie
import org.apache.shiro.web.session.mgt.DefaultWebSessionManager
import org.springframework.beans.factory.annotation.Qualifier
import org.springframework.context.annotation.Bean
import org.springframework.context.annotation.Configuration


@Configuration
open class AppAuthConfig {

    @Bean("shiroFilter")
    open fun shiroFilterFactoryBean(securityManager: DefaultWebSecurityManager): ShiroFilterFactoryBean {
        val factoryBean = ShiroFilterFactoryBean()
        factoryBean.setFilterChainDefinitions("")
        factoryBean.securityManager = securityManager
        return factoryBean
    }

    @Bean
    open fun securityManager(shiroRealm: Realm,
                             @Qualifier("sessionManager")
                             sessionManager: SessionManager,
                             cacheManager: CacheManager): DefaultWebSecurityManager {

        val securityManager = DefaultWebSecurityManager()
        securityManager.setRealm(shiroRealm)
        securityManager.sessionManager = sessionManager
        securityManager.cacheManager = cacheManager
        return securityManager
    }

    @Bean("sessionManager")
    open fun getSessionManager(redisSessionDao: RedisSessionDAO): DefaultWebSessionManager {

        val sessionManager = DefaultWebSessionManager()
        sessionManager.sessionDAO = redisSessionDao
        sessionManager.globalSessionTimeout = 24 * 3600 * 1000
        sessionManager.isDeleteInvalidSessions = false
        sessionManager.isSessionValidationSchedulerEnabled = false

        val cookie = SimpleCookie("RYSESSIONID")
        cookie.path = "/"
        cookie.maxAge = 86400000

        sessionManager.sessionIdCookie = cookie

        return sessionManager

    }

}