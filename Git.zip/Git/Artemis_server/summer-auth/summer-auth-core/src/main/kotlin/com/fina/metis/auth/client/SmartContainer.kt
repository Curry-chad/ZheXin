package com.fina.metis.auth.client

import com.caucho.hessian.client.HessianProxyFactory
import com.smart.sso.rpc.AuthenticationRpcService
import org.slf4j.LoggerFactory
import org.springframework.scheduling.annotation.EnableAsync
import org.springframework.util.AntPathMatcher
import org.springframework.util.StringUtils

import javax.servlet.*
import javax.servlet.http.HttpServletRequest
import javax.servlet.http.HttpServletResponse
import java.io.IOException
import java.net.MalformedURLException

/**
 * Smart容器中心
 *
 * @author Joe
 */
class SmartContainer : ParamFilter(), Filter {

    // 是否服务端，默认为false
    private var isServer = false

    private var filters: Array<ClientFilter>? = null

    private val pathMatcher = AntPathMatcher()

    @Throws(ServletException::class)
    override fun init(filterConfig: FilterConfig) {

        if (isServer) {
            ssoServerUrl = filterConfig.servletContext.contextPath
        } else if (StringUtils.isEmpty(ssoServerUrl)) {
            throw IllegalArgumentException("ssoServerUrl不能为空")
        }

        if (authenticationRpcService == null) {
            try {
                authenticationRpcService = HessianProxyFactory()
                        .create(AuthenticationRpcService::class.java, "$ssoServerUrl/rpc/authenticationRpcService") as AuthenticationRpcService
            } catch (e: MalformedURLException) {
                IllegalArgumentException("authenticationRpcService初始化失败")
            }

        }

        if (filters == null || filters!!.isEmpty()) {
            throw IllegalArgumentException("filters不能为空")
        }
        for (filter in filters!!) {
            filter.ssoServerUrl = ssoServerUrl!!
            filter.authenticationRpcService = authenticationRpcService

            filter.init(filterConfig)
        }
    }
    private val logger = LoggerFactory.getLogger(SsoFilter::class.java)

    @Throws(IOException::class, ServletException::class)
    override fun doFilter(request: ServletRequest, response: ServletResponse, chain: FilterChain) {

        val httpRequest = request as HttpServletRequest
        val httpResponse = response as HttpServletResponse
        val url = httpRequest.requestURI
        logger.info("request url = $url");
        if (url.contains("swagger") || url.contains("/finance/v2/api-docs")) {
            chain.doFilter(request, response)
            return
        }
        if (url.contains("/finance/finance/testnotify")) {
            chain.doFilter(request, response)
            return
        }
        if (url.contains("/finance/operate/sendSms")) {  //=====
            chain.doFilter(request, response)
            return
        }
        if (url.contains("/finance/operate/receivable")) {
            chain.doFilter(request, response)
            return
        }
        if (url.contains("/finance/operate/topup")) {
            chain.doFilter(request, response)
            return
        }
        if (url.contains("/finance/operate/deduct")) {
            chain.doFilter(request, response)
            return
        }

        //测试批量任务
        if (url.contains("/finance/finance/batch")) {
            chain.doFilter(request, response)
            return
        }
        //退款接口
        if (url.contains("/finance/operate/refund/notPower")) {
            chain.doFilter(request, response)
            return
        }
        //内部接口调用
        if (url.contains("/finance/inside")) {
            chain.doFilter(request, response)
            return
        }
        //内部接口调用
        if (url.contains("/finance/operate/notify/getBillTaskInfo")) {
            chain.doFilter(request, response)
            return
        }
        //扣款回调接口
        if (url.contains("/finance/operate/deduct/deductCallBack")) {
            chain.doFilter(request, response)
            return
        }
        //业务报表查询接口
        if (url.contains("/finance/data/business/statistics/list")) {
            chain.doFilter(request, response)
            return
        }
        //短信接口
        if (url.contains("/finance/sms")) {
            chain.doFilter(request, response)
            return
        }
        for (filter in filters!!) {
            if (matchPath(filter.pattern, httpRequest.servletPath) && !filter.isAccessAllowed(httpRequest, httpResponse)) {
                return
            }
        }
        chain.doFilter(request, response)
    }

    private fun matchPath(pattern: String?, path: String): Boolean {
        return StringUtils.isEmpty(pattern) || pathMatcher.match(pattern!!, path)
    }

    fun setIsServer(isServer: Boolean) {
        this.isServer = isServer
    }

    override fun destroy() {
        if (filters == null || filters!!.size == 0)
            return
        for (filter in filters!!) {
            filter.destroy()
        }
    }

    fun setFilters(filters: Array<ClientFilter>) {
        this.filters = filters
    }
}