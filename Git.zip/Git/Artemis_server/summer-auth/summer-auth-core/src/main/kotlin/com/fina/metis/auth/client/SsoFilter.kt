package com.fina.metis.auth.client


import org.slf4j.LoggerFactory
import javax.servlet.http.HttpServletRequest
import javax.servlet.http.HttpServletResponse
import java.io.IOException
import java.net.URLEncoder

/**
 * 单点登录及Token验证Filter
 *
 * @author Joe
 */
open class SsoFilter : ClientFilter() {

    private val logger = LoggerFactory.getLogger(SsoFilter::class.java)

    @Throws(IOException::class)
    override fun isAccessAllowed(request: HttpServletRequest, response: HttpServletResponse): Boolean {
        var token = getLocalToken(request)
        if (token != null) {
            val result = authenticationRpcService!!.validate(token)
            if (!result) {
                redirectLogin(request, response)
                return false
            }
            return true
        }else{
            token =  request.getHeader("token")
        }
        if (token == null) {
            logger.info("token is null  redirectLogin" )
            redirectLogin(request, response)
            return false
        }

        val loginResult = invokeAuthInfoInSession(request, token)
        // 再跳转一次当前URL，以便去掉URL中token参数
        if (loginResult) {
            return true
//                    response.sendRedirect(getRemoveTokenBackUrl(request))
        } else {
            redirectLogin(request, response)
        }
        return false


    }

    /**
     * 获取Session中token
     *
     * @param request
     * @return
     */
    private fun getLocalToken(request: HttpServletRequest): String? {
        val sessionUser = SessionUtils.getSessionUser(request)
        return sessionUser?.token
    }

    /**
     * 存储sessionUser
     *
     * @param request
     * @return
     * @throws IOException
     */
    @Throws(IOException::class)
    private fun invokeAuthInfoInSession(request: HttpServletRequest, token: String): Boolean {
        val rpcUser = authenticationRpcService!!.findAuthInfo(token)
        if (rpcUser != null) {
            SessionUtils.setSessionUser(request, SessionUser(token, rpcUser.account!!))
        }
        return rpcUser != null
    }

    /**
     * 跳转登录
     *
     * @param request
     * @param response
     * @throws IOException
     */
    @Throws(IOException::class)
    private fun redirectLogin(request: HttpServletRequest, response: HttpServletResponse) {
//        if (isAjaxRequest(request)) {
//            responseJson(response, SsoResultCode.SSO_TOKEN_ERROR, "未登录或已超时")
//        } else {
        SessionUtils.invalidate(request)
        var backurl=request.getHeader("referer")
        val ssoLoginUrl = StringBuilder().append(ssoServerUrl)
                .append("/login?backUrl=").append(URLEncoder.encode(backurl, "utf-8")).toString()

        logger.info("backurl is [$backurl]")
        response.sendRedirect(ssoLoginUrl)
//        }
    }

    /**
     * 去除返回地址中的token参数
     * @param request
     * @return
     */
//    private fun getRemoveTokenBackUrl(request: HttpServletRequest): String {
//        return getBackUrl(request)
//    }

    /**
     * 返回地址
     * @param request
     * @return
     */
//    open fun getBackUrl(request: HttpServletRequest): String {
//
//        return StringBuilder().append(ssO_BACK_URL).toString()
//    }

    companion object {

        // sso授权回调参数token名称
        val SSO_TOKEN_NAME = "__vt_param__"
    }

}