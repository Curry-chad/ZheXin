package com.fina.summer.auth.core.handler

import com.fina.summer.core.handler.SimpleException
import com.fina.summer.core.respone.ResEnum
import com.fina.summer.core.respone.WebResult
import com.fina.summer.core.utils.Id
import com.fina.summer.core.utils.IdGenerator
import org.apache.shiro.authc.IncorrectCredentialsException
import org.apache.shiro.authc.UnknownAccountException
import org.apache.shiro.authz.UnauthenticatedException
import org.apache.shiro.authz.UnauthorizedException
import org.slf4j.LoggerFactory
import org.springframework.http.HttpStatus
import org.springframework.validation.BindException
import org.springframework.web.bind.annotation.ControllerAdvice
import org.springframework.web.bind.annotation.ExceptionHandler
import org.springframework.web.bind.annotation.ResponseBody
import org.springframework.web.bind.annotation.ResponseStatus
import org.springframework.web.method.annotation.MethodArgumentTypeMismatchException
import java.lang.reflect.UndeclaredThrowableException
import javax.servlet.http.HttpServletRequest
import javax.servlet.http.HttpServletResponse

@ControllerAdvice
class AuthExceptionHandler {

    private val logger = LoggerFactory.getLogger(AuthExceptionHandler::class.java)


    @ExceptionHandler(UnauthorizedException::class)
    @ResponseStatus(HttpStatus.UNAUTHORIZED)
    @ResponseBody
    @Throws(Exception::class)
    fun handleUnauthorizedError(req: HttpServletRequest, rsp: HttpServletResponse, e: UnauthorizedException): WebResult<Void> {
        return ResEnum.Unauthorized.parse()
    }

    @ExceptionHandler(UnauthenticatedException::class)
    @ResponseStatus(HttpStatus.FORBIDDEN)
    @ResponseBody
    fun handleUnauthenticatedError(req: HttpServletRequest, rsp: HttpServletResponse, e: UnauthenticatedException): WebResult<Void> {
        return ResEnum.FORBIDDEN.parse()
    }


    @ExceptionHandler(MethodArgumentTypeMismatchException::class)
    @ResponseStatus(HttpStatus.FORBIDDEN)
    @ResponseBody
    fun handleMethodArgumentTypeMismatchException(e: UnauthenticatedException): WebResult<Void> {
        return ResEnum.ParamErr.parse()
    }

    //普通业务的异常会被这个方法捕获
    @ExceptionHandler(SimpleException::class)
    @ResponseStatus(HttpStatus.OK)
    @ResponseBody
    fun handleSimpleError(req: HttpServletRequest, rsp: HttpServletResponse, e: SimpleException): WebResult<Void> {
        logger.warn("请求出现异常！---${e.getCode()}, ${e.getMsg()}" )
        if (e.getCode() != "0") {
            return ResEnum.fail(e.getCode()!!, e.getMsg()!!)
        } else {
            return ResEnum.fail(e.message!!)
        }
    }

    @ExceptionHandler(UnknownAccountException::class)
    @ResponseStatus(HttpStatus.OK)
    @ResponseBody
    fun handleUnknownAccountError(req: HttpServletRequest, rsp: HttpServletResponse, e: UnknownAccountException): WebResult<Void> {
        return ResEnum.fail(ResEnum.UserNotExist)
    }

    @ExceptionHandler(IncorrectCredentialsException::class)
    @ResponseStatus(HttpStatus.OK)
    @ResponseBody
    fun handleIncorrectCredentialsError(req: HttpServletRequest, rsp: HttpServletResponse, e: IncorrectCredentialsException): WebResult<Void> {
        return ResEnum.fail(ResEnum.IncorrectCredentials)
    }

    @ExceptionHandler(UndeclaredThrowableException::class)
    @ResponseStatus(HttpStatus.OK)
    @ResponseBody
    fun handlerUndeclared(req: HttpServletRequest, rsp: HttpServletResponse, e: UndeclaredThrowableException): WebResult<Void> {
        if (e.cause is SimpleException) {
            val ee = e.cause as SimpleException
            logger.warn("系统异常", e.cause!!.cause)
            if (ee.getCode() != "0") {
                return ResEnum.fail(ee.getCode()!!, ee.getMsg()!!)
            } else {
                return ResEnum.fail(ee.getMsg()!!)
            }
        } else {
            val errNo = IdGenerator.nextId(Id.Error)
            logger.error("系统错误[{}]:", errNo, e)
            return ResEnum.fail("系统错误[$errNo]")
        }

    }

    //500的异常会被这个方法捕获
    @ExceptionHandler(Throwable::class)
    @ResponseStatus(HttpStatus.INTERNAL_SERVER_ERROR)
    @ResponseBody
    fun handleError(req: HttpServletRequest, rsp: HttpServletResponse, e: Exception): WebResult<Void> {
        val errNo = IdGenerator.nextId(Id.Error)
        logger.error("系统错误[{}]:", errNo, e)
        return ResEnum.fail("系统错误[$errNo]")
    }


    @ExceptionHandler(BindException::class)
    @ResponseStatus(HttpStatus.OK)
    @ResponseBody
    fun handleValidError(req: HttpServletRequest, rsp: HttpServletResponse, e: BindException): WebResult<Void> {
        var message = ""
        e.bindingResult.allErrors.forEach { message += it.defaultMessage + ";" }
        logger.warn("参数校验不通过！url:{},详情：{}", req.requestURL, message)
        return ResEnum.ParamErr.parseMsg(message)
    }
}