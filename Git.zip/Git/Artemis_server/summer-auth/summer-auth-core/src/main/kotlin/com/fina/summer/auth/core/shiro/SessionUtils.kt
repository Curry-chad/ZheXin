/**
 * 文件名:SessionUtils.java
 * 包名:com.dj.framework.shrio
 * 项目名:crbt
 * 文件说明:
 * 作者:lee
 * 创建时间:2016年6月1日 下午2:22:05
 */
package com.fina.summer.auth.core.shiro

import org.apache.shiro.SecurityUtils
import org.apache.shiro.session.Session


/**
 *
 * 类名:com.dj.framework.shrio.SessionUtils <pre>
 * 描述:
 * 基本思路:
 * 特别说明:
 * 编写者:李晓亮
 * 创建时间:2016年6月1日 下午2:22:05
 * 修改说明: 类的修改说明
</pre> *
 */
object SessionUtils {

    private val IS_NEW_USER = "IS_NEW_USER"


    /**
     * 获取当前用户session <br></br><pre>
     * 编写者：李晓亮
     * 创建时间：2016年6月1日 下午2:28:27 </pre>
     * @return
     */
    val session: Session
        get() = SecurityUtils.getSubject().session

    /**
     * 获取当前用户sessionId <br></br><pre>
     * 编写者：李晓亮
     * 创建时间：2016年6月1日 下午2:28:27 </pre>
     * @return
     */
    val sessionId: String
        get() = session.id.toString()

    /**
     * 获取当前用户session <br></br><pre>
     * 编写者：李晓亮
     * 创建时间：2016年6月1日 下午2:28:27 </pre>
     * @return
     */
    fun currentUserId(): String? {
        val currentUser = SecurityUtils.getSubject()
        return if (currentUser != null) {
            (currentUser.principal as String?)
        } else null
    }

    val isNewUser: Boolean?
        get() = getValue(IS_NEW_USER) as Boolean

    /**
     * 获取session值 <br></br><pre>
     * 编写者：李晓亮
     * 创建时间：2016年6月1日 下午2:28:01 </pre>
     * @param key
     * @return
     */
    fun getValue(key: Any): Any? {
        val session = session
        return session.getAttribute(key)
    }


    /**
     * 获取session值 <br></br><pre>
     * 编写者：李晓亮
     * 创建时间：2016年6月1日 下午2:28:01 </pre>
     * @param key
     * @return
     */
    fun setValue(key: Any, value: Any?) {
        val session = session
        session.setAttribute(key, value)
    }

    fun isNewUser(isNew: Boolean?) {
        setValue(IS_NEW_USER, isNew)
    }
}
