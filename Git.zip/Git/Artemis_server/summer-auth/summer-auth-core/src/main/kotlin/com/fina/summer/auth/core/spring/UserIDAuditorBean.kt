package com.fina.summer.auth.core.spring

import com.fina.summer.auth.core.shiro.SessionUtils
import org.springframework.context.annotation.Configuration
import org.springframework.data.domain.AuditorAware
import java.util.*

@Configuration
open class UserIDAuditorBean : AuditorAware<String> {
    override fun getCurrentAuditor(): Optional<String> {
        return try {
            Optional.ofNullable(SessionUtils.currentUserId().toString())
        } catch (e: Exception) {
//            e.printStackTrace()
            Optional.ofNullable(null)
        }
    }
}
