package com.fina.metis.auth.client

import com.smart.sso.rpc.RpcPermission
import org.springframework.util.StringUtils

import javax.servlet.FilterConfig
import javax.servlet.ServletException
import javax.servlet.http.HttpServletRequest
import javax.servlet.http.HttpServletResponse
import java.io.IOException
import java.util.ArrayList
import java.util.HashSet
import java.util.concurrent.CopyOnWriteArraySet

/**
 * 权限控制Filter
 *
 * @author Joe
 */
class PermissionFilter : ClientFilter() {

    // 当前应用关联权限系统的应用编码
    private var ssoAppCode: String? = null

    @Throws(ServletException::class)
    override fun init(filterConfig: FilterConfig) {
        if (StringUtils.isEmpty(ssoAppCode)) {
            throw IllegalArgumentException("ssoAppCode不能为空")
        }
        System.out.print("ssoAppCode is "+ssoAppCode)
        ApplicationPermission.initApplicationPermissions(authenticationRpcService!!, ssoAppCode!!)
    }

    @Throws(IOException::class)
    override fun isAccessAllowed(request: HttpServletRequest, response: HttpServletResponse): Boolean {
        val path = request.servletPath
        if (isPermitted(request, path))
            return true
        else if (!ApplicationPermission.getApplicationPermissionSet()!!.contains(path))
            return true
        else {
            responseJson(response, SsoResultCode.SSO_PERMISSION_ERROR, "没有访问权限")
            return false
        }
    }

    private fun isPermitted(request: HttpServletRequest, path: String): Boolean {
        val permissionSet = getLocalPermissionSet(request)
        return permissionSet!!.contains(path)
    }

    private fun getLocalPermissionSet(request: HttpServletRequest): Set<String>? {
        var sessionPermission: SessionPermission? = SessionUtils.getSessionPermission(request)
        val token = SessionUtils.getSessionUser(request)!!.token
        if (sessionPermission == null || !sessionPermissionCache.contains(token)) {
            sessionPermission = invokePermissionInSession(request, token)
        }
        return sessionPermission.permissionSet
    }

    /**
     * 保存权限信息
     *
     * @param token
     * @return
     */
    fun invokePermissionInSession(request: HttpServletRequest, token: String?): SessionPermission {
        val dbList = authenticationRpcService!!.findPermissionList(token!!, ssoAppCode!!)

        val menuList = ArrayList<RpcPermission>()
        val operateSet = HashSet<String>()
        for (menu in dbList) {
            if (menu.getIsMenu()!!) {
                menuList.add(menu)
            }
            if (menu.url != null) {
                operateSet.add(menu.url!!)
            }
        }

        val sessionPermission = SessionPermission()
        // 设置登录用户菜单列表
        sessionPermission.menuList = menuList

        // 保存登录用户没有权限的URL，方便前端去隐藏相应操作按钮
        val noPermissionSet = HashSet(ApplicationPermission.getApplicationPermissionSet()!!)
        noPermissionSet.removeAll(operateSet)

        sessionPermission.noPermissions = StringUtils.arrayToDelimitedString(noPermissionSet.toTypedArray(), ",")

        // 保存登录用户权限列表
        sessionPermission.permissionSet = operateSet
        SessionUtils.setSessionPermission(request, sessionPermission)

        // 添加权限监控集合，当前session已更新最新权限
        sessionPermissionCache.add(token)
        return sessionPermission
    }

    fun setSsoAppCode(ssoAppCode: String) {
        this.ssoAppCode = ssoAppCode
    }

    companion object {

        // 存储已获取最新权限的token集合，当权限发生变动时清空
        private val sessionPermissionCache = CopyOnWriteArraySet<String>()

        fun invalidateSessionPermissions() {
            sessionPermissionCache.clear()
        }
    }
}