package com.fina.metis.auth.entity

import com.smart.sso.rpc.RpcPermission
import java.io.Serializable

/**
 * @ClassName Session
 * @Description TODO
 * @Author lyx
 * @Date 2019/2/2016:33
 * @Version 1.0
 */
class Session : Serializable {
    // 用户菜单
    private var menuList: List<RpcPermission>? = null
    // 用户权限
    var permissionSet: Set<String>? = null

    // 登录名
    var account: String? = null

    fun getMenuList(menuList: Any): List<RpcPermission>? {
        return this.menuList
    }

    fun setMenuList(menuList: List<RpcPermission>) {
        this.menuList = menuList
    }

    companion object {
        private const val serialVersionUID = 1L
    }
}
