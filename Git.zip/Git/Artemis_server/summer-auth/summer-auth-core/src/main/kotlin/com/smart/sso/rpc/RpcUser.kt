package com.smart.sso.rpc

import java.io.Serializable

/**
 * RPC回传用户对象
 *
 * @author Joe
 */
class RpcUser(// 登录名
        var account: String?) : Serializable {
    companion object {

        private const val serialVersionUID = 4507869346123296527L
    }
}