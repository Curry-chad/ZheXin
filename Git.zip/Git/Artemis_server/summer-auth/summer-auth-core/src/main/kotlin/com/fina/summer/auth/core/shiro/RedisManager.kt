package com.fina.summer.auth.core.shiro

import org.slf4j.LoggerFactory
import org.springframework.boot.context.properties.ConfigurationProperties
import org.springframework.stereotype.Component
import redis.clients.jedis.JedisPool
import redis.clients.jedis.JedisPoolConfig
import javax.annotation.PostConstruct

@Component
@ConfigurationProperties("spring.redis")
class RedisManager {
    var host = "127.0.0.1"
    var port = 6379
    // 0 - never expire
    var expire = 0
    //timeout for jedis try to connect to redis server, not expire time! In milliseconds
    var timeout = 0
    var password: String? = ""

    private var jedisPool: JedisPool? = null

    /**
     * 初始化方法
     */
    @PostConstruct
    fun init() {
        println("===================哈哈哈哈哈哈哈哈===================")
        println(host)
        println(password)
        if (jedisPool == null) {
            jedisPool = if (password != null && "" != password) {
                JedisPool(JedisPoolConfig(), host, port, timeout, password)
            } else if (timeout != 0) {
                JedisPool(JedisPoolConfig(), host, port, timeout)
            } else {
                JedisPool(JedisPoolConfig(), host, port)
            }

        }
    }

    /**
     * get value from redis
     *
     * @param key
     * @return
     */
    operator fun get(key: ByteArray): ByteArray? {
        var value: ByteArray? = null
        val jedis = jedisPool!!.resource
        jedis.use { j ->
            value = j.get(key)
        }
        return value
    }

    /**
     * 描述: 获取String value <br></br><pre>
     * @author：[李晓亮](mailto:lixiaoliang@zhexinit.com)
     * 创建时间：2017/4/26 15:54 </pre>
     *
     * @return
     * @params
     */
    operator fun get(key: String): String? {
        var value: String? = null
        val jedis = jedisPool!!.resource
        jedis.use { j ->
            value = j.get(key)
        }
        return value
    }


    /**
     * set
     *
     * @param key
     * @param value
     * @return
     */
    operator fun set(key: ByteArray, value: ByteArray): ByteArray {
        val jedis = jedisPool!!.resource
        jedis.use { j ->
            j.set(key, value)
            if (this.expire != 0) {
                j.expire(key, this.expire)
            }
        }
        return value
    }


    fun exist(key: ByteArray): Boolean? {
        val jedis = jedisPool!!.resource
        jedis.use { j ->
            return j.exists(key)
        }
    }


    /**
     * set
     *
     * @param key
     * @param value
     * @param expire
     * @return
     */
    operator fun set(key: ByteArray, value: ByteArray, expire: Int): ByteArray {
        val jedis = jedisPool!!.resource
        jedis.use { j ->
            j.set(key, value)
            if (expire != 0) {
                j.expire(key, expire)
            }
        }
        return value
    }

    operator fun set(key: String, value: String , expire: Int): String{
        val jedis = jedisPool!!.resource
        jedis.use {
            jedis.set(key, value)
            if (expire != 0) {
                jedis.expire(key, expire)
            }
        }
        return value
    }

    /**
     * del
     *
     * @param key
     */
    fun del(key: ByteArray): Long? {
        val jedis = jedisPool!!.resource
        jedis.use { j ->
            return j.del(key)
        }
    }

    /**
     * flush
     */
    fun flushDB() {
        val jedis = jedisPool!!.resource
        jedis.use { j ->
            j.flushDB()
        }
    }

    /**
     * size
     */
    fun dbSize(): Long? {
        var dbSize: Long? = 0L
        val jedis = jedisPool!!.resource
        jedis.use { j ->
            dbSize = j.dbSize()
        }
        return dbSize
    }

    /**
     * keys
     *
     * @param pattern
     * @return
     */
    fun keys(pattern: String): Set<ByteArray>? {
        var keys: Set<ByteArray>? = null
        val jedis = jedisPool!!.resource
        jedis.use { j ->
            keys = j.keys(pattern.toByteArray())
        }
        return keys
    }

    fun expireByPattern(pattern: String, expire: Int) {
        var keys: Set<ByteArray>? = null
        val jedis = jedisPool!!.resource
        jedis.use { j ->
            keys = j.keys(pattern.toByteArray())
            keys?.forEach { key -> j.expire(key, expire) }
        }
    }

    companion object {
        private val LOGGER = LoggerFactory.getLogger(RedisManager::class.java)
    }


}
