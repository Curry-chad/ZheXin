package com.fina.summer.auth.core.auth

import com.fina.summer.core.respone.ResEnum
import com.fina.summer.persistent.entity.summer.user.User
import org.apache.shiro.SecurityUtils
import org.apache.shiro.authc.AuthenticationException
import org.apache.shiro.authc.IncorrectCredentialsException
import org.apache.shiro.authc.UsernamePasswordToken
import org.apache.shiro.crypto.hash.SimpleHash
import org.springframework.stereotype.Component
import java.util.*

@Component
class BaseAuth {


    fun login(auth: () -> User): User {
        val userInfo = auth()

        val subject = SecurityUtils.getSubject()
        val token = UsernamePasswordToken(userInfo.id.toString(), userInfo.password)

        subject.login(token)

        //从现在到凌晨23:59 ms
        val nowMill = System.currentTimeMillis()

        val now = Calendar.getInstance()
        now.set(Calendar.HOUR_OF_DAY,23)
        now.set(Calendar.MINUTE,59)
        val afterMill = now.timeInMillis

        subject.session.timeout = afterMill-nowMill
        return userInfo
    }

    fun logout() {
        SecurityUtils.getSubject().logout()
    }


    fun loginWithPW(auth: () -> UsernamePasswordToken): ResEnum {
        val token = auth()
        val subject = SecurityUtils.getSubject()
        try {
            token.password = SimpleHash("MD5", token.password, token.username, 1)
                    .toString().toCharArray()
            subject.login(token)

        } catch (e: IncorrectCredentialsException) {
            return ResEnum.IncorrectCredentials
        } catch (e: AuthenticationException) {
            return ResEnum.UserNotExist
        }
        return ResEnum.Success
    }


}