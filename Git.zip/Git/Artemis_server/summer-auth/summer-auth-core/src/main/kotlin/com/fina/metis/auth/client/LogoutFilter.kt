package com.fina.metis.auth.client

import org.springframework.util.StringUtils

import javax.servlet.FilterConfig
import javax.servlet.ServletException
import javax.servlet.http.HttpServletRequest
import javax.servlet.http.HttpServletResponse
import java.io.IOException

/**
 * 单点退出Filter
 *
 * @author Joe
 */
class LogoutFilter : ClientFilter() {

    // 单点退出成功后跳转页(配置当前应用上下文相对路径，不设置或为空表示项目根目录)
    private var ssoBackUrl: String? = null

    @Throws(ServletException::class)
    override fun init(filterConfig: FilterConfig) {
        if (StringUtils.isEmpty(pattern)) {
            throw IllegalArgumentException("pattern不能为空")
        }
        if (StringUtils.isEmpty(ssoBackUrl)) {
            throw IllegalArgumentException("ssoBackUrl不能为空")
        }
    }

    @Throws(IOException::class)
    override fun isAccessAllowed(request: HttpServletRequest, response: HttpServletResponse): Boolean {
        SessionUtils.invalidate(request)
        val logoutUrl = StringBuilder().append(ssoServerUrl)
                .append("/logout?backUrl=").append(getLocalUrl(request)).append(ssoBackUrl).toString()
        response.sendRedirect(logoutUrl)
        return false
    }

    /**
     * 获取当前上下文路径
     *
     * @param request
     * @return
     */
    private fun getLocalUrl(request: HttpServletRequest): String {
        return StringBuilder().append(request.scheme).append("://").append(request.serverName).append(":")
                .append(if (request.serverPort == 80) "" else request.serverPort).append(request.contextPath)
                .toString()
    }

    fun setSsoBackUrl(ssoBackUrl: String) {
        this.ssoBackUrl = ssoBackUrl
    }
}