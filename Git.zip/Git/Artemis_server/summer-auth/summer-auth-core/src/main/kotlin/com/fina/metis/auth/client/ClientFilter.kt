package com.fina.metis.auth.client

import org.springframework.http.HttpStatus

import javax.servlet.*
import javax.servlet.http.HttpServletRequest
import javax.servlet.http.HttpServletResponse
import java.io.IOException
import java.io.PrintWriter

/**
 * Filter基类
 *
 * @author Joe
 */
abstract class ClientFilter : ParamFilter(), Filter {

    // 匹配路径（? 匹配1个字符，* 匹配0个或多个字符，** 中的0个或多个目录）
    var pattern: String? = null

    @Throws(IOException::class)
    abstract fun isAccessAllowed(request: HttpServletRequest, response: HttpServletResponse): Boolean

    protected fun isAjaxRequest(request: HttpServletRequest): Boolean {
        val requestedWith = request.getHeader("X-Requested-With")
        return if (requestedWith != null) "XMLHttpRequest" == requestedWith else false
    }

    @Throws(IOException::class)
    protected fun responseJson(response: HttpServletResponse, code: Int, message: String) {
        response.contentType = "application/json;charset=UTF-8"
        response.status = HttpStatus.OK.value()
        val writer = response.writer
        writer.write(StringBuilder().append("{\"code\":").append(code).append(",\"message\":\"").append(message)
                .append("\"}").toString())
        writer.flush()
        writer.close()
    }

    @Throws(ServletException::class)
    override fun init(filterConfig: FilterConfig) {
    }

    @Throws(IOException::class)
    override fun doFilter(request: ServletRequest, response: ServletResponse, chain: FilterChain) {
    }

    override fun destroy() {}
}