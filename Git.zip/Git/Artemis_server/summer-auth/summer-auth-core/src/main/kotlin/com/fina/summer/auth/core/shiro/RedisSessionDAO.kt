package com.fina.summer.auth.core.shiro

import com.fina.summer.core.serialize.SerializeUtils
import org.apache.shiro.session.Session
import org.apache.shiro.session.UnknownSessionException
import org.apache.shiro.session.mgt.eis.AbstractSessionDAO
import org.slf4j.LoggerFactory
import org.springframework.stereotype.Component
import org.springframework.util.CollectionUtils
import java.io.Serializable

@Component
class RedisSessionDAO(private val redisManager: RedisManager) : AbstractSessionDAO() {
    /**
     * shiro-redis的session对象前缀
     * @param keyPrefix The prefix
     */
    var keyPrefix = "shiro_redis_session:"

    @Throws(UnknownSessionException::class)
    override fun update(session: Session) {
        logger.debug("============更新session：{}=============", session.id)
        this.saveSession(session)
    }

    /**
     * save session
     *
     * @param session
     * @throws UnknownSessionException
     */
    @Throws(UnknownSessionException::class)
    private fun saveSession(session: Session?) {
        if (session == null || session.id == null) {
            logger.error("session or session id is null")
            return
        }
        //		session.setTimeout(redisManager.getExpire()*1000);
        logger.debug("session生效时间============={}ms==============", session.timeout)
        val key = getByteKey(session.id)
        val value = SerializeUtils.serialize(session)

        //		this.ehcacheManager.saveSession(session);

        val l = session.timeout / 1000
        this.redisManager[key, value!!] = l.toInt()
    }

    override fun delete(session: Session?) {
        if (session == null || session.id == null) {
            logger.error("session or session id is null")
            return
        }
        //		ehcacheManager.removeSession(session);
        this.redisManager.del(this.getByteKey(session.id))
    }

    override fun getActiveSessions(): Collection<Session> {
        /*由于使用redis不需要shrio的session回收处理机制*/
        val keys = redisManager.keys(this.keyPrefix + "*")
        val sessions = mutableSetOf<Session>()
        if (!CollectionUtils.isEmpty(keys)) {
            keys!!.forEach {
                val s = SerializeUtils.deserialize<Session>(redisManager[it])
                if (s != null) {
                    sessions.add(s)
                }
            }
        }
        return sessions
    }


    override fun doCreate(session: Session): Serializable {
        val sessionId = this.generateSessionId(session)
        logger.debug("============创建sessionId：{}=============", sessionId)
        this.assignSessionId(session, sessionId)
        this.saveSession(session)
        return sessionId
    }

    override fun doReadSession(sessionId: Serializable?): Session? {
        if (sessionId == null) {
            logger.error("session id is null")
            return null
        }
        //	    Session s = ehcacheManager.getSession(sessionId);
        //	    if (s==null) {
        logger.debug("============从redis读取session:{}=============", sessionId)
//	        ehcacheManager.saveSession(s);
        //        }
        return SerializeUtils.deserialize(redisManager[getByteKey(sessionId)])
    }

    /**
     * 获得byte[]型的key
     *
     * @param sessionId
     * @return
     */
    private fun getByteKey(sessionId: Serializable): ByteArray {
        val preKey = this.keyPrefix + sessionId
        return preKey.toByteArray()
    }

    companion object {

        private val logger = LoggerFactory.getLogger(RedisSessionDAO::class.java)
    }


}
