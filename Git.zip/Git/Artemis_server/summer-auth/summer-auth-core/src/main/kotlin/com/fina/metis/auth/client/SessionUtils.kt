package com.fina.metis.auth.client

import org.springframework.web.util.WebUtils

import javax.servlet.http.HttpServletRequest

/**
 * 当前已登录用户Session工具
 *
 * @author Joe
 */
object SessionUtils {
    /**
     * 用户信息
     */
    val SESSION_USER = "_sessionUser"

    /**
     * 用户权限
     */
    val SESSION_USER_PERMISSION = "_sessionUserPermission"

    fun getSessionUser(request: HttpServletRequest): SessionUser? {
        return WebUtils.getSessionAttribute(request, SESSION_USER) as SessionUser?
    }

    fun setSessionUser(request: HttpServletRequest, sessionUser: SessionUser?) {
        WebUtils.setSessionAttribute(request, SESSION_USER, sessionUser)
    }

    fun getSessionPermission(request: HttpServletRequest): SessionPermission? {
        return WebUtils.getSessionAttribute(request, SESSION_USER_PERMISSION) as SessionPermission?
    }

    fun setSessionPermission(request: HttpServletRequest, sessionPermission: SessionPermission?) {
        WebUtils.setSessionAttribute(request, SESSION_USER_PERMISSION, sessionPermission)
    }

    fun invalidate(request: HttpServletRequest) {
        setSessionUser(request, null)
        setSessionPermission(request, null)
    }
}