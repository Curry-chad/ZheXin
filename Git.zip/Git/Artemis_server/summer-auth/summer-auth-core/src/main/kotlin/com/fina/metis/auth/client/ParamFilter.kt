package com.fina.metis.auth.client


import com.smart.sso.rpc.AuthenticationRpcService
import org.springframework.beans.factory.annotation.Value

/**
 * 参数注入Filter
 *
 * @author Joe
 */
open class ParamFilter {

    // 单点登录服务端URL
    var ssoServerUrl: String? = null
    // 单点登录服务端提供的RPC服务，由Spring容器注入
    var authenticationRpcService: AuthenticationRpcService? = null

}