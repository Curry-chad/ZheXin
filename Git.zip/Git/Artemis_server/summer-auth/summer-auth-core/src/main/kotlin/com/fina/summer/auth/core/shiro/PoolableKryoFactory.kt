package com.fina.summer.auth.core.shiro

import com.esotericsoftware.kryo.Kryo
import org.apache.commons.pool.PoolableObjectFactory

class PoolableKryoFactory : PoolableObjectFactory<Kryo> {

    @Throws(Exception::class)
    override fun activateObject(obj: Kryo) {

    }

    @Throws(Exception::class)
    override fun destroyObject(obj: Kryo?) {
        var obj = obj
        obj = null
    }

    @Throws(Exception::class)
    override fun makeObject(): Kryo {
        return Kryo()
    }

    @Throws(Exception::class)
    override fun passivateObject(obj: Kryo) {
    }

    override fun validateObject(obj: Kryo): Boolean {
        return true
    }

}
