package com.smart.sso.rpc

import java.io.Serializable

/**
 * RPC回传权限对象(含菜单)
 *
 * @author Joe
 */
class RpcPermission : Serializable {

    /** ID  */
    var id: Int? = null
    /** 父ID  */
    var parentId: Int? = null
    /** 图标  */
    var icon: String? = null
    /** 名称  */
    var name: String? = null
    /** 权限URL  */
    var url: String? = null
    /** 是否菜单  */
    private var isMenu: Boolean = false

    fun getIsMenu(): Boolean? {
        return isMenu
    }

    fun setIsMenu(isMenu: Boolean?) {
        this.isMenu = isMenu!!
    }

    companion object {

        private const val serialVersionUID = 6413358335961655343L
    }
}
