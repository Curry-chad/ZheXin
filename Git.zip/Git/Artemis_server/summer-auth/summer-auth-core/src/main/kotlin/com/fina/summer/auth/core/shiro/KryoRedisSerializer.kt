package com.fina.summer.auth.core.shiro

import com.esotericsoftware.kryo.Kryo
import com.esotericsoftware.kryo.io.Input
import com.esotericsoftware.kryo.io.Output
import org.apache.commons.pool.ObjectPool
import org.apache.commons.pool.impl.SoftReferenceObjectPool
import org.springframework.data.redis.serializer.RedisSerializer

class KryoRedisSerializer<T> : RedisSerializer<T> {
    /**
     * Serialize the given object to binary data.
     *
     * @param t object to serialize. Can be null.
     * @return the equivalent binary data. Can be null.
     */
    override fun serialize(t: T?): ByteArray? {
        val buffer = ByteArray(2048)
        val output = Output(buffer, -1)
        kryo.writeClassAndObject(output, t)
        return output.toBytes()
    }

    /**
     * Deserialize an object from the given binary data.
     *
     * @param bytes object binary representation. Can be null.
     * @return the equivalent object instance. Can be null.
     */
    @Suppress("UNCHECKED_CAST")
    override fun deserialize(bytes: ByteArray?): T? {
        if (bytes == null) {
            return null
        }

        val input = Input(bytes)
        return kryo.readClassAndObject(input) as T
    }

    // 因为kryo是线程不安全的，所以这里用到对象池
    private val kryo: Kryo
        get() {
            if (kryoFactory == null) {
                kryoFactory = SoftReferenceObjectPool(PoolableKryoFactory())
            }
            try {
                return kryoFactory!!.borrowObject()
            } catch (ex: Exception) {
                throw RuntimeException(ex)
            }

        }


    companion object {
        private var kryoFactory: ObjectPool<Kryo>? = null
    }
}
