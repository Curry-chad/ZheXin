package com.fina.summer.auth.core.auth

import com.fina.summer.persistent.artemis.entity.domain.user.ManagerUserDO
import org.apache.shiro.SecurityUtils
import org.apache.shiro.authc.UsernamePasswordToken
import org.springframework.stereotype.Component

@Component
class BaseManagerAuth {

    fun login(auth: () -> ManagerUserDO): ManagerUserDO {
        val user = auth()
        val userId = user.id!!

        val subject = SecurityUtils.getSubject()
        val token = UsernamePasswordToken(userId, "")

        subject.login(token)
        return user
    }

    fun logout() {
        SecurityUtils.getSubject().logout()
    }


    fun loginWithPW(auth: () -> UsernamePasswordToken) {
        val token = auth()
        val subject = SecurityUtils.getSubject()
        subject.login(token)
    }


}