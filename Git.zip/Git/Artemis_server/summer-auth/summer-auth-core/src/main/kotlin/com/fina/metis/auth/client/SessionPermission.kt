package com.fina.metis.auth.client


import com.smart.sso.rpc.RpcPermission

import java.io.Serializable

/**
 * 已登录用户权限信息
 *
 * @author Joe
 */
class SessionPermission : Serializable {

    // 用户菜单
    var menuList: List<RpcPermission>? = null
    // 用户权限
    var permissionSet: Set<String>? = null
    // 用户没有的权限
    var noPermissions: String? = null

    companion object {

        private const val serialVersionUID = 7744061178030182892L
    }
}
