package com.fina.summer.auth.core.shiro

import org.apache.shiro.web.mgt.DefaultWebSecurityManager
import org.springframework.context.annotation.Bean
import org.springframework.context.annotation.Configuration
import org.springframework.data.redis.serializer.StringRedisSerializer
import com.fasterxml.jackson.databind.ObjectMapper
import com.fasterxml.jackson.annotation.JsonAutoDetect
import com.fasterxml.jackson.annotation.PropertyAccessor
import org.apache.shiro.session.Session
import org.springframework.data.redis.serializer.Jackson2JsonRedisSerializer
import org.springframework.data.redis.core.RedisTemplate
import org.springframework.data.redis.connection.RedisConnectionFactory
import java.io.Serializable
import org.apache.shiro.spring.security.interceptor.AuthorizationAttributeSourceAdvisor


@Configuration
open class ShiroConfig {

    @Bean
    open fun redisTemplate(redisConnectionFactory: RedisConnectionFactory): RedisTemplate<Serializable, Session> {
        val redisTemplate = RedisTemplate<Serializable, Session>()
        redisTemplate.setConnectionFactory(redisConnectionFactory)

        // 使用Jackson2JsonRedisSerialize 替换默认序列化
        val jackson2JsonRedisSerializer = Jackson2JsonRedisSerializer(Any::class.java)

        val objectMapper = ObjectMapper()
        objectMapper.setVisibility(PropertyAccessor.ALL, JsonAutoDetect.Visibility.ANY)
        objectMapper.enableDefaultTyping(ObjectMapper.DefaultTyping.NON_FINAL)

        jackson2JsonRedisSerializer.setObjectMapper(objectMapper)

        // 设置value的序列化规则和 key的序列化规则
        redisTemplate.keySerializer = StringRedisSerializer()
        redisTemplate.valueSerializer = jackson2JsonRedisSerializer
        redisTemplate.afterPropertiesSet()
        return redisTemplate
    }



    /**
     * @author: tianyong
     * @time: 2018/8/14 17:09
     * @description:开启代码权限注解支持
     */
    @Bean
    open fun authorizationAttributeSourceAdvisor(securityManager: DefaultWebSecurityManager): AuthorizationAttributeSourceAdvisor {
        val authorizationAttributeSourceAdvisor = AuthorizationAttributeSourceAdvisor()
        authorizationAttributeSourceAdvisor.securityManager = securityManager
        return authorizationAttributeSourceAdvisor
    }

//    /**
//     * @author: tianyong
//     * @time: 2018/8/17 15:27
//     * @description:解决权限注解不生效问题
//     */
//    @Bean
//    open fun getDefaultAdvisorAutoProxyCreator(): DefaultAdvisorAutoProxyCreator {
//        return DefaultAdvisorAutoProxyCreator()
//    }


//    @Bean
//    open fun getMethodInvokingFactoryBean(securityManager:DefaultWebSecurityManager): MethodInvokingFactoryBean {
//        val methodInvokeFactoryBean = MethodInvokingFactoryBean()
//        methodInvokeFactoryBean.setArguments(securityManager)
//        methodInvokeFactoryBean.setStaticMethod("org.apache.shiro.SecurityUtils.setSecurityManager")
//        return methodInvokeFactoryBean
//    }


}