package com.fina.summer.auth.core.shiro

object UserConstant {
    const val THIRD_LOGIN_PSWD: String = "THIRD_LOGIN"

}
