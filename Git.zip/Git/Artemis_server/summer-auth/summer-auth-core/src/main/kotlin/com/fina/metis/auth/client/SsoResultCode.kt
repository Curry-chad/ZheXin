package com.fina.metis.auth.client

/**
 * 单点登录权限返回码
 *
 * @author Joe
 */
object SsoResultCode {

    // SSO 用户授权出错
    val SSO_TOKEN_ERROR = 1001 // TOKEN未授权或已过期
    val SSO_PERMISSION_ERROR = 1002 // 没有访问权限
}
