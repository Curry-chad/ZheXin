package com.fina.metis.auth.client

import java.io.Serializable

/**
 * 已登录用户信息
 *
 * @author Joe
 */
class SessionUser : Serializable {

    // 登录用户访问Token
    var token: String? = null
    // 登录名
    var account: String? = null

    constructor() : super() {}

    constructor(token: String, account: String) : super() {
        this.token = token
        this.account = account
    }

    companion object {

        private const val serialVersionUID = 1764365572138947234L
    }
}
