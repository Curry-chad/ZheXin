package com.fina.summer.auth.core.shiro

import org.apache.shiro.cache.Cache
import org.apache.shiro.cache.CacheException
import org.apache.shiro.cache.CacheManager
import org.slf4j.LoggerFactory
import org.springframework.stereotype.Component
import java.util.concurrent.ConcurrentHashMap

@Suppress("UNCHECKED_CAST")
@Component
class RedisCacheManager(private var redisManager: RedisManager) : CacheManager {

    // fast lookup by name map
    private val caches = ConcurrentHashMap<String, Cache<*, *>>()


    /**
     * The Redis key prefix for caches
     */
    /**
     * Returns the Redis session keys
     * prefix.
     * @return The prefix
     */
    /**
     * Sets the Redis sessions key
     * prefix.
     * @param keyPrefix The prefix
     */
    var keyPrefix = "shiro_redis_cache:"

    @Throws(CacheException::class)
    override fun <K, V> getCache(name: String): Cache<K, V> {
        logger.debug("获取名称为: $name 的RedisCache实例")

        var c: Cache<*, *>? = caches[name]

        if (c == null) {

            // initialize the Redis manager instance
            redisManager.init()

            // create a new cache instance
            c = RedisCache<K, V>(redisManager, keyPrefix)

            // add it to the cache collection
            caches[name] = c
        }
        return c as Cache<K, V>
    }

    companion object {

        private val logger = LoggerFactory
                .getLogger(RedisCacheManager::class.java)
    }

}
