package com.fina.metis.auth.client

import com.smart.sso.rpc.AuthenticationRpcService
import com.smart.sso.rpc.RpcPermission
import org.slf4j.Logger
import org.slf4j.LoggerFactory
import org.springframework.util.StringUtils

import java.util.ArrayList
import java.util.HashSet

/**
 * 当前应用所有权限
 *
 * @author Joe
 */
object ApplicationPermission {

    private val logger = LoggerFactory.getLogger(ApplicationPermission::class.java)

    // 应用所有权限URL
    private var applicationPermissionSet: MutableSet<String>? = null
    // 应用所有菜单
    private var applicationMenuList: MutableList<RpcPermission>? = null
    // 并发监控
    private val monitor = Any()

    /**
     * 1.应用初始化，获取应用所有的菜单及权限
     * 2.权限有变动修改，JMS通知重新加载
     */
    fun initApplicationPermissions(authenticationRpcService: AuthenticationRpcService,
                                   ssoAppCode: String) {
        var dbList: List<RpcPermission>?
        try {
            dbList = authenticationRpcService.findPermissionList(null, ssoAppCode)
        } catch (e: Exception) {
            dbList = ArrayList(0)
            logger.error("无法连接到单点登录服务端,请检查配置sso.server.url", e)
        }

        synchronized(monitor) {
            applicationMenuList = ArrayList()
            applicationPermissionSet = HashSet()
            for (menu in dbList!!) {
                if (menu.getIsMenu()!!) {
                    applicationMenuList!!.add(menu)
                }
                if (!StringUtils.isEmpty(menu.url)) {
                    applicationPermissionSet!!.add(menu.url!!)
                }
            }
        }
    }

    fun getApplicationPermissionSet(): Set<String>? {
        synchronized(monitor) {
            return applicationPermissionSet
        }
    }

    fun getApplicationMenuList(): List<RpcPermission>? {
        synchronized(monitor) {
            return applicationMenuList
        }
    }
}
